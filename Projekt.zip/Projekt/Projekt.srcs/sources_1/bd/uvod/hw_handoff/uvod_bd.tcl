
################################################################
# This is a generated script based on design: uvod
#
# Though there are limitations about the generated script,
# the main purpose of this utility is to make learning
# IP Integrator Tcl commands easier.
################################################################

namespace eval _tcl {
proc get_script_folder {} {
   set script_path [file normalize [info script]]
   set script_folder [file dirname $script_path]
   return $script_folder
}
}
variable script_folder
set script_folder [_tcl::get_script_folder]

################################################################
# Check if script is running in correct Vivado version.
################################################################
set scripts_vivado_version 2019.1
set current_vivado_version [version -short]

if { [string first $scripts_vivado_version $current_vivado_version] == -1 } {
   puts ""
   catch {common::send_msg_id "BD_TCL-109" "ERROR" "This script was generated using Vivado <$scripts_vivado_version> and is being run in <$current_vivado_version> of Vivado. Please run the script in Vivado <$scripts_vivado_version> then open the design in Vivado <$current_vivado_version>. Upgrade the design by running \"Tools => Report => Report IP Status...\", then run write_bd_tcl to create an updated script."}

   return 1
}

################################################################
# START
################################################################

# To test this script, run the following commands from Vivado Tcl console:
# source uvod_script.tcl


# The design that will be created by this Tcl script contains the following 
# module references:
# BUTTON_MATRIX, VGA_DRAW, debounce, debounce, debounce, debounce, svga, top

# Please add the sources of those modules before sourcing this Tcl script.

# If there is no project opened, this script will create a
# project, but make sure you do not have an existing project
# <./myproj/project_1.xpr> in the current working folder.

set list_projs [get_projects -quiet]
if { $list_projs eq "" } {
   create_project project_1 myproj -part xc7s25csga324-1
}


# CHANGE DESIGN NAME HERE
variable design_name
set design_name uvod

# If you do not already have an existing IP Integrator design open,
# you can create a design using the following command:
#    create_bd_design $design_name

# Creating design if needed
set errMsg ""
set nRet 0

set cur_design [current_bd_design -quiet]
set list_cells [get_bd_cells -quiet]

if { ${design_name} eq "" } {
   # USE CASES:
   #    1) Design_name not set

   set errMsg "Please set the variable <design_name> to a non-empty value."
   set nRet 1

} elseif { ${cur_design} ne "" && ${list_cells} eq "" } {
   # USE CASES:
   #    2): Current design opened AND is empty AND names same.
   #    3): Current design opened AND is empty AND names diff; design_name NOT in project.
   #    4): Current design opened AND is empty AND names diff; design_name exists in project.

   if { $cur_design ne $design_name } {
      common::send_msg_id "BD_TCL-001" "INFO" "Changing value of <design_name> from <$design_name> to <$cur_design> since current design is empty."
      set design_name [get_property NAME $cur_design]
   }
   common::send_msg_id "BD_TCL-002" "INFO" "Constructing design in IPI design <$cur_design>..."

} elseif { ${cur_design} ne "" && $list_cells ne "" && $cur_design eq $design_name } {
   # USE CASES:
   #    5) Current design opened AND has components AND same names.

   set errMsg "Design <$design_name> already exists in your project, please set the variable <design_name> to another value."
   set nRet 1
} elseif { [get_files -quiet ${design_name}.bd] ne "" } {
   # USE CASES: 
   #    6) Current opened design, has components, but diff names, design_name exists in project.
   #    7) No opened design, design_name exists in project.

   set errMsg "Design <$design_name> already exists in your project, please set the variable <design_name> to another value."
   set nRet 2

} else {
   # USE CASES:
   #    8) No opened design, design_name not in project.
   #    9) Current opened design, has components, but diff names, design_name not in project.

   common::send_msg_id "BD_TCL-003" "INFO" "Currently there is no design <$design_name> in project, so creating one..."

   create_bd_design $design_name

   common::send_msg_id "BD_TCL-004" "INFO" "Making design <$design_name> as current_bd_design."
   current_bd_design $design_name

}

common::send_msg_id "BD_TCL-005" "INFO" "Currently the variable <design_name> is equal to \"$design_name\"."

if { $nRet != 0 } {
   catch {common::send_msg_id "BD_TCL-114" "ERROR" $errMsg}
   return $nRet
}

##################################################################
# DESIGN PROCs
##################################################################



# Procedure to create entire design; Provide argument to make
# procedure reusable. If parentCell is "", will use root.
proc create_root_design { parentCell } {

  variable script_folder
  variable design_name

  if { $parentCell eq "" } {
     set parentCell [get_bd_cells /]
  }

  # Get object for parentCell
  set parentObj [get_bd_cells $parentCell]
  if { $parentObj == "" } {
     catch {common::send_msg_id "BD_TCL-100" "ERROR" "Unable to find parent cell <$parentCell>!"}
     return
  }

  # Make sure parentObj is hier blk
  set parentType [get_property TYPE $parentObj]
  if { $parentType ne "hier" } {
     catch {common::send_msg_id "BD_TCL-101" "ERROR" "Parent <$parentObj> has TYPE = <$parentType>. Expected to be <hier>."}
     return
  }

  # Save current instance; Restore later
  set oldCurInst [current_bd_instance .]

  # Set parent object as current
  current_bd_instance $parentObj


  # Create interface ports

  # Create ports
  set BLUE [ create_bd_port -dir O -from 3 -to 0 BLUE ]
  set BTN0 [ create_bd_port -dir I BTN0 ]
  set BTN1 [ create_bd_port -dir I BTN1 ]
  set BTN2 [ create_bd_port -dir I BTN2 ]
  set BTN3 [ create_bd_port -dir I BTN3 ]
  set CLK_12MHz [ create_bd_port -dir I -type clk CLK_12MHz ]
  set_property -dict [ list \
   CONFIG.FREQ_HZ {12000000} \
 ] $CLK_12MHz
  set GREEN [ create_bd_port -dir O -from 3 -to 0 GREEN ]
  set HSYNC [ create_bd_port -dir O HSYNC ]
  set LED2 [ create_bd_port -dir O LED2 ]
  set LED3 [ create_bd_port -dir O LED3 ]
  set LED4 [ create_bd_port -dir O LED4 ]
  set LED5 [ create_bd_port -dir O LED5 ]
  set MATRIX_COL [ create_bd_port -dir O -from 3 -to 0 MATRIX_COL ]
  set MATRIX_ROW [ create_bd_port -dir I -from 3 -to 0 MATRIX_ROW ]
  set RED [ create_bd_port -dir O -from 3 -to 0 RED ]
  set TXF [ create_bd_port -dir O TXF ]
  set VSYNC [ create_bd_port -dir O VSYNC ]

  # Create instance: BUTTON_MATRIX_0, and set properties
  set block_name BUTTON_MATRIX
  set block_cell_name BUTTON_MATRIX_0
  if { [catch {set BUTTON_MATRIX_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_msg_id "BD_TCL-105" "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $BUTTON_MATRIX_0 eq "" } {
     catch {common::send_msg_id "BD_TCL-106" "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: VGA_DRAW_0, and set properties
  set block_name VGA_DRAW
  set block_cell_name VGA_DRAW_0
  if { [catch {set VGA_DRAW_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_msg_id "BD_TCL-105" "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $VGA_DRAW_0 eq "" } {
     catch {common::send_msg_id "BD_TCL-106" "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: clk_wiz_0, and set properties
  set clk_wiz_0 [ create_bd_cell -type ip -vlnv xilinx.com:ip:clk_wiz:6.0 clk_wiz_0 ]
  set_property -dict [ list \
   CONFIG.CLKOUT1_DRIVES {BUFG} \
   CONFIG.CLKOUT1_JITTER {522.440} \
   CONFIG.CLKOUT1_PHASE_ERROR {613.025} \
   CONFIG.CLKOUT1_REQUESTED_OUT_FREQ {200.000} \
   CONFIG.CLKOUT1_USED {true} \
   CONFIG.CLKOUT2_DRIVES {BUFG} \
   CONFIG.CLKOUT2_JITTER {686.725} \
   CONFIG.CLKOUT2_PHASE_ERROR {613.025} \
   CONFIG.CLKOUT2_REQUESTED_OUT_FREQ {40.000} \
   CONFIG.CLKOUT2_USED {true} \
   CONFIG.CLKOUT3_DRIVES {BUFG} \
   CONFIG.CLKOUT3_JITTER {999.010} \
   CONFIG.CLKOUT3_PHASE_ERROR {613.025} \
   CONFIG.CLKOUT3_REQUESTED_OUT_FREQ {5} \
   CONFIG.CLKOUT3_USED {true} \
   CONFIG.CLKOUT4_DRIVES {BUFG} \
   CONFIG.CLKOUT5_DRIVES {BUFG} \
   CONFIG.CLKOUT6_DRIVES {BUFG} \
   CONFIG.CLKOUT7_DRIVES {BUFG} \
   CONFIG.CLK_OUT1_PORT {CLK_200MHZ} \
   CONFIG.CLK_OUT2_PORT {CLK_40MHZ} \
   CONFIG.CLK_OUT3_PORT {CLK_5MHZ} \
   CONFIG.FEEDBACK_SOURCE {FDBK_AUTO} \
   CONFIG.MMCM_BANDWIDTH {OPTIMIZED} \
   CONFIG.MMCM_CLKFBOUT_MULT_F {50.000} \
   CONFIG.MMCM_CLKOUT0_DIVIDE_F {3.000} \
   CONFIG.MMCM_CLKOUT1_DIVIDE {15} \
   CONFIG.MMCM_CLKOUT2_DIVIDE {120} \
   CONFIG.MMCM_COMPENSATION {ZHOLD} \
   CONFIG.NUM_OUT_CLKS {3} \
   CONFIG.PRIMITIVE {MMCM} \
   CONFIG.USE_LOCKED {false} \
   CONFIG.USE_RESET {false} \
 ] $clk_wiz_0

  # Create instance: debounce_0, and set properties
  set block_name debounce
  set block_cell_name debounce_0
  if { [catch {set debounce_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_msg_id "BD_TCL-105" "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $debounce_0 eq "" } {
     catch {common::send_msg_id "BD_TCL-106" "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: debounce_1, and set properties
  set block_name debounce
  set block_cell_name debounce_1
  if { [catch {set debounce_1 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_msg_id "BD_TCL-105" "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $debounce_1 eq "" } {
     catch {common::send_msg_id "BD_TCL-106" "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: debounce_2, and set properties
  set block_name debounce
  set block_cell_name debounce_2
  if { [catch {set debounce_2 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_msg_id "BD_TCL-105" "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $debounce_2 eq "" } {
     catch {common::send_msg_id "BD_TCL-106" "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: debounce_3, and set properties
  set block_name debounce
  set block_cell_name debounce_3
  if { [catch {set debounce_3 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_msg_id "BD_TCL-105" "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $debounce_3 eq "" } {
     catch {common::send_msg_id "BD_TCL-106" "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: svga_0, and set properties
  set block_name svga
  set block_cell_name svga_0
  if { [catch {set svga_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_msg_id "BD_TCL-105" "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $svga_0 eq "" } {
     catch {common::send_msg_id "BD_TCL-106" "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: top_0, and set properties
  set block_name top
  set block_cell_name top_0
  if { [catch {set top_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_msg_id "BD_TCL-105" "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $top_0 eq "" } {
     catch {common::send_msg_id "BD_TCL-106" "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create port connections
  connect_bd_net -net BUTTON_MATRIX_0_BUTTONS_OUT [get_bd_pins BUTTON_MATRIX_0/BUTTONS_OUT] [get_bd_pins VGA_DRAW_0/BUTTONS_IN]
  connect_bd_net -net BUTTON_MATRIX_0_COLUMNS_OUT [get_bd_ports MATRIX_COL] [get_bd_pins BUTTON_MATRIX_0/COLUMNS_OUT]
  connect_bd_net -net BUTTON_MATRIX_0_TOP_BTN_0 [get_bd_pins BUTTON_MATRIX_0/TOP_BTN_0] [get_bd_pins top_0/iw_btn0]
  connect_bd_net -net BUTTON_MATRIX_0_TOP_BTN_1 [get_bd_pins BUTTON_MATRIX_0/TOP_BTN_1] [get_bd_pins top_0/iw_btn1]
  connect_bd_net -net BUTTON_MATRIX_0_TOP_BTN_2 [get_bd_pins BUTTON_MATRIX_0/TOP_BTN_2] [get_bd_pins top_0/iw_btn2]
  connect_bd_net -net BUTTON_MATRIX_0_TOP_BTN_3 [get_bd_pins BUTTON_MATRIX_0/TOP_BTN_3] [get_bd_pins top_0/iw_btn3]
  connect_bd_net -net BUTTON_MATRIX_0_VALID_PRESS_OUT [get_bd_pins BUTTON_MATRIX_0/VALID_PRESS_OUT] [get_bd_pins VGA_DRAW_0/BTN_PRESS_VALID_IN]
  connect_bd_net -net BUTTON_MATRIX_0_VALID_RELEASE_OUT [get_bd_pins BUTTON_MATRIX_0/VALID_RELEASE_OUT] [get_bd_pins VGA_DRAW_0/BTN_RELEASE_VALID_IN]
  connect_bd_net -net BUTTON_MATRIX_0_t1 [get_bd_ports LED2]
  connect_bd_net -net BUTTON_MATRIX_0_t2 [get_bd_ports LED3]
  connect_bd_net -net BUTTON_MATRIX_0_t3 [get_bd_ports LED4]
  connect_bd_net -net BUTTON_MATRIX_0_t4 [get_bd_ports LED5]
  connect_bd_net -net CLK_12MHz_1 [get_bd_ports CLK_12MHz] [get_bd_pins clk_wiz_0/clk_in1]
  connect_bd_net -net MATRIX_ROW_1 [get_bd_ports MATRIX_ROW] [get_bd_pins BUTTON_MATRIX_0/ROWS_IN]
  connect_bd_net -net clk_wiz_0_CLK_40MHZ [get_bd_pins BUTTON_MATRIX_0/CLK_40M] [get_bd_pins VGA_DRAW_0/CLK] [get_bd_pins clk_wiz_0/CLK_40MHZ] [get_bd_pins svga_0/iw_pix_clk]
  connect_bd_net -net clk_wiz_0_CLK_5MHZ [get_bd_pins BUTTON_MATRIX_0/CLK_5M] [get_bd_pins clk_wiz_0/CLK_5MHZ]
  connect_bd_net -net clk_wiz_0_clk_out1 [get_bd_pins clk_wiz_0/CLK_200MHZ] [get_bd_pins debounce_0/iw_clk] [get_bd_pins debounce_1/iw_clk] [get_bd_pins debounce_2/iw_clk] [get_bd_pins debounce_3/iw_clk] [get_bd_pins top_0/iw_clk]
  connect_bd_net -net iw_button_0_1 [get_bd_ports BTN0] [get_bd_pins debounce_0/iw_button]
  connect_bd_net -net iw_button_1_1 [get_bd_ports BTN1] [get_bd_pins debounce_1/iw_button]
  connect_bd_net -net iw_button_2_1 [get_bd_ports BTN2] [get_bd_pins debounce_2/iw_button]
  connect_bd_net -net iw_button_3_1 [get_bd_ports BTN3] [get_bd_pins debounce_3/iw_button]
  connect_bd_net -net svga_0_ow4_blue [get_bd_ports BLUE] [get_bd_pins svga_0/ow4_blue]
  connect_bd_net -net svga_0_ow4_green [get_bd_ports GREEN] [get_bd_pins svga_0/ow4_green]
  connect_bd_net -net svga_0_ow4_red [get_bd_ports RED] [get_bd_pins svga_0/ow4_red]
  connect_bd_net -net svga_0_ow_cursor_x [get_bd_pins VGA_DRAW_0/X_IN]
  connect_bd_net -net svga_0_ow_cursor_y [get_bd_pins VGA_DRAW_0/Y_IN]
  connect_bd_net -net svga_0_ow_hsync [get_bd_ports HSYNC] [get_bd_pins svga_0/ow_hsync]
  connect_bd_net -net svga_0_ow_vsync [get_bd_ports VSYNC] [get_bd_pins svga_0/ow_vsync]
  connect_bd_net -net top_0_ow11_block_left_pos [get_bd_pins svga_0/iw11_block_left_pos] [get_bd_pins top_0/ow11_block_left_pos]
  connect_bd_net -net top_0_ow11_block_right_pos [get_bd_pins svga_0/iw11_block_right_pos] [get_bd_pins top_0/ow11_block_right_pos]
  connect_bd_net -net top_0_ow11_x_pos [get_bd_pins svga_0/iw11_x_pos] [get_bd_pins top_0/ow11_x_pos]
  connect_bd_net -net top_0_ow11_y_pos [get_bd_pins svga_0/iw11_y_pos] [get_bd_pins top_0/ow11_y_pos]
  connect_bd_net -net top_0_ow4_blue [get_bd_pins svga_0/iw4_blue] [get_bd_pins top_0/ow4_blue]
  connect_bd_net -net top_0_ow4_green [get_bd_pins svga_0/iw4_green] [get_bd_pins top_0/ow4_green]
  connect_bd_net -net top_0_ow4_red [get_bd_pins svga_0/iw4_red] [get_bd_pins top_0/ow4_red]
  connect_bd_net -net top_0_ow4_result_left [get_bd_pins svga_0/iw4_result_left] [get_bd_pins top_0/ow4_result_left]
  connect_bd_net -net top_0_ow4_result_right [get_bd_pins svga_0/iw4_result_right] [get_bd_pins top_0/ow4_result_right]

  # Create address segments


  # Restore current instance
  current_bd_instance $oldCurInst

  validate_bd_design
  save_bd_design
}
# End of create_root_design()


##################################################################
# MAIN FLOW
##################################################################

create_root_design ""


