//Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2019.1 (win64) Build 2552052 Fri May 24 14:49:42 MDT 2019
//Date        : Wed May  6 23:14:53 2026
//Host        : DESKTOP-TPP71AQ running 64-bit major release  (build 9200)
//Command     : generate_target uvod_wrapper.bd
//Design      : uvod_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module uvod_wrapper
   (BLUE,
    BTN0,
    BTN1,
    BTN2,
    BTN3,
    CLK_12MHz,
    GREEN,
    HSYNC,
    LED2,
    LED3,
    LED4,
    LED5,
    MATRIX_COL,
    MATRIX_ROW,
    RED,
    TXF,
    VSYNC);
  output [3:0]BLUE;
  input BTN0;
  input BTN1;
  input BTN2;
  input BTN3;
  input CLK_12MHz;
  output [3:0]GREEN;
  output HSYNC;
  output LED2;
  output LED3;
  output LED4;
  output LED5;
  output [3:0]MATRIX_COL;
  input [3:0]MATRIX_ROW;
  output [3:0]RED;
  output TXF;
  output VSYNC;

  wire [3:0]BLUE;
  wire BTN0;
  wire BTN1;
  wire BTN2;
  wire BTN3;
  wire CLK_12MHz;
  wire [3:0]GREEN;
  wire HSYNC;
  wire LED2;
  wire LED3;
  wire LED4;
  wire LED5;
  wire [3:0]MATRIX_COL;
  wire [3:0]MATRIX_ROW;
  wire [3:0]RED;
  wire TXF;
  wire VSYNC;

  uvod uvod_i
       (.BLUE(BLUE),
        .BTN0(BTN0),
        .BTN1(BTN1),
        .BTN2(BTN2),
        .BTN3(BTN3),
        .CLK_12MHz(CLK_12MHz),
        .GREEN(GREEN),
        .HSYNC(HSYNC),
        .LED2(LED2),
        .LED3(LED3),
        .LED4(LED4),
        .LED5(LED5),
        .MATRIX_COL(MATRIX_COL),
        .MATRIX_ROW(MATRIX_ROW),
        .RED(RED),
        .TXF(TXF),
        .VSYNC(VSYNC));
endmodule
