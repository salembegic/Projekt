//Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2019.1 (win64) Build 2552052 Fri May 24 14:49:42 MDT 2019
//Date        : Wed May  6 23:14:53 2026
//Host        : DESKTOP-TPP71AQ running 64-bit major release  (build 9200)
//Command     : generate_target uvod.bd
//Design      : uvod
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "uvod,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=uvod,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=9,numReposBlks=9,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=8,numPkgbdBlks=0,bdsource=USER,synth_mode=OOC_per_IP}" *) (* HW_HANDOFF = "uvod.hwdef" *) 
module uvod
   (BLUE,
    BTN0,
    BTN1,
    BTN2,
    BTN3,
    CLK_12MHz,
    GREEN,
    HSYNC,
    LED2,
    LED3,
    LED4,
    LED5,
    MATRIX_COL,
    MATRIX_ROW,
    RED,
    TXF,
    VSYNC);
  output [3:0]BLUE;
  input BTN0;
  input BTN1;
  input BTN2;
  input BTN3;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.CLK_12MHZ CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.CLK_12MHZ, CLK_DOMAIN uvod_CLK_12MHz, FREQ_HZ 12000000, INSERT_VIP 0, PHASE 0.000" *) input CLK_12MHz;
  output [3:0]GREEN;
  output HSYNC;
  output LED2;
  output LED3;
  output LED4;
  output LED5;
  output [3:0]MATRIX_COL;
  input [3:0]MATRIX_ROW;
  output [3:0]RED;
  output TXF;
  output VSYNC;

  wire [15:0]BUTTON_MATRIX_0_BUTTONS_OUT;
  wire [3:0]BUTTON_MATRIX_0_COLUMNS_OUT;
  wire BUTTON_MATRIX_0_TOP_BTN_0;
  wire BUTTON_MATRIX_0_TOP_BTN_1;
  wire BUTTON_MATRIX_0_TOP_BTN_2;
  wire BUTTON_MATRIX_0_TOP_BTN_3;
  wire BUTTON_MATRIX_0_VALID_PRESS_OUT;
  wire BUTTON_MATRIX_0_VALID_RELEASE_OUT;
  wire CLK_12MHz_1;
  wire [3:0]MATRIX_ROW_1;
  wire clk_wiz_0_CLK_40MHZ;
  wire clk_wiz_0_CLK_5MHZ;
  wire clk_wiz_0_clk_out1;
  wire iw_button_0_1;
  wire iw_button_1_1;
  wire iw_button_2_1;
  wire iw_button_3_1;
  wire [3:0]svga_0_ow4_blue;
  wire [3:0]svga_0_ow4_green;
  wire [3:0]svga_0_ow4_red;
  wire svga_0_ow_hsync;
  wire svga_0_ow_vsync;
  wire [10:0]top_0_ow11_block_left_pos;
  wire [10:0]top_0_ow11_block_right_pos;
  wire [10:0]top_0_ow11_x_pos;
  wire [10:0]top_0_ow11_y_pos;
  wire [3:0]top_0_ow4_blue;
  wire [3:0]top_0_ow4_green;
  wire [3:0]top_0_ow4_red;
  wire [3:0]top_0_ow4_result_left;
  wire [3:0]top_0_ow4_result_right;

  assign BLUE[3:0] = svga_0_ow4_blue;
  assign CLK_12MHz_1 = CLK_12MHz;
  assign GREEN[3:0] = svga_0_ow4_green;
  assign HSYNC = svga_0_ow_hsync;
  assign MATRIX_COL[3:0] = BUTTON_MATRIX_0_COLUMNS_OUT;
  assign MATRIX_ROW_1 = MATRIX_ROW[3:0];
  assign RED[3:0] = svga_0_ow4_red;
  assign VSYNC = svga_0_ow_vsync;
  assign iw_button_0_1 = BTN0;
  assign iw_button_1_1 = BTN1;
  assign iw_button_2_1 = BTN2;
  assign iw_button_3_1 = BTN3;
  uvod_BUTTON_MATRIX_0_0 BUTTON_MATRIX_0
       (.BUTTONS_OUT(BUTTON_MATRIX_0_BUTTONS_OUT),
        .CLK_40M(clk_wiz_0_CLK_40MHZ),
        .CLK_5M(clk_wiz_0_CLK_5MHZ),
        .COLUMNS_OUT(BUTTON_MATRIX_0_COLUMNS_OUT),
        .ROWS_IN(MATRIX_ROW_1),
        .TOP_BTN_0(BUTTON_MATRIX_0_TOP_BTN_0),
        .TOP_BTN_1(BUTTON_MATRIX_0_TOP_BTN_1),
        .TOP_BTN_2(BUTTON_MATRIX_0_TOP_BTN_2),
        .TOP_BTN_3(BUTTON_MATRIX_0_TOP_BTN_3),
        .VALID_PRESS_OUT(BUTTON_MATRIX_0_VALID_PRESS_OUT),
        .VALID_RELEASE_OUT(BUTTON_MATRIX_0_VALID_RELEASE_OUT));
  uvod_VGA_DRAW_0_0 VGA_DRAW_0
       (.BTN_PRESS_VALID_IN(BUTTON_MATRIX_0_VALID_PRESS_OUT),
        .BTN_RELEASE_VALID_IN(BUTTON_MATRIX_0_VALID_RELEASE_OUT),
        .BUTTONS_IN(BUTTON_MATRIX_0_BUTTONS_OUT),
        .CLK(clk_wiz_0_CLK_40MHZ));
  uvod_clk_wiz_0_0 clk_wiz_0
       (.CLK_200MHZ(clk_wiz_0_clk_out1),
        .CLK_40MHZ(clk_wiz_0_CLK_40MHZ),
        .CLK_5MHZ(clk_wiz_0_CLK_5MHZ),
        .clk_in1(CLK_12MHz_1));
  uvod_debounce_0_0 debounce_0
       (.iw_button(iw_button_0_1),
        .iw_clk(clk_wiz_0_clk_out1));
  uvod_debounce_0_1 debounce_1
       (.iw_button(iw_button_1_1),
        .iw_clk(clk_wiz_0_clk_out1));
  uvod_debounce_1_0 debounce_2
       (.iw_button(iw_button_2_1),
        .iw_clk(clk_wiz_0_clk_out1));
  uvod_debounce_2_0 debounce_3
       (.iw_button(iw_button_3_1),
        .iw_clk(clk_wiz_0_clk_out1));
  uvod_svga_0_0 svga_0
       (.iw11_block_left_pos(top_0_ow11_block_left_pos),
        .iw11_block_right_pos(top_0_ow11_block_right_pos),
        .iw11_x_pos(top_0_ow11_x_pos),
        .iw11_y_pos(top_0_ow11_y_pos),
        .iw4_blue(top_0_ow4_blue),
        .iw4_green(top_0_ow4_green),
        .iw4_red(top_0_ow4_red),
        .iw4_result_left(top_0_ow4_result_left),
        .iw4_result_right(top_0_ow4_result_right),
        .iw_pix_clk(clk_wiz_0_CLK_40MHZ),
        .ow4_blue(svga_0_ow4_blue),
        .ow4_green(svga_0_ow4_green),
        .ow4_red(svga_0_ow4_red),
        .ow_hsync(svga_0_ow_hsync),
        .ow_vsync(svga_0_ow_vsync));
  uvod_top_0_0 top_0
       (.iw_btn0(BUTTON_MATRIX_0_TOP_BTN_0),
        .iw_btn1(BUTTON_MATRIX_0_TOP_BTN_1),
        .iw_btn2(BUTTON_MATRIX_0_TOP_BTN_2),
        .iw_btn3(BUTTON_MATRIX_0_TOP_BTN_3),
        .iw_clk(clk_wiz_0_clk_out1),
        .ow11_block_left_pos(top_0_ow11_block_left_pos),
        .ow11_block_right_pos(top_0_ow11_block_right_pos),
        .ow11_x_pos(top_0_ow11_x_pos),
        .ow11_y_pos(top_0_ow11_y_pos),
        .ow4_blue(top_0_ow4_blue),
        .ow4_green(top_0_ow4_green),
        .ow4_red(top_0_ow4_red),
        .ow4_result_left(top_0_ow4_result_left),
        .ow4_result_right(top_0_ow4_result_right));
endmodule
