-- Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2019.1 (win64) Build 2552052 Fri May 24 14:49:42 MDT 2019
-- Date        : Mon Apr 27 20:07:12 2026
-- Host        : DESKTOP-TPP71AQ running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               C:/workspace/PEV/uvod/uvod.srcs/sources_1/bd/uvod/ip/uvod_clk_wiz_0_0/uvod_clk_wiz_0_0_stub.vhdl
-- Design      : uvod_clk_wiz_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7s25csga324-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity uvod_clk_wiz_0_0 is
  Port ( 
    CLK_200MHZ : out STD_LOGIC;
    CLK_40MHZ : out STD_LOGIC;
    CLK_5MHZ : out STD_LOGIC;
    clk_in1 : in STD_LOGIC
  );

end uvod_clk_wiz_0_0;

architecture stub of uvod_clk_wiz_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "CLK_200MHZ,CLK_40MHZ,CLK_5MHZ,clk_in1";
begin
end;
