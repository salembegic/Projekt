-- Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2019.1 (win64) Build 2552052 Fri May 24 14:49:42 MDT 2019
-- Date        : Wed May  6 23:01:25 2026
-- Host        : DESKTOP-TPP71AQ running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               C:/workspace/PEV/uvod/uvod.srcs/sources_1/bd/uvod/ip/uvod_BUTTON_MATRIX_0_0/uvod_BUTTON_MATRIX_0_0_stub.vhdl
-- Design      : uvod_BUTTON_MATRIX_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7s25csga324-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity uvod_BUTTON_MATRIX_0_0 is
  Port ( 
    CLK_5M : in STD_LOGIC;
    CLK_40M : in STD_LOGIC;
    ROWS_IN : in STD_LOGIC_VECTOR ( 3 downto 0 );
    COLUMNS_OUT : out STD_LOGIC_VECTOR ( 3 downto 0 );
    BUTTONS_OUT : out STD_LOGIC_VECTOR ( 15 downto 0 );
    VALID_PRESS_OUT : out STD_LOGIC;
    VALID_RELEASE_OUT : out STD_LOGIC;
    TOP_BTN_0 : out STD_LOGIC;
    TOP_BTN_1 : out STD_LOGIC;
    TOP_BTN_2 : out STD_LOGIC;
    TOP_BTN_3 : out STD_LOGIC
  );

end uvod_BUTTON_MATRIX_0_0;

architecture stub of uvod_BUTTON_MATRIX_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "CLK_5M,CLK_40M,ROWS_IN[3:0],COLUMNS_OUT[3:0],BUTTONS_OUT[15:0],VALID_PRESS_OUT,VALID_RELEASE_OUT,TOP_BTN_0,TOP_BTN_1,TOP_BTN_2,TOP_BTN_3";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "BUTTON_MATRIX,Vivado 2019.1";
begin
end;
