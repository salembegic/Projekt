// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2019.1 (win64) Build 2552052 Fri May 24 14:49:42 MDT 2019
// Date        : Wed May  6 23:01:25 2026
// Host        : DESKTOP-TPP71AQ running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               C:/workspace/PEV/uvod/uvod.srcs/sources_1/bd/uvod/ip/uvod_BUTTON_MATRIX_0_0/uvod_BUTTON_MATRIX_0_0_stub.v
// Design      : uvod_BUTTON_MATRIX_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7s25csga324-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "BUTTON_MATRIX,Vivado 2019.1" *)
module uvod_BUTTON_MATRIX_0_0(CLK_5M, CLK_40M, ROWS_IN, COLUMNS_OUT, 
  BUTTONS_OUT, VALID_PRESS_OUT, VALID_RELEASE_OUT, TOP_BTN_0, TOP_BTN_1, TOP_BTN_2, TOP_BTN_3)
/* synthesis syn_black_box black_box_pad_pin="CLK_5M,CLK_40M,ROWS_IN[3:0],COLUMNS_OUT[3:0],BUTTONS_OUT[15:0],VALID_PRESS_OUT,VALID_RELEASE_OUT,TOP_BTN_0,TOP_BTN_1,TOP_BTN_2,TOP_BTN_3" */;
  input CLK_5M;
  input CLK_40M;
  input [3:0]ROWS_IN;
  output [3:0]COLUMNS_OUT;
  output [15:0]BUTTONS_OUT;
  output VALID_PRESS_OUT;
  output VALID_RELEASE_OUT;
  output TOP_BTN_0;
  output TOP_BTN_1;
  output TOP_BTN_2;
  output TOP_BTN_3;
endmodule
