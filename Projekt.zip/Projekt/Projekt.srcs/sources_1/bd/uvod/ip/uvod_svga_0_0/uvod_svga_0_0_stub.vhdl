-- Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2019.1 (win64) Build 2552052 Fri May 24 14:49:42 MDT 2019
-- Date        : Wed May  6 23:15:48 2026
-- Host        : DESKTOP-TPP71AQ running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               C:/workspace/PEV/uvod/uvod.srcs/sources_1/bd/uvod/ip/uvod_svga_0_0/uvod_svga_0_0_stub.vhdl
-- Design      : uvod_svga_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7s25csga324-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity uvod_svga_0_0 is
  Port ( 
    iw_pix_clk : in STD_LOGIC;
    iw4_red : in STD_LOGIC_VECTOR ( 3 downto 0 );
    iw4_green : in STD_LOGIC_VECTOR ( 3 downto 0 );
    iw4_blue : in STD_LOGIC_VECTOR ( 3 downto 0 );
    iw4_result_left : in STD_LOGIC_VECTOR ( 3 downto 0 );
    iw4_result_right : in STD_LOGIC_VECTOR ( 3 downto 0 );
    iw11_x_pos : in STD_LOGIC_VECTOR ( 10 downto 0 );
    iw11_y_pos : in STD_LOGIC_VECTOR ( 10 downto 0 );
    iw11_block_left_pos : in STD_LOGIC_VECTOR ( 10 downto 0 );
    iw11_block_right_pos : in STD_LOGIC_VECTOR ( 10 downto 0 );
    ow4_red : out STD_LOGIC_VECTOR ( 3 downto 0 );
    ow4_green : out STD_LOGIC_VECTOR ( 3 downto 0 );
    ow4_blue : out STD_LOGIC_VECTOR ( 3 downto 0 );
    ow_hsync : out STD_LOGIC;
    ow_vsync : out STD_LOGIC
  );

end uvod_svga_0_0;

architecture stub of uvod_svga_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "iw_pix_clk,iw4_red[3:0],iw4_green[3:0],iw4_blue[3:0],iw4_result_left[3:0],iw4_result_right[3:0],iw11_x_pos[10:0],iw11_y_pos[10:0],iw11_block_left_pos[10:0],iw11_block_right_pos[10:0],ow4_red[3:0],ow4_green[3:0],ow4_blue[3:0],ow_hsync,ow_vsync";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "svga,Vivado 2019.1";
begin
end;
