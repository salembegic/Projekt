// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2019.1 (win64) Build 2552052 Fri May 24 14:49:42 MDT 2019
// Date        : Wed May  6 23:15:48 2026
// Host        : DESKTOP-TPP71AQ running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               C:/workspace/PEV/uvod/uvod.srcs/sources_1/bd/uvod/ip/uvod_svga_0_0/uvod_svga_0_0_stub.v
// Design      : uvod_svga_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7s25csga324-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "svga,Vivado 2019.1" *)
module uvod_svga_0_0(iw_pix_clk, iw4_red, iw4_green, iw4_blue, 
  iw4_result_left, iw4_result_right, iw11_x_pos, iw11_y_pos, iw11_block_left_pos, 
  iw11_block_right_pos, ow4_red, ow4_green, ow4_blue, ow_hsync, ow_vsync)
/* synthesis syn_black_box black_box_pad_pin="iw_pix_clk,iw4_red[3:0],iw4_green[3:0],iw4_blue[3:0],iw4_result_left[3:0],iw4_result_right[3:0],iw11_x_pos[10:0],iw11_y_pos[10:0],iw11_block_left_pos[10:0],iw11_block_right_pos[10:0],ow4_red[3:0],ow4_green[3:0],ow4_blue[3:0],ow_hsync,ow_vsync" */;
  input iw_pix_clk;
  input [3:0]iw4_red;
  input [3:0]iw4_green;
  input [3:0]iw4_blue;
  input [3:0]iw4_result_left;
  input [3:0]iw4_result_right;
  input [10:0]iw11_x_pos;
  input [10:0]iw11_y_pos;
  input [10:0]iw11_block_left_pos;
  input [10:0]iw11_block_right_pos;
  output [3:0]ow4_red;
  output [3:0]ow4_green;
  output [3:0]ow4_blue;
  output ow_hsync;
  output ow_vsync;
endmodule
