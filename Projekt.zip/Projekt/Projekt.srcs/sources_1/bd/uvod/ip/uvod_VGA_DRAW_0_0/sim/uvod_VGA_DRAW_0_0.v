// (c) Copyright 1995-2026 Xilinx, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of Xilinx, Inc. and is protected under U.S. and
// international copyright and other intellectual property
// laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// Xilinx, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) Xilinx shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or Xilinx had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// Xilinx products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of Xilinx products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


// IP VLNV: xilinx.com:module_ref:VGA_DRAW:1.0
// IP Revision: 1

`timescale 1ns/1ps

(* IP_DEFINITION_SOURCE = "module_ref" *)
(* DowngradeIPIdentifiedWarnings = "yes" *)
module uvod_VGA_DRAW_0_0 (
  CLK,
  X_IN,
  Y_IN,
  BTN_PRESS_VALID_IN,
  BTN_RELEASE_VALID_IN,
  BUTTONS_IN,
  R_OUT,
  G_OUT,
  B_OUT
);

(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK, FREQ_HZ 40000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0" *)
(* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK CLK" *)
input wire CLK;
input wire [10 : 0] X_IN;
input wire [10 : 0] Y_IN;
input wire BTN_PRESS_VALID_IN;
input wire BTN_RELEASE_VALID_IN;
input wire [15 : 0] BUTTONS_IN;
output wire [3 : 0] R_OUT;
output wire [3 : 0] G_OUT;
output wire [3 : 0] B_OUT;

  VGA_DRAW #(
    .G_COL_CHNL_BIT_WIDTH(4),
    .G_IMG_SCALE(3)
  ) inst (
    .CLK(CLK),
    .X_IN(X_IN),
    .Y_IN(Y_IN),
    .BTN_PRESS_VALID_IN(BTN_PRESS_VALID_IN),
    .BTN_RELEASE_VALID_IN(BTN_RELEASE_VALID_IN),
    .BUTTONS_IN(BUTTONS_IN),
    .R_OUT(R_OUT),
    .G_OUT(G_OUT),
    .B_OUT(B_OUT)
  );
endmodule
