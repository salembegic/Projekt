-- Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2019.1 (win64) Build 2552052 Fri May 24 14:49:42 MDT 2019
-- Date        : Wed May  6 22:48:39 2026
-- Host        : DESKTOP-TPP71AQ running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               C:/workspace/PEV/uvod/uvod.srcs/sources_1/bd/uvod/ip/uvod_VGA_DRAW_0_0/uvod_VGA_DRAW_0_0_stub.vhdl
-- Design      : uvod_VGA_DRAW_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7s25csga324-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity uvod_VGA_DRAW_0_0 is
  Port ( 
    CLK : in STD_LOGIC;
    X_IN : in STD_LOGIC_VECTOR ( 10 downto 0 );
    Y_IN : in STD_LOGIC_VECTOR ( 10 downto 0 );
    BTN_PRESS_VALID_IN : in STD_LOGIC;
    BTN_RELEASE_VALID_IN : in STD_LOGIC;
    BUTTONS_IN : in STD_LOGIC_VECTOR ( 15 downto 0 );
    R_OUT : out STD_LOGIC_VECTOR ( 3 downto 0 );
    G_OUT : out STD_LOGIC_VECTOR ( 3 downto 0 );
    B_OUT : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );

end uvod_VGA_DRAW_0_0;

architecture stub of uvod_VGA_DRAW_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "CLK,X_IN[10:0],Y_IN[10:0],BTN_PRESS_VALID_IN,BTN_RELEASE_VALID_IN,BUTTONS_IN[15:0],R_OUT[3:0],G_OUT[3:0],B_OUT[3:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "VGA_DRAW,Vivado 2019.1";
begin
end;
