// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2019.1 (win64) Build 2552052 Fri May 24 14:49:42 MDT 2019
// Date        : Wed May  6 22:48:39 2026
// Host        : DESKTOP-TPP71AQ running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               C:/workspace/PEV/uvod/uvod.srcs/sources_1/bd/uvod/ip/uvod_VGA_DRAW_0_0/uvod_VGA_DRAW_0_0_stub.v
// Design      : uvod_VGA_DRAW_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7s25csga324-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "VGA_DRAW,Vivado 2019.1" *)
module uvod_VGA_DRAW_0_0(CLK, X_IN, Y_IN, BTN_PRESS_VALID_IN, 
  BTN_RELEASE_VALID_IN, BUTTONS_IN, R_OUT, G_OUT, B_OUT)
/* synthesis syn_black_box black_box_pad_pin="CLK,X_IN[10:0],Y_IN[10:0],BTN_PRESS_VALID_IN,BTN_RELEASE_VALID_IN,BUTTONS_IN[15:0],R_OUT[3:0],G_OUT[3:0],B_OUT[3:0]" */;
  input CLK;
  input [10:0]X_IN;
  input [10:0]Y_IN;
  input BTN_PRESS_VALID_IN;
  input BTN_RELEASE_VALID_IN;
  input [15:0]BUTTONS_IN;
  output [3:0]R_OUT;
  output [3:0]G_OUT;
  output [3:0]B_OUT;
endmodule
