// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2019.1 (win64) Build 2552052 Fri May 24 14:49:42 MDT 2019
// Date        : Wed May  6 22:48:39 2026
// Host        : DESKTOP-TPP71AQ running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               C:/workspace/PEV/uvod/uvod.srcs/sources_1/bd/uvod/ip/uvod_VGA_DRAW_0_0/uvod_VGA_DRAW_0_0_sim_netlist.v
// Design      : uvod_VGA_DRAW_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7s25csga324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "uvod_VGA_DRAW_0_0,VGA_DRAW,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "VGA_DRAW,Vivado 2019.1" *) 
(* NotValidForBitStream *)
module uvod_VGA_DRAW_0_0
   (CLK,
    X_IN,
    Y_IN,
    BTN_PRESS_VALID_IN,
    BTN_RELEASE_VALID_IN,
    BUTTONS_IN,
    R_OUT,
    G_OUT,
    B_OUT);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK, FREQ_HZ 40000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0" *) input CLK;
  input [10:0]X_IN;
  input [10:0]Y_IN;
  input BTN_PRESS_VALID_IN;
  input BTN_RELEASE_VALID_IN;
  input [15:0]BUTTONS_IN;
  output [3:0]R_OUT;
  output [3:0]G_OUT;
  output [3:0]B_OUT;

  wire BTN_PRESS_VALID_IN;
  wire [15:0]BUTTONS_IN;
  wire [2:2]\^B_OUT ;
  wire CLK;
  wire [2:2]\^G_OUT ;
  wire [2:2]\^R_OUT ;
  wire [10:0]X_IN;
  wire [10:0]Y_IN;

  assign B_OUT[3] = \^B_OUT [2];
  assign B_OUT[2] = \^B_OUT [2];
  assign B_OUT[1] = \^B_OUT [2];
  assign B_OUT[0] = \^B_OUT [2];
  assign G_OUT[3] = \^G_OUT [2];
  assign G_OUT[2] = \^G_OUT [2];
  assign G_OUT[1] = \^G_OUT [2];
  assign G_OUT[0] = \^G_OUT [2];
  assign R_OUT[3] = \^R_OUT [2];
  assign R_OUT[2] = \^R_OUT [2];
  assign R_OUT[1] = \^R_OUT [2];
  assign R_OUT[0] = \^R_OUT [2];
  uvod_VGA_DRAW_0_0_VGA_DRAW inst
       (.BTN_PRESS_VALID_IN(BTN_PRESS_VALID_IN),
        .BUTTONS_IN(BUTTONS_IN),
        .B_OUT(\^B_OUT ),
        .CLK(CLK),
        .G_OUT(\^G_OUT ),
        .R_OUT(\^R_OUT ),
        .X_IN(X_IN[9:0]),
        .Y_IN(Y_IN[9:0]));
endmodule

(* ORIG_REF_NAME = "VGA_DRAW" *) 
module uvod_VGA_DRAW_0_0_VGA_DRAW
   (R_OUT,
    G_OUT,
    B_OUT,
    Y_IN,
    X_IN,
    BTN_PRESS_VALID_IN,
    CLK,
    BUTTONS_IN);
  output [0:0]R_OUT;
  output [0:0]G_OUT;
  output [0:0]B_OUT;
  input [9:0]Y_IN;
  input [9:0]X_IN;
  input BTN_PRESS_VALID_IN;
  input CLK;
  input [15:0]BUTTONS_IN;

  wire \BTN_CNTR[9]_i_2_n_0 ;
  wire [9:0]BTN_CNTR_reg;
  wire BTN_PRESS_VALID_IN;
  wire [15:0]BUTTONS_IN;
  wire [0:0]B_OUT;
  wire B_OUT0;
  wire \B_OUT[3]_i_10_n_0 ;
  wire \B_OUT[3]_i_11_n_0 ;
  wire \B_OUT[3]_i_16_n_0 ;
  wire \B_OUT[3]_i_24_n_0 ;
  wire \B_OUT[3]_i_28_n_0 ;
  wire \B_OUT[3]_i_29_n_0 ;
  wire \B_OUT[3]_i_2_n_0 ;
  wire \B_OUT[3]_i_30_n_0 ;
  wire \B_OUT[3]_i_31_n_0 ;
  wire \B_OUT[3]_i_32_n_0 ;
  wire \B_OUT[3]_i_33_n_0 ;
  wire \B_OUT[3]_i_34_n_0 ;
  wire \B_OUT[3]_i_35_n_0 ;
  wire \B_OUT[3]_i_36_n_0 ;
  wire \B_OUT[3]_i_37_n_0 ;
  wire \B_OUT[3]_i_38_n_0 ;
  wire \B_OUT[3]_i_39_n_0 ;
  wire \B_OUT[3]_i_40_n_0 ;
  wire \B_OUT[3]_i_41_n_0 ;
  wire \B_OUT[3]_i_42_n_0 ;
  wire \B_OUT[3]_i_43_n_0 ;
  wire \B_OUT[3]_i_44_n_0 ;
  wire \B_OUT[3]_i_45_n_0 ;
  wire \B_OUT[3]_i_46_n_0 ;
  wire \B_OUT[3]_i_47_n_0 ;
  wire \B_OUT[3]_i_48_n_0 ;
  wire \B_OUT[3]_i_49_n_0 ;
  wire \B_OUT[3]_i_4_n_0 ;
  wire \B_OUT[3]_i_50_n_0 ;
  wire \B_OUT[3]_i_51_n_0 ;
  wire \B_OUT[3]_i_52_n_0 ;
  wire \B_OUT[3]_i_53_n_0 ;
  wire \B_OUT[3]_i_54_n_0 ;
  wire \B_OUT[3]_i_55_n_0 ;
  wire \B_OUT[3]_i_56_n_0 ;
  wire \B_OUT[3]_i_60_n_0 ;
  wire \B_OUT[3]_i_64_n_0 ;
  wire \B_OUT[3]_i_65_n_0 ;
  wire \B_OUT[3]_i_68_n_0 ;
  wire \B_OUT[3]_i_6_n_0 ;
  wire \B_OUT[3]_i_70_n_0 ;
  wire \B_OUT[3]_i_74_n_0 ;
  wire \B_OUT[3]_i_75_n_0 ;
  wire \B_OUT[3]_i_78_n_0 ;
  wire \B_OUT[3]_i_7_n_0 ;
  wire \B_OUT[3]_i_80_n_0 ;
  wire \B_OUT[3]_i_8_n_0 ;
  wire \B_OUT[3]_i_9_n_0 ;
  wire \B_OUT_reg[3]_i_100_n_0 ;
  wire \B_OUT_reg[3]_i_101_n_0 ;
  wire \B_OUT_reg[3]_i_102_n_0 ;
  wire \B_OUT_reg[3]_i_103_n_0 ;
  wire \B_OUT_reg[3]_i_104_n_0 ;
  wire \B_OUT_reg[3]_i_105_n_0 ;
  wire \B_OUT_reg[3]_i_106_n_0 ;
  wire \B_OUT_reg[3]_i_107_n_0 ;
  wire \B_OUT_reg[3]_i_108_n_0 ;
  wire \B_OUT_reg[3]_i_109_n_0 ;
  wire \B_OUT_reg[3]_i_110_n_0 ;
  wire \B_OUT_reg[3]_i_111_n_0 ;
  wire \B_OUT_reg[3]_i_112_n_0 ;
  wire \B_OUT_reg[3]_i_113_n_0 ;
  wire \B_OUT_reg[3]_i_114_n_0 ;
  wire \B_OUT_reg[3]_i_115_n_0 ;
  wire \B_OUT_reg[3]_i_116_n_0 ;
  wire \B_OUT_reg[3]_i_117_n_0 ;
  wire \B_OUT_reg[3]_i_119_n_0 ;
  wire \B_OUT_reg[3]_i_122_n_0 ;
  wire \B_OUT_reg[3]_i_125_n_0 ;
  wire \B_OUT_reg[3]_i_129_n_0 ;
  wire \B_OUT_reg[3]_i_12_n_0 ;
  wire \B_OUT_reg[3]_i_133_n_0 ;
  wire \B_OUT_reg[3]_i_137_n_0 ;
  wire \B_OUT_reg[3]_i_139_n_0 ;
  wire \B_OUT_reg[3]_i_13_n_0 ;
  wire \B_OUT_reg[3]_i_141_n_0 ;
  wire \B_OUT_reg[3]_i_144_n_0 ;
  wire \B_OUT_reg[3]_i_145_n_0 ;
  wire \B_OUT_reg[3]_i_147_n_0 ;
  wire \B_OUT_reg[3]_i_14_n_0 ;
  wire \B_OUT_reg[3]_i_150_n_0 ;
  wire \B_OUT_reg[3]_i_15_n_0 ;
  wire \B_OUT_reg[3]_i_17_n_0 ;
  wire \B_OUT_reg[3]_i_18_n_0 ;
  wire \B_OUT_reg[3]_i_19_n_0 ;
  wire \B_OUT_reg[3]_i_20_n_0 ;
  wire \B_OUT_reg[3]_i_21_n_0 ;
  wire \B_OUT_reg[3]_i_22_n_0 ;
  wire \B_OUT_reg[3]_i_23_n_0 ;
  wire \B_OUT_reg[3]_i_25_n_0 ;
  wire \B_OUT_reg[3]_i_26_n_0 ;
  wire \B_OUT_reg[3]_i_27_n_0 ;
  wire \B_OUT_reg[3]_i_3_n_0 ;
  wire \B_OUT_reg[3]_i_57_n_0 ;
  wire \B_OUT_reg[3]_i_58_n_0 ;
  wire \B_OUT_reg[3]_i_59_n_0 ;
  wire \B_OUT_reg[3]_i_5_n_0 ;
  wire \B_OUT_reg[3]_i_62_n_0 ;
  wire \B_OUT_reg[3]_i_63_n_0 ;
  wire \B_OUT_reg[3]_i_67_n_0 ;
  wire \B_OUT_reg[3]_i_69_n_0 ;
  wire \B_OUT_reg[3]_i_72_n_0 ;
  wire \B_OUT_reg[3]_i_73_n_0 ;
  wire \B_OUT_reg[3]_i_76_n_0 ;
  wire \B_OUT_reg[3]_i_79_n_0 ;
  wire \B_OUT_reg[3]_i_84_n_0 ;
  wire \B_OUT_reg[3]_i_85_n_0 ;
  wire \B_OUT_reg[3]_i_86_n_0 ;
  wire \B_OUT_reg[3]_i_90_n_0 ;
  wire \B_OUT_reg[3]_i_91_n_0 ;
  wire \B_OUT_reg[3]_i_92_n_0 ;
  wire \B_OUT_reg[3]_i_96_n_0 ;
  wire \B_OUT_reg[3]_i_97_n_0 ;
  wire \B_OUT_reg[3]_i_98_n_0 ;
  wire \B_OUT_reg[3]_i_99_n_0 ;
  wire CLK;
  wire [0:0]G_OUT;
  wire G_OUT0;
  wire \G_OUT[3]_i_100_n_0 ;
  wire \G_OUT[3]_i_107_n_0 ;
  wire \G_OUT[3]_i_108_n_0 ;
  wire \G_OUT[3]_i_109_n_0 ;
  wire \G_OUT[3]_i_10_n_0 ;
  wire \G_OUT[3]_i_110_n_0 ;
  wire \G_OUT[3]_i_112_n_0 ;
  wire \G_OUT[3]_i_113_n_0 ;
  wire \G_OUT[3]_i_11_n_0 ;
  wire \G_OUT[3]_i_120_n_0 ;
  wire \G_OUT[3]_i_122_n_0 ;
  wire \G_OUT[3]_i_123_n_0 ;
  wire \G_OUT[3]_i_124_n_0 ;
  wire \G_OUT[3]_i_125_n_0 ;
  wire \G_OUT[3]_i_127_n_0 ;
  wire \G_OUT[3]_i_130_n_0 ;
  wire \G_OUT[3]_i_132_n_0 ;
  wire \G_OUT[3]_i_133_n_0 ;
  wire \G_OUT[3]_i_138_n_0 ;
  wire \G_OUT[3]_i_13_n_0 ;
  wire \G_OUT[3]_i_141_n_0 ;
  wire \G_OUT[3]_i_142_n_0 ;
  wire \G_OUT[3]_i_146_n_0 ;
  wire \G_OUT[3]_i_147_n_0 ;
  wire \G_OUT[3]_i_148_n_0 ;
  wire \G_OUT[3]_i_149_n_0 ;
  wire \G_OUT[3]_i_15_n_0 ;
  wire \G_OUT[3]_i_16_n_0 ;
  wire \G_OUT[3]_i_17_n_0 ;
  wire \G_OUT[3]_i_20_n_0 ;
  wire \G_OUT[3]_i_21_n_0 ;
  wire \G_OUT[3]_i_22_n_0 ;
  wire \G_OUT[3]_i_23_n_0 ;
  wire \G_OUT[3]_i_25_n_0 ;
  wire \G_OUT[3]_i_27_n_0 ;
  wire \G_OUT[3]_i_28_n_0 ;
  wire \G_OUT[3]_i_2_n_0 ;
  wire \G_OUT[3]_i_30_n_0 ;
  wire \G_OUT[3]_i_31_n_0 ;
  wire \G_OUT[3]_i_32_n_0 ;
  wire \G_OUT[3]_i_33_n_0 ;
  wire \G_OUT[3]_i_34_n_0 ;
  wire \G_OUT[3]_i_35_n_0 ;
  wire \G_OUT[3]_i_37_n_0 ;
  wire \G_OUT[3]_i_38_n_0 ;
  wire \G_OUT[3]_i_39_n_0 ;
  wire \G_OUT[3]_i_3_n_0 ;
  wire \G_OUT[3]_i_41_n_0 ;
  wire \G_OUT[3]_i_42_n_0 ;
  wire \G_OUT[3]_i_43_n_0 ;
  wire \G_OUT[3]_i_44_n_0 ;
  wire \G_OUT[3]_i_45_n_0 ;
  wire \G_OUT[3]_i_46_n_0 ;
  wire \G_OUT[3]_i_47_n_0 ;
  wire \G_OUT[3]_i_4_n_0 ;
  wire \G_OUT[3]_i_52_n_0 ;
  wire \G_OUT[3]_i_53_n_0 ;
  wire \G_OUT[3]_i_57_n_0 ;
  wire \G_OUT[3]_i_58_n_0 ;
  wire \G_OUT[3]_i_59_n_0 ;
  wire \G_OUT[3]_i_60_n_0 ;
  wire \G_OUT[3]_i_61_n_0 ;
  wire \G_OUT[3]_i_62_n_0 ;
  wire \G_OUT[3]_i_66_n_0 ;
  wire \G_OUT[3]_i_69_n_0 ;
  wire \G_OUT[3]_i_70_n_0 ;
  wire \G_OUT[3]_i_74_n_0 ;
  wire \G_OUT[3]_i_78_n_0 ;
  wire \G_OUT[3]_i_81_n_0 ;
  wire \G_OUT[3]_i_82_n_0 ;
  wire \G_OUT[3]_i_84_n_0 ;
  wire \G_OUT[3]_i_85_n_0 ;
  wire \G_OUT[3]_i_87_n_0 ;
  wire \G_OUT[3]_i_8_n_0 ;
  wire \G_OUT[3]_i_91_n_0 ;
  wire \G_OUT[3]_i_96_n_0 ;
  wire \G_OUT[3]_i_9_n_0 ;
  wire \G_OUT_reg[3]_i_101_n_0 ;
  wire \G_OUT_reg[3]_i_103_n_0 ;
  wire \G_OUT_reg[3]_i_106_n_0 ;
  wire \G_OUT_reg[3]_i_114_n_0 ;
  wire \G_OUT_reg[3]_i_116_n_0 ;
  wire \G_OUT_reg[3]_i_119_n_0 ;
  wire \G_OUT_reg[3]_i_121_n_0 ;
  wire \G_OUT_reg[3]_i_126_n_0 ;
  wire \G_OUT_reg[3]_i_12_n_0 ;
  wire \G_OUT_reg[3]_i_134_n_0 ;
  wire \G_OUT_reg[3]_i_137_n_0 ;
  wire \G_OUT_reg[3]_i_139_n_0 ;
  wire \G_OUT_reg[3]_i_14_n_0 ;
  wire \G_OUT_reg[3]_i_18_n_0 ;
  wire \G_OUT_reg[3]_i_19_n_0 ;
  wire \G_OUT_reg[3]_i_26_n_0 ;
  wire \G_OUT_reg[3]_i_29_n_0 ;
  wire \G_OUT_reg[3]_i_36_n_0 ;
  wire \G_OUT_reg[3]_i_40_n_0 ;
  wire \G_OUT_reg[3]_i_48_n_0 ;
  wire \G_OUT_reg[3]_i_49_n_0 ;
  wire \G_OUT_reg[3]_i_50_n_0 ;
  wire \G_OUT_reg[3]_i_51_n_0 ;
  wire \G_OUT_reg[3]_i_54_n_0 ;
  wire \G_OUT_reg[3]_i_55_n_0 ;
  wire \G_OUT_reg[3]_i_56_n_0 ;
  wire \G_OUT_reg[3]_i_5_n_0 ;
  wire \G_OUT_reg[3]_i_67_n_0 ;
  wire \G_OUT_reg[3]_i_6_n_0 ;
  wire \G_OUT_reg[3]_i_76_n_0 ;
  wire \G_OUT_reg[3]_i_7_n_0 ;
  wire \G_OUT_reg[3]_i_80_n_0 ;
  wire \G_OUT_reg[3]_i_83_n_0 ;
  wire \G_OUT_reg[3]_i_90_n_0 ;
  wire \G_OUT_reg[3]_i_93_n_0 ;
  wire \G_OUT_reg[3]_i_95_n_0 ;
  wire [0:0]R_OUT;
  wire R_OUT0;
  wire \R_OUT[3]_i_10_n_0 ;
  wire \R_OUT[3]_i_11_n_0 ;
  wire \R_OUT[3]_i_12_n_0 ;
  wire \R_OUT[3]_i_13_n_0 ;
  wire \R_OUT[3]_i_14_n_0 ;
  wire \R_OUT[3]_i_15_n_0 ;
  wire \R_OUT[3]_i_16_n_0 ;
  wire \R_OUT[3]_i_17_n_0 ;
  wire \R_OUT[3]_i_18_n_0 ;
  wire \R_OUT[3]_i_19_n_0 ;
  wire \R_OUT[3]_i_20_n_0 ;
  wire \R_OUT[3]_i_22_n_0 ;
  wire \R_OUT[3]_i_23_n_0 ;
  wire \R_OUT[3]_i_24_n_0 ;
  wire \R_OUT[3]_i_25_n_0 ;
  wire \R_OUT[3]_i_26_n_0 ;
  wire \R_OUT[3]_i_27_n_0 ;
  wire \R_OUT[3]_i_28_n_0 ;
  wire \R_OUT[3]_i_29_n_0 ;
  wire \R_OUT[3]_i_2_n_0 ;
  wire \R_OUT[3]_i_30_n_0 ;
  wire \R_OUT[3]_i_31_n_0 ;
  wire \R_OUT[3]_i_32_n_0 ;
  wire \R_OUT[3]_i_33_n_0 ;
  wire \R_OUT[3]_i_34_n_0 ;
  wire \R_OUT[3]_i_35_n_0 ;
  wire \R_OUT[3]_i_36_n_0 ;
  wire \R_OUT[3]_i_38_n_0 ;
  wire \R_OUT[3]_i_39_n_0 ;
  wire \R_OUT[3]_i_3_n_0 ;
  wire \R_OUT[3]_i_40_n_0 ;
  wire \R_OUT[3]_i_41_n_0 ;
  wire \R_OUT[3]_i_42_n_0 ;
  wire \R_OUT[3]_i_43_n_0 ;
  wire \R_OUT[3]_i_44_n_0 ;
  wire \R_OUT[3]_i_45_n_0 ;
  wire \R_OUT[3]_i_46_n_0 ;
  wire \R_OUT[3]_i_47_n_0 ;
  wire \R_OUT[3]_i_48_n_0 ;
  wire \R_OUT[3]_i_49_n_0 ;
  wire \R_OUT[3]_i_4_n_0 ;
  wire \R_OUT[3]_i_50_n_0 ;
  wire \R_OUT[3]_i_51_n_0 ;
  wire \R_OUT[3]_i_52_n_0 ;
  wire \R_OUT[3]_i_53_n_0 ;
  wire \R_OUT[3]_i_54_n_0 ;
  wire \R_OUT[3]_i_56_n_0 ;
  wire \R_OUT[3]_i_57_n_0 ;
  wire \R_OUT[3]_i_58_n_0 ;
  wire \R_OUT[3]_i_59_n_0 ;
  wire \R_OUT[3]_i_5_n_0 ;
  wire \R_OUT[3]_i_60_n_0 ;
  wire \R_OUT[3]_i_61_n_0 ;
  wire \R_OUT[3]_i_62_n_0 ;
  wire \R_OUT[3]_i_63_n_0 ;
  wire \R_OUT[3]_i_64_n_0 ;
  wire \R_OUT[3]_i_65_n_0 ;
  wire \R_OUT[3]_i_66_n_0 ;
  wire \R_OUT[3]_i_67_n_0 ;
  wire \R_OUT[3]_i_68_n_0 ;
  wire \R_OUT[3]_i_69_n_0 ;
  wire \R_OUT[3]_i_6_n_0 ;
  wire \R_OUT[3]_i_70_n_0 ;
  wire \R_OUT[3]_i_71_n_0 ;
  wire \R_OUT[3]_i_72_n_0 ;
  wire \R_OUT[3]_i_73_n_0 ;
  wire \R_OUT[3]_i_75_n_0 ;
  wire \R_OUT[3]_i_76_n_0 ;
  wire \R_OUT[3]_i_77_n_0 ;
  wire \R_OUT[3]_i_78_n_0 ;
  wire \R_OUT[3]_i_79_n_0 ;
  wire \R_OUT[3]_i_7_n_0 ;
  wire \R_OUT[3]_i_80_n_0 ;
  wire \R_OUT[3]_i_81_n_0 ;
  wire \R_OUT[3]_i_82_n_0 ;
  wire \R_OUT[3]_i_83_n_0 ;
  wire \R_OUT[3]_i_8_n_0 ;
  wire \R_OUT[3]_i_9_n_0 ;
  wire \R_OUT_reg[3]_i_21_n_0 ;
  wire \R_OUT_reg[3]_i_37_n_0 ;
  wire \R_OUT_reg[3]_i_55_n_0 ;
  wire \R_OUT_reg[3]_i_74_n_0 ;
  wire [9:0]X_IN;
  wire [9:0]Y_IN;
  wire g0_b0_n_0;
  wire g0_b1__0_n_0;
  wire g0_b1__10_n_0;
  wire g0_b1__11_n_0;
  wire g0_b1__12_n_0;
  wire g0_b1__13_n_0;
  wire g0_b1__14_n_0;
  wire g0_b1__15_n_0;
  wire g0_b1__16_n_0;
  wire g0_b1__17_n_0;
  wire g0_b1__18_n_0;
  wire g0_b1__19_n_0;
  wire g0_b1__1_n_0;
  wire g0_b1__20_n_0;
  wire g0_b1__21_n_0;
  wire g0_b1__22_n_0;
  wire g0_b1__23_n_0;
  wire g0_b1__24_n_0;
  wire g0_b1__25_n_0;
  wire g0_b1__26_n_0;
  wire g0_b1__27_n_0;
  wire g0_b1__28_n_0;
  wire g0_b1__29_n_0;
  wire g0_b1__2_n_0;
  wire g0_b1__30_n_0;
  wire g0_b1__31_n_0;
  wire g0_b1__32_n_0;
  wire g0_b1__33_n_0;
  wire g0_b1__34_n_0;
  wire g0_b1__35_n_0;
  wire g0_b1__3_n_0;
  wire g0_b1__4_n_0;
  wire g0_b1__5_n_0;
  wire g0_b1__6_n_0;
  wire g0_b1__7_n_0;
  wire g0_b1__8_n_0;
  wire g0_b1__9_n_0;
  wire g0_b1_i_1__0_n_0;
  wire g0_b1_i_1_n_0;
  wire g0_b1_i_2__0_n_0;
  wire g0_b1_i_2_n_0;
  wire g0_b1_i_3__0_n_0;
  wire g0_b1_i_3_n_0;
  wire g0_b1_i_4__0_n_0;
  wire g0_b1_i_4_n_0;
  wire g0_b1_i_5__0_n_0;
  wire g0_b1_i_5_n_0;
  wire g0_b1_i_6__0_n_0;
  wire g0_b1_i_6_n_0;
  wire g0_b1_i_7_n_0;
  wire g0_b1_i_8_n_0;
  wire g0_b1_i_9_n_0;
  wire g0_b1_n_0;
  wire g0_b2__0_n_0;
  wire g0_b2__10_n_0;
  wire g0_b2__11_n_0;
  wire g0_b2__12_n_0;
  wire g0_b2__13_n_0;
  wire g0_b2__14_n_0;
  wire g0_b2__15_n_0;
  wire g0_b2__16_n_0;
  wire g0_b2__17_n_0;
  wire g0_b2__18_n_0;
  wire g0_b2__19_n_0;
  wire g0_b2__1_n_0;
  wire g0_b2__20_n_0;
  wire g0_b2__21_n_0;
  wire g0_b2__22_n_0;
  wire g0_b2__23_n_0;
  wire g0_b2__24_n_0;
  wire g0_b2__25_n_0;
  wire g0_b2__26_n_0;
  wire g0_b2__27_n_0;
  wire g0_b2__28_n_0;
  wire g0_b2__29_n_0;
  wire g0_b2__2_n_0;
  wire g0_b2__30_n_0;
  wire g0_b2__31_n_0;
  wire g0_b2__32_n_0;
  wire g0_b2__33_n_0;
  wire g0_b2__34_n_0;
  wire g0_b2__35_n_0;
  wire g0_b2__3_n_0;
  wire g0_b2__4_n_0;
  wire g0_b2__5_n_0;
  wire g0_b2__6_n_0;
  wire g0_b2__7_n_0;
  wire g0_b2__8_n_0;
  wire g0_b2__9_n_0;
  wire g0_b2_n_0;
  wire g0_b3__0_n_0;
  wire g0_b3__10_n_0;
  wire g0_b3__11_n_0;
  wire g0_b3__12_n_0;
  wire g0_b3__13_n_0;
  wire g0_b3__14_n_0;
  wire g0_b3__15_n_0;
  wire g0_b3__16_n_0;
  wire g0_b3__17_n_0;
  wire g0_b3__18_n_0;
  wire g0_b3__19_n_0;
  wire g0_b3__1_n_0;
  wire g0_b3__20_n_0;
  wire g0_b3__21_n_0;
  wire g0_b3__22_n_0;
  wire g0_b3__23_n_0;
  wire g0_b3__24_n_0;
  wire g0_b3__25_n_0;
  wire g0_b3__26_n_0;
  wire g0_b3__27_n_0;
  wire g0_b3__28_n_0;
  wire g0_b3__29_n_0;
  wire g0_b3__2_n_0;
  wire g0_b3__30_n_0;
  wire g0_b3__31_n_0;
  wire g0_b3__32_n_0;
  wire g0_b3__33_n_0;
  wire g0_b3__34_n_0;
  wire g0_b3__35_n_0;
  wire g0_b3__3_n_0;
  wire g0_b3__4_n_0;
  wire g0_b3__5_n_0;
  wire g0_b3__6_n_0;
  wire g0_b3__7_n_0;
  wire g0_b3__8_n_0;
  wire g0_b3__9_n_0;
  wire g0_b3_n_0;
  wire g0_b4__0_n_0;
  wire g0_b4__10_n_0;
  wire g0_b4__11_n_0;
  wire g0_b4__12_n_0;
  wire g0_b4__13_n_0;
  wire g0_b4__14_n_0;
  wire g0_b4__15_n_0;
  wire g0_b4__16_n_0;
  wire g0_b4__17_n_0;
  wire g0_b4__18_n_0;
  wire g0_b4__19_n_0;
  wire g0_b4__1_n_0;
  wire g0_b4__20_n_0;
  wire g0_b4__21_n_0;
  wire g0_b4__22_n_0;
  wire g0_b4__23_n_0;
  wire g0_b4__24_n_0;
  wire g0_b4__25_n_0;
  wire g0_b4__26_n_0;
  wire g0_b4__27_n_0;
  wire g0_b4__28_n_0;
  wire g0_b4__29_n_0;
  wire g0_b4__2_n_0;
  wire g0_b4__30_n_0;
  wire g0_b4__31_n_0;
  wire g0_b4__32_n_0;
  wire g0_b4__33_n_0;
  wire g0_b4__34_n_0;
  wire g0_b4__35_n_0;
  wire g0_b4__3_n_0;
  wire g0_b4__4_n_0;
  wire g0_b4__5_n_0;
  wire g0_b4__6_n_0;
  wire g0_b4__7_n_0;
  wire g0_b4__8_n_0;
  wire g0_b4__9_n_0;
  wire g0_b4_n_0;
  wire g0_b5__0_n_0;
  wire g0_b5__10_n_0;
  wire g0_b5__11_n_0;
  wire g0_b5__12_n_0;
  wire g0_b5__13_n_0;
  wire g0_b5__14_n_0;
  wire g0_b5__15_n_0;
  wire g0_b5__16_n_0;
  wire g0_b5__17_n_0;
  wire g0_b5__18_n_0;
  wire g0_b5__19_n_0;
  wire g0_b5__1_n_0;
  wire g0_b5__20_n_0;
  wire g0_b5__21_n_0;
  wire g0_b5__22_n_0;
  wire g0_b5__23_n_0;
  wire g0_b5__24_n_0;
  wire g0_b5__25_n_0;
  wire g0_b5__26_n_0;
  wire g0_b5__27_n_0;
  wire g0_b5__28_n_0;
  wire g0_b5__29_n_0;
  wire g0_b5__2_n_0;
  wire g0_b5__30_n_0;
  wire g0_b5__31_n_0;
  wire g0_b5__32_n_0;
  wire g0_b5__33_n_0;
  wire g0_b5__34_n_0;
  wire g0_b5__3_n_0;
  wire g0_b5__4_n_0;
  wire g0_b5__5_n_0;
  wire g0_b5__6_n_0;
  wire g0_b5__7_n_0;
  wire g0_b5__8_n_0;
  wire g0_b5__9_n_0;
  wire g0_b5_n_0;
  wire g0_b6__0_n_0;
  wire g0_b6__10_n_0;
  wire g0_b6__11_n_0;
  wire g0_b6__12_n_0;
  wire g0_b6__13_n_0;
  wire g0_b6__14_n_0;
  wire g0_b6__15_n_0;
  wire g0_b6__16_n_0;
  wire g0_b6__17_n_0;
  wire g0_b6__18_n_0;
  wire g0_b6__19_n_0;
  wire g0_b6__1_n_0;
  wire g0_b6__20_n_0;
  wire g0_b6__21_n_0;
  wire g0_b6__22_n_0;
  wire g0_b6__23_n_0;
  wire g0_b6__24_n_0;
  wire g0_b6__25_n_0;
  wire g0_b6__26_n_0;
  wire g0_b6__27_n_0;
  wire g0_b6__28_n_0;
  wire g0_b6__29_n_0;
  wire g0_b6__2_n_0;
  wire g0_b6__30_n_0;
  wire g0_b6__31_n_0;
  wire g0_b6__32_n_0;
  wire g0_b6__33_n_0;
  wire g0_b6__34_n_0;
  wire g0_b6__35_n_0;
  wire g0_b6__3_n_0;
  wire g0_b6__4_n_0;
  wire g0_b6__5_n_0;
  wire g0_b6__6_n_0;
  wire g0_b6__7_n_0;
  wire g0_b6__8_n_0;
  wire g0_b6__9_n_0;
  wire g0_b6_n_0;
  wire g0_b7__0_n_0;
  wire g0_b7__10_n_0;
  wire g0_b7__11_n_0;
  wire g0_b7__12_n_0;
  wire g0_b7__13_n_0;
  wire g0_b7__14_n_0;
  wire g0_b7__15_n_0;
  wire g0_b7__16_n_0;
  wire g0_b7__17_n_0;
  wire g0_b7__18_n_0;
  wire g0_b7__19_n_0;
  wire g0_b7__1_n_0;
  wire g0_b7__20_n_0;
  wire g0_b7__21_n_0;
  wire g0_b7__22_n_0;
  wire g0_b7__23_n_0;
  wire g0_b7__24_n_0;
  wire g0_b7__25_n_0;
  wire g0_b7__26_n_0;
  wire g0_b7__27_n_0;
  wire g0_b7__28_n_0;
  wire g0_b7__29_n_0;
  wire g0_b7__2_n_0;
  wire g0_b7__30_n_0;
  wire g0_b7__31_n_0;
  wire g0_b7__32_n_0;
  wire g0_b7__3_n_0;
  wire g0_b7__4_n_0;
  wire g0_b7__5_n_0;
  wire g0_b7__6_n_0;
  wire g0_b7__7_n_0;
  wire g0_b7__8_n_0;
  wire g0_b7__9_n_0;
  wire g0_b7_i_10_n_0;
  wire g0_b7_i_11_n_0;
  wire g0_b7_i_12_n_0;
  wire g0_b7_i_13_n_0;
  wire g0_b7_i_14_n_0;
  wire g0_b7_i_15_n_0;
  wire g0_b7_i_16_n_0;
  wire g0_b7_i_1__0_n_0;
  wire g0_b7_i_1_n_0;
  wire g0_b7_i_2__0_n_0;
  wire g0_b7_i_3_n_0;
  wire g0_b7_i_4__0_n_0;
  wire g0_b7_i_5__0_n_0;
  wire g0_b7_i_5_n_0;
  wire g0_b7_i_6_n_0;
  wire g0_b7_i_7_n_0;
  wire g0_b7_i_8_n_0;
  wire g0_b7_i_9_n_0;
  wire g0_b7_n_0;
  wire g1_b0_n_0;
  wire g1_b1__0_n_0;
  wire g1_b1__10_n_0;
  wire g1_b1__11_n_0;
  wire g1_b1__12_n_0;
  wire g1_b1__13_n_0;
  wire g1_b1__14_n_0;
  wire g1_b1__15_n_0;
  wire g1_b1__16_n_0;
  wire g1_b1__1_n_0;
  wire g1_b1__2_n_0;
  wire g1_b1__3_n_0;
  wire g1_b1__4_n_0;
  wire g1_b1__5_n_0;
  wire g1_b1__6_n_0;
  wire g1_b1__7_n_0;
  wire g1_b1__8_n_0;
  wire g1_b1__9_n_0;
  wire g1_b1_n_0;
  wire g1_b2__0_n_0;
  wire g1_b2__10_n_0;
  wire g1_b2__11_n_0;
  wire g1_b2__12_n_0;
  wire g1_b2__13_n_0;
  wire g1_b2__14_n_0;
  wire g1_b2__15_n_0;
  wire g1_b2__16_n_0;
  wire g1_b2__17_n_0;
  wire g1_b2__1_n_0;
  wire g1_b2__2_n_0;
  wire g1_b2__3_n_0;
  wire g1_b2__4_n_0;
  wire g1_b2__5_n_0;
  wire g1_b2__6_n_0;
  wire g1_b2__7_n_0;
  wire g1_b2__8_n_0;
  wire g1_b2__9_n_0;
  wire g1_b2_n_0;
  wire g1_b3__0_n_0;
  wire g1_b3__10_n_0;
  wire g1_b3__11_n_0;
  wire g1_b3__12_n_0;
  wire g1_b3__13_n_0;
  wire g1_b3__14_n_0;
  wire g1_b3__15_n_0;
  wire g1_b3__16_n_0;
  wire g1_b3__17_n_0;
  wire g1_b3__1_n_0;
  wire g1_b3__2_n_0;
  wire g1_b3__3_n_0;
  wire g1_b3__4_n_0;
  wire g1_b3__5_n_0;
  wire g1_b3__6_n_0;
  wire g1_b3__7_n_0;
  wire g1_b3__8_n_0;
  wire g1_b3__9_n_0;
  wire g1_b3_n_0;
  wire g1_b4__0_n_0;
  wire g1_b4__10_n_0;
  wire g1_b4__11_n_0;
  wire g1_b4__12_n_0;
  wire g1_b4__13_n_0;
  wire g1_b4__14_n_0;
  wire g1_b4__15_n_0;
  wire g1_b4__16_n_0;
  wire g1_b4__17_n_0;
  wire g1_b4__1_n_0;
  wire g1_b4__2_n_0;
  wire g1_b4__3_n_0;
  wire g1_b4__4_n_0;
  wire g1_b4__5_n_0;
  wire g1_b4__6_n_0;
  wire g1_b4__7_n_0;
  wire g1_b4__8_n_0;
  wire g1_b4__9_n_0;
  wire g1_b4_n_0;
  wire g1_b5__0_n_0;
  wire g1_b5__10_n_0;
  wire g1_b5__11_n_0;
  wire g1_b5__12_n_0;
  wire g1_b5__13_n_0;
  wire g1_b5__14_n_0;
  wire g1_b5__15_n_0;
  wire g1_b5__1_n_0;
  wire g1_b5__2_n_0;
  wire g1_b5__3_n_0;
  wire g1_b5__4_n_0;
  wire g1_b5__5_n_0;
  wire g1_b5__6_n_0;
  wire g1_b5__7_n_0;
  wire g1_b5__8_n_0;
  wire g1_b5__9_n_0;
  wire g1_b5_n_0;
  wire g1_b6__0_n_0;
  wire g1_b6__10_n_0;
  wire g1_b6__11_n_0;
  wire g1_b6__12_n_0;
  wire g1_b6__13_n_0;
  wire g1_b6__14_n_0;
  wire g1_b6__15_n_0;
  wire g1_b6__1_n_0;
  wire g1_b6__2_n_0;
  wire g1_b6__3_n_0;
  wire g1_b6__4_n_0;
  wire g1_b6__5_n_0;
  wire g1_b6__6_n_0;
  wire g1_b6__7_n_0;
  wire g1_b6__8_n_0;
  wire g1_b6__9_n_0;
  wire g1_b6_n_0;
  wire g1_b7__0_n_0;
  wire g1_b7__10_n_0;
  wire g1_b7__11_n_0;
  wire g1_b7__12_n_0;
  wire g1_b7__1_n_0;
  wire g1_b7__2_n_0;
  wire g1_b7__3_n_0;
  wire g1_b7__4_n_0;
  wire g1_b7__5_n_0;
  wire g1_b7__6_n_0;
  wire g1_b7__7_n_0;
  wire g1_b7__8_n_0;
  wire g1_b7__9_n_0;
  wire g1_b7_n_0;
  wire [4:2]\ids[0]_0 ;
  wire \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ;
  wire \ids[0]_inferred__1/g0_b1_i_1_n_0 ;
  wire \ids[0]_inferred__1/g0_b1_i_2_n_0 ;
  wire \ids[0]_inferred__1/g0_b1_i_3_n_0 ;
  wire \ids[0]_inferred__1/g0_b1_i_4_n_0 ;
  wire \ids[0]_inferred__1/g0_b1_i_5_n_0 ;
  wire \ids[0]_inferred__1/g0_b1_i_6_n_0 ;
  wire [9:0]plusOp;
  wire \strnum_v[2][0]_i_1_n_0 ;
  wire \strnum_v[2][0]_i_2_n_0 ;
  wire \strnum_v[2][0]_i_3_n_0 ;
  wire \strnum_v[2][0]_i_4_n_0 ;
  wire \strnum_v[2][0]_i_5_n_0 ;
  wire \strnum_v[2][0]_i_6_n_0 ;
  wire \strnum_v[2][0]_i_7_n_0 ;
  wire \strnum_v[2][0]_i_8_n_0 ;
  wire \strnum_v[2][4]_i_1_n_0 ;
  wire \strnum_v[3][0]_i_1_n_0 ;
  wire \strnum_v[3][0]_i_2_n_0 ;
  wire \strnum_v[3][0]_i_3_n_0 ;
  wire \strnum_v[3][0]_i_4_n_0 ;
  wire \strnum_v[3][0]_i_5_n_0 ;
  wire \strnum_v[3][1]_i_1_n_0 ;
  wire \strnum_v[3][1]_i_2_n_0 ;
  wire \strnum_v[3][2]_i_1_n_0 ;
  wire \strnum_v[3][3]_i_1_n_0 ;
  wire \strnum_v[3][3]_i_2_n_0 ;
  wire \strnum_v[3][4]_i_1_n_0 ;
  wire \strnum_v[4][0]_i_1_n_0 ;
  wire \strnum_v[4][0]_i_2_n_0 ;
  wire \strnum_v[4][0]_i_3_n_0 ;
  wire \strnum_v[4][1]_i_1_n_0 ;
  wire \strnum_v[4][1]_i_2_n_0 ;
  wire \strnum_v[4][1]_i_3_n_0 ;
  wire \strnum_v[4][1]_i_4_n_0 ;
  wire \strnum_v[4][2]_i_1_n_0 ;
  wire \strnum_v[4][2]_i_2_n_0 ;
  wire \strnum_v[4][3]_i_1_n_0 ;
  wire \strnum_v[4][3]_i_2_n_0 ;
  wire \strnum_v[4][4]_i_1_n_0 ;
  wire \strnum_v[5][0]_i_1_n_0 ;
  wire \strnum_v[5][1]_i_1_n_0 ;
  wire \strnum_v[5][2]_i_1_n_0 ;
  wire \strnum_v[5][3]_i_1_n_0 ;
  wire \strnum_v[5][3]_i_2_n_0 ;
  wire \strnum_v[5][4]_i_1_n_0 ;
  wire \strnum_v_reg_n_0_[2][0] ;
  wire \strnum_v_reg_n_0_[2][4] ;
  wire \strnum_v_reg_n_0_[3][0] ;
  wire \strnum_v_reg_n_0_[3][1] ;
  wire \strnum_v_reg_n_0_[3][2] ;
  wire \strnum_v_reg_n_0_[3][3] ;
  wire \strnum_v_reg_n_0_[3][4] ;
  wire \strnum_v_reg_n_0_[4][0] ;
  wire \strnum_v_reg_n_0_[4][1] ;
  wire \strnum_v_reg_n_0_[4][2] ;
  wire \strnum_v_reg_n_0_[4][3] ;
  wire \strnum_v_reg_n_0_[4][4] ;
  wire \strnum_v_reg_n_0_[5][0] ;
  wire \strnum_v_reg_n_0_[5][1] ;
  wire \strnum_v_reg_n_0_[5][2] ;
  wire \strnum_v_reg_n_0_[5][3] ;
  wire \strnum_v_reg_n_0_[5][4] ;
  wire \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_61_n_0 ;
  wire \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_66_n_0 ;
  wire \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_71_n_0 ;
  wire \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_77_n_0 ;
  wire \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_83_n_0 ;
  wire \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_89_n_0 ;
  wire \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_95_n_0 ;
  wire \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_111_n_0 ;
  wire \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_143_n_0 ;
  wire \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_63_n_0 ;
  wire \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_71_n_0 ;
  wire \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_79_n_0 ;
  wire \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_86_n_0 ;
  wire \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_97_n_0 ;
  wire \vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_121_n_0 ;
  wire \vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_143_n_0 ;
  wire \vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_149_n_0 ;
  wire \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_105_n_0 ;
  wire \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_118_n_0 ;
  wire \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_131_n_0 ;
  wire \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_136_n_0 ;
  wire \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_75_n_0 ;
  wire \vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_120_n_0 ;
  wire \vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_142_n_0 ;
  wire \vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_148_n_0 ;
  wire \vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_104_n_0 ;
  wire \vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_117_n_0 ;
  wire \vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_94_n_0 ;
  wire \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_118_n_0 ;
  wire \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_126_n_0 ;
  wire \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_130_n_0 ;
  wire \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_134_n_0 ;
  wire \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_138_n_0 ;
  wire \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_140_n_0 ;
  wire \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_146_n_0 ;
  wire \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_102_n_0 ;
  wire \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_115_n_0 ;
  wire \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_135_n_0 ;
  wire \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_140_n_0 ;
  wire \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_68_n_0 ;
  wire \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_77_n_0 ;
  wire \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_92_n_0 ;
  wire \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_123_n_0 ;
  wire \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_127_n_0 ;
  wire \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_131_n_0 ;
  wire \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_135_n_0 ;
  wire \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_81_n_0 ;
  wire \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_87_n_0 ;
  wire \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_93_n_0 ;
  wire \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_128_n_0 ;
  wire \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_144_n_0 ;
  wire \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_65_n_0 ;
  wire \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_73_n_0 ;
  wire \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_88_n_0 ;
  wire \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_99_n_0 ;
  wire \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_124_n_0 ;
  wire \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_128_n_0 ;
  wire \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_132_n_0 ;
  wire \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_136_n_0 ;
  wire \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_82_n_0 ;
  wire \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_88_n_0 ;
  wire \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_94_n_0 ;
  wire \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_129_n_0 ;
  wire \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_145_n_0 ;
  wire \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_64_n_0 ;
  wire \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_72_n_0 ;
  wire \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_89_n_0 ;
  wire \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_98_n_0 ;

  LUT1 #(
    .INIT(2'h1)) 
    \BTN_CNTR[0]_i_1 
       (.I0(BTN_CNTR_reg[0]),
        .O(plusOp[0]));
  (* SOFT_HLUTNM = "soft_lutpair66" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \BTN_CNTR[1]_i_1 
       (.I0(BTN_CNTR_reg[0]),
        .I1(BTN_CNTR_reg[1]),
        .O(plusOp[1]));
  (* SOFT_HLUTNM = "soft_lutpair66" *) 
  LUT3 #(
    .INIT(8'h6A)) 
    \BTN_CNTR[2]_i_1 
       (.I0(BTN_CNTR_reg[2]),
        .I1(BTN_CNTR_reg[1]),
        .I2(BTN_CNTR_reg[0]),
        .O(plusOp[2]));
  (* SOFT_HLUTNM = "soft_lutpair46" *) 
  LUT4 #(
    .INIT(16'h6AAA)) 
    \BTN_CNTR[3]_i_1 
       (.I0(BTN_CNTR_reg[3]),
        .I1(BTN_CNTR_reg[2]),
        .I2(BTN_CNTR_reg[0]),
        .I3(BTN_CNTR_reg[1]),
        .O(plusOp[3]));
  (* SOFT_HLUTNM = "soft_lutpair46" *) 
  LUT5 #(
    .INIT(32'h6AAAAAAA)) 
    \BTN_CNTR[4]_i_1 
       (.I0(BTN_CNTR_reg[4]),
        .I1(BTN_CNTR_reg[3]),
        .I2(BTN_CNTR_reg[1]),
        .I3(BTN_CNTR_reg[0]),
        .I4(BTN_CNTR_reg[2]),
        .O(plusOp[4]));
  LUT6 #(
    .INIT(64'h6AAAAAAAAAAAAAAA)) 
    \BTN_CNTR[5]_i_1 
       (.I0(BTN_CNTR_reg[5]),
        .I1(BTN_CNTR_reg[4]),
        .I2(BTN_CNTR_reg[2]),
        .I3(BTN_CNTR_reg[0]),
        .I4(BTN_CNTR_reg[1]),
        .I5(BTN_CNTR_reg[3]),
        .O(plusOp[5]));
  (* SOFT_HLUTNM = "soft_lutpair67" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \BTN_CNTR[6]_i_1 
       (.I0(BTN_CNTR_reg[6]),
        .I1(\BTN_CNTR[9]_i_2_n_0 ),
        .O(plusOp[6]));
  (* SOFT_HLUTNM = "soft_lutpair67" *) 
  LUT3 #(
    .INIT(8'h6A)) 
    \BTN_CNTR[7]_i_1 
       (.I0(BTN_CNTR_reg[7]),
        .I1(BTN_CNTR_reg[6]),
        .I2(\BTN_CNTR[9]_i_2_n_0 ),
        .O(plusOp[7]));
  (* SOFT_HLUTNM = "soft_lutpair48" *) 
  LUT4 #(
    .INIT(16'h6AAA)) 
    \BTN_CNTR[8]_i_1 
       (.I0(BTN_CNTR_reg[8]),
        .I1(BTN_CNTR_reg[7]),
        .I2(\BTN_CNTR[9]_i_2_n_0 ),
        .I3(BTN_CNTR_reg[6]),
        .O(plusOp[8]));
  (* SOFT_HLUTNM = "soft_lutpair48" *) 
  LUT5 #(
    .INIT(32'h6AAAAAAA)) 
    \BTN_CNTR[9]_i_1 
       (.I0(BTN_CNTR_reg[9]),
        .I1(BTN_CNTR_reg[8]),
        .I2(BTN_CNTR_reg[6]),
        .I3(\BTN_CNTR[9]_i_2_n_0 ),
        .I4(BTN_CNTR_reg[7]),
        .O(plusOp[9]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \BTN_CNTR[9]_i_2 
       (.I0(BTN_CNTR_reg[4]),
        .I1(BTN_CNTR_reg[2]),
        .I2(BTN_CNTR_reg[0]),
        .I3(BTN_CNTR_reg[1]),
        .I4(BTN_CNTR_reg[3]),
        .I5(BTN_CNTR_reg[5]),
        .O(\BTN_CNTR[9]_i_2_n_0 ));
  FDRE \BTN_CNTR_reg[0] 
       (.C(CLK),
        .CE(BTN_PRESS_VALID_IN),
        .D(plusOp[0]),
        .Q(BTN_CNTR_reg[0]),
        .R(1'b0));
  FDRE \BTN_CNTR_reg[1] 
       (.C(CLK),
        .CE(BTN_PRESS_VALID_IN),
        .D(plusOp[1]),
        .Q(BTN_CNTR_reg[1]),
        .R(1'b0));
  FDRE \BTN_CNTR_reg[2] 
       (.C(CLK),
        .CE(BTN_PRESS_VALID_IN),
        .D(plusOp[2]),
        .Q(BTN_CNTR_reg[2]),
        .R(1'b0));
  FDRE \BTN_CNTR_reg[3] 
       (.C(CLK),
        .CE(BTN_PRESS_VALID_IN),
        .D(plusOp[3]),
        .Q(BTN_CNTR_reg[3]),
        .R(1'b0));
  FDRE \BTN_CNTR_reg[4] 
       (.C(CLK),
        .CE(BTN_PRESS_VALID_IN),
        .D(plusOp[4]),
        .Q(BTN_CNTR_reg[4]),
        .R(1'b0));
  FDRE \BTN_CNTR_reg[5] 
       (.C(CLK),
        .CE(BTN_PRESS_VALID_IN),
        .D(plusOp[5]),
        .Q(BTN_CNTR_reg[5]),
        .R(1'b0));
  FDRE \BTN_CNTR_reg[6] 
       (.C(CLK),
        .CE(BTN_PRESS_VALID_IN),
        .D(plusOp[6]),
        .Q(BTN_CNTR_reg[6]),
        .R(1'b0));
  FDRE \BTN_CNTR_reg[7] 
       (.C(CLK),
        .CE(BTN_PRESS_VALID_IN),
        .D(plusOp[7]),
        .Q(BTN_CNTR_reg[7]),
        .R(1'b0));
  FDRE \BTN_CNTR_reg[8] 
       (.C(CLK),
        .CE(BTN_PRESS_VALID_IN),
        .D(plusOp[8]),
        .Q(BTN_CNTR_reg[8]),
        .R(1'b0));
  FDRE \BTN_CNTR_reg[9] 
       (.C(CLK),
        .CE(BTN_PRESS_VALID_IN),
        .D(plusOp[9]),
        .Q(BTN_CNTR_reg[9]),
        .R(1'b0));
  LUT6 #(
    .INIT(64'h0001FFFF00010001)) 
    \B_OUT[3]_i_1 
       (.I0(\R_OUT[3]_i_2_n_0 ),
        .I1(\B_OUT[3]_i_2_n_0 ),
        .I2(X_IN[9]),
        .I3(\B_OUT_reg[3]_i_3_n_0 ),
        .I4(\B_OUT[3]_i_4_n_0 ),
        .I5(\B_OUT_reg[3]_i_5_n_0 ),
        .O(B_OUT0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \B_OUT[3]_i_10 
       (.I0(\B_OUT_reg[3]_i_20_n_0 ),
        .I1(\B_OUT_reg[3]_i_21_n_0 ),
        .I2(X_IN[1]),
        .I3(\B_OUT_reg[3]_i_22_n_0 ),
        .I4(X_IN[0]),
        .I5(\B_OUT_reg[3]_i_23_n_0 ),
        .O(\B_OUT[3]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hA0AFA0AFC0C0CFCF)) 
    \B_OUT[3]_i_11 
       (.I0(\B_OUT[3]_i_24_n_0 ),
        .I1(\B_OUT_reg[3]_i_25_n_0 ),
        .I2(X_IN[1]),
        .I3(\B_OUT_reg[3]_i_26_n_0 ),
        .I4(\B_OUT_reg[3]_i_27_n_0 ),
        .I5(X_IN[0]),
        .O(\B_OUT[3]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFEFFFFFFFFFFF)) 
    \B_OUT[3]_i_16 
       (.I0(Y_IN[0]),
        .I1(Y_IN[3]),
        .I2(Y_IN[2]),
        .I3(Y_IN[1]),
        .I4(\B_OUT[3]_i_36_n_0 ),
        .I5(g1_b1__14_n_0),
        .O(\B_OUT[3]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h8000800080000000)) 
    \B_OUT[3]_i_2 
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[5]),
        .I4(X_IN[4]),
        .I5(X_IN[3]),
        .O(\B_OUT[3]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h00000080)) 
    \B_OUT[3]_i_24 
       (.I0(Y_IN[1]),
        .I1(1'b0),
        .I2(Y_IN[2]),
        .I3(Y_IN[0]),
        .I4(Y_IN[3]),
        .O(\B_OUT[3]_i_24_n_0 ));
  LUT5 #(
    .INIT(32'hAFA0C0C0)) 
    \B_OUT[3]_i_28 
       (.I0(\B_OUT_reg[3]_i_57_n_0 ),
        .I1(\B_OUT_reg[3]_i_58_n_0 ),
        .I2(Y_IN[2]),
        .I3(\B_OUT_reg[3]_i_59_n_0 ),
        .I4(Y_IN[1]),
        .O(\B_OUT[3]_i_28_n_0 ));
  LUT6 #(
    .INIT(64'h0A0A0A0A0CFF0C00)) 
    \B_OUT[3]_i_29 
       (.I0(\B_OUT[3]_i_60_n_0 ),
        .I1(\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_61_n_0 ),
        .I2(Y_IN[0]),
        .I3(Y_IN[1]),
        .I4(\B_OUT_reg[3]_i_62_n_0 ),
        .I5(Y_IN[2]),
        .O(\B_OUT[3]_i_29_n_0 ));
  LUT5 #(
    .INIT(32'hAFA0C0C0)) 
    \B_OUT[3]_i_30 
       (.I0(\B_OUT_reg[3]_i_63_n_0 ),
        .I1(\B_OUT[3]_i_64_n_0 ),
        .I2(Y_IN[2]),
        .I3(\B_OUT[3]_i_65_n_0 ),
        .I4(Y_IN[1]),
        .O(\B_OUT[3]_i_30_n_0 ));
  LUT6 #(
    .INIT(64'h22222222B8FFB800)) 
    \B_OUT[3]_i_31 
       (.I0(\B_OUT[3]_i_60_n_0 ),
        .I1(Y_IN[0]),
        .I2(\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_66_n_0 ),
        .I3(Y_IN[1]),
        .I4(\B_OUT_reg[3]_i_67_n_0 ),
        .I5(Y_IN[2]),
        .O(\B_OUT[3]_i_31_n_0 ));
  LUT5 #(
    .INIT(32'h303F5F5F)) 
    \B_OUT[3]_i_32 
       (.I0(\B_OUT[3]_i_68_n_0 ),
        .I1(\B_OUT_reg[3]_i_69_n_0 ),
        .I2(Y_IN[1]),
        .I3(\B_OUT[3]_i_70_n_0 ),
        .I4(Y_IN[2]),
        .O(\B_OUT[3]_i_32_n_0 ));
  LUT6 #(
    .INIT(64'hB2B7A2A2B2B7F7F7)) 
    \B_OUT[3]_i_33 
       (.I0(Y_IN[2]),
        .I1(\B_OUT[3]_i_60_n_0 ),
        .I2(Y_IN[0]),
        .I3(\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_71_n_0 ),
        .I4(Y_IN[1]),
        .I5(\B_OUT_reg[3]_i_72_n_0 ),
        .O(\B_OUT[3]_i_33_n_0 ));
  LUT5 #(
    .INIT(32'h55330FFF)) 
    \B_OUT[3]_i_34 
       (.I0(\B_OUT_reg[3]_i_73_n_0 ),
        .I1(\B_OUT[3]_i_74_n_0 ),
        .I2(\B_OUT[3]_i_75_n_0 ),
        .I3(Y_IN[1]),
        .I4(Y_IN[2]),
        .O(\B_OUT[3]_i_34_n_0 ));
  LUT6 #(
    .INIT(64'hFF44FF77CF47CF47)) 
    \B_OUT[3]_i_35 
       (.I0(\B_OUT[3]_i_60_n_0 ),
        .I1(Y_IN[2]),
        .I2(\B_OUT_reg[3]_i_76_n_0 ),
        .I3(Y_IN[0]),
        .I4(\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_77_n_0 ),
        .I5(Y_IN[1]),
        .O(\B_OUT[3]_i_35_n_0 ));
  LUT6 #(
    .INIT(64'h002AAA2AA8A2AA00)) 
    \B_OUT[3]_i_36 
       (.I0(X_IN[8]),
        .I1(X_IN[3]),
        .I2(X_IN[4]),
        .I3(X_IN[5]),
        .I4(X_IN[6]),
        .I5(X_IN[7]),
        .O(\B_OUT[3]_i_36_n_0 ));
  LUT5 #(
    .INIT(32'h303F5F5F)) 
    \B_OUT[3]_i_37 
       (.I0(\B_OUT[3]_i_78_n_0 ),
        .I1(\B_OUT_reg[3]_i_79_n_0 ),
        .I2(Y_IN[1]),
        .I3(\B_OUT[3]_i_80_n_0 ),
        .I4(Y_IN[2]),
        .O(\B_OUT[3]_i_37_n_0 ));
  LUT6 #(
    .INIT(64'hFAFAABFBFFFFABFB)) 
    \B_OUT[3]_i_38 
       (.I0(Y_IN[2]),
        .I1(\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_81_n_0 ),
        .I2(Y_IN[0]),
        .I3(\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_82_n_0 ),
        .I4(Y_IN[1]),
        .I5(\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_83_n_0 ),
        .O(\B_OUT[3]_i_38_n_0 ));
  LUT5 #(
    .INIT(32'hAFA0C0C0)) 
    \B_OUT[3]_i_39 
       (.I0(\B_OUT_reg[3]_i_84_n_0 ),
        .I1(\B_OUT_reg[3]_i_85_n_0 ),
        .I2(Y_IN[2]),
        .I3(\B_OUT_reg[3]_i_86_n_0 ),
        .I4(Y_IN[1]),
        .O(\B_OUT[3]_i_39_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFA888)) 
    \B_OUT[3]_i_4 
       (.I0(\B_OUT[3]_i_8_n_0 ),
        .I1(X_IN[5]),
        .I2(X_IN[3]),
        .I3(X_IN[4]),
        .I4(\B_OUT[3]_i_9_n_0 ),
        .I5(\R_OUT[3]_i_6_n_0 ),
        .O(\B_OUT[3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \B_OUT[3]_i_40 
       (.I0(\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_87_n_0 ),
        .I1(Y_IN[0]),
        .I2(\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_88_n_0 ),
        .I3(Y_IN[1]),
        .I4(\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_89_n_0 ),
        .I5(Y_IN[2]),
        .O(\B_OUT[3]_i_40_n_0 ));
  LUT5 #(
    .INIT(32'hAFA0C0C0)) 
    \B_OUT[3]_i_41 
       (.I0(\B_OUT_reg[3]_i_90_n_0 ),
        .I1(\B_OUT_reg[3]_i_91_n_0 ),
        .I2(Y_IN[2]),
        .I3(\B_OUT_reg[3]_i_92_n_0 ),
        .I4(Y_IN[1]),
        .O(\B_OUT[3]_i_41_n_0 ));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \B_OUT[3]_i_42 
       (.I0(\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_93_n_0 ),
        .I1(Y_IN[0]),
        .I2(\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_94_n_0 ),
        .I3(Y_IN[1]),
        .I4(\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_95_n_0 ),
        .I5(Y_IN[2]),
        .O(\B_OUT[3]_i_42_n_0 ));
  LUT5 #(
    .INIT(32'hAFA0C0C0)) 
    \B_OUT[3]_i_43 
       (.I0(\B_OUT_reg[3]_i_96_n_0 ),
        .I1(\B_OUT_reg[3]_i_97_n_0 ),
        .I2(Y_IN[2]),
        .I3(\B_OUT_reg[3]_i_98_n_0 ),
        .I4(Y_IN[1]),
        .O(\B_OUT[3]_i_43_n_0 ));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \B_OUT[3]_i_44 
       (.I0(g0_b4__34_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b4__27_n_0),
        .I3(Y_IN[1]),
        .I4(g0_b4__35_n_0),
        .I5(Y_IN[2]),
        .O(\B_OUT[3]_i_44_n_0 ));
  LUT5 #(
    .INIT(32'hAFA0C0C0)) 
    \B_OUT[3]_i_45 
       (.I0(\B_OUT_reg[3]_i_99_n_0 ),
        .I1(\B_OUT_reg[3]_i_100_n_0 ),
        .I2(Y_IN[2]),
        .I3(\B_OUT_reg[3]_i_101_n_0 ),
        .I4(Y_IN[1]),
        .O(\B_OUT[3]_i_45_n_0 ));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \B_OUT[3]_i_46 
       (.I0(1'b0),
        .I1(Y_IN[0]),
        .I2(g0_b5__27_n_0),
        .I3(Y_IN[1]),
        .I4(g0_b5__34_n_0),
        .I5(Y_IN[2]),
        .O(\B_OUT[3]_i_46_n_0 ));
  LUT5 #(
    .INIT(32'hAFA0C0C0)) 
    \B_OUT[3]_i_47 
       (.I0(\B_OUT_reg[3]_i_102_n_0 ),
        .I1(\B_OUT_reg[3]_i_103_n_0 ),
        .I2(Y_IN[2]),
        .I3(\B_OUT_reg[3]_i_104_n_0 ),
        .I4(Y_IN[1]),
        .O(\B_OUT[3]_i_47_n_0 ));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \B_OUT[3]_i_48 
       (.I0(g0_b6__34_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b6__27_n_0),
        .I3(Y_IN[1]),
        .I4(g0_b6__35_n_0),
        .I5(Y_IN[2]),
        .O(\B_OUT[3]_i_48_n_0 ));
  LUT5 #(
    .INIT(32'hAFA0C0C0)) 
    \B_OUT[3]_i_49 
       (.I0(\B_OUT_reg[3]_i_105_n_0 ),
        .I1(\B_OUT_reg[3]_i_106_n_0 ),
        .I2(Y_IN[2]),
        .I3(\B_OUT_reg[3]_i_107_n_0 ),
        .I4(Y_IN[1]),
        .O(\B_OUT[3]_i_49_n_0 ));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \B_OUT[3]_i_50 
       (.I0(g0_b7__32_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b7__26_n_0),
        .I3(Y_IN[1]),
        .I4(1'b0),
        .I5(Y_IN[2]),
        .O(\B_OUT[3]_i_50_n_0 ));
  LUT5 #(
    .INIT(32'hAFA0C0C0)) 
    \B_OUT[3]_i_51 
       (.I0(\B_OUT_reg[3]_i_108_n_0 ),
        .I1(\B_OUT_reg[3]_i_109_n_0 ),
        .I2(Y_IN[2]),
        .I3(\B_OUT_reg[3]_i_110_n_0 ),
        .I4(Y_IN[1]),
        .O(\B_OUT[3]_i_51_n_0 ));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \B_OUT[3]_i_52 
       (.I0(g0_b1__34_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b1__27_n_0),
        .I3(Y_IN[1]),
        .I4(g0_b1__35_n_0),
        .I5(Y_IN[2]),
        .O(\B_OUT[3]_i_52_n_0 ));
  LUT5 #(
    .INIT(32'h503F5F3F)) 
    \B_OUT[3]_i_53 
       (.I0(\B_OUT_reg[3]_i_111_n_0 ),
        .I1(\B_OUT_reg[3]_i_112_n_0 ),
        .I2(Y_IN[2]),
        .I3(Y_IN[1]),
        .I4(\B_OUT_reg[3]_i_113_n_0 ),
        .O(\B_OUT[3]_i_53_n_0 ));
  LUT6 #(
    .INIT(64'hFAFAABFBFFFFABFB)) 
    \B_OUT[3]_i_54 
       (.I0(Y_IN[2]),
        .I1(g0_b2__34_n_0),
        .I2(Y_IN[0]),
        .I3(g0_b2__27_n_0),
        .I4(Y_IN[1]),
        .I5(g0_b2__35_n_0),
        .O(\B_OUT[3]_i_54_n_0 ));
  LUT5 #(
    .INIT(32'h503F5F3F)) 
    \B_OUT[3]_i_55 
       (.I0(\B_OUT_reg[3]_i_114_n_0 ),
        .I1(\B_OUT_reg[3]_i_115_n_0 ),
        .I2(Y_IN[2]),
        .I3(Y_IN[1]),
        .I4(\B_OUT_reg[3]_i_116_n_0 ),
        .O(\B_OUT[3]_i_55_n_0 ));
  LUT6 #(
    .INIT(64'hFAFAABFBFFFFABFB)) 
    \B_OUT[3]_i_56 
       (.I0(Y_IN[2]),
        .I1(g0_b3__34_n_0),
        .I2(Y_IN[0]),
        .I3(g0_b3__27_n_0),
        .I4(Y_IN[1]),
        .I5(g0_b3__35_n_0),
        .O(\B_OUT[3]_i_56_n_0 ));
  LUT6 #(
    .INIT(64'h5F503F3F5F503030)) 
    \B_OUT[3]_i_6 
       (.I0(\B_OUT_reg[3]_i_12_n_0 ),
        .I1(\B_OUT_reg[3]_i_13_n_0 ),
        .I2(X_IN[1]),
        .I3(\B_OUT_reg[3]_i_14_n_0 ),
        .I4(X_IN[0]),
        .I5(\B_OUT_reg[3]_i_15_n_0 ),
        .O(\B_OUT[3]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000200000)) 
    \B_OUT[3]_i_60 
       (.I0(X_IN[8]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[3]),
        .O(\B_OUT[3]_i_60_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \B_OUT[3]_i_64 
       (.I0(g1_b5__0_n_0),
        .I1(g0_b5__2_n_0),
        .I2(Y_IN[0]),
        .I3(g1_b5__14_n_0),
        .I4(\B_OUT[3]_i_36_n_0 ),
        .I5(g0_b5__1_n_0),
        .O(\B_OUT[3]_i_64_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \B_OUT[3]_i_65 
       (.I0(g1_b5__14_n_0),
        .I1(g0_b5__0_n_0),
        .I2(Y_IN[0]),
        .I3(g1_b5_n_0),
        .I4(\B_OUT[3]_i_36_n_0 ),
        .I5(g0_b5_n_0),
        .O(\B_OUT[3]_i_65_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \B_OUT[3]_i_68 
       (.I0(g1_b6__14_n_0),
        .I1(g0_b6__0_n_0),
        .I2(Y_IN[0]),
        .I3(g1_b6_n_0),
        .I4(\B_OUT[3]_i_36_n_0 ),
        .I5(g0_b6_n_0),
        .O(\B_OUT[3]_i_68_n_0 ));
  LUT6 #(
    .INIT(64'hA0AFC0C0A0AFCFCF)) 
    \B_OUT[3]_i_7 
       (.I0(\B_OUT[3]_i_16_n_0 ),
        .I1(\B_OUT_reg[3]_i_17_n_0 ),
        .I2(X_IN[1]),
        .I3(\B_OUT_reg[3]_i_18_n_0 ),
        .I4(X_IN[0]),
        .I5(\B_OUT_reg[3]_i_19_n_0 ),
        .O(\B_OUT[3]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \B_OUT[3]_i_70 
       (.I0(g1_b6__0_n_0),
        .I1(g0_b6__2_n_0),
        .I2(Y_IN[0]),
        .I3(g1_b6__14_n_0),
        .I4(\B_OUT[3]_i_36_n_0 ),
        .I5(g0_b6__1_n_0),
        .O(\B_OUT[3]_i_70_n_0 ));
  LUT5 #(
    .INIT(32'hA0A0CFC0)) 
    \B_OUT[3]_i_74 
       (.I0(g1_b7__0_n_0),
        .I1(g0_b7__3_n_0),
        .I2(Y_IN[0]),
        .I3(g0_b7__2_n_0),
        .I4(\B_OUT[3]_i_36_n_0 ),
        .O(\B_OUT[3]_i_74_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \B_OUT[3]_i_75 
       (.I0(g0_b7__1_n_0),
        .I1(Y_IN[0]),
        .I2(g1_b7_n_0),
        .I3(\B_OUT[3]_i_36_n_0 ),
        .I4(g0_b7__0_n_0),
        .O(\B_OUT[3]_i_75_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \B_OUT[3]_i_78 
       (.I0(g1_b1__14_n_0),
        .I1(g0_b1__0_n_0),
        .I2(Y_IN[0]),
        .I3(g1_b1_n_0),
        .I4(\B_OUT[3]_i_36_n_0 ),
        .I5(g0_b1_n_0),
        .O(\B_OUT[3]_i_78_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \B_OUT[3]_i_8 
       (.I0(X_IN[6]),
        .I1(X_IN[7]),
        .I2(X_IN[8]),
        .O(\B_OUT[3]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'hA0A0CFC0)) 
    \B_OUT[3]_i_80 
       (.I0(g1_b1__0_n_0),
        .I1(g0_b1__2_n_0),
        .I2(Y_IN[0]),
        .I3(g0_b1__1_n_0),
        .I4(\B_OUT[3]_i_36_n_0 ),
        .O(\B_OUT[3]_i_80_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFF80)) 
    \B_OUT[3]_i_9 
       (.I0(Y_IN[2]),
        .I1(Y_IN[1]),
        .I2(Y_IN[3]),
        .I3(Y_IN[4]),
        .I4(Y_IN[5]),
        .I5(X_IN[9]),
        .O(\B_OUT[3]_i_9_n_0 ));
  FDRE \B_OUT_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(B_OUT0),
        .Q(B_OUT),
        .R(1'b0));
  MUXF7 \B_OUT_reg[3]_i_100 
       (.I0(g0_b5__32_n_0),
        .I1(g0_b5__29_n_0),
        .O(\B_OUT_reg[3]_i_100_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_101 
       (.I0(g0_b5__31_n_0),
        .I1(g0_b5__30_n_0),
        .O(\B_OUT_reg[3]_i_101_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_102 
       (.I0(g0_b6__33_n_0),
        .I1(g0_b6__28_n_0),
        .O(\B_OUT_reg[3]_i_102_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_103 
       (.I0(g0_b6__32_n_0),
        .I1(g0_b6__29_n_0),
        .O(\B_OUT_reg[3]_i_103_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_104 
       (.I0(g0_b6__31_n_0),
        .I1(g0_b6__30_n_0),
        .O(\B_OUT_reg[3]_i_104_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_105 
       (.I0(g0_b7__31_n_0),
        .I1(g0_b7__27_n_0),
        .O(\B_OUT_reg[3]_i_105_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_106 
       (.I0(g0_b7__30_n_0),
        .I1(g0_b7__28_n_0),
        .O(\B_OUT_reg[3]_i_106_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_107 
       (.I0(1'b0),
        .I1(g0_b7__29_n_0),
        .O(\B_OUT_reg[3]_i_107_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_108 
       (.I0(g0_b1__33_n_0),
        .I1(g0_b1__28_n_0),
        .O(\B_OUT_reg[3]_i_108_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_109 
       (.I0(g0_b1__32_n_0),
        .I1(g0_b1__29_n_0),
        .O(\B_OUT_reg[3]_i_109_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_110 
       (.I0(g0_b1__31_n_0),
        .I1(g0_b1__30_n_0),
        .O(\B_OUT_reg[3]_i_110_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_111 
       (.I0(g0_b2__33_n_0),
        .I1(g0_b2__28_n_0),
        .O(\B_OUT_reg[3]_i_111_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_112 
       (.I0(g0_b2__32_n_0),
        .I1(g0_b2__29_n_0),
        .O(\B_OUT_reg[3]_i_112_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_113 
       (.I0(g0_b2__31_n_0),
        .I1(g0_b2__30_n_0),
        .O(\B_OUT_reg[3]_i_113_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_114 
       (.I0(g0_b3__33_n_0),
        .I1(g0_b3__28_n_0),
        .O(\B_OUT_reg[3]_i_114_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_115 
       (.I0(g0_b3__32_n_0),
        .I1(g0_b3__29_n_0),
        .O(\B_OUT_reg[3]_i_115_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_116 
       (.I0(g0_b3__31_n_0),
        .I1(g0_b3__30_n_0),
        .O(\B_OUT_reg[3]_i_116_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_117 
       (.I0(g0_b4__3_n_0),
        .I1(g1_b4__3_n_0),
        .O(\B_OUT_reg[3]_i_117_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \B_OUT_reg[3]_i_119 
       (.I0(g0_b4__1_n_0),
        .I1(g1_b4__1_n_0),
        .O(\B_OUT_reg[3]_i_119_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \B_OUT_reg[3]_i_12 
       (.I0(\B_OUT[3]_i_28_n_0 ),
        .I1(\B_OUT[3]_i_29_n_0 ),
        .O(\B_OUT_reg[3]_i_12_n_0 ),
        .S(Y_IN[3]));
  MUXF7 \B_OUT_reg[3]_i_122 
       (.I0(g0_b4__0_n_0),
        .I1(g1_b4__0_n_0),
        .O(\B_OUT_reg[3]_i_122_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \B_OUT_reg[3]_i_125 
       (.I0(g0_b5__3_n_0),
        .I1(g1_b5__1_n_0),
        .O(\B_OUT_reg[3]_i_125_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \B_OUT_reg[3]_i_129 
       (.I0(g0_b6__3_n_0),
        .I1(g1_b6__1_n_0),
        .O(\B_OUT_reg[3]_i_129_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \B_OUT_reg[3]_i_13 
       (.I0(\B_OUT[3]_i_30_n_0 ),
        .I1(\B_OUT[3]_i_31_n_0 ),
        .O(\B_OUT_reg[3]_i_13_n_0 ),
        .S(Y_IN[3]));
  MUXF7 \B_OUT_reg[3]_i_133 
       (.I0(g0_b7__4_n_0),
        .I1(g1_b7__1_n_0),
        .O(\B_OUT_reg[3]_i_133_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \B_OUT_reg[3]_i_137 
       (.I0(g0_b1__3_n_0),
        .I1(g1_b1__1_n_0),
        .O(\B_OUT_reg[3]_i_137_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \B_OUT_reg[3]_i_139 
       (.I0(g0_b2__3_n_0),
        .I1(g1_b2__3_n_0),
        .O(\B_OUT_reg[3]_i_139_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \B_OUT_reg[3]_i_14 
       (.I0(\B_OUT[3]_i_32_n_0 ),
        .I1(\B_OUT[3]_i_33_n_0 ),
        .O(\B_OUT_reg[3]_i_14_n_0 ),
        .S(Y_IN[3]));
  MUXF7 \B_OUT_reg[3]_i_141 
       (.I0(g0_b2__1_n_0),
        .I1(g1_b2__1_n_0),
        .O(\B_OUT_reg[3]_i_141_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \B_OUT_reg[3]_i_144 
       (.I0(g0_b2__0_n_0),
        .I1(g1_b2__0_n_0),
        .O(\B_OUT_reg[3]_i_144_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \B_OUT_reg[3]_i_145 
       (.I0(g0_b3__3_n_0),
        .I1(g1_b3__3_n_0),
        .O(\B_OUT_reg[3]_i_145_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \B_OUT_reg[3]_i_147 
       (.I0(g0_b3__1_n_0),
        .I1(g1_b3__1_n_0),
        .O(\B_OUT_reg[3]_i_147_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \B_OUT_reg[3]_i_15 
       (.I0(\B_OUT[3]_i_34_n_0 ),
        .I1(\B_OUT[3]_i_35_n_0 ),
        .O(\B_OUT_reg[3]_i_15_n_0 ),
        .S(Y_IN[3]));
  MUXF7 \B_OUT_reg[3]_i_150 
       (.I0(g0_b3__0_n_0),
        .I1(g1_b3__0_n_0),
        .O(\B_OUT_reg[3]_i_150_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \B_OUT_reg[3]_i_17 
       (.I0(\B_OUT[3]_i_37_n_0 ),
        .I1(\B_OUT[3]_i_38_n_0 ),
        .O(\B_OUT_reg[3]_i_17_n_0 ),
        .S(Y_IN[3]));
  MUXF7 \B_OUT_reg[3]_i_18 
       (.I0(\B_OUT[3]_i_39_n_0 ),
        .I1(\B_OUT[3]_i_40_n_0 ),
        .O(\B_OUT_reg[3]_i_18_n_0 ),
        .S(Y_IN[3]));
  MUXF7 \B_OUT_reg[3]_i_19 
       (.I0(\B_OUT[3]_i_41_n_0 ),
        .I1(\B_OUT[3]_i_42_n_0 ),
        .O(\B_OUT_reg[3]_i_19_n_0 ),
        .S(Y_IN[3]));
  MUXF7 \B_OUT_reg[3]_i_20 
       (.I0(\B_OUT[3]_i_43_n_0 ),
        .I1(\B_OUT[3]_i_44_n_0 ),
        .O(\B_OUT_reg[3]_i_20_n_0 ),
        .S(Y_IN[3]));
  MUXF7 \B_OUT_reg[3]_i_21 
       (.I0(\B_OUT[3]_i_45_n_0 ),
        .I1(\B_OUT[3]_i_46_n_0 ),
        .O(\B_OUT_reg[3]_i_21_n_0 ),
        .S(Y_IN[3]));
  MUXF7 \B_OUT_reg[3]_i_22 
       (.I0(\B_OUT[3]_i_47_n_0 ),
        .I1(\B_OUT[3]_i_48_n_0 ),
        .O(\B_OUT_reg[3]_i_22_n_0 ),
        .S(Y_IN[3]));
  MUXF7 \B_OUT_reg[3]_i_23 
       (.I0(\B_OUT[3]_i_49_n_0 ),
        .I1(\B_OUT[3]_i_50_n_0 ),
        .O(\B_OUT_reg[3]_i_23_n_0 ),
        .S(Y_IN[3]));
  MUXF7 \B_OUT_reg[3]_i_25 
       (.I0(\B_OUT[3]_i_51_n_0 ),
        .I1(\B_OUT[3]_i_52_n_0 ),
        .O(\B_OUT_reg[3]_i_25_n_0 ),
        .S(Y_IN[3]));
  MUXF7 \B_OUT_reg[3]_i_26 
       (.I0(\B_OUT[3]_i_53_n_0 ),
        .I1(\B_OUT[3]_i_54_n_0 ),
        .O(\B_OUT_reg[3]_i_26_n_0 ),
        .S(Y_IN[3]));
  MUXF7 \B_OUT_reg[3]_i_27 
       (.I0(\B_OUT[3]_i_55_n_0 ),
        .I1(\B_OUT[3]_i_56_n_0 ),
        .O(\B_OUT_reg[3]_i_27_n_0 ),
        .S(Y_IN[3]));
  MUXF7 \B_OUT_reg[3]_i_3 
       (.I0(\B_OUT[3]_i_6_n_0 ),
        .I1(\B_OUT[3]_i_7_n_0 ),
        .O(\B_OUT_reg[3]_i_3_n_0 ),
        .S(X_IN[2]));
  MUXF7 \B_OUT_reg[3]_i_5 
       (.I0(\B_OUT[3]_i_10_n_0 ),
        .I1(\B_OUT[3]_i_11_n_0 ),
        .O(\B_OUT_reg[3]_i_5_n_0 ),
        .S(X_IN[2]));
  MUXF8 \B_OUT_reg[3]_i_57 
       (.I0(\B_OUT_reg[3]_i_117_n_0 ),
        .I1(\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_118_n_0 ),
        .O(\B_OUT_reg[3]_i_57_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \B_OUT_reg[3]_i_58 
       (.I0(\B_OUT_reg[3]_i_119_n_0 ),
        .I1(\vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_120_n_0 ),
        .O(\B_OUT_reg[3]_i_58_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \B_OUT_reg[3]_i_59 
       (.I0(\vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_121_n_0 ),
        .I1(\B_OUT_reg[3]_i_122_n_0 ),
        .O(\B_OUT_reg[3]_i_59_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \B_OUT_reg[3]_i_62 
       (.I0(\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_123_n_0 ),
        .I1(\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_124_n_0 ),
        .O(\B_OUT_reg[3]_i_62_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \B_OUT_reg[3]_i_63 
       (.I0(\B_OUT_reg[3]_i_125_n_0 ),
        .I1(\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_126_n_0 ),
        .O(\B_OUT_reg[3]_i_63_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \B_OUT_reg[3]_i_67 
       (.I0(\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_127_n_0 ),
        .I1(\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_128_n_0 ),
        .O(\B_OUT_reg[3]_i_67_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \B_OUT_reg[3]_i_69 
       (.I0(\B_OUT_reg[3]_i_129_n_0 ),
        .I1(\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_130_n_0 ),
        .O(\B_OUT_reg[3]_i_69_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \B_OUT_reg[3]_i_72 
       (.I0(\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_131_n_0 ),
        .I1(\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_132_n_0 ),
        .O(\B_OUT_reg[3]_i_72_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \B_OUT_reg[3]_i_73 
       (.I0(\B_OUT_reg[3]_i_133_n_0 ),
        .I1(\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_134_n_0 ),
        .O(\B_OUT_reg[3]_i_73_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \B_OUT_reg[3]_i_76 
       (.I0(\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_135_n_0 ),
        .I1(\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_136_n_0 ),
        .O(\B_OUT_reg[3]_i_76_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \B_OUT_reg[3]_i_79 
       (.I0(\B_OUT_reg[3]_i_137_n_0 ),
        .I1(\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_138_n_0 ),
        .O(\B_OUT_reg[3]_i_79_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \B_OUT_reg[3]_i_84 
       (.I0(\B_OUT_reg[3]_i_139_n_0 ),
        .I1(\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_140_n_0 ),
        .O(\B_OUT_reg[3]_i_84_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \B_OUT_reg[3]_i_85 
       (.I0(\B_OUT_reg[3]_i_141_n_0 ),
        .I1(\vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_142_n_0 ),
        .O(\B_OUT_reg[3]_i_85_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \B_OUT_reg[3]_i_86 
       (.I0(\vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_143_n_0 ),
        .I1(\B_OUT_reg[3]_i_144_n_0 ),
        .O(\B_OUT_reg[3]_i_86_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \B_OUT_reg[3]_i_90 
       (.I0(\B_OUT_reg[3]_i_145_n_0 ),
        .I1(\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_146_n_0 ),
        .O(\B_OUT_reg[3]_i_90_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \B_OUT_reg[3]_i_91 
       (.I0(\B_OUT_reg[3]_i_147_n_0 ),
        .I1(\vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_148_n_0 ),
        .O(\B_OUT_reg[3]_i_91_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \B_OUT_reg[3]_i_92 
       (.I0(\vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_149_n_0 ),
        .I1(\B_OUT_reg[3]_i_150_n_0 ),
        .O(\B_OUT_reg[3]_i_92_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_96 
       (.I0(g0_b4__33_n_0),
        .I1(g0_b4__28_n_0),
        .O(\B_OUT_reg[3]_i_96_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_97 
       (.I0(g0_b4__32_n_0),
        .I1(g0_b4__29_n_0),
        .O(\B_OUT_reg[3]_i_97_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_98 
       (.I0(g0_b4__31_n_0),
        .I1(g0_b4__30_n_0),
        .O(\B_OUT_reg[3]_i_98_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \B_OUT_reg[3]_i_99 
       (.I0(g0_b5__33_n_0),
        .I1(g0_b5__28_n_0),
        .O(\B_OUT_reg[3]_i_99_n_0 ),
        .S(Y_IN[0]));
  LUT5 #(
    .INIT(32'hFFFF0100)) 
    \G_OUT[3]_i_1 
       (.I0(\G_OUT[3]_i_2_n_0 ),
        .I1(\G_OUT[3]_i_3_n_0 ),
        .I2(\G_OUT[3]_i_4_n_0 ),
        .I3(\G_OUT_reg[3]_i_5_n_0 ),
        .I4(B_OUT0),
        .O(G_OUT0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \G_OUT[3]_i_10 
       (.I0(\G_OUT_reg[3]_i_19_n_0 ),
        .I1(\G_OUT[3]_i_20_n_0 ),
        .I2(X_IN[0]),
        .I3(\G_OUT[3]_i_21_n_0 ),
        .I4(Y_IN[3]),
        .I5(\G_OUT[3]_i_22_n_0 ),
        .O(\G_OUT[3]_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT5 #(
    .INIT(32'h7EFFFFF3)) 
    \G_OUT[3]_i_100 
       (.I0(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .O(\G_OUT[3]_i_100_n_0 ));
  LUT6 #(
    .INIT(64'hFFFBFFFFFFFFFFFD)) 
    \G_OUT[3]_i_107 
       (.I0(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I5(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .O(\G_OUT[3]_i_107_n_0 ));
  LUT6 #(
    .INIT(64'hF7FFEFFFFFCFFFFF)) 
    \G_OUT[3]_i_108 
       (.I0(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I2(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .O(\G_OUT[3]_i_108_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hFCFFBFFF)) 
    \G_OUT[3]_i_109 
       (.I0(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .O(\G_OUT[3]_i_109_n_0 ));
  LUT6 #(
    .INIT(64'hAAAEFFFFAAAE0000)) 
    \G_OUT[3]_i_11 
       (.I0(\G_OUT[3]_i_23_n_0 ),
        .I1(g1_b1__15_n_0),
        .I2(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I3(\G_OUT[3]_i_25_n_0 ),
        .I4(X_IN[0]),
        .I5(\G_OUT_reg[3]_i_26_n_0 ),
        .O(\G_OUT[3]_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair41" *) 
  LUT5 #(
    .INIT(32'h00F02000)) 
    \G_OUT[3]_i_110 
       (.I0(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I2(Y_IN[0]),
        .I3(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I4(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .O(\G_OUT[3]_i_110_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT4 #(
    .INIT(16'hFFEF)) 
    \G_OUT[3]_i_112 
       (.I0(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .O(\G_OUT[3]_i_112_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \G_OUT[3]_i_113 
       (.I0(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .O(\G_OUT[3]_i_113_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair40" *) 
  LUT5 #(
    .INIT(32'h7FFFFFFC)) 
    \G_OUT[3]_i_120 
       (.I0(Y_IN[0]),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .O(\G_OUT[3]_i_120_n_0 ));
  LUT5 #(
    .INIT(32'hA0A0CFC0)) 
    \G_OUT[3]_i_122 
       (.I0(g1_b1__8_n_0),
        .I1(g0_b1__12_n_0),
        .I2(Y_IN[0]),
        .I3(g0_b1__11_n_0),
        .I4(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .O(\G_OUT[3]_i_122_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \G_OUT[3]_i_123 
       (.I0(g1_b1__15_n_0),
        .I1(g0_b1__10_n_0),
        .I2(Y_IN[0]),
        .I3(g1_b1__7_n_0),
        .I4(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I5(g0_b1__9_n_0),
        .O(\G_OUT[3]_i_123_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF7FFFFFFDFFFF)) 
    \G_OUT[3]_i_124 
       (.I0(\G_OUT[3]_i_141_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I4(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(\G_OUT[3]_i_124_n_0 ));
  LUT6 #(
    .INIT(64'h0028FFFF00280000)) 
    \G_OUT[3]_i_125 
       (.I0(\G_OUT[3]_i_142_n_0 ),
        .I1(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I4(Y_IN[0]),
        .I5(\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_143_n_0 ),
        .O(\G_OUT[3]_i_125_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \G_OUT[3]_i_127 
       (.I0(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(\G_OUT[3]_i_127_n_0 ));
  LUT6 #(
    .INIT(64'hAFAFCFC0AFA0CFC0)) 
    \G_OUT[3]_i_13 
       (.I0(\G_OUT_reg[3]_i_29_n_0 ),
        .I1(\G_OUT[3]_i_30_n_0 ),
        .I2(Y_IN[2]),
        .I3(\G_OUT[3]_i_31_n_0 ),
        .I4(Y_IN[1]),
        .I5(\G_OUT[3]_i_32_n_0 ),
        .O(\G_OUT[3]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hFEFEFE00FEFEFEFE)) 
    \G_OUT[3]_i_130 
       (.I0(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I2(\G_OUT[3]_i_146_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I4(\G_OUT[3]_i_147_n_0 ),
        .I5(\G_OUT[3]_i_148_n_0 ),
        .O(\G_OUT[3]_i_130_n_0 ));
  LUT6 #(
    .INIT(64'hEAAAEAEAEAAAAAAA)) 
    \G_OUT[3]_i_132 
       (.I0(Y_IN[2]),
        .I1(Y_IN[0]),
        .I2(Y_IN[1]),
        .I3(g1_b5__15_n_0),
        .I4(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I5(g0_b5__10_n_0),
        .O(\G_OUT[3]_i_132_n_0 ));
  LUT6 #(
    .INIT(64'h0000000200000000)) 
    \G_OUT[3]_i_133 
       (.I0(\G_OUT[3]_i_149_n_0 ),
        .I1(Y_IN[1]),
        .I2(Y_IN[0]),
        .I3(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\G_OUT[3]_i_127_n_0 ),
        .O(\G_OUT[3]_i_133_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF7FFFFFFFFFF)) 
    \G_OUT[3]_i_138 
       (.I0(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I2(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .O(\G_OUT[3]_i_138_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair56" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \G_OUT[3]_i_141 
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .O(\G_OUT[3]_i_141_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT5 #(
    .INIT(32'h00024000)) 
    \G_OUT[3]_i_142 
       (.I0(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .O(\G_OUT[3]_i_142_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hFFF7FFFF)) 
    \G_OUT[3]_i_146 
       (.I0(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .O(\G_OUT[3]_i_146_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair40" *) 
  LUT3 #(
    .INIT(8'h7E)) 
    \G_OUT[3]_i_147 
       (.I0(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .O(\G_OUT[3]_i_147_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair55" *) 
  LUT4 #(
    .INIT(16'h4006)) 
    \G_OUT[3]_i_148 
       (.I0(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .O(\G_OUT[3]_i_148_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair55" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \G_OUT[3]_i_149 
       (.I0(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .O(\G_OUT[3]_i_149_n_0 ));
  LUT5 #(
    .INIT(32'hEFEAAAAA)) 
    \G_OUT[3]_i_15 
       (.I0(\G_OUT[3]_i_35_n_0 ),
        .I1(\G_OUT_reg[3]_i_36_n_0 ),
        .I2(Y_IN[1]),
        .I3(\G_OUT[3]_i_37_n_0 ),
        .I4(Y_IN[2]),
        .O(\G_OUT[3]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h3313331333130313)) 
    \G_OUT[3]_i_16 
       (.I0(\G_OUT[3]_i_38_n_0 ),
        .I1(\G_OUT[3]_i_39_n_0 ),
        .I2(Y_IN[3]),
        .I3(Y_IN[2]),
        .I4(Y_IN[0]),
        .I5(\G_OUT_reg[3]_i_40_n_0 ),
        .O(\G_OUT[3]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h0E020E020000FFFF)) 
    \G_OUT[3]_i_17 
       (.I0(\G_OUT[3]_i_41_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(Y_IN[0]),
        .I3(\G_OUT[3]_i_42_n_0 ),
        .I4(\G_OUT[3]_i_43_n_0 ),
        .I5(Y_IN[2]),
        .O(\G_OUT[3]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEFFFFFFFFFF)) 
    \G_OUT[3]_i_2 
       (.I0(Y_IN[8]),
        .I1(Y_IN[9]),
        .I2(Y_IN[6]),
        .I3(Y_IN[5]),
        .I4(Y_IN[4]),
        .I5(Y_IN[7]),
        .O(\G_OUT[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFAFCFC0AFA0CFC0)) 
    \G_OUT[3]_i_20 
       (.I0(\G_OUT_reg[3]_i_48_n_0 ),
        .I1(\G_OUT_reg[3]_i_49_n_0 ),
        .I2(Y_IN[2]),
        .I3(\G_OUT[3]_i_31_n_0 ),
        .I4(Y_IN[1]),
        .I5(\G_OUT_reg[3]_i_50_n_0 ),
        .O(\G_OUT[3]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'h111111110F000FFF)) 
    \G_OUT[3]_i_21 
       (.I0(\G_OUT_reg[3]_i_51_n_0 ),
        .I1(Y_IN[0]),
        .I2(\G_OUT[3]_i_52_n_0 ),
        .I3(Y_IN[1]),
        .I4(\G_OUT[3]_i_53_n_0 ),
        .I5(Y_IN[2]),
        .O(\G_OUT[3]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'hAFC0A0C0AFCFAFCF)) 
    \G_OUT[3]_i_22 
       (.I0(\G_OUT_reg[3]_i_54_n_0 ),
        .I1(\G_OUT_reg[3]_i_55_n_0 ),
        .I2(Y_IN[2]),
        .I3(Y_IN[1]),
        .I4(\G_OUT_reg[3]_i_56_n_0 ),
        .I5(\G_OUT[3]_i_57_n_0 ),
        .O(\G_OUT[3]_i_22_n_0 ));
  LUT6 #(
    .INIT(64'h0000000080000000)) 
    \G_OUT[3]_i_23 
       (.I0(\G_OUT[3]_i_58_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I5(\G_OUT[3]_i_59_n_0 ),
        .O(\G_OUT[3]_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair50" *) 
  LUT4 #(
    .INIT(16'hFFF7)) 
    \G_OUT[3]_i_25 
       (.I0(Y_IN[1]),
        .I1(Y_IN[2]),
        .I2(Y_IN[3]),
        .I3(Y_IN[0]),
        .O(\G_OUT[3]_i_25_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \G_OUT[3]_i_27 
       (.I0(\G_OUT[3]_i_62_n_0 ),
        .I1(\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_63_n_0 ),
        .I2(Y_IN[1]),
        .I3(\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_64_n_0 ),
        .I4(Y_IN[0]),
        .I5(\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_65_n_0 ),
        .O(\G_OUT[3]_i_27_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000144000)) 
    \G_OUT[3]_i_28 
       (.I0(Y_IN[0]),
        .I1(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I4(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I5(\G_OUT[3]_i_66_n_0 ),
        .O(\G_OUT[3]_i_28_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair59" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \G_OUT[3]_i_3 
       (.I0(Y_IN[3]),
        .I1(Y_IN[1]),
        .I2(Y_IN[2]),
        .O(\G_OUT[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \G_OUT[3]_i_30 
       (.I0(g1_b6__8_n_0),
        .I1(g0_b6__12_n_0),
        .I2(Y_IN[0]),
        .I3(g1_b6__15_n_0),
        .I4(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I5(g0_b6__11_n_0),
        .O(\G_OUT[3]_i_30_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair56" *) 
  LUT4 #(
    .INIT(16'h0002)) 
    \G_OUT[3]_i_31 
       (.I0(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I3(\G_OUT[3]_i_69_n_0 ),
        .O(\G_OUT[3]_i_31_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \G_OUT[3]_i_32 
       (.I0(g1_b6__15_n_0),
        .I1(g0_b6__10_n_0),
        .I2(Y_IN[0]),
        .I3(g1_b6__7_n_0),
        .I4(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I5(g0_b6__9_n_0),
        .O(\G_OUT[3]_i_32_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \G_OUT[3]_i_33 
       (.I0(\G_OUT[3]_i_70_n_0 ),
        .I1(\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_71_n_0 ),
        .I2(Y_IN[1]),
        .I3(\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_72_n_0 ),
        .I4(Y_IN[0]),
        .I5(\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_73_n_0 ),
        .O(\G_OUT[3]_i_33_n_0 ));
  LUT5 #(
    .INIT(32'h00004100)) 
    \G_OUT[3]_i_34 
       (.I0(Y_IN[0]),
        .I1(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I4(\G_OUT[3]_i_74_n_0 ),
        .O(\G_OUT[3]_i_34_n_0 ));
  LUT6 #(
    .INIT(64'h000000002F200000)) 
    \G_OUT[3]_i_35 
       (.I0(g0_b7__10_n_0),
        .I1(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I2(Y_IN[0]),
        .I3(\vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_75_n_0 ),
        .I4(Y_IN[1]),
        .I5(Y_IN[2]),
        .O(\G_OUT[3]_i_35_n_0 ));
  LUT5 #(
    .INIT(32'hA0A0CFC0)) 
    \G_OUT[3]_i_37 
       (.I0(g1_b7__7_n_0),
        .I1(g0_b7__12_n_0),
        .I2(Y_IN[0]),
        .I3(g0_b7__11_n_0),
        .I4(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .O(\G_OUT[3]_i_37_n_0 ));
  LUT6 #(
    .INIT(64'h2F20FFFF2F200000)) 
    \G_OUT[3]_i_38 
       (.I0(\G_OUT[3]_i_78_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I2(Y_IN[0]),
        .I3(\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_79_n_0 ),
        .I4(Y_IN[1]),
        .I5(\G_OUT_reg[3]_i_80_n_0 ),
        .O(\G_OUT[3]_i_38_n_0 ));
  LUT6 #(
    .INIT(64'h00000000AAA222A2)) 
    \G_OUT[3]_i_39 
       (.I0(\G_OUT[3]_i_81_n_0 ),
        .I1(Y_IN[2]),
        .I2(\G_OUT[3]_i_82_n_0 ),
        .I3(Y_IN[1]),
        .I4(\G_OUT_reg[3]_i_83_n_0 ),
        .I5(Y_IN[3]),
        .O(\G_OUT[3]_i_39_n_0 ));
  LUT6 #(
    .INIT(64'hF0F0F0F0F0F08000)) 
    \G_OUT[3]_i_4 
       (.I0(X_IN[5]),
        .I1(X_IN[4]),
        .I2(X_IN[9]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(\G_OUT[3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0200000002000210)) 
    \G_OUT[3]_i_41 
       (.I0(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .O(\G_OUT[3]_i_41_n_0 ));
  LUT6 #(
    .INIT(64'h2004000000000040)) 
    \G_OUT[3]_i_42 
       (.I0(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I1(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .O(\G_OUT[3]_i_42_n_0 ));
  LUT6 #(
    .INIT(64'hC0C0CFCF505F505F)) 
    \G_OUT[3]_i_43 
       (.I0(\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_86_n_0 ),
        .I1(\G_OUT[3]_i_87_n_0 ),
        .I2(Y_IN[1]),
        .I3(\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_88_n_0 ),
        .I4(\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_89_n_0 ),
        .I5(Y_IN[0]),
        .O(\G_OUT[3]_i_43_n_0 ));
  LUT5 #(
    .INIT(32'h88888BB8)) 
    \G_OUT[3]_i_44 
       (.I0(\G_OUT_reg[3]_i_90_n_0 ),
        .I1(Y_IN[1]),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I4(\G_OUT[3]_i_91_n_0 ),
        .O(\G_OUT[3]_i_44_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \G_OUT[3]_i_45 
       (.I0(\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_92_n_0 ),
        .I1(\G_OUT_reg[3]_i_93_n_0 ),
        .I2(Y_IN[1]),
        .I3(\vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_94_n_0 ),
        .I4(Y_IN[0]),
        .I5(\G_OUT_reg[3]_i_95_n_0 ),
        .O(\G_OUT[3]_i_45_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0EFEFAFA0E0E0)) 
    \G_OUT[3]_i_46 
       (.I0(\G_OUT[3]_i_96_n_0 ),
        .I1(\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_97_n_0 ),
        .I2(Y_IN[1]),
        .I3(\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_98_n_0 ),
        .I4(Y_IN[0]),
        .I5(\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_99_n_0 ),
        .O(\G_OUT[3]_i_46_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000144000)) 
    \G_OUT[3]_i_47 
       (.I0(Y_IN[0]),
        .I1(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I4(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I5(\G_OUT[3]_i_100_n_0 ),
        .O(\G_OUT[3]_i_47_n_0 ));
  LUT6 #(
    .INIT(64'hBB0B000BBB0BBB0B)) 
    \G_OUT[3]_i_52 
       (.I0(\G_OUT[3]_i_109_n_0 ),
        .I1(\G_OUT[3]_i_110_n_0 ),
        .I2(\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_111_n_0 ),
        .I3(Y_IN[0]),
        .I4(\G_OUT[3]_i_112_n_0 ),
        .I5(\G_OUT[3]_i_113_n_0 ),
        .O(\G_OUT[3]_i_52_n_0 ));
  LUT6 #(
    .INIT(64'h0F000FFF55335533)) 
    \G_OUT[3]_i_53 
       (.I0(g1_b3__15_n_0),
        .I1(g0_b3__15_n_0),
        .I2(g1_b3__16_n_0),
        .I3(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I4(g0_b3__16_n_0),
        .I5(Y_IN[0]),
        .O(\G_OUT[3]_i_53_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFFB)) 
    \G_OUT[3]_i_57 
       (.I0(\G_OUT[3]_i_120_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I2(Y_IN[1]),
        .I3(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .O(\G_OUT[3]_i_57_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'h40)) 
    \G_OUT[3]_i_58 
       (.I0(Y_IN[0]),
        .I1(Y_IN[2]),
        .I2(Y_IN[3]),
        .O(\G_OUT[3]_i_58_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair41" *) 
  LUT3 #(
    .INIT(8'hBF)) 
    \G_OUT[3]_i_59 
       (.I0(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .O(\G_OUT[3]_i_59_n_0 ));
  LUT6 #(
    .INIT(64'hAFAFCFC0AFA0CFC0)) 
    \G_OUT[3]_i_60 
       (.I0(\G_OUT_reg[3]_i_121_n_0 ),
        .I1(\G_OUT[3]_i_122_n_0 ),
        .I2(Y_IN[2]),
        .I3(\G_OUT[3]_i_31_n_0 ),
        .I4(Y_IN[1]),
        .I5(\G_OUT[3]_i_123_n_0 ),
        .O(\G_OUT[3]_i_60_n_0 ));
  LUT6 #(
    .INIT(64'h1F101F1F1F101010)) 
    \G_OUT[3]_i_61 
       (.I0(Y_IN[0]),
        .I1(\G_OUT[3]_i_124_n_0 ),
        .I2(Y_IN[2]),
        .I3(\G_OUT[3]_i_125_n_0 ),
        .I4(Y_IN[1]),
        .I5(\G_OUT_reg[3]_i_126_n_0 ),
        .O(\G_OUT[3]_i_61_n_0 ));
  LUT6 #(
    .INIT(64'h0000010002008000)) 
    \G_OUT[3]_i_62 
       (.I0(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I3(\G_OUT[3]_i_127_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .O(\G_OUT[3]_i_62_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT5 #(
    .INIT(32'h7BFFFF78)) 
    \G_OUT[3]_i_66 
       (.I0(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .O(\G_OUT[3]_i_66_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEFFFFFFFF)) 
    \G_OUT[3]_i_69 
       (.I0(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I2(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I4(Y_IN[1]),
        .I5(Y_IN[0]),
        .O(\G_OUT[3]_i_69_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \G_OUT[3]_i_70 
       (.I0(\G_OUT[3]_i_113_n_0 ),
        .I1(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .O(\G_OUT[3]_i_70_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF5EFFFF5EFFFF)) 
    \G_OUT[3]_i_74 
       (.I0(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I4(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .O(\G_OUT[3]_i_74_n_0 ));
  LUT6 #(
    .INIT(64'h0000012000000040)) 
    \G_OUT[3]_i_78 
       (.I0(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I5(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .O(\G_OUT[3]_i_78_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \G_OUT[3]_i_8 
       (.I0(\G_OUT_reg[3]_i_12_n_0 ),
        .I1(\G_OUT[3]_i_13_n_0 ),
        .I2(X_IN[0]),
        .I3(\G_OUT_reg[3]_i_14_n_0 ),
        .I4(Y_IN[3]),
        .I5(\G_OUT[3]_i_15_n_0 ),
        .O(\G_OUT[3]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFF3404)) 
    \G_OUT[3]_i_81 
       (.I0(\G_OUT[3]_i_130_n_0 ),
        .I1(Y_IN[0]),
        .I2(Y_IN[1]),
        .I3(\vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_131_n_0 ),
        .I4(\G_OUT[3]_i_132_n_0 ),
        .I5(\G_OUT[3]_i_133_n_0 ),
        .O(\G_OUT[3]_i_81_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \G_OUT[3]_i_82 
       (.I0(g1_b5__8_n_0),
        .I1(g0_b5__12_n_0),
        .I2(Y_IN[0]),
        .I3(g1_b5__15_n_0),
        .I4(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I5(g0_b5__11_n_0),
        .O(\G_OUT[3]_i_82_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFDBFFFF)) 
    \G_OUT[3]_i_84 
       (.I0(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I4(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .O(\G_OUT[3]_i_84_n_0 ));
  LUT6 #(
    .INIT(64'hBFFDFFFFFFFFDFFF)) 
    \G_OUT[3]_i_85 
       (.I0(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .O(\G_OUT[3]_i_85_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFB)) 
    \G_OUT[3]_i_87 
       (.I0(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I3(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .O(\G_OUT[3]_i_87_n_0 ));
  LUT5 #(
    .INIT(32'hD1DDD111)) 
    \G_OUT[3]_i_9 
       (.I0(\G_OUT[3]_i_16_n_0 ),
        .I1(X_IN[0]),
        .I2(\G_OUT[3]_i_17_n_0 ),
        .I3(Y_IN[3]),
        .I4(\G_OUT_reg[3]_i_18_n_0 ),
        .O(\G_OUT[3]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hA8AA28AAA8AAA8AA)) 
    \G_OUT[3]_i_91 
       (.I0(\G_OUT[3]_i_138_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I3(\G_OUT[3]_i_113_n_0 ),
        .I4(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .I5(Y_IN[0]),
        .O(\G_OUT[3]_i_91_n_0 ));
  LUT6 #(
    .INIT(64'h020000A000080000)) 
    \G_OUT[3]_i_96 
       (.I0(\G_OUT[3]_i_110_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .O(\G_OUT[3]_i_96_n_0 ));
  FDRE \G_OUT_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(G_OUT0),
        .Q(G_OUT),
        .R(1'b0));
  MUXF7 \G_OUT_reg[3]_i_101 
       (.I0(g0_b2__13_n_0),
        .I1(g1_b2__13_n_0),
        .O(\G_OUT_reg[3]_i_101_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \G_OUT_reg[3]_i_103 
       (.I0(g0_b2__11_n_0),
        .I1(g1_b2__11_n_0),
        .O(\G_OUT_reg[3]_i_103_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \G_OUT_reg[3]_i_106 
       (.I0(g0_b2__10_n_0),
        .I1(g1_b2__10_n_0),
        .O(\G_OUT_reg[3]_i_106_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \G_OUT_reg[3]_i_114 
       (.I0(g0_b3__13_n_0),
        .I1(g1_b3__13_n_0),
        .O(\G_OUT_reg[3]_i_114_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \G_OUT_reg[3]_i_116 
       (.I0(g0_b3__11_n_0),
        .I1(g1_b3__11_n_0),
        .O(\G_OUT_reg[3]_i_116_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \G_OUT_reg[3]_i_119 
       (.I0(g0_b3__10_n_0),
        .I1(g1_b3__10_n_0),
        .O(\G_OUT_reg[3]_i_119_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \G_OUT_reg[3]_i_12 
       (.I0(\G_OUT[3]_i_27_n_0 ),
        .I1(\G_OUT[3]_i_28_n_0 ),
        .O(\G_OUT_reg[3]_i_12_n_0 ),
        .S(Y_IN[2]));
  MUXF8 \G_OUT_reg[3]_i_121 
       (.I0(\G_OUT_reg[3]_i_139_n_0 ),
        .I1(\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_140_n_0 ),
        .O(\G_OUT_reg[3]_i_121_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \G_OUT_reg[3]_i_126 
       (.I0(\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_144_n_0 ),
        .I1(\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_145_n_0 ),
        .O(\G_OUT_reg[3]_i_126_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \G_OUT_reg[3]_i_134 
       (.I0(g0_b5__13_n_0),
        .I1(g1_b5__9_n_0),
        .O(\G_OUT_reg[3]_i_134_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \G_OUT_reg[3]_i_137 
       (.I0(g0_b4__10_n_0),
        .I1(g1_b4__10_n_0),
        .O(\G_OUT_reg[3]_i_137_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \G_OUT_reg[3]_i_139 
       (.I0(g0_b1__13_n_0),
        .I1(g1_b1__9_n_0),
        .O(\G_OUT_reg[3]_i_139_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \G_OUT_reg[3]_i_14 
       (.I0(\G_OUT[3]_i_33_n_0 ),
        .I1(\G_OUT[3]_i_34_n_0 ),
        .O(\G_OUT_reg[3]_i_14_n_0 ),
        .S(Y_IN[2]));
  MUXF7 \G_OUT_reg[3]_i_18 
       (.I0(\G_OUT[3]_i_44_n_0 ),
        .I1(\G_OUT[3]_i_45_n_0 ),
        .O(\G_OUT_reg[3]_i_18_n_0 ),
        .S(Y_IN[2]));
  MUXF7 \G_OUT_reg[3]_i_19 
       (.I0(\G_OUT[3]_i_46_n_0 ),
        .I1(\G_OUT[3]_i_47_n_0 ),
        .O(\G_OUT_reg[3]_i_19_n_0 ),
        .S(Y_IN[2]));
  MUXF7 \G_OUT_reg[3]_i_26 
       (.I0(\G_OUT[3]_i_60_n_0 ),
        .I1(\G_OUT[3]_i_61_n_0 ),
        .O(\G_OUT_reg[3]_i_26_n_0 ),
        .S(Y_IN[3]));
  MUXF8 \G_OUT_reg[3]_i_29 
       (.I0(\G_OUT_reg[3]_i_67_n_0 ),
        .I1(\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_68_n_0 ),
        .O(\G_OUT_reg[3]_i_29_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \G_OUT_reg[3]_i_36 
       (.I0(\G_OUT_reg[3]_i_76_n_0 ),
        .I1(\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_77_n_0 ),
        .O(\G_OUT_reg[3]_i_36_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \G_OUT_reg[3]_i_40 
       (.I0(\G_OUT[3]_i_84_n_0 ),
        .I1(\G_OUT[3]_i_85_n_0 ),
        .O(\G_OUT_reg[3]_i_40_n_0 ),
        .S(\ids[0]_inferred__1/g0_b1_i_1_n_0 ));
  MUXF8 \G_OUT_reg[3]_i_48 
       (.I0(\G_OUT_reg[3]_i_101_n_0 ),
        .I1(\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_102_n_0 ),
        .O(\G_OUT_reg[3]_i_48_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \G_OUT_reg[3]_i_49 
       (.I0(\G_OUT_reg[3]_i_103_n_0 ),
        .I1(\vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_104_n_0 ),
        .O(\G_OUT_reg[3]_i_49_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \G_OUT_reg[3]_i_5 
       (.I0(\G_OUT_reg[3]_i_6_n_0 ),
        .I1(\G_OUT_reg[3]_i_7_n_0 ),
        .O(\G_OUT_reg[3]_i_5_n_0 ),
        .S(X_IN[2]));
  MUXF8 \G_OUT_reg[3]_i_50 
       (.I0(\vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_105_n_0 ),
        .I1(\G_OUT_reg[3]_i_106_n_0 ),
        .O(\G_OUT_reg[3]_i_50_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \G_OUT_reg[3]_i_51 
       (.I0(\G_OUT[3]_i_107_n_0 ),
        .I1(\G_OUT[3]_i_108_n_0 ),
        .O(\G_OUT_reg[3]_i_51_n_0 ),
        .S(\ids[0]_inferred__1/g0_b1_i_1_n_0 ));
  MUXF8 \G_OUT_reg[3]_i_54 
       (.I0(\G_OUT_reg[3]_i_114_n_0 ),
        .I1(\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_115_n_0 ),
        .O(\G_OUT_reg[3]_i_54_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \G_OUT_reg[3]_i_55 
       (.I0(\G_OUT_reg[3]_i_116_n_0 ),
        .I1(\vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_117_n_0 ),
        .O(\G_OUT_reg[3]_i_55_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \G_OUT_reg[3]_i_56 
       (.I0(\vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_118_n_0 ),
        .I1(\G_OUT_reg[3]_i_119_n_0 ),
        .O(\G_OUT_reg[3]_i_56_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \G_OUT_reg[3]_i_6 
       (.I0(\G_OUT[3]_i_8_n_0 ),
        .I1(\G_OUT[3]_i_9_n_0 ),
        .O(\G_OUT_reg[3]_i_6_n_0 ),
        .S(X_IN[1]));
  MUXF7 \G_OUT_reg[3]_i_67 
       (.I0(g0_b6__13_n_0),
        .I1(g1_b6__9_n_0),
        .O(\G_OUT_reg[3]_i_67_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \G_OUT_reg[3]_i_7 
       (.I0(\G_OUT[3]_i_10_n_0 ),
        .I1(\G_OUT[3]_i_11_n_0 ),
        .O(\G_OUT_reg[3]_i_7_n_0 ),
        .S(X_IN[1]));
  MUXF7 \G_OUT_reg[3]_i_76 
       (.I0(g0_b7__13_n_0),
        .I1(g1_b7__8_n_0),
        .O(\G_OUT_reg[3]_i_76_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF8 \G_OUT_reg[3]_i_80 
       (.I0(\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_128_n_0 ),
        .I1(\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_129_n_0 ),
        .O(\G_OUT_reg[3]_i_80_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \G_OUT_reg[3]_i_83 
       (.I0(\G_OUT_reg[3]_i_134_n_0 ),
        .I1(\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_135_n_0 ),
        .O(\G_OUT_reg[3]_i_83_n_0 ),
        .S(Y_IN[0]));
  MUXF8 \G_OUT_reg[3]_i_90 
       (.I0(\vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_136_n_0 ),
        .I1(\G_OUT_reg[3]_i_137_n_0 ),
        .O(\G_OUT_reg[3]_i_90_n_0 ),
        .S(Y_IN[0]));
  MUXF7 \G_OUT_reg[3]_i_93 
       (.I0(g0_b4__13_n_0),
        .I1(g1_b4__13_n_0),
        .O(\G_OUT_reg[3]_i_93_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \G_OUT_reg[3]_i_95 
       (.I0(g0_b4__11_n_0),
        .I1(g1_b4__11_n_0),
        .O(\G_OUT_reg[3]_i_95_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  LUT6 #(
    .INIT(64'hABAAABABABAAAAAA)) 
    \R_OUT[3]_i_1 
       (.I0(G_OUT0),
        .I1(\R_OUT[3]_i_2_n_0 ),
        .I2(\R_OUT[3]_i_3_n_0 ),
        .I3(\R_OUT[3]_i_4_n_0 ),
        .I4(X_IN[2]),
        .I5(\R_OUT[3]_i_5_n_0 ),
        .O(R_OUT0));
  LUT6 #(
    .INIT(64'h0F0F3F3FAF0F3F3F)) 
    \R_OUT[3]_i_10 
       (.I0(\R_OUT[3]_i_25_n_0 ),
        .I1(\R_OUT[3]_i_26_n_0 ),
        .I2(Y_IN[3]),
        .I3(\R_OUT[3]_i_27_n_0 ),
        .I4(Y_IN[2]),
        .I5(Y_IN[0]),
        .O(\R_OUT[3]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'h00005D00)) 
    \R_OUT[3]_i_11 
       (.I0(Y_IN[3]),
        .I1(\R_OUT[3]_i_28_n_0 ),
        .I2(\R_OUT[3]_i_29_n_0 ),
        .I3(X_IN[0]),
        .I4(\R_OUT[3]_i_30_n_0 ),
        .O(\R_OUT[3]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hF0F0202000F02020)) 
    \R_OUT[3]_i_12 
       (.I0(\R_OUT[3]_i_31_n_0 ),
        .I1(\R_OUT[3]_i_32_n_0 ),
        .I2(X_IN[0]),
        .I3(\R_OUT[3]_i_33_n_0 ),
        .I4(Y_IN[3]),
        .I5(\R_OUT[3]_i_34_n_0 ),
        .O(\R_OUT[3]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'hBA)) 
    \R_OUT[3]_i_13 
       (.I0(X_IN[0]),
        .I1(\R_OUT[3]_i_35_n_0 ),
        .I2(\R_OUT[3]_i_36_n_0 ),
        .O(\R_OUT[3]_i_13_n_0 ));
  LUT5 #(
    .INIT(32'hFBFBFBAA)) 
    \R_OUT[3]_i_14 
       (.I0(Y_IN[3]),
        .I1(Y_IN[2]),
        .I2(\R_OUT_reg[3]_i_37_n_0 ),
        .I3(\R_OUT[3]_i_38_n_0 ),
        .I4(\R_OUT[3]_i_39_n_0 ),
        .O(\R_OUT[3]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CFCCCFCD)) 
    \R_OUT[3]_i_15 
       (.I0(Y_IN[0]),
        .I1(\R_OUT[3]_i_40_n_0 ),
        .I2(Y_IN[2]),
        .I3(\R_OUT[3]_i_41_n_0 ),
        .I4(\R_OUT[3]_i_42_n_0 ),
        .I5(\R_OUT[3]_i_43_n_0 ),
        .O(\R_OUT[3]_i_15_n_0 ));
  LUT5 #(
    .INIT(32'h00000075)) 
    \R_OUT[3]_i_16 
       (.I0(Y_IN[3]),
        .I1(Y_IN[2]),
        .I2(\R_OUT[3]_i_44_n_0 ),
        .I3(\R_OUT[3]_i_45_n_0 ),
        .I4(X_IN[0]),
        .O(\R_OUT[3]_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair50" *) 
  LUT5 #(
    .INIT(32'hEFFFFFFF)) 
    \R_OUT[3]_i_17 
       (.I0(Y_IN[0]),
        .I1(Y_IN[3]),
        .I2(Y_IN[2]),
        .I3(Y_IN[1]),
        .I4(g1_b1__16_n_0),
        .O(\R_OUT[3]_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair59" *) 
  LUT4 #(
    .INIT(16'h0400)) 
    \R_OUT[3]_i_18 
       (.I0(Y_IN[2]),
        .I1(Y_IN[1]),
        .I2(Y_IN[0]),
        .I3(g0_b1__18_n_0),
        .O(\R_OUT[3]_i_18_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'h000000B8)) 
    \R_OUT[3]_i_19 
       (.I0(g0_b1__19_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b1__20_n_0),
        .I3(Y_IN[1]),
        .I4(Y_IN[2]),
        .O(\R_OUT[3]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF80FFFFFF)) 
    \R_OUT[3]_i_2 
       (.I0(Y_IN[2]),
        .I1(Y_IN[1]),
        .I2(Y_IN[3]),
        .I3(Y_IN[4]),
        .I4(Y_IN[5]),
        .I5(\R_OUT[3]_i_6_n_0 ),
        .O(\R_OUT[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFF000EECCEECC)) 
    \R_OUT[3]_i_20 
       (.I0(\R_OUT[3]_i_46_n_0 ),
        .I1(\R_OUT[3]_i_47_n_0 ),
        .I2(\R_OUT[3]_i_48_n_0 ),
        .I3(Y_IN[1]),
        .I4(\R_OUT[3]_i_49_n_0 ),
        .I5(Y_IN[2]),
        .O(\R_OUT[3]_i_20_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair47" *) 
  LUT5 #(
    .INIT(32'hFFF7FFFF)) 
    \R_OUT[3]_i_22 
       (.I0(g0_b7_i_1_n_0),
        .I1(\ids[0]_0 [2]),
        .I2(\ids[0]_0 [4]),
        .I3(\ids[0]_0 [3]),
        .I4(\R_OUT[3]_i_25_n_0 ),
        .O(\R_OUT[3]_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \R_OUT[3]_i_23 
       (.I0(Y_IN[0]),
        .I1(Y_IN[1]),
        .O(\R_OUT[3]_i_23_n_0 ));
  LUT5 #(
    .INIT(32'hF8FFF8F8)) 
    \R_OUT[3]_i_24 
       (.I0(\R_OUT[3]_i_52_n_0 ),
        .I1(Y_IN[1]),
        .I2(Y_IN[2]),
        .I3(\R_OUT[3]_i_53_n_0 ),
        .I4(\R_OUT[3]_i_54_n_0 ),
        .O(\R_OUT[3]_i_24_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair42" *) 
  LUT5 #(
    .INIT(32'hFBC8FFFF)) 
    \R_OUT[3]_i_25 
       (.I0(g0_b7_i_6_n_0),
        .I1(X_IN[5]),
        .I2(X_IN[4]),
        .I3(g0_b7_i_5__0_n_0),
        .I4(X_IN[9]),
        .O(\R_OUT[3]_i_25_n_0 ));
  LUT6 #(
    .INIT(64'hD0D3DCDF10131C1F)) 
    \R_OUT[3]_i_26 
       (.I0(g0_b3__19_n_0),
        .I1(Y_IN[0]),
        .I2(Y_IN[1]),
        .I3(g0_b3__18_n_0),
        .I4(g0_b3__20_n_0),
        .I5(\R_OUT[3]_i_22_n_0 ),
        .O(\R_OUT[3]_i_26_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair39" *) 
  LUT5 #(
    .INIT(32'hABAAAAAA)) 
    \R_OUT[3]_i_27 
       (.I0(g0_b7_i_1__0_n_0),
        .I1(\ids[0]_0 [4]),
        .I2(\ids[0]_0 [3]),
        .I3(g0_b7_i_1_n_0),
        .I4(\ids[0]_0 [2]),
        .O(\R_OUT[3]_i_27_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair53" *) 
  LUT3 #(
    .INIT(8'h4F)) 
    \R_OUT[3]_i_28 
       (.I0(Y_IN[0]),
        .I1(g0_b2__18_n_0),
        .I2(Y_IN[1]),
        .O(\R_OUT[3]_i_28_n_0 ));
  LUT5 #(
    .INIT(32'hFFFF0131)) 
    \R_OUT[3]_i_29 
       (.I0(g0_b2__20_n_0),
        .I1(Y_IN[1]),
        .I2(Y_IN[0]),
        .I3(g0_b2__19_n_0),
        .I4(Y_IN[2]),
        .O(\R_OUT[3]_i_29_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAA80)) 
    \R_OUT[3]_i_3 
       (.I0(X_IN[9]),
        .I1(\R_OUT[3]_i_7_n_0 ),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(\R_OUT[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0404041504150415)) 
    \R_OUT[3]_i_30 
       (.I0(Y_IN[3]),
        .I1(Y_IN[2]),
        .I2(\R_OUT_reg[3]_i_55_n_0 ),
        .I3(\R_OUT[3]_i_47_n_0 ),
        .I4(\R_OUT[3]_i_56_n_0 ),
        .I5(Y_IN[1]),
        .O(\R_OUT[3]_i_30_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF00001F11)) 
    \R_OUT[3]_i_31 
       (.I0(\R_OUT[3]_i_57_n_0 ),
        .I1(\R_OUT[3]_i_58_n_0 ),
        .I2(\R_OUT[3]_i_59_n_0 ),
        .I3(\R_OUT[3]_i_60_n_0 ),
        .I4(Y_IN[1]),
        .I5(\R_OUT[3]_i_61_n_0 ),
        .O(\R_OUT[3]_i_31_n_0 ));
  LUT6 #(
    .INIT(64'h00004700FF004700)) 
    \R_OUT[3]_i_32 
       (.I0(g0_b4__23_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b4__24_n_0),
        .I3(Y_IN[2]),
        .I4(Y_IN[1]),
        .I5(\R_OUT[3]_i_62_n_0 ),
        .O(\R_OUT[3]_i_32_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair64" *) 
  LUT3 #(
    .INIT(8'hDF)) 
    \R_OUT[3]_i_33 
       (.I0(Y_IN[2]),
        .I1(Y_IN[0]),
        .I2(\R_OUT[3]_i_63_n_0 ),
        .O(\R_OUT[3]_i_33_n_0 ));
  LUT6 #(
    .INIT(64'h4454444444444444)) 
    \R_OUT[3]_i_34 
       (.I0(Y_IN[2]),
        .I1(\R_OUT[3]_i_64_n_0 ),
        .I2(\R_OUT[3]_i_65_n_0 ),
        .I3(\R_OUT[3]_i_66_n_0 ),
        .I4(Y_IN[0]),
        .I5(Y_IN[1]),
        .O(\R_OUT[3]_i_34_n_0 ));
  LUT6 #(
    .INIT(64'h000000B8FFFFFFFF)) 
    \R_OUT[3]_i_35 
       (.I0(g0_b5__19_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b5__20_n_0),
        .I3(Y_IN[1]),
        .I4(Y_IN[2]),
        .I5(Y_IN[3]),
        .O(\R_OUT[3]_i_35_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFC8FBFFFFFFFF)) 
    \R_OUT[3]_i_36 
       (.I0(g0_b7_i_1__0_n_0),
        .I1(Y_IN[0]),
        .I2(\R_OUT[3]_i_67_n_0 ),
        .I3(g0_b5__18_n_0),
        .I4(Y_IN[2]),
        .I5(Y_IN[1]),
        .O(\R_OUT[3]_i_36_n_0 ));
  LUT5 #(
    .INIT(32'hFABAEAAA)) 
    \R_OUT[3]_i_38 
       (.I0(Y_IN[2]),
        .I1(Y_IN[0]),
        .I2(Y_IN[1]),
        .I3(g0_b5__25_n_0),
        .I4(g0_b5__26_n_0),
        .O(\R_OUT[3]_i_38_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair53" *) 
  LUT4 #(
    .INIT(16'h4440)) 
    \R_OUT[3]_i_39 
       (.I0(Y_IN[1]),
        .I1(Y_IN[0]),
        .I2(\R_OUT[3]_i_70_n_0 ),
        .I3(\R_OUT[3]_i_71_n_0 ),
        .O(\R_OUT[3]_i_39_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBB888B8888)) 
    \R_OUT[3]_i_4 
       (.I0(\R_OUT[3]_i_8_n_0 ),
        .I1(X_IN[1]),
        .I2(X_IN[0]),
        .I3(\R_OUT[3]_i_9_n_0 ),
        .I4(\R_OUT[3]_i_10_n_0 ),
        .I5(\R_OUT[3]_i_11_n_0 ),
        .O(\R_OUT[3]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h1000FFFF)) 
    \R_OUT[3]_i_40 
       (.I0(\R_OUT[3]_i_72_n_0 ),
        .I1(Y_IN[0]),
        .I2(Y_IN[2]),
        .I3(\ids[0]_0 [2]),
        .I4(Y_IN[3]),
        .O(\R_OUT[3]_i_40_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair61" *) 
  LUT4 #(
    .INIT(16'h00E2)) 
    \R_OUT[3]_i_41 
       (.I0(g0_b6__18_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b6__20_n_0),
        .I3(Y_IN[1]),
        .O(\R_OUT[3]_i_41_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair61" *) 
  LUT3 #(
    .INIT(8'h1F)) 
    \R_OUT[3]_i_42 
       (.I0(g0_b6__19_n_0),
        .I1(Y_IN[0]),
        .I2(Y_IN[1]),
        .O(\R_OUT[3]_i_42_n_0 ));
  LUT6 #(
    .INIT(64'h00001F11FFFFFFFF)) 
    \R_OUT[3]_i_43 
       (.I0(\R_OUT[3]_i_47_n_0 ),
        .I1(\R_OUT[3]_i_73_n_0 ),
        .I2(\R_OUT_reg[3]_i_74_n_0 ),
        .I3(Y_IN[2]),
        .I4(Y_IN[3]),
        .I5(X_IN[0]),
        .O(\R_OUT[3]_i_43_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'h3300B8B8)) 
    \R_OUT[3]_i_44 
       (.I0(g0_b7__19_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b7__20_n_0),
        .I3(g0_b7__18_n_0),
        .I4(Y_IN[1]),
        .O(\R_OUT[3]_i_44_n_0 ));
  LUT6 #(
    .INIT(64'h00000000000047FF)) 
    \R_OUT[3]_i_45 
       (.I0(\R_OUT[3]_i_75_n_0 ),
        .I1(Y_IN[1]),
        .I2(\R_OUT[3]_i_76_n_0 ),
        .I3(Y_IN[2]),
        .I4(\R_OUT[3]_i_77_n_0 ),
        .I5(Y_IN[3]),
        .O(\R_OUT[3]_i_45_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair64" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \R_OUT[3]_i_46 
       (.I0(g0_b1__25_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b1__26_n_0),
        .O(\R_OUT[3]_i_46_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000004)) 
    \R_OUT[3]_i_47 
       (.I0(\ids[0]_0 [4]),
        .I1(\R_OUT[3]_i_25_n_0 ),
        .I2(\ids[0]_0 [2]),
        .I3(\R_OUT[3]_i_78_n_0 ),
        .I4(g0_b7_i_1_n_0),
        .I5(\ids[0]_0 [3]),
        .O(\R_OUT[3]_i_47_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair72" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \R_OUT[3]_i_48 
       (.I0(g0_b1__21_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b1__22_n_0),
        .O(\R_OUT[3]_i_48_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair71" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \R_OUT[3]_i_49 
       (.I0(g0_b1__23_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b1__24_n_0),
        .O(\R_OUT[3]_i_49_n_0 ));
  LUT6 #(
    .INIT(64'hBAFFBAFFBAFFBA00)) 
    \R_OUT[3]_i_5 
       (.I0(\R_OUT[3]_i_12_n_0 ),
        .I1(\R_OUT[3]_i_13_n_0 ),
        .I2(\R_OUT[3]_i_14_n_0 ),
        .I3(X_IN[1]),
        .I4(\R_OUT[3]_i_15_n_0 ),
        .I5(\R_OUT[3]_i_16_n_0 ),
        .O(\R_OUT[3]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \R_OUT[3]_i_50 
       (.I0(g0_b3__23_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b3__24_n_0),
        .O(\R_OUT[3]_i_50_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \R_OUT[3]_i_51 
       (.I0(g0_b3__21_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b3__22_n_0),
        .O(\R_OUT[3]_i_51_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair70" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \R_OUT[3]_i_52 
       (.I0(g0_b3__25_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b3__26_n_0),
        .O(\R_OUT[3]_i_52_n_0 ));
  LUT5 #(
    .INIT(32'hFBBBFBFF)) 
    \R_OUT[3]_i_53 
       (.I0(Y_IN[1]),
        .I1(\ids[0]_0 [2]),
        .I2(g0_b7_i_14_n_0),
        .I3(\ids[0]_0 [3]),
        .I4(g0_b7_i_1_n_0),
        .O(\R_OUT[3]_i_53_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair58" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \R_OUT[3]_i_54 
       (.I0(g0_b7_i_1__0_n_0),
        .I1(Y_IN[0]),
        .I2(\ids[0]_0 [4]),
        .O(\R_OUT[3]_i_54_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair70" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \R_OUT[3]_i_56 
       (.I0(g0_b2__25_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b2__26_n_0),
        .O(\R_OUT[3]_i_56_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair44" *) 
  LUT5 #(
    .INIT(32'hCFFFFF9F)) 
    \R_OUT[3]_i_57 
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(Y_IN[0]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(\R_OUT[3]_i_57_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair52" *) 
  LUT4 #(
    .INIT(16'hFBBB)) 
    \R_OUT[3]_i_58 
       (.I0(\ids[0]_0 [4]),
        .I1(\ids[0]_0 [2]),
        .I2(g0_b7_i_1_n_0),
        .I3(\ids[0]_0 [3]),
        .O(\R_OUT[3]_i_58_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair44" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \R_OUT[3]_i_59 
       (.I0(\ids[0]_0 [4]),
        .I1(g0_b7_i_1__0_n_0),
        .I2(Y_IN[0]),
        .O(\R_OUT[3]_i_59_n_0 ));
  LUT4 #(
    .INIT(16'hEFFF)) 
    \R_OUT[3]_i_6 
       (.I0(Y_IN[8]),
        .I1(Y_IN[9]),
        .I2(Y_IN[7]),
        .I3(Y_IN[6]),
        .O(\R_OUT[3]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair52" *) 
  LUT4 #(
    .INIT(16'h4020)) 
    \R_OUT[3]_i_60 
       (.I0(g0_b7_i_1_n_0),
        .I1(\ids[0]_0 [3]),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [4]),
        .O(\R_OUT[3]_i_60_n_0 ));
  LUT5 #(
    .INIT(32'hFFB8FF00)) 
    \R_OUT[3]_i_61 
       (.I0(g0_b4__25_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b4__26_n_0),
        .I3(Y_IN[2]),
        .I4(Y_IN[1]),
        .O(\R_OUT[3]_i_61_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair72" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \R_OUT[3]_i_62 
       (.I0(g0_b4__21_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b4__22_n_0),
        .O(\R_OUT[3]_i_62_n_0 ));
  LUT6 #(
    .INIT(64'h0400000004040000)) 
    \R_OUT[3]_i_63 
       (.I0(\ids[0]_0 [4]),
        .I1(g0_b7_i_1_n_0),
        .I2(\ids[0]_0 [3]),
        .I3(\R_OUT[3]_i_81_n_0 ),
        .I4(\ids[0]_0 [2]),
        .I5(X_IN[9]),
        .O(\R_OUT[3]_i_63_n_0 ));
  LUT5 #(
    .INIT(32'h0FCA00CA)) 
    \R_OUT[3]_i_64 
       (.I0(g0_b4__20_n_0),
        .I1(g0_b4__18_n_0),
        .I2(Y_IN[1]),
        .I3(Y_IN[0]),
        .I4(g0_b4__19_n_0),
        .O(\R_OUT[3]_i_64_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \R_OUT[3]_i_65 
       (.I0(\R_OUT[3]_i_25_n_0 ),
        .I1(\ids[0]_0 [4]),
        .O(\R_OUT[3]_i_65_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair43" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \R_OUT[3]_i_66 
       (.I0(\ids[0]_0 [2]),
        .I1(g0_b7_i_1_n_0),
        .O(\R_OUT[3]_i_66_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair49" *) 
  LUT4 #(
    .INIT(16'hBFFF)) 
    \R_OUT[3]_i_67 
       (.I0(\ids[0]_0 [4]),
        .I1(g0_b7_i_1_n_0),
        .I2(\ids[0]_0 [3]),
        .I3(\ids[0]_0 [2]),
        .O(\R_OUT[3]_i_67_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \R_OUT[3]_i_68 
       (.I0(g0_b5__23_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b5__24_n_0),
        .O(\R_OUT[3]_i_68_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \R_OUT[3]_i_69 
       (.I0(g0_b5__21_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b5__22_n_0),
        .O(\R_OUT[3]_i_69_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \R_OUT[3]_i_7 
       (.I0(X_IN[4]),
        .I1(X_IN[3]),
        .O(\R_OUT[3]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair49" *) 
  LUT5 #(
    .INIT(32'h00000001)) 
    \R_OUT[3]_i_70 
       (.I0(\ids[0]_0 [2]),
        .I1(g0_b7_i_1_n_0),
        .I2(\ids[0]_0 [4]),
        .I3(\ids[0]_0 [3]),
        .I4(g0_b7_i_1__0_n_0),
        .O(\R_OUT[3]_i_70_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair43" *) 
  LUT5 #(
    .INIT(32'h00200000)) 
    \R_OUT[3]_i_71 
       (.I0(g0_b7_i_1__0_n_0),
        .I1(g0_b7_i_1_n_0),
        .I2(g0_b7_i_14_n_0),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [2]),
        .O(\R_OUT[3]_i_71_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair47" *) 
  LUT5 #(
    .INIT(32'hFFCFFF6F)) 
    \R_OUT[3]_i_72 
       (.I0(\ids[0]_0 [4]),
        .I1(\ids[0]_0 [3]),
        .I2(g0_b7_i_1_n_0),
        .I3(\ids[0]_0 [2]),
        .I4(\R_OUT[3]_i_25_n_0 ),
        .O(\R_OUT[3]_i_72_n_0 ));
  LUT5 #(
    .INIT(32'hFFB8FF00)) 
    \R_OUT[3]_i_73 
       (.I0(g0_b6__25_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b6__26_n_0),
        .I3(Y_IN[2]),
        .I4(Y_IN[1]),
        .O(\R_OUT[3]_i_73_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \R_OUT[3]_i_75 
       (.I0(g0_b7__21_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b7__22_n_0),
        .O(\R_OUT[3]_i_75_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair71" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \R_OUT[3]_i_76 
       (.I0(g0_b7__23_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b7__24_n_0),
        .O(\R_OUT[3]_i_76_n_0 ));
  LUT5 #(
    .INIT(32'h0000B800)) 
    \R_OUT[3]_i_77 
       (.I0(g0_b7__25_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b7_n_0),
        .I3(Y_IN[1]),
        .I4(Y_IN[2]),
        .O(\R_OUT[3]_i_77_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \R_OUT[3]_i_78 
       (.I0(Y_IN[1]),
        .I1(Y_IN[0]),
        .O(\R_OUT[3]_i_78_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \R_OUT[3]_i_79 
       (.I0(g0_b2__23_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b2__24_n_0),
        .O(\R_OUT[3]_i_79_n_0 ));
  LUT6 #(
    .INIT(64'h7774777777744444)) 
    \R_OUT[3]_i_8 
       (.I0(\R_OUT[3]_i_17_n_0 ),
        .I1(X_IN[0]),
        .I2(\R_OUT[3]_i_18_n_0 ),
        .I3(\R_OUT[3]_i_19_n_0 ),
        .I4(Y_IN[3]),
        .I5(\R_OUT[3]_i_20_n_0 ),
        .O(\R_OUT[3]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \R_OUT[3]_i_80 
       (.I0(g0_b2__21_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b2__22_n_0),
        .O(\R_OUT[3]_i_80_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF53FFFF0053FF)) 
    \R_OUT[3]_i_81 
       (.I0(\strnum_v[3][0]_i_1_n_0 ),
        .I1(\strnum_v[2][0]_i_1_n_0 ),
        .I2(X_IN[3]),
        .I3(X_IN[4]),
        .I4(X_IN[5]),
        .I5(g0_b7_i_6_n_0),
        .O(\R_OUT[3]_i_81_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \R_OUT[3]_i_82 
       (.I0(g0_b6__23_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b6__24_n_0),
        .O(\R_OUT[3]_i_82_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \R_OUT[3]_i_83 
       (.I0(g0_b6__21_n_0),
        .I1(Y_IN[0]),
        .I2(g0_b6__22_n_0),
        .O(\R_OUT[3]_i_83_n_0 ));
  LUT6 #(
    .INIT(64'h0404040455045555)) 
    \R_OUT[3]_i_9 
       (.I0(Y_IN[3]),
        .I1(Y_IN[2]),
        .I2(\R_OUT_reg[3]_i_21_n_0 ),
        .I3(\R_OUT[3]_i_22_n_0 ),
        .I4(\R_OUT[3]_i_23_n_0 ),
        .I5(\R_OUT[3]_i_24_n_0 ),
        .O(\R_OUT[3]_i_9_n_0 ));
  FDRE \R_OUT_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(R_OUT0),
        .Q(R_OUT),
        .R(1'b0));
  MUXF7 \R_OUT_reg[3]_i_21 
       (.I0(\R_OUT[3]_i_50_n_0 ),
        .I1(\R_OUT[3]_i_51_n_0 ),
        .O(\R_OUT_reg[3]_i_21_n_0 ),
        .S(Y_IN[1]));
  MUXF7 \R_OUT_reg[3]_i_37 
       (.I0(\R_OUT[3]_i_68_n_0 ),
        .I1(\R_OUT[3]_i_69_n_0 ),
        .O(\R_OUT_reg[3]_i_37_n_0 ),
        .S(Y_IN[1]));
  MUXF7 \R_OUT_reg[3]_i_55 
       (.I0(\R_OUT[3]_i_79_n_0 ),
        .I1(\R_OUT[3]_i_80_n_0 ),
        .O(\R_OUT_reg[3]_i_55_n_0 ),
        .S(Y_IN[1]));
  MUXF7 \R_OUT_reg[3]_i_74 
       (.I0(\R_OUT[3]_i_82_n_0 ),
        .I1(\R_OUT[3]_i_83_n_0 ),
        .O(\R_OUT_reg[3]_i_74_n_0 ),
        .S(Y_IN[1]));
  LUT6 #(
    .INIT(64'h441144F3C5240000)) 
    g0_b0
       (.I0(X_IN[3]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(g0_b0_n_0));
  LUT6 #(
    .INIT(64'h07F06D6010A08004)) 
    g0_b1
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b1_n_0));
  LUT6 #(
    .INIT(64'h47FF69ED838D8014)) 
    g0_b1__0
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b1__0_n_0));
  LUT6 #(
    .INIT(64'h02FFE1FD838D0438)) 
    g0_b1__1
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b1__1_n_0));
  LUT6 #(
    .INIT(64'h47FF69ED838D8014)) 
    g0_b1__10
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b1__10_n_0));
  LUT6 #(
    .INIT(64'h02FFE1FD838D0438)) 
    g0_b1__11
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b1__11_n_0));
  LUT6 #(
    .INIT(64'h02E7E11723090020)) 
    g0_b1__12
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b1__12_n_0));
  LUT6 #(
    .INIT(64'h00E2E11342012C40)) 
    g0_b1__13
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b1__13_n_0));
  LUT6 #(
    .INIT(64'h00E2E19703790010)) 
    g0_b1__14
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b1__14_n_0));
  LUT6 #(
    .INIT(64'h14AEF1BE23690418)) 
    g0_b1__15
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b1__15_n_0));
  LUT6 #(
    .INIT(64'h152C79AE016D0030)) 
    g0_b1__16
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b1__16_n_0));
  LUT6 #(
    .INIT(64'h150479A210160060)) 
    g0_b1__17
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b1__17_n_0));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT5 #(
    .INIT(32'h20290090)) 
    g0_b1__18
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b1__18_n_0));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT5 #(
    .INIT(32'h029700A0)) 
    g0_b1__19
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b1__19_n_0));
  LUT6 #(
    .INIT(64'h02E7E11723090020)) 
    g0_b1__2
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b1__2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT5 #(
    .INIT(32'h8A960124)) 
    g0_b1__20
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b1__20_n_0));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT5 #(
    .INIT(32'h0AB60020)) 
    g0_b1__21
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b1__21_n_0));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT5 #(
    .INIT(32'h18028510)) 
    g0_b1__22
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b1__22_n_0));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT5 #(
    .INIT(32'h8A060080)) 
    g0_b1__23
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b1__23_n_0));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT5 #(
    .INIT(32'h4A4701A4)) 
    g0_b1__24
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b1__24_n_0));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'h4A474021)) 
    g0_b1__25
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b1__25_n_0));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'h20C04001)) 
    g0_b1__26
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b1__26_n_0));
  LUT6 #(
    .INIT(64'h00007FFF00000000)) 
    g0_b1__27
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b1__27_n_0));
  LUT6 #(
    .INIT(64'h00007FFF00000000)) 
    g0_b1__28
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b1__28_n_0));
  LUT6 #(
    .INIT(64'h00007FFF00000000)) 
    g0_b1__29
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b1__29_n_0));
  LUT6 #(
    .INIT(64'h00E2E11342012C40)) 
    g0_b1__3
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b1__3_n_0));
  LUT6 #(
    .INIT(64'h80007FFF80000000)) 
    g0_b1__30
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b1__30_n_0));
  LUT6 #(
    .INIT(64'h0000000080000000)) 
    g0_b1__31
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b1__31_n_0));
  LUT6 #(
    .INIT(64'h80007FFF00000000)) 
    g0_b1__32
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b1__32_n_0));
  LUT2 #(
    .INIT(4'h4)) 
    g0_b1__33
       (.I0(g0_b1_i_1_n_0),
        .I1(g0_b1_i_2_n_0),
        .O(g0_b1__33_n_0));
  LUT6 #(
    .INIT(64'h00007FFF00000000)) 
    g0_b1__34
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b1__34_n_0));
  LUT6 #(
    .INIT(64'h7FFF000000000000)) 
    g0_b1__35
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b1__35_n_0));
  LUT6 #(
    .INIT(64'h00E2E19703790010)) 
    g0_b1__4
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b1__4_n_0));
  LUT6 #(
    .INIT(64'h14AEF1BE23690418)) 
    g0_b1__5
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b1__5_n_0));
  LUT6 #(
    .INIT(64'h152C79AE016D0030)) 
    g0_b1__6
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b1__6_n_0));
  LUT6 #(
    .INIT(64'h150479A210160060)) 
    g0_b1__7
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b1__7_n_0));
  LUT6 #(
    .INIT(64'h054050C1A7100000)) 
    g0_b1__8
       (.I0(X_IN[3]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(g0_b1__8_n_0));
  LUT6 #(
    .INIT(64'h07F06D6010A08004)) 
    g0_b1__9
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b1__9_n_0));
  LUT6 #(
    .INIT(64'hC808C0C0C8080000)) 
    g0_b1_i_1
       (.I0(g0_b1_i_3_n_0),
        .I1(X_IN[8]),
        .I2(X_IN[7]),
        .I3(g0_b1_i_4__0_n_0),
        .I4(X_IN[6]),
        .I5(g0_b1_i_5__0_n_0),
        .O(g0_b1_i_1_n_0));
  LUT6 #(
    .INIT(64'h202220820A008880)) 
    g0_b1_i_1__0
       (.I0(X_IN[8]),
        .I1(X_IN[6]),
        .I2(X_IN[4]),
        .I3(X_IN[7]),
        .I4(X_IN[3]),
        .I5(X_IN[5]),
        .O(g0_b1_i_1__0_n_0));
  LUT5 #(
    .INIT(32'h0CC8C0C0)) 
    g0_b1_i_2
       (.I0(X_IN[5]),
        .I1(X_IN[8]),
        .I2(X_IN[7]),
        .I3(X_IN[4]),
        .I4(X_IN[6]),
        .O(g0_b1_i_2_n_0));
  LUT6 #(
    .INIT(64'h220882A022222800)) 
    g0_b1_i_2__0
       (.I0(X_IN[8]),
        .I1(X_IN[5]),
        .I2(X_IN[7]),
        .I3(X_IN[4]),
        .I4(X_IN[6]),
        .I5(X_IN[3]),
        .O(g0_b1_i_2__0_n_0));
  LUT6 #(
    .INIT(64'hFFFFB0800000B080)) 
    g0_b1_i_3
       (.I0(BUTTONS_IN[1]),
        .I1(X_IN[3]),
        .I2(X_IN[4]),
        .I3(BUTTONS_IN[0]),
        .I4(X_IN[5]),
        .I5(g0_b1_i_6__0_n_0),
        .O(g0_b1_i_3_n_0));
  LUT6 #(
    .INIT(64'h020288A8008A8820)) 
    g0_b1_i_3__0
       (.I0(X_IN[8]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[3]),
        .O(g0_b1_i_3__0_n_0));
  LUT6 #(
    .INIT(64'h0802022002080000)) 
    g0_b1_i_4
       (.I0(X_IN[8]),
        .I1(X_IN[6]),
        .I2(X_IN[5]),
        .I3(X_IN[7]),
        .I4(X_IN[4]),
        .I5(X_IN[3]),
        .O(g0_b1_i_4_n_0));
  LUT6 #(
    .INIT(64'h4747470000004700)) 
    g0_b1_i_4__0
       (.I0(X_IN[4]),
        .I1(X_IN[6]),
        .I2(X_IN[5]),
        .I3(BUTTONS_IN[14]),
        .I4(X_IN[3]),
        .I5(BUTTONS_IN[15]),
        .O(g0_b1_i_4__0_n_0));
  LUT6 #(
    .INIT(64'h008AA202A0020200)) 
    g0_b1_i_5
       (.I0(X_IN[8]),
        .I1(X_IN[3]),
        .I2(X_IN[4]),
        .I3(X_IN[6]),
        .I4(X_IN[5]),
        .I5(X_IN[7]),
        .O(g0_b1_i_5_n_0));
  MUXF7 g0_b1_i_5__0
       (.I0(g0_b1_i_8_n_0),
        .I1(g0_b1_i_9_n_0),
        .O(g0_b1_i_5__0_n_0),
        .S(g0_b1_i_7_n_0));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    g0_b1_i_6
       (.I0(X_IN[3]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(g0_b1_i_6_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    g0_b1_i_6__0
       (.I0(BUTTONS_IN[5]),
        .I1(BUTTONS_IN[4]),
        .I2(X_IN[4]),
        .I3(BUTTONS_IN[3]),
        .I4(X_IN[3]),
        .I5(BUTTONS_IN[2]),
        .O(g0_b1_i_6__0_n_0));
  LUT3 #(
    .INIT(8'h1D)) 
    g0_b1_i_7
       (.I0(X_IN[5]),
        .I1(X_IN[6]),
        .I2(X_IN[4]),
        .O(g0_b1_i_7_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    g0_b1_i_8
       (.I0(BUTTONS_IN[13]),
        .I1(BUTTONS_IN[12]),
        .I2(X_IN[4]),
        .I3(BUTTONS_IN[11]),
        .I4(X_IN[3]),
        .I5(BUTTONS_IN[10]),
        .O(g0_b1_i_8_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    g0_b1_i_9
       (.I0(BUTTONS_IN[9]),
        .I1(BUTTONS_IN[8]),
        .I2(X_IN[4]),
        .I3(BUTTONS_IN[7]),
        .I4(X_IN[3]),
        .I5(BUTTONS_IN[6]),
        .O(g0_b1_i_9_n_0));
  LUT6 #(
    .INIT(64'h6FFF6FED93BD011C)) 
    g0_b2
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b2_n_0));
  LUT6 #(
    .INIT(64'h67FFEDFD939D805E)) 
    g0_b2__0
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b2__0_n_0));
  LUT6 #(
    .INIT(64'h27EFED17839D864E)) 
    g0_b2__1
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b2__1_n_0));
  LUT6 #(
    .INIT(64'h67FFEDFD939D805E)) 
    g0_b2__10
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b2__10_n_0));
  LUT6 #(
    .INIT(64'h27EFED17839D864E)) 
    g0_b2__11
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b2__11_n_0));
  LUT6 #(
    .INIT(64'h22E7ED17E39D062A)) 
    g0_b2__12
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b2__12_n_0));
  LUT6 #(
    .INIT(64'h22E7E51743792E78)) 
    g0_b2__13
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b2__13_n_0));
  LUT6 #(
    .INIT(64'h30EEED9743790658)) 
    g0_b2__14
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b2__14_n_0));
  LUT6 #(
    .INIT(64'h31EEED9723790658)) 
    g0_b2__15
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b2__15_n_0));
  LUT6 #(
    .INIT(64'h35AEFDBE137D0078)) 
    g0_b2__16
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b2__16_n_0));
  LUT6 #(
    .INIT(64'h2FBE7B2F117F0178)) 
    g0_b2__17
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b2__17_n_0));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT5 #(
    .INIT(32'h22BF02B4)) 
    g0_b2__18
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b2__18_n_0));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT5 #(
    .INIT(32'h2AB700B4)) 
    g0_b2__19
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b2__19_n_0));
  LUT6 #(
    .INIT(64'h22E7ED17E39D062A)) 
    g0_b2__2
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b2__2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT5 #(
    .INIT(32'h8AB60934)) 
    g0_b2__20
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b2__20_n_0));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT5 #(
    .INIT(32'h1AB60934)) 
    g0_b2__21
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b2__21_n_0));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT5 #(
    .INIT(32'h1AB68DB4)) 
    g0_b2__22
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b2__22_n_0));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT5 #(
    .INIT(32'hDA67098C)) 
    g0_b2__23
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b2__23_n_0));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT5 #(
    .INIT(32'h4A67491D)) 
    g0_b2__24
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b2__24_n_0));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h6A67403D)) 
    g0_b2__25
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b2__25_n_0));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'h6AE70225)) 
    g0_b2__26
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b2__26_n_0));
  LUT6 #(
    .INIT(64'h00007FFF00000000)) 
    g0_b2__27
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b2__27_n_0));
  LUT2 #(
    .INIT(4'h4)) 
    g0_b2__28
       (.I0(g0_b1_i_1_n_0),
        .I1(g0_b1_i_2_n_0),
        .O(g0_b2__28_n_0));
  LUT6 #(
    .INIT(64'h8000FFFF7FFF0000)) 
    g0_b2__29
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b2__29_n_0));
  LUT6 #(
    .INIT(64'h22E7E51743792E78)) 
    g0_b2__3
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b2__3_n_0));
  LUT6 #(
    .INIT(64'h80007FFFFFFF0000)) 
    g0_b2__30
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b2__30_n_0));
  LUT6 #(
    .INIT(64'h80007FFF00000000)) 
    g0_b2__31
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b2__31_n_0));
  LUT6 #(
    .INIT(64'h80007FFFFFFF0000)) 
    g0_b2__32
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b2__32_n_0));
  LUT2 #(
    .INIT(4'h4)) 
    g0_b2__33
       (.I0(g0_b1_i_1_n_0),
        .I1(g0_b1_i_2_n_0),
        .O(g0_b2__33_n_0));
  LUT6 #(
    .INIT(64'h00007FFF00000000)) 
    g0_b2__34
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b2__34_n_0));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h7FFF0000)) 
    g0_b2__35
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_2_n_0),
        .O(g0_b2__35_n_0));
  LUT6 #(
    .INIT(64'h30EEED9743790658)) 
    g0_b2__4
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b2__4_n_0));
  LUT6 #(
    .INIT(64'h31EEED9723790658)) 
    g0_b2__5
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b2__5_n_0));
  LUT6 #(
    .INIT(64'h35AEFDBE137D0078)) 
    g0_b2__6
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b2__6_n_0));
  LUT6 #(
    .INIT(64'h2FBE7B2F117F0178)) 
    g0_b2__7
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b2__7_n_0));
  LUT6 #(
    .INIT(64'hAEFEA81643E50000)) 
    g0_b2__8
       (.I0(X_IN[3]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(g0_b2__8_n_0));
  LUT6 #(
    .INIT(64'h6FFF6FED93BD011C)) 
    g0_b2__9
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b2__9_n_0));
  LUT6 #(
    .INIT(64'h6C1F86FD83FF015A)) 
    g0_b3
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b3_n_0));
  LUT6 #(
    .INIT(64'h2010A6121C12034A)) 
    g0_b3__0
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b3__0_n_0));
  LUT6 #(
    .INIT(64'h25102E025C138A4A)) 
    g0_b3__1
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b3__1_n_0));
  LUT6 #(
    .INIT(64'h2010A6121C12034A)) 
    g0_b3__10
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b3__10_n_0));
  LUT6 #(
    .INIT(64'h25102E025C138A4A)) 
    g0_b3__11
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b3__11_n_0));
  LUT6 #(
    .INIT(64'h25106E61E0978E4A)) 
    g0_b3__12
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b3__12_n_0));
  LUT6 #(
    .INIT(64'h331D4F6583FE2E3A)) 
    g0_b3__13
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b3__13_n_0));
  LUT6 #(
    .INIT(64'h331C4EE3C0120E6A)) 
    g0_b3__14
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b3__14_n_0));
  LUT6 #(
    .INIT(64'h33D20E017C121A48)) 
    g0_b3__15
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b3__15_n_0));
  LUT6 #(
    .INIT(64'h22D286109E12534A)) 
    g0_b3__16
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b3__16_n_0));
  LUT6 #(
    .INIT(64'h2EBA96BD837F511A)) 
    g0_b3__17
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b3__17_n_0));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'hB5282C14)) 
    g0_b3__18
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b3__18_n_0));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT5 #(
    .INIT(32'h4ABF322C)) 
    g0_b3__19
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b3__19_n_0));
  LUT6 #(
    .INIT(64'h25106E61E0978E4A)) 
    g0_b3__2
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b3__2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT5 #(
    .INIT(32'h6D283A1C)) 
    g0_b3__20
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b3__20_n_0));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT5 #(
    .INIT(32'h50280D9C)) 
    g0_b3__21
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b3__21_n_0));
  (* SOFT_HLUTNM = "soft_lutpair39" *) 
  LUT5 #(
    .INIT(32'h4AFD8DAC)) 
    g0_b3__22
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b3__22_n_0));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT5 #(
    .INIT(32'hD06B4D1C)) 
    g0_b3__23
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b3__23_n_0));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT5 #(
    .INIT(32'h352A4C1C)) 
    g0_b3__24
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b3__24_n_0));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT5 #(
    .INIT(32'h25280A1C)) 
    g0_b3__25
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b3__25_n_0));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'h4AFF023C)) 
    g0_b3__26
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b3__26_n_0));
  LUT6 #(
    .INIT(64'hFFFF00007FFF8000)) 
    g0_b3__27
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b3__27_n_0));
  LUT6 #(
    .INIT(64'hFFFF80007FFF0000)) 
    g0_b3__28
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b3__28_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    g0_b3__29
       (.I0(g0_b1_i_1_n_0),
        .I1(g0_b1_i_2_n_0),
        .O(g0_b3__29_n_0));
  LUT6 #(
    .INIT(64'h331D4F6583FE2E3A)) 
    g0_b3__3
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b3__3_n_0));
  LUT5 #(
    .INIT(32'h7FFF0000)) 
    g0_b3__30
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .O(g0_b3__30_n_0));
  LUT6 #(
    .INIT(64'hFFFF7FFF7FFF0000)) 
    g0_b3__31
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b3__31_n_0));
  LUT6 #(
    .INIT(64'h7FFFFFFFFFFF0000)) 
    g0_b3__32
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b3__32_n_0));
  LUT6 #(
    .INIT(64'hFFFF00007FFF0000)) 
    g0_b3__33
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b3__33_n_0));
  LUT6 #(
    .INIT(64'h7FFF800000000000)) 
    g0_b3__34
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b3__34_n_0));
  LUT6 #(
    .INIT(64'hFFFF7FFF7FFF8000)) 
    g0_b3__35
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b3__35_n_0));
  LUT6 #(
    .INIT(64'h331C4EE3C0120E6A)) 
    g0_b3__4
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b3__4_n_0));
  LUT6 #(
    .INIT(64'h33D20E017C121A48)) 
    g0_b3__5
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b3__5_n_0));
  LUT6 #(
    .INIT(64'h22D286109E12534A)) 
    g0_b3__6
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b3__6_n_0));
  LUT6 #(
    .INIT(64'h2EBA96BD837F511A)) 
    g0_b3__7
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b3__7_n_0));
  LUT6 #(
    .INIT(64'hFAAAAA9003020000)) 
    g0_b3__8
       (.I0(X_IN[3]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(g0_b3__8_n_0));
  LUT6 #(
    .INIT(64'h6C1F86FD83FF015A)) 
    g0_b3__9
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b3__9_n_0));
  LUT6 #(
    .INIT(64'h2C1F96FF83EF02D2)) 
    g0_b4
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b4_n_0));
  LUT6 #(
    .INIT(64'h081002024C120382)) 
    g0_b4__0
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b4__0_n_0));
  LUT6 #(
    .INIT(64'h081062005C12090A)) 
    g0_b4__1
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b4__1_n_0));
  LUT6 #(
    .INIT(64'h081002024C120382)) 
    g0_b4__10
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b4__10_n_0));
  LUT6 #(
    .INIT(64'h081062005C12090A)) 
    g0_b4__11
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b4__11_n_0));
  LUT6 #(
    .INIT(64'h1D10620130038D42)) 
    g0_b4__12
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b4__12_n_0));
  LUT6 #(
    .INIT(64'h1F9D6B6583EFAD52)) 
    g0_b4__13
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b4__13_n_0));
  LUT6 #(
    .INIT(64'h1B92028390960D62)) 
    g0_b4__14
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b4__14_n_0));
  LUT6 #(
    .INIT(64'h0A9202017C821928)) 
    g0_b4__15
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b4__15_n_0));
  LUT6 #(
    .INIT(64'h0AD20200CC825302)) 
    g0_b4__16
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b4__16_n_0));
  LUT6 #(
    .INIT(64'h2E7996FD8BFF5252)) 
    g0_b4__17
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b4__17_n_0));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT5 #(
    .INIT(32'h4EFF3838)) 
    g0_b4__18
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b4__18_n_0));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT5 #(
    .INIT(32'h55483A08)) 
    g0_b4__19
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b4__19_n_0));
  LUT6 #(
    .INIT(64'h1D10620130038D42)) 
    g0_b4__2
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b4__2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT5 #(
    .INIT(32'hB5482684)) 
    g0_b4__20
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b4__20_n_0));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT5 #(
    .INIT(32'h60690798)) 
    g0_b4__21
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b4__21_n_0));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT5 #(
    .INIT(32'h4ADFC738)) 
    g0_b4__22
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b4__22_n_0));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT5 #(
    .INIT(32'hA00A4718)) 
    g0_b4__23
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b4__23_n_0));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT5 #(
    .INIT(32'h3528060C)) 
    g0_b4__24
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b4__24_n_0));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT5 #(
    .INIT(32'h15280A48)) 
    g0_b4__25
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b4__25_n_0));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT5 #(
    .INIT(32'h4ADF0878)) 
    g0_b4__26
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b4__26_n_0));
  LUT6 #(
    .INIT(64'hFFFF80007FFF8000)) 
    g0_b4__27
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b4__27_n_0));
  LUT6 #(
    .INIT(64'hFFFF00007FFF0000)) 
    g0_b4__28
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b4__28_n_0));
  LUT6 #(
    .INIT(64'h7FFF7FFFFFFF0000)) 
    g0_b4__29
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b4__29_n_0));
  LUT6 #(
    .INIT(64'h1F9D6B6583EFAD52)) 
    g0_b4__3
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b4__3_n_0));
  LUT6 #(
    .INIT(64'h7FFF80007FFF0000)) 
    g0_b4__30
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b4__30_n_0));
  LUT6 #(
    .INIT(64'hFFFF7FFF7FFF0000)) 
    g0_b4__31
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b4__31_n_0));
  LUT6 #(
    .INIT(64'h7FFF80007FFF0000)) 
    g0_b4__32
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b4__32_n_0));
  LUT6 #(
    .INIT(64'hFFFF7FFFFFFF0000)) 
    g0_b4__33
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b4__33_n_0));
  LUT6 #(
    .INIT(64'h7FFF800000000000)) 
    g0_b4__34
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b4__34_n_0));
  LUT6 #(
    .INIT(64'hFFFF7FFF7FFF8000)) 
    g0_b4__35
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b4__35_n_0));
  LUT6 #(
    .INIT(64'h1B92028390960D62)) 
    g0_b4__4
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b4__4_n_0));
  LUT6 #(
    .INIT(64'h0A9202017C821928)) 
    g0_b4__5
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b4__5_n_0));
  LUT6 #(
    .INIT(64'h0AD20200CC825302)) 
    g0_b4__6
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b4__6_n_0));
  LUT6 #(
    .INIT(64'h2E7996FD8BFF5252)) 
    g0_b4__7
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b4__7_n_0));
  LUT6 #(
    .INIT(64'h54545441B4E10000)) 
    g0_b4__8
       (.I0(X_IN[3]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(g0_b4__8_n_0));
  LUT6 #(
    .INIT(64'h2C1F96FF83EF02D2)) 
    g0_b4__9
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b4__9_n_0));
  LUT6 #(
    .INIT(64'h6E1F9AFDC3ED02DC)) 
    g0_b5
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b5_n_0));
  LUT6 #(
    .INIT(64'h0A15F8FE404200CE)) 
    g0_b5__0
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b5__0_n_0));
  LUT6 #(
    .INIT(64'h1B057876001205CE)) 
    g0_b5__1
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b5__1_n_0));
  LUT6 #(
    .INIT(64'h0A15F8FE404200CE)) 
    g0_b5__10
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b5__10_n_0));
  LUT6 #(
    .INIT(64'h1B057876001205CE)) 
    g0_b5__11
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b5__11_n_0));
  LUT6 #(
    .INIT(64'h1B0D78743010054A)) 
    g0_b5__12
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b5__12_n_0));
  LUT6 #(
    .INIT(64'h1F0D19741369AD58)) 
    g0_b5__13
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b5__13_n_0));
  LUT6 #(
    .INIT(64'h0D05187610958508)) 
    g0_b5__14
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b5__14_n_0));
  LUT6 #(
    .INIT(64'h09C5187420840528)) 
    g0_b5__15
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b5__15_n_0));
  LUT6 #(
    .INIT(64'h08C798FC40800028)) 
    g0_b5__16
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b5__16_n_0));
  LUT6 #(
    .INIT(64'h2EBD9EFD4BEF0258)) 
    g0_b5__17
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b5__17_n_0));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT5 #(
    .INIT(32'h1EDF0834)) 
    g0_b5__18
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b5__18_n_0));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT5 #(
    .INIT(32'h10400084)) 
    g0_b5__19
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b5__19_n_0));
  LUT6 #(
    .INIT(64'h1B0D78743010054A)) 
    g0_b5__2
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b5__2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT5 #(
    .INIT(32'h80410384)) 
    g0_b5__20
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b5__20_n_0));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT5 #(
    .INIT(32'h20634304)) 
    g0_b5__21
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b5__21_n_0));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT5 #(
    .INIT(32'h2A96C734)) 
    g0_b5__22
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b5__22_n_0));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT5 #(
    .INIT(32'hA020031C)) 
    g0_b5__23
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b5__23_n_0));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT5 #(
    .INIT(32'h0028035D)) 
    g0_b5__24
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b5__24_n_0));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT5 #(
    .INIT(32'h1018005D)) 
    g0_b5__25
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b5__25_n_0));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT5 #(
    .INIT(32'h5AD70875)) 
    g0_b5__26
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b5__26_n_0));
  LUT6 #(
    .INIT(64'h0000800000000000)) 
    g0_b5__27
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b5__27_n_0));
  LUT6 #(
    .INIT(64'h00007FFF80000000)) 
    g0_b5__28
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b5__28_n_0));
  LUT6 #(
    .INIT(64'h000000007FFF0000)) 
    g0_b5__29
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b5__29_n_0));
  LUT6 #(
    .INIT(64'h1F0D19741369AD58)) 
    g0_b5__3
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b5__3_n_0));
  LUT6 #(
    .INIT(64'h7FFF80007FFF0000)) 
    g0_b5__30
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b5__30_n_0));
  LUT6 #(
    .INIT(64'h8000FFFF00000000)) 
    g0_b5__31
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b5__31_n_0));
  LUT5 #(
    .INIT(32'h7FFF0000)) 
    g0_b5__32
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .O(g0_b5__32_n_0));
  LUT6 #(
    .INIT(64'h00007FFF80000000)) 
    g0_b5__33
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b5__33_n_0));
  LUT6 #(
    .INIT(64'h7FFFFFFF00000000)) 
    g0_b5__34
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b5__34_n_0));
  LUT6 #(
    .INIT(64'h0D05187610958508)) 
    g0_b5__4
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b5__4_n_0));
  LUT6 #(
    .INIT(64'h09C5187420840528)) 
    g0_b5__5
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b5__5_n_0));
  LUT6 #(
    .INIT(64'h08C798FC40800028)) 
    g0_b5__6
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b5__6_n_0));
  LUT6 #(
    .INIT(64'h2EBD9EFD4BEF0258)) 
    g0_b5__7
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b5__7_n_0));
  LUT6 #(
    .INIT(64'h0101000000010000)) 
    g0_b5__8
       (.I0(X_IN[3]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(g0_b5__8_n_0));
  LUT6 #(
    .INIT(64'h6E1F9AFDC3ED02DC)) 
    g0_b5__9
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b5__9_n_0));
  LUT6 #(
    .INIT(64'h47FF7975C3AD001C)) 
    g0_b6
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b6_n_0));
  LUT6 #(
    .INIT(64'h57FFF9FD83ED005C)) 
    g0_b6__0
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b6__0_n_0));
  LUT6 #(
    .INIT(64'h13FFF9FF836304F8)) 
    g0_b6__1
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b6__1_n_0));
  LUT6 #(
    .INIT(64'h57FFF9FD83ED005C)) 
    g0_b6__10
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b6__10_n_0));
  LUT6 #(
    .INIT(64'h13FFF9FF836304F8)) 
    g0_b6__11
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b6__11_n_0));
  LUT6 #(
    .INIT(64'h12EFF9FF23710038)) 
    g0_b6__12
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b6__12_n_0));
  LUT6 #(
    .INIT(64'h00E7F9FF13712C58)) 
    g0_b6__13
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b6__13_n_0));
  LUT6 #(
    .INIT(64'h04E7F9FF01518048)) 
    g0_b6__14
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b6__14_n_0));
  LUT6 #(
    .INIT(64'h05EFFDFF21458448)) 
    g0_b6__15
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b6__15_n_0));
  LUT6 #(
    .INIT(64'h05AFFDFF016D0078)) 
    g0_b6__16
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b6__16_n_0));
  LUT6 #(
    .INIT(64'h05AD7D77436F0078)) 
    g0_b6__17
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b6__17_n_0));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'h82134114)) 
    g0_b6__18
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b6__18_n_0));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'h1A9F00B4)) 
    g0_b6__19
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b6__19_n_0));
  LUT6 #(
    .INIT(64'h12EFF9FF23710038)) 
    g0_b6__2
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b6__2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT5 #(
    .INIT(32'h029700B4)) 
    g0_b6__20
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b6__20_n_0));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT5 #(
    .INIT(32'h02324014)) 
    g0_b6__21
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b6__21_n_0));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT5 #(
    .INIT(32'h2AB28534)) 
    g0_b6__22
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b6__22_n_0));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT5 #(
    .INIT(32'h8AB200A4)) 
    g0_b6__23
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b6__23_n_0));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT5 #(
    .INIT(32'h4A9A01F4)) 
    g0_b6__24
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b6__24_n_0));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT5 #(
    .INIT(32'h4AD70035)) 
    g0_b6__25
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b6__25_n_0));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT5 #(
    .INIT(32'h5AC70025)) 
    g0_b6__26
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b6__26_n_0));
  LUT6 #(
    .INIT(64'h00007FFF00000000)) 
    g0_b6__27
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b6__27_n_0));
  LUT6 #(
    .INIT(64'h00007FFF80000000)) 
    g0_b6__28
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b6__28_n_0));
  LUT6 #(
    .INIT(64'h00007FFF00000000)) 
    g0_b6__29
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b6__29_n_0));
  LUT6 #(
    .INIT(64'h00E7F9FF13712C58)) 
    g0_b6__3
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b6__3_n_0));
  LUT6 #(
    .INIT(64'h80007FFF00000000)) 
    g0_b6__30
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b6__30_n_0));
  LUT6 #(
    .INIT(64'h8000FFFF00000000)) 
    g0_b6__31
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b6__31_n_0));
  LUT6 #(
    .INIT(64'hFFFF7FFF00000000)) 
    g0_b6__32
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b6__32_n_0));
  LUT6 #(
    .INIT(64'h00007FFF00000000)) 
    g0_b6__33
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b6__33_n_0));
  LUT6 #(
    .INIT(64'h00007FFF80000000)) 
    g0_b6__34
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b6__34_n_0));
  LUT6 #(
    .INIT(64'h7FFFFFFF00000000)) 
    g0_b6__35
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b6__35_n_0));
  LUT6 #(
    .INIT(64'h04E7F9FF01518048)) 
    g0_b6__4
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b6__4_n_0));
  LUT6 #(
    .INIT(64'h05EFFDFF21458448)) 
    g0_b6__5
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b6__5_n_0));
  LUT6 #(
    .INIT(64'h05AFFDFF016D0078)) 
    g0_b6__6
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b6__6_n_0));
  LUT6 #(
    .INIT(64'h05AD7D77436F0078)) 
    g0_b6__7
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b6__7_n_0));
  LUT6 #(
    .INIT(64'h000000F7F7F60000)) 
    g0_b6__8
       (.I0(X_IN[3]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(g0_b6__8_n_0));
  LUT6 #(
    .INIT(64'h47FF7975C3AD001C)) 
    g0_b6__9
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b6__9_n_0));
  (* SOFT_HLUTNM = "soft_lutpair58" *) 
  LUT4 #(
    .INIT(16'h0800)) 
    g0_b7
       (.I0(g0_b7_i_1__0_n_0),
        .I1(\ids[0]_0 [2]),
        .I2(\ids[0]_0 [3]),
        .I3(\ids[0]_0 [4]),
        .O(g0_b7_n_0));
  LUT6 #(
    .INIT(64'h15E5797400A00000)) 
    g0_b7__0
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b7__0_n_0));
  LUT6 #(
    .INIT(64'h55EA610183AD0010)) 
    g0_b7__1
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b7__1_n_0));
  LUT6 #(
    .INIT(64'h55EA610183AD0010)) 
    g0_b7__10
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b7__10_n_0));
  LUT6 #(
    .INIT(64'h14EAE18983610038)) 
    g0_b7__11
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b7__11_n_0));
  LUT6 #(
    .INIT(64'h00E2E18B03610030)) 
    g0_b7__12
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b7__12_n_0));
  LUT6 #(
    .INIT(64'h00E2E18B00712400)) 
    g0_b7__13
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b7__13_n_0));
  LUT6 #(
    .INIT(64'h00E2E18B01510040)) 
    g0_b7__14
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b7__14_n_0));
  LUT6 #(
    .INIT(64'h04AAE58B01418058)) 
    g0_b7__15
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b7__15_n_0));
  LUT6 #(
    .INIT(64'h05286503016D8050)) 
    g0_b7__16
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b7__16_n_0));
  LUT6 #(
    .INIT(64'h0505797600040020)) 
    g0_b7__17
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b7__17_n_0));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h00010080)) 
    g0_b7__18
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b7__18_n_0));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT5 #(
    .INIT(32'h02974030)) 
    g0_b7__19
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b7__19_n_0));
  LUT6 #(
    .INIT(64'h14EAE18983610038)) 
    g0_b7__2
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b7__2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT5 #(
    .INIT(32'h02124034)) 
    g0_b7__20
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b7__20_n_0));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT5 #(
    .INIT(32'h02320010)) 
    g0_b7__21
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b7__21_n_0));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT5 #(
    .INIT(32'h00B28100)) 
    g0_b7__22
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b7__22_n_0));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT5 #(
    .INIT(32'h0A9200A0)) 
    g0_b7__23
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b7__23_n_0));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT5 #(
    .INIT(32'h4A9200A4)) 
    g0_b7__24
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b7__24_n_0));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT5 #(
    .INIT(32'h4AC70020)) 
    g0_b7__25
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g0_b7__25_n_0));
  LUT6 #(
    .INIT(64'h00007FFF80000000)) 
    g0_b7__26
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b7__26_n_0));
  LUT6 #(
    .INIT(64'h00007FFF00000000)) 
    g0_b7__27
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b7__27_n_0));
  LUT6 #(
    .INIT(64'h00007FFF00000000)) 
    g0_b7__28
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b7__28_n_0));
  LUT6 #(
    .INIT(64'h80007FFF00000000)) 
    g0_b7__29
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b7__29_n_0));
  LUT6 #(
    .INIT(64'h00E2E18B03610030)) 
    g0_b7__3
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b7__3_n_0));
  LUT6 #(
    .INIT(64'h80007FFF00000000)) 
    g0_b7__30
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b7__30_n_0));
  LUT6 #(
    .INIT(64'h00007FFF00000000)) 
    g0_b7__31
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b7__31_n_0));
  LUT6 #(
    .INIT(64'h00007FFF80000000)) 
    g0_b7__32
       (.I0(X_IN[8]),
        .I1(X_IN[7]),
        .I2(X_IN[6]),
        .I3(X_IN[4]),
        .I4(g0_b1_i_1_n_0),
        .I5(g0_b1_i_2_n_0),
        .O(g0_b7__32_n_0));
  LUT6 #(
    .INIT(64'h00E2E18B00712400)) 
    g0_b7__4
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b7__4_n_0));
  LUT6 #(
    .INIT(64'h00E2E18B01510040)) 
    g0_b7__5
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b7__5_n_0));
  LUT6 #(
    .INIT(64'h04AAE58B01418058)) 
    g0_b7__6
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b7__6_n_0));
  LUT6 #(
    .INIT(64'h05286503016D8050)) 
    g0_b7__7
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b7__7_n_0));
  LUT6 #(
    .INIT(64'h0505797600040020)) 
    g0_b7__8
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g0_b7__8_n_0));
  LUT6 #(
    .INIT(64'h15E5797400A00000)) 
    g0_b7__9
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g0_b7__9_n_0));
  LUT6 #(
    .INIT(64'hAAAAAAAABBBFFFBF)) 
    g0_b7_i_1
       (.I0(g0_b7_i_2__0_n_0),
        .I1(g0_b7_i_8_n_0),
        .I2(\strnum_v_reg_n_0_[4][1] ),
        .I3(BTN_PRESS_VALID_IN),
        .I4(g0_b7_i_3_n_0),
        .I5(g0_b7_i_4__0_n_0),
        .O(g0_b7_i_1_n_0));
  LUT6 #(
    .INIT(64'h004700FFFFFFFFFF)) 
    g0_b7_i_10
       (.I0(\strnum_v[3][3]_i_2_n_0 ),
        .I1(BTN_PRESS_VALID_IN),
        .I2(\strnum_v_reg_n_0_[3][2] ),
        .I3(X_IN[5]),
        .I4(\R_OUT[3]_i_7_n_0 ),
        .I5(X_IN[9]),
        .O(g0_b7_i_10_n_0));
  LUT6 #(
    .INIT(64'hFEFEFECECECEFECE)) 
    g0_b7_i_11
       (.I0(g0_b7_i_15_n_0),
        .I1(g0_b7_i_7_n_0),
        .I2(g0_b7_i_8_n_0),
        .I3(\strnum_v_reg_n_0_[4][3] ),
        .I4(BTN_PRESS_VALID_IN),
        .I5(\strnum_v[4][3]_i_2_n_0 ),
        .O(g0_b7_i_11_n_0));
  (* SOFT_HLUTNM = "soft_lutpair69" *) 
  LUT3 #(
    .INIT(8'h7F)) 
    g0_b7_i_12
       (.I0(\strnum_v[3][3]_i_1_n_0 ),
        .I1(X_IN[3]),
        .I2(X_IN[4]),
        .O(g0_b7_i_12_n_0));
  (* SOFT_HLUTNM = "soft_lutpair62" *) 
  LUT3 #(
    .INIT(8'h01)) 
    g0_b7_i_13
       (.I0(\strnum_v[3][3]_i_1_n_0 ),
        .I1(\strnum_v_reg_n_0_[3][4] ),
        .I2(BTN_PRESS_VALID_IN),
        .O(g0_b7_i_13_n_0));
  LUT6 #(
    .INIT(64'h00000000FF01FF31)) 
    g0_b7_i_14
       (.I0(\strnum_v_reg_n_0_[5][4] ),
        .I1(BTN_PRESS_VALID_IN),
        .I2(g0_b7_i_8_n_0),
        .I3(g0_b7_i_7_n_0),
        .I4(\strnum_v_reg_n_0_[4][4] ),
        .I5(g0_b7_i_16_n_0),
        .O(g0_b7_i_14_n_0));
  (* SOFT_HLUTNM = "soft_lutpair63" *) 
  LUT3 #(
    .INIT(8'hCA)) 
    g0_b7_i_15
       (.I0(\strnum_v_reg_n_0_[5][3] ),
        .I1(\strnum_v[5][3]_i_2_n_0 ),
        .I2(BTN_PRESS_VALID_IN),
        .O(g0_b7_i_15_n_0));
  LUT6 #(
    .INIT(64'h5500540050005400)) 
    g0_b7_i_16
       (.I0(X_IN[5]),
        .I1(\strnum_v_reg_n_0_[2][4] ),
        .I2(BTN_PRESS_VALID_IN),
        .I3(X_IN[4]),
        .I4(X_IN[3]),
        .I5(\strnum_v_reg_n_0_[3][4] ),
        .O(g0_b7_i_16_n_0));
  LUT5 #(
    .INIT(32'h00220A22)) 
    g0_b7_i_1__0
       (.I0(X_IN[9]),
        .I1(g0_b7_i_5__0_n_0),
        .I2(X_IN[4]),
        .I3(X_IN[5]),
        .I4(g0_b7_i_6_n_0),
        .O(g0_b7_i_1__0_n_0));
  LUT5 #(
    .INIT(32'h0000BFBA)) 
    g0_b7_i_2
       (.I0(g0_b7_i_7_n_0),
        .I1(\strnum_v[4][2]_i_2_n_0 ),
        .I2(g0_b7_i_8_n_0),
        .I3(g0_b7_i_9_n_0),
        .I4(g0_b7_i_10_n_0),
        .O(\ids[0]_0 [2]));
  LUT6 #(
    .INIT(64'h10155555FFFFFFFF)) 
    g0_b7_i_2__0
       (.I0(X_IN[5]),
        .I1(g0_b7_i_5_n_0),
        .I2(BTN_PRESS_VALID_IN),
        .I3(\strnum_v_reg_n_0_[3][1] ),
        .I4(\R_OUT[3]_i_7_n_0 ),
        .I5(X_IN[9]),
        .O(g0_b7_i_2__0_n_0));
  LUT6 #(
    .INIT(64'h555A1AAA55511AAA)) 
    g0_b7_i_3
       (.I0(\strnum_v[4][1]_i_2_n_0 ),
        .I1(\strnum_v[2][0]_i_5_n_0 ),
        .I2(\strnum_v[3][0]_i_5_n_0 ),
        .I3(\strnum_v[3][1]_i_2_n_0 ),
        .I4(\strnum_v[3][0]_i_4_n_0 ),
        .I5(\strnum_v[3][0]_i_3_n_0 ),
        .O(g0_b7_i_3_n_0));
  LUT5 #(
    .INIT(32'h88880008)) 
    g0_b7_i_3__0
       (.I0(g0_b7_i_11_n_0),
        .I1(X_IN[9]),
        .I2(g0_b7_i_12_n_0),
        .I3(g0_b7_i_13_n_0),
        .I4(X_IN[5]),
        .O(\ids[0]_0 [3]));
  LUT2 #(
    .INIT(4'h2)) 
    g0_b7_i_4
       (.I0(X_IN[9]),
        .I1(g0_b7_i_14_n_0),
        .O(\ids[0]_0 [4]));
  LUT6 #(
    .INIT(64'hABBABBBBABBAAAAA)) 
    g0_b7_i_4__0
       (.I0(g0_b7_i_7_n_0),
        .I1(g0_b7_i_8_n_0),
        .I2(\strnum_v[4][0]_i_2_n_0 ),
        .I3(BTN_CNTR_reg[1]),
        .I4(BTN_PRESS_VALID_IN),
        .I5(\strnum_v_reg_n_0_[5][1] ),
        .O(g0_b7_i_4__0_n_0));
  LUT6 #(
    .INIT(64'h0484D544880054DD)) 
    g0_b7_i_5
       (.I0(\strnum_v[2][0]_i_4_n_0 ),
        .I1(\strnum_v[3][3]_i_2_n_0 ),
        .I2(\strnum_v[2][0]_i_5_n_0 ),
        .I3(\strnum_v[2][0]_i_6_n_0 ),
        .I4(\strnum_v[2][0]_i_2_n_0 ),
        .I5(\strnum_v[2][0]_i_7_n_0 ),
        .O(g0_b7_i_5_n_0));
  LUT6 #(
    .INIT(64'h1B111BBBFFFFFFFF)) 
    g0_b7_i_5__0
       (.I0(X_IN[3]),
        .I1(\strnum_v[2][0]_i_1_n_0 ),
        .I2(\strnum_v[3][0]_i_2_n_0 ),
        .I3(BTN_PRESS_VALID_IN),
        .I4(\strnum_v_reg_n_0_[3][0] ),
        .I5(X_IN[4]),
        .O(g0_b7_i_5__0_n_0));
  LUT6 #(
    .INIT(64'h55335533000FFF0F)) 
    g0_b7_i_6
       (.I0(\strnum_v[4][0]_i_2_n_0 ),
        .I1(\strnum_v_reg_n_0_[4][0] ),
        .I2(\strnum_v_reg_n_0_[5][0] ),
        .I3(BTN_PRESS_VALID_IN),
        .I4(BTN_CNTR_reg[0]),
        .I5(g0_b7_i_8_n_0),
        .O(g0_b7_i_6_n_0));
  (* SOFT_HLUTNM = "soft_lutpair42" *) 
  LUT2 #(
    .INIT(4'hB)) 
    g0_b7_i_7
       (.I0(X_IN[4]),
        .I1(X_IN[5]),
        .O(g0_b7_i_7_n_0));
  (* SOFT_HLUTNM = "soft_lutpair69" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    g0_b7_i_8
       (.I0(X_IN[5]),
        .I1(X_IN[4]),
        .I2(X_IN[3]),
        .O(g0_b7_i_8_n_0));
  LUT6 #(
    .INIT(64'h22E2EE2EEE2E22E2)) 
    g0_b7_i_9
       (.I0(\strnum_v_reg_n_0_[5][2] ),
        .I1(BTN_PRESS_VALID_IN),
        .I2(\strnum_v[4][0]_i_2_n_0 ),
        .I3(BTN_CNTR_reg[1]),
        .I4(\strnum_v[4][1]_i_2_n_0 ),
        .I5(BTN_CNTR_reg[2]),
        .O(g0_b7_i_9_n_0));
  LUT6 #(
    .INIT(64'h0000000000001A41)) 
    g1_b0
       (.I0(X_IN[3]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(g1_b0_n_0));
  LUT6 #(
    .INIT(64'h0000000008000400)) 
    g1_b1
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b1_n_0));
  LUT6 #(
    .INIT(64'h0000000007C20C80)) 
    g1_b1__0
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b1__0_n_0));
  LUT6 #(
    .INIT(64'h0000000012CDE528)) 
    g1_b1__1
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b1__1_n_0));
  LUT6 #(
    .INIT(64'h0000000002C5E524)) 
    g1_b1__10
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b1__10_n_0));
  LUT6 #(
    .INIT(64'h0000000002C1E504)) 
    g1_b1__11
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b1__11_n_0));
  LUT6 #(
    .INIT(64'h000000000698ED2C)) 
    g1_b1__12
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b1__12_n_0));
  LUT6 #(
    .INIT(64'h000000000F206D12)) 
    g1_b1__13
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b1__13_n_0));
  LUT6 #(
    .INIT(64'h0000000000000400)) 
    g1_b1__14
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b1__14_n_0));
  LUT6 #(
    .INIT(64'h0000000000000400)) 
    g1_b1__15
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b1__15_n_0));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'h00000100)) 
    g1_b1__16
       (.I0(g0_b7_i_1_n_0),
        .I1(g0_b7_i_1__0_n_0),
        .I2(\ids[0]_0 [2]),
        .I3(\ids[0]_0 [3]),
        .I4(\ids[0]_0 [4]),
        .O(g1_b1__16_n_0));
  LUT6 #(
    .INIT(64'h0000000002C5E524)) 
    g1_b1__2
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b1__2_n_0));
  LUT6 #(
    .INIT(64'h0000000002C1E504)) 
    g1_b1__3
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b1__3_n_0));
  LUT6 #(
    .INIT(64'h000000000698ED2C)) 
    g1_b1__4
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b1__4_n_0));
  LUT6 #(
    .INIT(64'h000000000F206D12)) 
    g1_b1__5
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b1__5_n_0));
  LUT6 #(
    .INIT(64'h0000000000003011)) 
    g1_b1__6
       (.I0(X_IN[3]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(g1_b1__6_n_0));
  LUT6 #(
    .INIT(64'h0000000008000400)) 
    g1_b1__7
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b1__7_n_0));
  LUT6 #(
    .INIT(64'h0000000007C20C80)) 
    g1_b1__8
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b1__8_n_0));
  LUT6 #(
    .INIT(64'h0000000012CDE528)) 
    g1_b1__9
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b1__9_n_0));
  LUT6 #(
    .INIT(64'h0000000008000410)) 
    g1_b2
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b2_n_0));
  LUT6 #(
    .INIT(64'h0000000000000450)) 
    g1_b2__0
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b2__0_n_0));
  LUT5 #(
    .INIT(32'h00000004)) 
    g1_b2__1
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_3__0_n_0),
        .I2(g0_b1_i_4_n_0),
        .I3(g0_b1_i_5_n_0),
        .I4(g0_b1_i_6_n_0),
        .O(g1_b2__1_n_0));
  LUT6 #(
    .INIT(64'h0000000000000450)) 
    g1_b2__10
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b2__10_n_0));
  LUT5 #(
    .INIT(32'h00000004)) 
    g1_b2__11
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b2__11_n_0));
  LUT6 #(
    .INIT(64'h0000000007FFEDB8)) 
    g1_b2__12
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b2__12_n_0));
  LUT6 #(
    .INIT(64'h0000000017EFEDBE)) 
    g1_b2__13
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b2__13_n_0));
  LUT6 #(
    .INIT(64'h0000000002E7E5B6)) 
    g1_b2__14
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b2__14_n_0));
  LUT6 #(
    .INIT(64'h0000000002EBED96)) 
    g1_b2__15
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b2__15_n_0));
  LUT6 #(
    .INIT(64'h0000000007FBEDBE)) 
    g1_b2__16
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b2__16_n_0));
  LUT6 #(
    .INIT(64'h000000000FBAFFBE)) 
    g1_b2__17
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b2__17_n_0));
  LUT6 #(
    .INIT(64'h0000000007FFEDB8)) 
    g1_b2__2
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b2__2_n_0));
  LUT6 #(
    .INIT(64'h0000000017EFEDBE)) 
    g1_b2__3
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b2__3_n_0));
  LUT6 #(
    .INIT(64'h0000000002E7E5B6)) 
    g1_b2__4
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b2__4_n_0));
  LUT6 #(
    .INIT(64'h0000000002EBED96)) 
    g1_b2__5
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b2__5_n_0));
  LUT6 #(
    .INIT(64'h0000000007FBEDBE)) 
    g1_b2__6
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b2__6_n_0));
  LUT6 #(
    .INIT(64'h000000000FBAFFBE)) 
    g1_b2__7
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b2__7_n_0));
  LUT6 #(
    .INIT(64'h00000000000001FA)) 
    g1_b2__8
       (.I0(X_IN[3]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(g1_b2__8_n_0));
  LUT6 #(
    .INIT(64'h0000000008000410)) 
    g1_b2__9
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b2__9_n_0));
  LUT6 #(
    .INIT(64'h0000000008001251)) 
    g1_b3
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b3_n_0));
  LUT6 #(
    .INIT(64'h0000000018001250)) 
    g1_b3__0
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b3__0_n_0));
  LUT6 #(
    .INIT(64'h0000000018001010)) 
    g1_b3__1
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b3__1_n_0));
  LUT6 #(
    .INIT(64'h0000000018001250)) 
    g1_b3__10
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b3__10_n_0));
  LUT6 #(
    .INIT(64'h0000000018001010)) 
    g1_b3__11
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b3__11_n_0));
  LUT6 #(
    .INIT(64'h000000001C3DF73E)) 
    g1_b3__12
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b3__12_n_0));
  LUT6 #(
    .INIT(64'h0000000015223A96)) 
    g1_b3__13
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b3__13_n_0));
  LUT6 #(
    .INIT(64'h000000001D221AB2)) 
    g1_b3__14
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b3__14_n_0));
  LUT6 #(
    .INIT(64'h00000000192A1A92)) 
    g1_b3__15
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b3__15_n_0));
  LUT6 #(
    .INIT(64'h000000001BE31292)) 
    g1_b3__16
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b3__16_n_0));
  LUT6 #(
    .INIT(64'h000000000CDA92AC)) 
    g1_b3__17
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b3__17_n_0));
  LUT6 #(
    .INIT(64'h000000001C3DF73E)) 
    g1_b3__2
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b3__2_n_0));
  LUT6 #(
    .INIT(64'h0000000015223A96)) 
    g1_b3__3
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b3__3_n_0));
  LUT6 #(
    .INIT(64'h000000001D221AB2)) 
    g1_b3__4
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b3__4_n_0));
  LUT6 #(
    .INIT(64'h00000000192A1A92)) 
    g1_b3__5
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b3__5_n_0));
  LUT6 #(
    .INIT(64'h000000001BE31292)) 
    g1_b3__6
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b3__6_n_0));
  LUT6 #(
    .INIT(64'h000000000CDA92AC)) 
    g1_b3__7
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b3__7_n_0));
  LUT6 #(
    .INIT(64'h0000000000002AAA)) 
    g1_b3__8
       (.I0(X_IN[3]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(g1_b3__8_n_0));
  LUT6 #(
    .INIT(64'h0000000008001251)) 
    g1_b3__9
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b3__9_n_0));
  LUT6 #(
    .INIT(64'h0000000010101251)) 
    g1_b4
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b4_n_0));
  LUT6 #(
    .INIT(64'h0000000018101200)) 
    g1_b4__0
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b4__0_n_0));
  LUT6 #(
    .INIT(64'h0000000018101000)) 
    g1_b4__1
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b4__1_n_0));
  LUT6 #(
    .INIT(64'h0000000018101200)) 
    g1_b4__10
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b4__10_n_0));
  LUT6 #(
    .INIT(64'h0000000018101000)) 
    g1_b4__11
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b4__11_n_0));
  LUT6 #(
    .INIT(64'h000000001C1FD2BE)) 
    g1_b4__12
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b4__12_n_0));
  LUT6 #(
    .INIT(64'h0000000008143340)) 
    g1_b4__13
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b4__13_n_0));
  LUT6 #(
    .INIT(64'h000000001D983A22)) 
    g1_b4__14
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b4__14_n_0));
  LUT6 #(
    .INIT(64'h000000001D983200)) 
    g1_b4__15
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b4__15_n_0));
  LUT6 #(
    .INIT(64'h000000001AD33280)) 
    g1_b4__16
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b4__16_n_0));
  LUT6 #(
    .INIT(64'h00000000147C927E)) 
    g1_b4__17
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b4__17_n_0));
  LUT6 #(
    .INIT(64'h000000001C1FD2BE)) 
    g1_b4__2
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b4__2_n_0));
  LUT6 #(
    .INIT(64'h0000000008143340)) 
    g1_b4__3
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b4__3_n_0));
  LUT6 #(
    .INIT(64'h000000001D983A22)) 
    g1_b4__4
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b4__4_n_0));
  LUT6 #(
    .INIT(64'h000000001D983200)) 
    g1_b4__5
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b4__5_n_0));
  LUT6 #(
    .INIT(64'h000000001AD33280)) 
    g1_b4__6
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b4__6_n_0));
  LUT6 #(
    .INIT(64'h00000000147C927E)) 
    g1_b4__7
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b4__7_n_0));
  LUT6 #(
    .INIT(64'h0000000000003004)) 
    g1_b4__8
       (.I0(X_IN[3]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(g1_b4__8_n_0));
  LUT6 #(
    .INIT(64'h0000000010101251)) 
    g1_b4__9
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b4__9_n_0));
  LUT6 #(
    .INIT(64'h0000000010001944)) 
    g1_b5
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b5_n_0));
  LUT6 #(
    .INIT(64'h00000000045AABFE)) 
    g1_b5__0
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b5__0_n_0));
  LUT6 #(
    .INIT(64'h0000000009556954)) 
    g1_b5__1
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b5__1_n_0));
  LUT6 #(
    .INIT(64'h00000000015D4966)) 
    g1_b5__10
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b5__10_n_0));
  LUT6 #(
    .INIT(64'h0000000005554944)) 
    g1_b5__11
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b5__11_n_0));
  LUT6 #(
    .INIT(64'h0000000007D749C4)) 
    g1_b5__12
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b5__12_n_0));
  LUT6 #(
    .INIT(64'h0000000014ADDF7E)) 
    g1_b5__13
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b5__13_n_0));
  LUT6 #(
    .INIT(64'h0000000000100944)) 
    g1_b5__14
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b5__14_n_0));
  LUT6 #(
    .INIT(64'h0000000000100944)) 
    g1_b5__15
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b5__15_n_0));
  LUT6 #(
    .INIT(64'h00000000015D4966)) 
    g1_b5__2
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b5__2_n_0));
  LUT6 #(
    .INIT(64'h0000000005554944)) 
    g1_b5__3
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b5__3_n_0));
  LUT6 #(
    .INIT(64'h0000000007D749C4)) 
    g1_b5__4
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b5__4_n_0));
  LUT6 #(
    .INIT(64'h0000000014ADDF7E)) 
    g1_b5__5
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b5__5_n_0));
  LUT6 #(
    .INIT(64'h0000000000000151)) 
    g1_b5__6
       (.I0(X_IN[3]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(g1_b5__6_n_0));
  LUT6 #(
    .INIT(64'h0000000010001944)) 
    g1_b5__7
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b5__7_n_0));
  LUT6 #(
    .INIT(64'h00000000045AABFE)) 
    g1_b5__8
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b5__8_n_0));
  LUT6 #(
    .INIT(64'h0000000009556954)) 
    g1_b5__9
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b5__9_n_0));
  LUT6 #(
    .INIT(64'h0000000010000904)) 
    g1_b6
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b6_n_0));
  LUT6 #(
    .INIT(64'h0000000007FFE9EE)) 
    g1_b6__0
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b6__0_n_0));
  LUT6 #(
    .INIT(64'h000000000FEFE9FC)) 
    g1_b6__1
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b6__1_n_0));
  LUT6 #(
    .INIT(64'h0000000002EFE9FE)) 
    g1_b6__10
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b6__10_n_0));
  LUT6 #(
    .INIT(64'h0000000002E7E9FE)) 
    g1_b6__11
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b6__11_n_0));
  LUT6 #(
    .INIT(64'h0000000007AFE9FE)) 
    g1_b6__12
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b6__12_n_0));
  LUT6 #(
    .INIT(64'h0000000015ADED7E)) 
    g1_b6__13
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b6__13_n_0));
  LUT6 #(
    .INIT(64'h0000000000000944)) 
    g1_b6__14
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b6__14_n_0));
  LUT6 #(
    .INIT(64'h0000000000000944)) 
    g1_b6__15
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b6__15_n_0));
  LUT6 #(
    .INIT(64'h0000000002EFE9FE)) 
    g1_b6__2
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b6__2_n_0));
  LUT6 #(
    .INIT(64'h0000000002E7E9FE)) 
    g1_b6__3
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b6__3_n_0));
  LUT6 #(
    .INIT(64'h0000000007AFE9FE)) 
    g1_b6__4
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b6__4_n_0));
  LUT6 #(
    .INIT(64'h0000000015ADED7E)) 
    g1_b6__5
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b6__5_n_0));
  LUT6 #(
    .INIT(64'h0000000000001800)) 
    g1_b6__6
       (.I0(X_IN[3]),
        .I1(X_IN[4]),
        .I2(X_IN[5]),
        .I3(X_IN[6]),
        .I4(X_IN[7]),
        .I5(X_IN[8]),
        .O(g1_b6__6_n_0));
  LUT6 #(
    .INIT(64'h0000000010000904)) 
    g1_b6__7
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b6__7_n_0));
  LUT6 #(
    .INIT(64'h0000000007FFE9EE)) 
    g1_b6__8
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b6__8_n_0));
  LUT6 #(
    .INIT(64'h000000000FEFE9FC)) 
    g1_b6__9
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b6__9_n_0));
  LUT6 #(
    .INIT(64'h0000000000000904)) 
    g1_b7
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b7_n_0));
  LUT6 #(
    .INIT(64'h0000000007B56000)) 
    g1_b7__0
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b7__0_n_0));
  LUT6 #(
    .INIT(64'h0000000006AAA0E8)) 
    g1_b7__1
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b7__1_n_0));
  LUT6 #(
    .INIT(64'h0000000002A2A0BA)) 
    g1_b7__10
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b7__10_n_0));
  LUT6 #(
    .INIT(64'h0000000000A8A03A)) 
    g1_b7__11
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b7__11_n_0));
  LUT6 #(
    .INIT(64'h0000000005042940)) 
    g1_b7__12
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b7__12_n_0));
  LUT6 #(
    .INIT(64'h0000000002A2A0B8)) 
    g1_b7__2
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b7__2_n_0));
  LUT6 #(
    .INIT(64'h0000000002A2A0BA)) 
    g1_b7__3
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b7__3_n_0));
  LUT6 #(
    .INIT(64'h0000000000A8A03A)) 
    g1_b7__4
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b7__4_n_0));
  LUT6 #(
    .INIT(64'h0000000005042940)) 
    g1_b7__5
       (.I0(g0_b1_i_1__0_n_0),
        .I1(g0_b1_i_2__0_n_0),
        .I2(g0_b1_i_3__0_n_0),
        .I3(g0_b1_i_4_n_0),
        .I4(g0_b1_i_5_n_0),
        .I5(g0_b1_i_6_n_0),
        .O(g1_b7__5_n_0));
  LUT6 #(
    .INIT(64'h0000000000000904)) 
    g1_b7__6
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b7__6_n_0));
  LUT6 #(
    .INIT(64'h0000000007B56000)) 
    g1_b7__7
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b7__7_n_0));
  LUT6 #(
    .INIT(64'h0000000006AAA0E8)) 
    g1_b7__8
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b7__8_n_0));
  LUT6 #(
    .INIT(64'h0000000002A2A0B8)) 
    g1_b7__9
       (.I0(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .I1(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .I2(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .I3(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .I4(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .I5(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .O(g1_b7__9_n_0));
  MUXF7 \ids[0]_inferred__1/G_OUT_reg[3]_i_24 
       (.I0(g0_b6__8_n_0),
        .I1(g1_b6__6_n_0),
        .O(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ),
        .S(X_IN[9]));
  MUXF7 \ids[0]_inferred__1/g0_b1_i_1 
       (.I0(g0_b0_n_0),
        .I1(g1_b0_n_0),
        .O(\ids[0]_inferred__1/g0_b1_i_1_n_0 ),
        .S(X_IN[9]));
  MUXF7 \ids[0]_inferred__1/g0_b1_i_2 
       (.I0(g0_b1__8_n_0),
        .I1(g1_b1__6_n_0),
        .O(\ids[0]_inferred__1/g0_b1_i_2_n_0 ),
        .S(X_IN[9]));
  MUXF7 \ids[0]_inferred__1/g0_b1_i_3 
       (.I0(g0_b2__8_n_0),
        .I1(g1_b2__8_n_0),
        .O(\ids[0]_inferred__1/g0_b1_i_3_n_0 ),
        .S(X_IN[9]));
  MUXF7 \ids[0]_inferred__1/g0_b1_i_4 
       (.I0(g0_b3__8_n_0),
        .I1(g1_b3__8_n_0),
        .O(\ids[0]_inferred__1/g0_b1_i_4_n_0 ),
        .S(X_IN[9]));
  MUXF7 \ids[0]_inferred__1/g0_b1_i_5 
       (.I0(g0_b4__8_n_0),
        .I1(g1_b4__8_n_0),
        .O(\ids[0]_inferred__1/g0_b1_i_5_n_0 ),
        .S(X_IN[9]));
  MUXF7 \ids[0]_inferred__1/g0_b1_i_6 
       (.I0(g0_b5__8_n_0),
        .I1(g1_b5__6_n_0),
        .O(\ids[0]_inferred__1/g0_b1_i_6_n_0 ),
        .S(X_IN[9]));
  (* SOFT_HLUTNM = "soft_lutpair57" *) 
  LUT4 #(
    .INIT(16'h2F20)) 
    \strnum_v[2][0]_i_1 
       (.I0(\strnum_v[2][0]_i_2_n_0 ),
        .I1(\strnum_v[2][0]_i_3_n_0 ),
        .I2(BTN_PRESS_VALID_IN),
        .I3(\strnum_v_reg_n_0_[2][0] ),
        .O(\strnum_v[2][0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair45" *) 
  LUT5 #(
    .INIT(32'hF000E000)) 
    \strnum_v[2][0]_i_2 
       (.I0(BTN_CNTR_reg[5]),
        .I1(BTN_CNTR_reg[6]),
        .I2(BTN_CNTR_reg[8]),
        .I3(BTN_CNTR_reg[9]),
        .I4(BTN_CNTR_reg[7]),
        .O(\strnum_v[2][0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hBFAEAEBFAAABABAA)) 
    \strnum_v[2][0]_i_3 
       (.I0(\strnum_v[2][0]_i_4_n_0 ),
        .I1(\strnum_v[3][3]_i_2_n_0 ),
        .I2(\strnum_v[2][0]_i_5_n_0 ),
        .I3(\strnum_v[2][0]_i_6_n_0 ),
        .I4(\strnum_v[2][0]_i_2_n_0 ),
        .I5(\strnum_v[2][0]_i_7_n_0 ),
        .O(\strnum_v[2][0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h1C303CF33C7108F3)) 
    \strnum_v[2][0]_i_4 
       (.I0(BTN_CNTR_reg[4]),
        .I1(BTN_CNTR_reg[7]),
        .I2(BTN_CNTR_reg[9]),
        .I3(BTN_CNTR_reg[8]),
        .I4(BTN_CNTR_reg[6]),
        .I5(BTN_CNTR_reg[5]),
        .O(\strnum_v[2][0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hF6DB34D0F4D32490)) 
    \strnum_v[2][0]_i_5 
       (.I0(BTN_CNTR_reg[4]),
        .I1(BTN_CNTR_reg[5]),
        .I2(\strnum_v[2][0]_i_8_n_0 ),
        .I3(\strnum_v[2][0]_i_6_n_0 ),
        .I4(\strnum_v[2][0]_i_7_n_0 ),
        .I5(BTN_CNTR_reg[3]),
        .O(\strnum_v[2][0]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair45" *) 
  LUT5 #(
    .INIT(32'h66D64694)) 
    \strnum_v[2][0]_i_6 
       (.I0(BTN_CNTR_reg[7]),
        .I1(BTN_CNTR_reg[9]),
        .I2(BTN_CNTR_reg[8]),
        .I3(BTN_CNTR_reg[6]),
        .I4(BTN_CNTR_reg[5]),
        .O(\strnum_v[2][0]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h37C993EC368113C8)) 
    \strnum_v[2][0]_i_7 
       (.I0(BTN_CNTR_reg[5]),
        .I1(BTN_CNTR_reg[6]),
        .I2(BTN_CNTR_reg[9]),
        .I3(BTN_CNTR_reg[8]),
        .I4(BTN_CNTR_reg[7]),
        .I5(BTN_CNTR_reg[4]),
        .O(\strnum_v[2][0]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hA6DB5924)) 
    \strnum_v[2][0]_i_8 
       (.I0(BTN_CNTR_reg[8]),
        .I1(BTN_CNTR_reg[9]),
        .I2(BTN_CNTR_reg[7]),
        .I3(BTN_CNTR_reg[6]),
        .I4(BTN_CNTR_reg[5]),
        .O(\strnum_v[2][0]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair68" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \strnum_v[2][4]_i_1 
       (.I0(\strnum_v_reg_n_0_[2][4] ),
        .I1(BTN_PRESS_VALID_IN),
        .O(\strnum_v[2][4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair54" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \strnum_v[3][0]_i_1 
       (.I0(\strnum_v[3][0]_i_2_n_0 ),
        .I1(BTN_PRESS_VALID_IN),
        .I2(\strnum_v_reg_n_0_[3][0] ),
        .O(\strnum_v[3][0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFCC4FCC4CCC0FCC4)) 
    \strnum_v[3][0]_i_2 
       (.I0(\strnum_v[3][0]_i_3_n_0 ),
        .I1(\strnum_v[3][0]_i_4_n_0 ),
        .I2(\strnum_v[3][1]_i_2_n_0 ),
        .I3(\strnum_v[3][0]_i_5_n_0 ),
        .I4(\strnum_v[2][0]_i_5_n_0 ),
        .I5(\strnum_v[4][1]_i_2_n_0 ),
        .O(\strnum_v[3][0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hF2FFFB0F2FFFB0FF)) 
    \strnum_v[3][0]_i_3 
       (.I0(\strnum_v[2][0]_i_5_n_0 ),
        .I1(BTN_CNTR_reg[2]),
        .I2(\strnum_v[2][0]_i_7_n_0 ),
        .I3(\strnum_v[4][1]_i_3_n_0 ),
        .I4(BTN_CNTR_reg[3]),
        .I5(BTN_CNTR_reg[4]),
        .O(\strnum_v[3][0]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair51" *) 
  LUT5 #(
    .INIT(32'h8778E11E)) 
    \strnum_v[3][0]_i_4 
       (.I0(\strnum_v[2][0]_i_5_n_0 ),
        .I1(\strnum_v[2][0]_i_7_n_0 ),
        .I2(\strnum_v[2][0]_i_2_n_0 ),
        .I3(\strnum_v[2][0]_i_6_n_0 ),
        .I4(\strnum_v[3][3]_i_2_n_0 ),
        .O(\strnum_v[3][0]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair51" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \strnum_v[3][0]_i_5 
       (.I0(\strnum_v[2][0]_i_5_n_0 ),
        .I1(\strnum_v[3][3]_i_2_n_0 ),
        .I2(\strnum_v[2][0]_i_7_n_0 ),
        .O(\strnum_v[3][0]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'h8AFF8A00)) 
    \strnum_v[3][1]_i_1 
       (.I0(\strnum_v[3][1]_i_2_n_0 ),
        .I1(\strnum_v[2][0]_i_3_n_0 ),
        .I2(\strnum_v[2][0]_i_2_n_0 ),
        .I3(BTN_PRESS_VALID_IN),
        .I4(\strnum_v_reg_n_0_[3][1] ),
        .O(\strnum_v[3][1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h69410000FFFF7D69)) 
    \strnum_v[3][1]_i_2 
       (.I0(\strnum_v[2][0]_i_7_n_0 ),
        .I1(\strnum_v[2][0]_i_2_n_0 ),
        .I2(\strnum_v[2][0]_i_6_n_0 ),
        .I3(\strnum_v[2][0]_i_5_n_0 ),
        .I4(\strnum_v[3][3]_i_2_n_0 ),
        .I5(\strnum_v[2][0]_i_4_n_0 ),
        .O(\strnum_v[3][1]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair62" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \strnum_v[3][2]_i_1 
       (.I0(\strnum_v[3][3]_i_2_n_0 ),
        .I1(BTN_PRESS_VALID_IN),
        .I2(\strnum_v_reg_n_0_[3][2] ),
        .O(\strnum_v[3][2]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hA8FFA800)) 
    \strnum_v[3][3]_i_1 
       (.I0(\strnum_v[2][0]_i_2_n_0 ),
        .I1(\strnum_v[2][0]_i_3_n_0 ),
        .I2(\strnum_v[3][3]_i_2_n_0 ),
        .I3(BTN_PRESS_VALID_IN),
        .I4(\strnum_v_reg_n_0_[3][3] ),
        .O(\strnum_v[3][3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h3C0C3C0C3C0C2CCC)) 
    \strnum_v[3][3]_i_2 
       (.I0(BTN_CNTR_reg[4]),
        .I1(BTN_CNTR_reg[9]),
        .I2(BTN_CNTR_reg[8]),
        .I3(BTN_CNTR_reg[7]),
        .I4(BTN_CNTR_reg[6]),
        .I5(BTN_CNTR_reg[5]),
        .O(\strnum_v[3][3]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \strnum_v[3][4]_i_1 
       (.I0(\strnum_v_reg_n_0_[3][4] ),
        .I1(BTN_PRESS_VALID_IN),
        .O(\strnum_v[3][4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair60" *) 
  LUT3 #(
    .INIT(8'hCA)) 
    \strnum_v[4][0]_i_1 
       (.I0(\strnum_v_reg_n_0_[4][0] ),
        .I1(\strnum_v[4][0]_i_2_n_0 ),
        .I2(BTN_PRESS_VALID_IN),
        .O(\strnum_v[4][0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h6FDB2F5B250B2409)) 
    \strnum_v[4][0]_i_2 
       (.I0(BTN_CNTR_reg[3]),
        .I1(BTN_CNTR_reg[2]),
        .I2(\strnum_v[4][0]_i_3_n_0 ),
        .I3(\strnum_v[2][0]_i_5_n_0 ),
        .I4(BTN_CNTR_reg[1]),
        .I5(\strnum_v[4][1]_i_2_n_0 ),
        .O(\strnum_v[4][0]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \strnum_v[4][0]_i_3 
       (.I0(BTN_CNTR_reg[3]),
        .I1(\strnum_v[2][0]_i_7_n_0 ),
        .I2(BTN_CNTR_reg[4]),
        .O(\strnum_v[4][0]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair54" *) 
  LUT4 #(
    .INIT(16'h6F60)) 
    \strnum_v[4][1]_i_1 
       (.I0(\strnum_v[4][1]_i_2_n_0 ),
        .I1(\strnum_v[3][0]_i_2_n_0 ),
        .I2(BTN_PRESS_VALID_IN),
        .I3(\strnum_v_reg_n_0_[4][1] ),
        .O(\strnum_v[4][1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF6BD56B0F2954290)) 
    \strnum_v[4][1]_i_2 
       (.I0(BTN_CNTR_reg[4]),
        .I1(BTN_CNTR_reg[3]),
        .I2(\strnum_v[4][1]_i_3_n_0 ),
        .I3(\strnum_v[2][0]_i_7_n_0 ),
        .I4(\strnum_v[4][1]_i_4_n_0 ),
        .I5(BTN_CNTR_reg[2]),
        .O(\strnum_v[4][1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h66D6B96B99294694)) 
    \strnum_v[4][1]_i_3 
       (.I0(BTN_CNTR_reg[7]),
        .I1(BTN_CNTR_reg[9]),
        .I2(BTN_CNTR_reg[8]),
        .I3(BTN_CNTR_reg[6]),
        .I4(BTN_CNTR_reg[5]),
        .I5(BTN_CNTR_reg[4]),
        .O(\strnum_v[4][1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hC96CB29B9BC926B2)) 
    \strnum_v[4][1]_i_4 
       (.I0(BTN_CNTR_reg[4]),
        .I1(BTN_CNTR_reg[8]),
        .I2(BTN_CNTR_reg[9]),
        .I3(BTN_CNTR_reg[7]),
        .I4(BTN_CNTR_reg[6]),
        .I5(BTN_CNTR_reg[5]),
        .O(\strnum_v[4][1]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \strnum_v[4][2]_i_1 
       (.I0(\strnum_v[4][2]_i_2_n_0 ),
        .O(\strnum_v[4][2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hB44B0000B44BFFFF)) 
    \strnum_v[4][2]_i_2 
       (.I0(\strnum_v[4][1]_i_2_n_0 ),
        .I1(\strnum_v[3][0]_i_2_n_0 ),
        .I2(\strnum_v[3][1]_i_2_n_0 ),
        .I3(\strnum_v[2][0]_i_5_n_0 ),
        .I4(BTN_PRESS_VALID_IN),
        .I5(\strnum_v_reg_n_0_[4][2] ),
        .O(\strnum_v[4][2]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair65" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \strnum_v[4][3]_i_1 
       (.I0(\strnum_v[4][3]_i_2_n_0 ),
        .I1(BTN_PRESS_VALID_IN),
        .I2(\strnum_v_reg_n_0_[4][3] ),
        .O(\strnum_v[4][3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h07C004CBF30004CB)) 
    \strnum_v[4][3]_i_2 
       (.I0(\strnum_v[3][0]_i_3_n_0 ),
        .I1(\strnum_v[3][0]_i_4_n_0 ),
        .I2(\strnum_v[3][1]_i_2_n_0 ),
        .I3(\strnum_v[3][0]_i_5_n_0 ),
        .I4(\strnum_v[2][0]_i_5_n_0 ),
        .I5(\strnum_v[4][1]_i_2_n_0 ),
        .O(\strnum_v[4][3]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair57" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \strnum_v[4][4]_i_1 
       (.I0(\strnum_v_reg_n_0_[4][4] ),
        .I1(BTN_PRESS_VALID_IN),
        .O(\strnum_v[4][4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair68" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \strnum_v[5][0]_i_1 
       (.I0(BTN_CNTR_reg[0]),
        .I1(BTN_PRESS_VALID_IN),
        .I2(\strnum_v_reg_n_0_[5][0] ),
        .O(\strnum_v[5][0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair60" *) 
  LUT4 #(
    .INIT(16'h6F60)) 
    \strnum_v[5][1]_i_1 
       (.I0(\strnum_v[4][0]_i_2_n_0 ),
        .I1(BTN_CNTR_reg[1]),
        .I2(BTN_PRESS_VALID_IN),
        .I3(\strnum_v_reg_n_0_[5][1] ),
        .O(\strnum_v[5][1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h22E2EE2EEE2E22E2)) 
    \strnum_v[5][2]_i_1 
       (.I0(\strnum_v_reg_n_0_[5][2] ),
        .I1(BTN_PRESS_VALID_IN),
        .I2(\strnum_v[4][0]_i_2_n_0 ),
        .I3(BTN_CNTR_reg[1]),
        .I4(\strnum_v[4][1]_i_2_n_0 ),
        .I5(BTN_CNTR_reg[2]),
        .O(\strnum_v[5][2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair63" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \strnum_v[5][3]_i_1 
       (.I0(\strnum_v[5][3]_i_2_n_0 ),
        .I1(BTN_PRESS_VALID_IN),
        .I2(\strnum_v_reg_n_0_[5][3] ),
        .O(\strnum_v[5][3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h04482FF087700112)) 
    \strnum_v[5][3]_i_2 
       (.I0(BTN_CNTR_reg[1]),
        .I1(BTN_CNTR_reg[2]),
        .I2(\strnum_v[2][0]_i_5_n_0 ),
        .I3(BTN_CNTR_reg[3]),
        .I4(\strnum_v[4][1]_i_2_n_0 ),
        .I5(\strnum_v[4][0]_i_3_n_0 ),
        .O(\strnum_v[5][3]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair65" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \strnum_v[5][4]_i_1 
       (.I0(\strnum_v_reg_n_0_[5][4] ),
        .I1(BTN_PRESS_VALID_IN),
        .O(\strnum_v[5][4]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[2][0] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[2][0]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[2][0] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[2][4] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[2][4]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[2][4] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[3][0] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[3][0]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[3][0] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[3][1] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[3][1]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[3][1] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[3][2] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[3][2]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[3][2] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[3][3] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[3][3]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[3][3] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[3][4] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[3][4]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[3][4] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[4][0] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[4][0]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[4][0] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[4][1] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[4][1]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[4][1] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[4][2] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[4][2]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[4][2] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[4][3] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[4][3]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[4][3] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[4][4] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[4][4]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[4][4] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[5][0] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[5][0]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[5][0] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[5][1] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[5][1]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[5][1] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[5][2] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[5][2]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[5][2] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[5][3] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[5][3]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[5][3] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \strnum_v_reg[5][4] 
       (.C(CLK),
        .CE(1'b1),
        .D(\strnum_v[5][4]_i_1_n_0 ),
        .Q(\strnum_v_reg_n_0_[5][4] ),
        .R(1'b0));
  MUXF7 \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_61 
       (.I0(g0_b4__7_n_0),
        .I1(g1_b4__7_n_0),
        .O(\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_61_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_66 
       (.I0(g0_b5__7_n_0),
        .I1(g1_b5__5_n_0),
        .O(\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_66_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_71 
       (.I0(g0_b6__7_n_0),
        .I1(g1_b6__5_n_0),
        .O(\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_71_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_77 
       (.I0(g0_b7__8_n_0),
        .I1(g1_b7__5_n_0),
        .O(\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_77_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_83 
       (.I0(g0_b1__7_n_0),
        .I1(g1_b1__5_n_0),
        .O(\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_83_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_89 
       (.I0(g0_b2__7_n_0),
        .I1(g1_b2__7_n_0),
        .O(\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_89_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_95 
       (.I0(g0_b3__7_n_0),
        .I1(g1_b3__7_n_0),
        .O(\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_95_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_111 
       (.I0(g0_b3__17_n_0),
        .I1(g1_b3__17_n_0),
        .O(\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_111_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_143 
       (.I0(g0_b1__17_n_0),
        .I1(g1_b1__13_n_0),
        .O(\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_143_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_63 
       (.I0(g0_b6__17_n_0),
        .I1(g1_b6__13_n_0),
        .O(\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_63_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_71 
       (.I0(g0_b7__17_n_0),
        .I1(g1_b7__12_n_0),
        .O(\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_71_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_79 
       (.I0(g0_b5__17_n_0),
        .I1(g1_b5__13_n_0),
        .O(\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_79_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_86 
       (.I0(g0_b4__17_n_0),
        .I1(g1_b4__17_n_0),
        .O(\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_86_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_97 
       (.I0(g0_b2__17_n_0),
        .I1(g1_b2__17_n_0),
        .O(\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_97_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_121 
       (.I0(g0_b4_n_0),
        .I1(g1_b4_n_0),
        .O(\vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_121_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_143 
       (.I0(g0_b2_n_0),
        .I1(g1_b2_n_0),
        .O(\vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_143_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_149 
       (.I0(g0_b3_n_0),
        .I1(g1_b3_n_0),
        .O(\vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_149_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_105 
       (.I0(g0_b2__9_n_0),
        .I1(g1_b2__9_n_0),
        .O(\vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_105_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_118 
       (.I0(g0_b3__9_n_0),
        .I1(g1_b3__9_n_0),
        .O(\vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_118_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_131 
       (.I0(g0_b5__9_n_0),
        .I1(g1_b5__7_n_0),
        .O(\vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_131_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_136 
       (.I0(g0_b4__9_n_0),
        .I1(g1_b4__9_n_0),
        .O(\vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_136_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_75 
       (.I0(g0_b7__9_n_0),
        .I1(g1_b7__6_n_0),
        .O(\vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_75_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_120 
       (.I0(g0_b4__2_n_0),
        .I1(g1_b4__2_n_0),
        .O(\vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_120_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_142 
       (.I0(g0_b2__2_n_0),
        .I1(g1_b2__2_n_0),
        .O(\vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_142_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_148 
       (.I0(g0_b3__2_n_0),
        .I1(g1_b3__2_n_0),
        .O(\vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_148_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_104 
       (.I0(g0_b2__12_n_0),
        .I1(g1_b2__12_n_0),
        .O(\vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_104_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_117 
       (.I0(g0_b3__12_n_0),
        .I1(g1_b3__12_n_0),
        .O(\vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_117_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_94 
       (.I0(g0_b4__12_n_0),
        .I1(g1_b4__12_n_0),
        .O(\vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_94_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_118 
       (.I0(g0_b4__4_n_0),
        .I1(g1_b4__4_n_0),
        .O(\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_118_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_126 
       (.I0(g0_b5__4_n_0),
        .I1(g1_b5__2_n_0),
        .O(\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_126_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_130 
       (.I0(g0_b6__4_n_0),
        .I1(g1_b6__2_n_0),
        .O(\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_130_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_134 
       (.I0(g0_b7__5_n_0),
        .I1(g1_b7__2_n_0),
        .O(\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_134_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_138 
       (.I0(g0_b1__4_n_0),
        .I1(g1_b1__2_n_0),
        .O(\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_138_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_140 
       (.I0(g0_b2__4_n_0),
        .I1(g1_b2__4_n_0),
        .O(\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_140_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_146 
       (.I0(g0_b3__4_n_0),
        .I1(g1_b3__4_n_0),
        .O(\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_146_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_102 
       (.I0(g0_b2__14_n_0),
        .I1(g1_b2__14_n_0),
        .O(\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_102_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_115 
       (.I0(g0_b3__14_n_0),
        .I1(g1_b3__14_n_0),
        .O(\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_115_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_135 
       (.I0(g0_b5__14_n_0),
        .I1(g1_b5__10_n_0),
        .O(\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_135_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_140 
       (.I0(g0_b1__14_n_0),
        .I1(g1_b1__10_n_0),
        .O(\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_140_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_68 
       (.I0(g0_b6__14_n_0),
        .I1(g1_b6__10_n_0),
        .O(\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_68_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_77 
       (.I0(g0_b7__14_n_0),
        .I1(g1_b7__9_n_0),
        .O(\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_77_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_92 
       (.I0(g0_b4__14_n_0),
        .I1(g1_b4__14_n_0),
        .O(\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_92_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_123 
       (.I0(g0_b4__5_n_0),
        .I1(g1_b4__5_n_0),
        .O(\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_123_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_127 
       (.I0(g0_b5__5_n_0),
        .I1(g1_b5__3_n_0),
        .O(\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_127_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_131 
       (.I0(g0_b6__5_n_0),
        .I1(g1_b6__3_n_0),
        .O(\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_131_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_135 
       (.I0(g0_b7__6_n_0),
        .I1(g1_b7__3_n_0),
        .O(\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_135_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_81 
       (.I0(g0_b1__5_n_0),
        .I1(g1_b1__3_n_0),
        .O(\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_81_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_87 
       (.I0(g0_b2__5_n_0),
        .I1(g1_b2__5_n_0),
        .O(\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_87_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_93 
       (.I0(g0_b3__5_n_0),
        .I1(g1_b3__5_n_0),
        .O(\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_93_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_128 
       (.I0(g0_b5__15_n_0),
        .I1(g1_b5__11_n_0),
        .O(\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_128_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_144 
       (.I0(g0_b1__15_n_0),
        .I1(g1_b1__11_n_0),
        .O(\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_144_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_65 
       (.I0(g0_b6__15_n_0),
        .I1(g1_b6__11_n_0),
        .O(\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_65_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_73 
       (.I0(g0_b7__15_n_0),
        .I1(g1_b7__10_n_0),
        .O(\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_73_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_88 
       (.I0(g0_b4__15_n_0),
        .I1(g1_b4__15_n_0),
        .O(\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_88_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_99 
       (.I0(g0_b2__15_n_0),
        .I1(g1_b2__15_n_0),
        .O(\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_99_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_124 
       (.I0(g0_b4__6_n_0),
        .I1(g1_b4__6_n_0),
        .O(\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_124_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_128 
       (.I0(g0_b5__6_n_0),
        .I1(g1_b5__4_n_0),
        .O(\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_128_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_132 
       (.I0(g0_b6__6_n_0),
        .I1(g1_b6__4_n_0),
        .O(\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_132_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_136 
       (.I0(g0_b7__7_n_0),
        .I1(g1_b7__4_n_0),
        .O(\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_136_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_82 
       (.I0(g0_b1__6_n_0),
        .I1(g1_b1__4_n_0),
        .O(\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_82_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_88 
       (.I0(g0_b2__6_n_0),
        .I1(g1_b2__6_n_0),
        .O(\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_88_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_94 
       (.I0(g0_b3__6_n_0),
        .I1(g1_b3__6_n_0),
        .O(\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_94_n_0 ),
        .S(\B_OUT[3]_i_36_n_0 ));
  MUXF7 \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_129 
       (.I0(g0_b5__16_n_0),
        .I1(g1_b5__12_n_0),
        .O(\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_129_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_145 
       (.I0(g0_b1__16_n_0),
        .I1(g1_b1__12_n_0),
        .O(\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_145_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_64 
       (.I0(g0_b6__16_n_0),
        .I1(g1_b6__12_n_0),
        .O(\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_64_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_72 
       (.I0(g0_b7__16_n_0),
        .I1(g1_b7__11_n_0),
        .O(\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_72_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_89 
       (.I0(g0_b4__16_n_0),
        .I1(g1_b4__16_n_0),
        .O(\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_89_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
  MUXF7 \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_98 
       (.I0(g0_b2__16_n_0),
        .I1(g1_b2__16_n_0),
        .O(\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_98_n_0 ),
        .S(\ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0 ));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

endmodule
`endif
