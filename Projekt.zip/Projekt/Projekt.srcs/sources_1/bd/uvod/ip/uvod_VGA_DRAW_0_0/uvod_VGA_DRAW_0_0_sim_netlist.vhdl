-- Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2019.1 (win64) Build 2552052 Fri May 24 14:49:42 MDT 2019
-- Date        : Wed May  6 22:48:39 2026
-- Host        : DESKTOP-TPP71AQ running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               C:/workspace/PEV/uvod/uvod.srcs/sources_1/bd/uvod/ip/uvod_VGA_DRAW_0_0/uvod_VGA_DRAW_0_0_sim_netlist.vhdl
-- Design      : uvod_VGA_DRAW_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7s25csga324-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity uvod_VGA_DRAW_0_0_VGA_DRAW is
  port (
    R_OUT : out STD_LOGIC_VECTOR ( 0 to 0 );
    G_OUT : out STD_LOGIC_VECTOR ( 0 to 0 );
    B_OUT : out STD_LOGIC_VECTOR ( 0 to 0 );
    Y_IN : in STD_LOGIC_VECTOR ( 9 downto 0 );
    X_IN : in STD_LOGIC_VECTOR ( 9 downto 0 );
    BTN_PRESS_VALID_IN : in STD_LOGIC;
    CLK : in STD_LOGIC;
    BUTTONS_IN : in STD_LOGIC_VECTOR ( 15 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of uvod_VGA_DRAW_0_0_VGA_DRAW : entity is "VGA_DRAW";
end uvod_VGA_DRAW_0_0_VGA_DRAW;

architecture STRUCTURE of uvod_VGA_DRAW_0_0_VGA_DRAW is
  signal \BTN_CNTR[9]_i_2_n_0\ : STD_LOGIC;
  signal BTN_CNTR_reg : STD_LOGIC_VECTOR ( 9 downto 0 );
  signal B_OUT0 : STD_LOGIC;
  signal \B_OUT[3]_i_10_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_11_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_16_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_24_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_28_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_29_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_2_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_30_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_31_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_32_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_33_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_34_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_35_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_36_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_37_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_38_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_39_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_40_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_41_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_42_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_43_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_44_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_45_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_46_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_47_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_48_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_49_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_4_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_50_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_51_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_52_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_53_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_54_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_55_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_56_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_60_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_64_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_65_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_68_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_6_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_70_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_74_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_75_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_78_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_7_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_80_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_8_n_0\ : STD_LOGIC;
  signal \B_OUT[3]_i_9_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_100_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_101_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_102_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_103_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_104_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_105_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_106_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_107_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_108_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_109_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_110_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_111_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_112_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_113_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_114_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_115_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_116_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_117_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_119_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_122_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_125_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_129_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_12_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_133_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_137_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_139_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_13_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_141_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_144_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_145_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_147_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_14_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_150_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_15_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_17_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_18_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_19_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_20_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_21_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_22_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_23_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_25_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_26_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_27_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_3_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_57_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_58_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_59_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_5_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_62_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_63_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_67_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_69_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_72_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_73_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_76_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_79_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_84_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_85_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_86_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_90_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_91_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_92_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_96_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_97_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_98_n_0\ : STD_LOGIC;
  signal \B_OUT_reg[3]_i_99_n_0\ : STD_LOGIC;
  signal G_OUT0 : STD_LOGIC;
  signal \G_OUT[3]_i_100_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_107_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_108_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_109_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_10_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_110_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_112_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_113_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_11_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_120_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_122_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_123_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_124_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_125_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_127_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_130_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_132_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_133_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_138_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_13_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_141_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_142_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_146_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_147_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_148_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_149_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_15_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_16_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_17_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_20_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_21_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_22_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_23_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_25_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_27_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_28_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_2_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_30_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_31_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_32_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_33_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_34_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_35_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_37_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_38_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_39_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_3_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_41_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_42_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_43_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_44_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_45_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_46_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_47_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_4_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_52_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_53_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_57_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_58_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_59_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_60_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_61_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_62_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_66_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_69_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_70_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_74_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_78_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_81_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_82_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_84_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_85_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_87_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_8_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_91_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_96_n_0\ : STD_LOGIC;
  signal \G_OUT[3]_i_9_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_101_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_103_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_106_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_114_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_116_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_119_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_121_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_126_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_12_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_134_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_137_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_139_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_14_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_18_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_19_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_26_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_29_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_36_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_40_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_48_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_49_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_50_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_51_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_54_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_55_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_56_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_5_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_67_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_6_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_76_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_7_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_80_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_83_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_90_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_93_n_0\ : STD_LOGIC;
  signal \G_OUT_reg[3]_i_95_n_0\ : STD_LOGIC;
  signal R_OUT0 : STD_LOGIC;
  signal \R_OUT[3]_i_10_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_11_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_12_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_13_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_14_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_15_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_16_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_17_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_18_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_19_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_20_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_22_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_23_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_24_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_25_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_26_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_27_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_28_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_29_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_2_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_30_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_31_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_32_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_33_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_34_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_35_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_36_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_38_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_39_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_3_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_40_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_41_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_42_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_43_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_44_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_45_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_46_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_47_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_48_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_49_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_4_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_50_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_51_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_52_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_53_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_54_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_56_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_57_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_58_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_59_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_5_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_60_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_61_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_62_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_63_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_64_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_65_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_66_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_67_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_68_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_69_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_6_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_70_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_71_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_72_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_73_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_75_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_76_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_77_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_78_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_79_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_7_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_80_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_81_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_82_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_83_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_8_n_0\ : STD_LOGIC;
  signal \R_OUT[3]_i_9_n_0\ : STD_LOGIC;
  signal \R_OUT_reg[3]_i_21_n_0\ : STD_LOGIC;
  signal \R_OUT_reg[3]_i_37_n_0\ : STD_LOGIC;
  signal \R_OUT_reg[3]_i_55_n_0\ : STD_LOGIC;
  signal \R_OUT_reg[3]_i_74_n_0\ : STD_LOGIC;
  signal g0_b0_n_0 : STD_LOGIC;
  signal \g0_b1__0_n_0\ : STD_LOGIC;
  signal \g0_b1__10_n_0\ : STD_LOGIC;
  signal \g0_b1__11_n_0\ : STD_LOGIC;
  signal \g0_b1__12_n_0\ : STD_LOGIC;
  signal \g0_b1__13_n_0\ : STD_LOGIC;
  signal \g0_b1__14_n_0\ : STD_LOGIC;
  signal \g0_b1__15_n_0\ : STD_LOGIC;
  signal \g0_b1__16_n_0\ : STD_LOGIC;
  signal \g0_b1__17_n_0\ : STD_LOGIC;
  signal \g0_b1__18_n_0\ : STD_LOGIC;
  signal \g0_b1__19_n_0\ : STD_LOGIC;
  signal \g0_b1__1_n_0\ : STD_LOGIC;
  signal \g0_b1__20_n_0\ : STD_LOGIC;
  signal \g0_b1__21_n_0\ : STD_LOGIC;
  signal \g0_b1__22_n_0\ : STD_LOGIC;
  signal \g0_b1__23_n_0\ : STD_LOGIC;
  signal \g0_b1__24_n_0\ : STD_LOGIC;
  signal \g0_b1__25_n_0\ : STD_LOGIC;
  signal \g0_b1__26_n_0\ : STD_LOGIC;
  signal \g0_b1__27_n_0\ : STD_LOGIC;
  signal \g0_b1__28_n_0\ : STD_LOGIC;
  signal \g0_b1__29_n_0\ : STD_LOGIC;
  signal \g0_b1__2_n_0\ : STD_LOGIC;
  signal \g0_b1__30_n_0\ : STD_LOGIC;
  signal \g0_b1__31_n_0\ : STD_LOGIC;
  signal \g0_b1__32_n_0\ : STD_LOGIC;
  signal \g0_b1__33_n_0\ : STD_LOGIC;
  signal \g0_b1__34_n_0\ : STD_LOGIC;
  signal \g0_b1__35_n_0\ : STD_LOGIC;
  signal \g0_b1__3_n_0\ : STD_LOGIC;
  signal \g0_b1__4_n_0\ : STD_LOGIC;
  signal \g0_b1__5_n_0\ : STD_LOGIC;
  signal \g0_b1__6_n_0\ : STD_LOGIC;
  signal \g0_b1__7_n_0\ : STD_LOGIC;
  signal \g0_b1__8_n_0\ : STD_LOGIC;
  signal \g0_b1__9_n_0\ : STD_LOGIC;
  signal \g0_b1_i_1__0_n_0\ : STD_LOGIC;
  signal g0_b1_i_1_n_0 : STD_LOGIC;
  signal \g0_b1_i_2__0_n_0\ : STD_LOGIC;
  signal g0_b1_i_2_n_0 : STD_LOGIC;
  signal \g0_b1_i_3__0_n_0\ : STD_LOGIC;
  signal g0_b1_i_3_n_0 : STD_LOGIC;
  signal \g0_b1_i_4__0_n_0\ : STD_LOGIC;
  signal g0_b1_i_4_n_0 : STD_LOGIC;
  signal \g0_b1_i_5__0_n_0\ : STD_LOGIC;
  signal g0_b1_i_5_n_0 : STD_LOGIC;
  signal \g0_b1_i_6__0_n_0\ : STD_LOGIC;
  signal g0_b1_i_6_n_0 : STD_LOGIC;
  signal g0_b1_i_7_n_0 : STD_LOGIC;
  signal g0_b1_i_8_n_0 : STD_LOGIC;
  signal g0_b1_i_9_n_0 : STD_LOGIC;
  signal g0_b1_n_0 : STD_LOGIC;
  signal \g0_b2__0_n_0\ : STD_LOGIC;
  signal \g0_b2__10_n_0\ : STD_LOGIC;
  signal \g0_b2__11_n_0\ : STD_LOGIC;
  signal \g0_b2__12_n_0\ : STD_LOGIC;
  signal \g0_b2__13_n_0\ : STD_LOGIC;
  signal \g0_b2__14_n_0\ : STD_LOGIC;
  signal \g0_b2__15_n_0\ : STD_LOGIC;
  signal \g0_b2__16_n_0\ : STD_LOGIC;
  signal \g0_b2__17_n_0\ : STD_LOGIC;
  signal \g0_b2__18_n_0\ : STD_LOGIC;
  signal \g0_b2__19_n_0\ : STD_LOGIC;
  signal \g0_b2__1_n_0\ : STD_LOGIC;
  signal \g0_b2__20_n_0\ : STD_LOGIC;
  signal \g0_b2__21_n_0\ : STD_LOGIC;
  signal \g0_b2__22_n_0\ : STD_LOGIC;
  signal \g0_b2__23_n_0\ : STD_LOGIC;
  signal \g0_b2__24_n_0\ : STD_LOGIC;
  signal \g0_b2__25_n_0\ : STD_LOGIC;
  signal \g0_b2__26_n_0\ : STD_LOGIC;
  signal \g0_b2__27_n_0\ : STD_LOGIC;
  signal \g0_b2__28_n_0\ : STD_LOGIC;
  signal \g0_b2__29_n_0\ : STD_LOGIC;
  signal \g0_b2__2_n_0\ : STD_LOGIC;
  signal \g0_b2__30_n_0\ : STD_LOGIC;
  signal \g0_b2__31_n_0\ : STD_LOGIC;
  signal \g0_b2__32_n_0\ : STD_LOGIC;
  signal \g0_b2__33_n_0\ : STD_LOGIC;
  signal \g0_b2__34_n_0\ : STD_LOGIC;
  signal \g0_b2__35_n_0\ : STD_LOGIC;
  signal \g0_b2__3_n_0\ : STD_LOGIC;
  signal \g0_b2__4_n_0\ : STD_LOGIC;
  signal \g0_b2__5_n_0\ : STD_LOGIC;
  signal \g0_b2__6_n_0\ : STD_LOGIC;
  signal \g0_b2__7_n_0\ : STD_LOGIC;
  signal \g0_b2__8_n_0\ : STD_LOGIC;
  signal \g0_b2__9_n_0\ : STD_LOGIC;
  signal g0_b2_n_0 : STD_LOGIC;
  signal \g0_b3__0_n_0\ : STD_LOGIC;
  signal \g0_b3__10_n_0\ : STD_LOGIC;
  signal \g0_b3__11_n_0\ : STD_LOGIC;
  signal \g0_b3__12_n_0\ : STD_LOGIC;
  signal \g0_b3__13_n_0\ : STD_LOGIC;
  signal \g0_b3__14_n_0\ : STD_LOGIC;
  signal \g0_b3__15_n_0\ : STD_LOGIC;
  signal \g0_b3__16_n_0\ : STD_LOGIC;
  signal \g0_b3__17_n_0\ : STD_LOGIC;
  signal \g0_b3__18_n_0\ : STD_LOGIC;
  signal \g0_b3__19_n_0\ : STD_LOGIC;
  signal \g0_b3__1_n_0\ : STD_LOGIC;
  signal \g0_b3__20_n_0\ : STD_LOGIC;
  signal \g0_b3__21_n_0\ : STD_LOGIC;
  signal \g0_b3__22_n_0\ : STD_LOGIC;
  signal \g0_b3__23_n_0\ : STD_LOGIC;
  signal \g0_b3__24_n_0\ : STD_LOGIC;
  signal \g0_b3__25_n_0\ : STD_LOGIC;
  signal \g0_b3__26_n_0\ : STD_LOGIC;
  signal \g0_b3__27_n_0\ : STD_LOGIC;
  signal \g0_b3__28_n_0\ : STD_LOGIC;
  signal \g0_b3__29_n_0\ : STD_LOGIC;
  signal \g0_b3__2_n_0\ : STD_LOGIC;
  signal \g0_b3__30_n_0\ : STD_LOGIC;
  signal \g0_b3__31_n_0\ : STD_LOGIC;
  signal \g0_b3__32_n_0\ : STD_LOGIC;
  signal \g0_b3__33_n_0\ : STD_LOGIC;
  signal \g0_b3__34_n_0\ : STD_LOGIC;
  signal \g0_b3__35_n_0\ : STD_LOGIC;
  signal \g0_b3__3_n_0\ : STD_LOGIC;
  signal \g0_b3__4_n_0\ : STD_LOGIC;
  signal \g0_b3__5_n_0\ : STD_LOGIC;
  signal \g0_b3__6_n_0\ : STD_LOGIC;
  signal \g0_b3__7_n_0\ : STD_LOGIC;
  signal \g0_b3__8_n_0\ : STD_LOGIC;
  signal \g0_b3__9_n_0\ : STD_LOGIC;
  signal g0_b3_n_0 : STD_LOGIC;
  signal \g0_b4__0_n_0\ : STD_LOGIC;
  signal \g0_b4__10_n_0\ : STD_LOGIC;
  signal \g0_b4__11_n_0\ : STD_LOGIC;
  signal \g0_b4__12_n_0\ : STD_LOGIC;
  signal \g0_b4__13_n_0\ : STD_LOGIC;
  signal \g0_b4__14_n_0\ : STD_LOGIC;
  signal \g0_b4__15_n_0\ : STD_LOGIC;
  signal \g0_b4__16_n_0\ : STD_LOGIC;
  signal \g0_b4__17_n_0\ : STD_LOGIC;
  signal \g0_b4__18_n_0\ : STD_LOGIC;
  signal \g0_b4__19_n_0\ : STD_LOGIC;
  signal \g0_b4__1_n_0\ : STD_LOGIC;
  signal \g0_b4__20_n_0\ : STD_LOGIC;
  signal \g0_b4__21_n_0\ : STD_LOGIC;
  signal \g0_b4__22_n_0\ : STD_LOGIC;
  signal \g0_b4__23_n_0\ : STD_LOGIC;
  signal \g0_b4__24_n_0\ : STD_LOGIC;
  signal \g0_b4__25_n_0\ : STD_LOGIC;
  signal \g0_b4__26_n_0\ : STD_LOGIC;
  signal \g0_b4__27_n_0\ : STD_LOGIC;
  signal \g0_b4__28_n_0\ : STD_LOGIC;
  signal \g0_b4__29_n_0\ : STD_LOGIC;
  signal \g0_b4__2_n_0\ : STD_LOGIC;
  signal \g0_b4__30_n_0\ : STD_LOGIC;
  signal \g0_b4__31_n_0\ : STD_LOGIC;
  signal \g0_b4__32_n_0\ : STD_LOGIC;
  signal \g0_b4__33_n_0\ : STD_LOGIC;
  signal \g0_b4__34_n_0\ : STD_LOGIC;
  signal \g0_b4__35_n_0\ : STD_LOGIC;
  signal \g0_b4__3_n_0\ : STD_LOGIC;
  signal \g0_b4__4_n_0\ : STD_LOGIC;
  signal \g0_b4__5_n_0\ : STD_LOGIC;
  signal \g0_b4__6_n_0\ : STD_LOGIC;
  signal \g0_b4__7_n_0\ : STD_LOGIC;
  signal \g0_b4__8_n_0\ : STD_LOGIC;
  signal \g0_b4__9_n_0\ : STD_LOGIC;
  signal g0_b4_n_0 : STD_LOGIC;
  signal \g0_b5__0_n_0\ : STD_LOGIC;
  signal \g0_b5__10_n_0\ : STD_LOGIC;
  signal \g0_b5__11_n_0\ : STD_LOGIC;
  signal \g0_b5__12_n_0\ : STD_LOGIC;
  signal \g0_b5__13_n_0\ : STD_LOGIC;
  signal \g0_b5__14_n_0\ : STD_LOGIC;
  signal \g0_b5__15_n_0\ : STD_LOGIC;
  signal \g0_b5__16_n_0\ : STD_LOGIC;
  signal \g0_b5__17_n_0\ : STD_LOGIC;
  signal \g0_b5__18_n_0\ : STD_LOGIC;
  signal \g0_b5__19_n_0\ : STD_LOGIC;
  signal \g0_b5__1_n_0\ : STD_LOGIC;
  signal \g0_b5__20_n_0\ : STD_LOGIC;
  signal \g0_b5__21_n_0\ : STD_LOGIC;
  signal \g0_b5__22_n_0\ : STD_LOGIC;
  signal \g0_b5__23_n_0\ : STD_LOGIC;
  signal \g0_b5__24_n_0\ : STD_LOGIC;
  signal \g0_b5__25_n_0\ : STD_LOGIC;
  signal \g0_b5__26_n_0\ : STD_LOGIC;
  signal \g0_b5__27_n_0\ : STD_LOGIC;
  signal \g0_b5__28_n_0\ : STD_LOGIC;
  signal \g0_b5__29_n_0\ : STD_LOGIC;
  signal \g0_b5__2_n_0\ : STD_LOGIC;
  signal \g0_b5__30_n_0\ : STD_LOGIC;
  signal \g0_b5__31_n_0\ : STD_LOGIC;
  signal \g0_b5__32_n_0\ : STD_LOGIC;
  signal \g0_b5__33_n_0\ : STD_LOGIC;
  signal \g0_b5__34_n_0\ : STD_LOGIC;
  signal \g0_b5__3_n_0\ : STD_LOGIC;
  signal \g0_b5__4_n_0\ : STD_LOGIC;
  signal \g0_b5__5_n_0\ : STD_LOGIC;
  signal \g0_b5__6_n_0\ : STD_LOGIC;
  signal \g0_b5__7_n_0\ : STD_LOGIC;
  signal \g0_b5__8_n_0\ : STD_LOGIC;
  signal \g0_b5__9_n_0\ : STD_LOGIC;
  signal g0_b5_n_0 : STD_LOGIC;
  signal \g0_b6__0_n_0\ : STD_LOGIC;
  signal \g0_b6__10_n_0\ : STD_LOGIC;
  signal \g0_b6__11_n_0\ : STD_LOGIC;
  signal \g0_b6__12_n_0\ : STD_LOGIC;
  signal \g0_b6__13_n_0\ : STD_LOGIC;
  signal \g0_b6__14_n_0\ : STD_LOGIC;
  signal \g0_b6__15_n_0\ : STD_LOGIC;
  signal \g0_b6__16_n_0\ : STD_LOGIC;
  signal \g0_b6__17_n_0\ : STD_LOGIC;
  signal \g0_b6__18_n_0\ : STD_LOGIC;
  signal \g0_b6__19_n_0\ : STD_LOGIC;
  signal \g0_b6__1_n_0\ : STD_LOGIC;
  signal \g0_b6__20_n_0\ : STD_LOGIC;
  signal \g0_b6__21_n_0\ : STD_LOGIC;
  signal \g0_b6__22_n_0\ : STD_LOGIC;
  signal \g0_b6__23_n_0\ : STD_LOGIC;
  signal \g0_b6__24_n_0\ : STD_LOGIC;
  signal \g0_b6__25_n_0\ : STD_LOGIC;
  signal \g0_b6__26_n_0\ : STD_LOGIC;
  signal \g0_b6__27_n_0\ : STD_LOGIC;
  signal \g0_b6__28_n_0\ : STD_LOGIC;
  signal \g0_b6__29_n_0\ : STD_LOGIC;
  signal \g0_b6__2_n_0\ : STD_LOGIC;
  signal \g0_b6__30_n_0\ : STD_LOGIC;
  signal \g0_b6__31_n_0\ : STD_LOGIC;
  signal \g0_b6__32_n_0\ : STD_LOGIC;
  signal \g0_b6__33_n_0\ : STD_LOGIC;
  signal \g0_b6__34_n_0\ : STD_LOGIC;
  signal \g0_b6__35_n_0\ : STD_LOGIC;
  signal \g0_b6__3_n_0\ : STD_LOGIC;
  signal \g0_b6__4_n_0\ : STD_LOGIC;
  signal \g0_b6__5_n_0\ : STD_LOGIC;
  signal \g0_b6__6_n_0\ : STD_LOGIC;
  signal \g0_b6__7_n_0\ : STD_LOGIC;
  signal \g0_b6__8_n_0\ : STD_LOGIC;
  signal \g0_b6__9_n_0\ : STD_LOGIC;
  signal g0_b6_n_0 : STD_LOGIC;
  signal \g0_b7__0_n_0\ : STD_LOGIC;
  signal \g0_b7__10_n_0\ : STD_LOGIC;
  signal \g0_b7__11_n_0\ : STD_LOGIC;
  signal \g0_b7__12_n_0\ : STD_LOGIC;
  signal \g0_b7__13_n_0\ : STD_LOGIC;
  signal \g0_b7__14_n_0\ : STD_LOGIC;
  signal \g0_b7__15_n_0\ : STD_LOGIC;
  signal \g0_b7__16_n_0\ : STD_LOGIC;
  signal \g0_b7__17_n_0\ : STD_LOGIC;
  signal \g0_b7__18_n_0\ : STD_LOGIC;
  signal \g0_b7__19_n_0\ : STD_LOGIC;
  signal \g0_b7__1_n_0\ : STD_LOGIC;
  signal \g0_b7__20_n_0\ : STD_LOGIC;
  signal \g0_b7__21_n_0\ : STD_LOGIC;
  signal \g0_b7__22_n_0\ : STD_LOGIC;
  signal \g0_b7__23_n_0\ : STD_LOGIC;
  signal \g0_b7__24_n_0\ : STD_LOGIC;
  signal \g0_b7__25_n_0\ : STD_LOGIC;
  signal \g0_b7__26_n_0\ : STD_LOGIC;
  signal \g0_b7__27_n_0\ : STD_LOGIC;
  signal \g0_b7__28_n_0\ : STD_LOGIC;
  signal \g0_b7__29_n_0\ : STD_LOGIC;
  signal \g0_b7__2_n_0\ : STD_LOGIC;
  signal \g0_b7__30_n_0\ : STD_LOGIC;
  signal \g0_b7__31_n_0\ : STD_LOGIC;
  signal \g0_b7__32_n_0\ : STD_LOGIC;
  signal \g0_b7__3_n_0\ : STD_LOGIC;
  signal \g0_b7__4_n_0\ : STD_LOGIC;
  signal \g0_b7__5_n_0\ : STD_LOGIC;
  signal \g0_b7__6_n_0\ : STD_LOGIC;
  signal \g0_b7__7_n_0\ : STD_LOGIC;
  signal \g0_b7__8_n_0\ : STD_LOGIC;
  signal \g0_b7__9_n_0\ : STD_LOGIC;
  signal g0_b7_i_10_n_0 : STD_LOGIC;
  signal g0_b7_i_11_n_0 : STD_LOGIC;
  signal g0_b7_i_12_n_0 : STD_LOGIC;
  signal g0_b7_i_13_n_0 : STD_LOGIC;
  signal g0_b7_i_14_n_0 : STD_LOGIC;
  signal g0_b7_i_15_n_0 : STD_LOGIC;
  signal g0_b7_i_16_n_0 : STD_LOGIC;
  signal \g0_b7_i_1__0_n_0\ : STD_LOGIC;
  signal g0_b7_i_1_n_0 : STD_LOGIC;
  signal \g0_b7_i_2__0_n_0\ : STD_LOGIC;
  signal g0_b7_i_3_n_0 : STD_LOGIC;
  signal \g0_b7_i_4__0_n_0\ : STD_LOGIC;
  signal \g0_b7_i_5__0_n_0\ : STD_LOGIC;
  signal g0_b7_i_5_n_0 : STD_LOGIC;
  signal g0_b7_i_6_n_0 : STD_LOGIC;
  signal g0_b7_i_7_n_0 : STD_LOGIC;
  signal g0_b7_i_8_n_0 : STD_LOGIC;
  signal g0_b7_i_9_n_0 : STD_LOGIC;
  signal g0_b7_n_0 : STD_LOGIC;
  signal g1_b0_n_0 : STD_LOGIC;
  signal \g1_b1__0_n_0\ : STD_LOGIC;
  signal \g1_b1__10_n_0\ : STD_LOGIC;
  signal \g1_b1__11_n_0\ : STD_LOGIC;
  signal \g1_b1__12_n_0\ : STD_LOGIC;
  signal \g1_b1__13_n_0\ : STD_LOGIC;
  signal \g1_b1__14_n_0\ : STD_LOGIC;
  signal \g1_b1__15_n_0\ : STD_LOGIC;
  signal \g1_b1__16_n_0\ : STD_LOGIC;
  signal \g1_b1__1_n_0\ : STD_LOGIC;
  signal \g1_b1__2_n_0\ : STD_LOGIC;
  signal \g1_b1__3_n_0\ : STD_LOGIC;
  signal \g1_b1__4_n_0\ : STD_LOGIC;
  signal \g1_b1__5_n_0\ : STD_LOGIC;
  signal \g1_b1__6_n_0\ : STD_LOGIC;
  signal \g1_b1__7_n_0\ : STD_LOGIC;
  signal \g1_b1__8_n_0\ : STD_LOGIC;
  signal \g1_b1__9_n_0\ : STD_LOGIC;
  signal g1_b1_n_0 : STD_LOGIC;
  signal \g1_b2__0_n_0\ : STD_LOGIC;
  signal \g1_b2__10_n_0\ : STD_LOGIC;
  signal \g1_b2__11_n_0\ : STD_LOGIC;
  signal \g1_b2__12_n_0\ : STD_LOGIC;
  signal \g1_b2__13_n_0\ : STD_LOGIC;
  signal \g1_b2__14_n_0\ : STD_LOGIC;
  signal \g1_b2__15_n_0\ : STD_LOGIC;
  signal \g1_b2__16_n_0\ : STD_LOGIC;
  signal \g1_b2__17_n_0\ : STD_LOGIC;
  signal \g1_b2__1_n_0\ : STD_LOGIC;
  signal \g1_b2__2_n_0\ : STD_LOGIC;
  signal \g1_b2__3_n_0\ : STD_LOGIC;
  signal \g1_b2__4_n_0\ : STD_LOGIC;
  signal \g1_b2__5_n_0\ : STD_LOGIC;
  signal \g1_b2__6_n_0\ : STD_LOGIC;
  signal \g1_b2__7_n_0\ : STD_LOGIC;
  signal \g1_b2__8_n_0\ : STD_LOGIC;
  signal \g1_b2__9_n_0\ : STD_LOGIC;
  signal g1_b2_n_0 : STD_LOGIC;
  signal \g1_b3__0_n_0\ : STD_LOGIC;
  signal \g1_b3__10_n_0\ : STD_LOGIC;
  signal \g1_b3__11_n_0\ : STD_LOGIC;
  signal \g1_b3__12_n_0\ : STD_LOGIC;
  signal \g1_b3__13_n_0\ : STD_LOGIC;
  signal \g1_b3__14_n_0\ : STD_LOGIC;
  signal \g1_b3__15_n_0\ : STD_LOGIC;
  signal \g1_b3__16_n_0\ : STD_LOGIC;
  signal \g1_b3__17_n_0\ : STD_LOGIC;
  signal \g1_b3__1_n_0\ : STD_LOGIC;
  signal \g1_b3__2_n_0\ : STD_LOGIC;
  signal \g1_b3__3_n_0\ : STD_LOGIC;
  signal \g1_b3__4_n_0\ : STD_LOGIC;
  signal \g1_b3__5_n_0\ : STD_LOGIC;
  signal \g1_b3__6_n_0\ : STD_LOGIC;
  signal \g1_b3__7_n_0\ : STD_LOGIC;
  signal \g1_b3__8_n_0\ : STD_LOGIC;
  signal \g1_b3__9_n_0\ : STD_LOGIC;
  signal g1_b3_n_0 : STD_LOGIC;
  signal \g1_b4__0_n_0\ : STD_LOGIC;
  signal \g1_b4__10_n_0\ : STD_LOGIC;
  signal \g1_b4__11_n_0\ : STD_LOGIC;
  signal \g1_b4__12_n_0\ : STD_LOGIC;
  signal \g1_b4__13_n_0\ : STD_LOGIC;
  signal \g1_b4__14_n_0\ : STD_LOGIC;
  signal \g1_b4__15_n_0\ : STD_LOGIC;
  signal \g1_b4__16_n_0\ : STD_LOGIC;
  signal \g1_b4__17_n_0\ : STD_LOGIC;
  signal \g1_b4__1_n_0\ : STD_LOGIC;
  signal \g1_b4__2_n_0\ : STD_LOGIC;
  signal \g1_b4__3_n_0\ : STD_LOGIC;
  signal \g1_b4__4_n_0\ : STD_LOGIC;
  signal \g1_b4__5_n_0\ : STD_LOGIC;
  signal \g1_b4__6_n_0\ : STD_LOGIC;
  signal \g1_b4__7_n_0\ : STD_LOGIC;
  signal \g1_b4__8_n_0\ : STD_LOGIC;
  signal \g1_b4__9_n_0\ : STD_LOGIC;
  signal g1_b4_n_0 : STD_LOGIC;
  signal \g1_b5__0_n_0\ : STD_LOGIC;
  signal \g1_b5__10_n_0\ : STD_LOGIC;
  signal \g1_b5__11_n_0\ : STD_LOGIC;
  signal \g1_b5__12_n_0\ : STD_LOGIC;
  signal \g1_b5__13_n_0\ : STD_LOGIC;
  signal \g1_b5__14_n_0\ : STD_LOGIC;
  signal \g1_b5__15_n_0\ : STD_LOGIC;
  signal \g1_b5__1_n_0\ : STD_LOGIC;
  signal \g1_b5__2_n_0\ : STD_LOGIC;
  signal \g1_b5__3_n_0\ : STD_LOGIC;
  signal \g1_b5__4_n_0\ : STD_LOGIC;
  signal \g1_b5__5_n_0\ : STD_LOGIC;
  signal \g1_b5__6_n_0\ : STD_LOGIC;
  signal \g1_b5__7_n_0\ : STD_LOGIC;
  signal \g1_b5__8_n_0\ : STD_LOGIC;
  signal \g1_b5__9_n_0\ : STD_LOGIC;
  signal g1_b5_n_0 : STD_LOGIC;
  signal \g1_b6__0_n_0\ : STD_LOGIC;
  signal \g1_b6__10_n_0\ : STD_LOGIC;
  signal \g1_b6__11_n_0\ : STD_LOGIC;
  signal \g1_b6__12_n_0\ : STD_LOGIC;
  signal \g1_b6__13_n_0\ : STD_LOGIC;
  signal \g1_b6__14_n_0\ : STD_LOGIC;
  signal \g1_b6__15_n_0\ : STD_LOGIC;
  signal \g1_b6__1_n_0\ : STD_LOGIC;
  signal \g1_b6__2_n_0\ : STD_LOGIC;
  signal \g1_b6__3_n_0\ : STD_LOGIC;
  signal \g1_b6__4_n_0\ : STD_LOGIC;
  signal \g1_b6__5_n_0\ : STD_LOGIC;
  signal \g1_b6__6_n_0\ : STD_LOGIC;
  signal \g1_b6__7_n_0\ : STD_LOGIC;
  signal \g1_b6__8_n_0\ : STD_LOGIC;
  signal \g1_b6__9_n_0\ : STD_LOGIC;
  signal g1_b6_n_0 : STD_LOGIC;
  signal \g1_b7__0_n_0\ : STD_LOGIC;
  signal \g1_b7__10_n_0\ : STD_LOGIC;
  signal \g1_b7__11_n_0\ : STD_LOGIC;
  signal \g1_b7__12_n_0\ : STD_LOGIC;
  signal \g1_b7__1_n_0\ : STD_LOGIC;
  signal \g1_b7__2_n_0\ : STD_LOGIC;
  signal \g1_b7__3_n_0\ : STD_LOGIC;
  signal \g1_b7__4_n_0\ : STD_LOGIC;
  signal \g1_b7__5_n_0\ : STD_LOGIC;
  signal \g1_b7__6_n_0\ : STD_LOGIC;
  signal \g1_b7__7_n_0\ : STD_LOGIC;
  signal \g1_b7__8_n_0\ : STD_LOGIC;
  signal \g1_b7__9_n_0\ : STD_LOGIC;
  signal g1_b7_n_0 : STD_LOGIC;
  signal \ids[0]_0\ : STD_LOGIC_VECTOR ( 4 downto 2 );
  signal \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\ : STD_LOGIC;
  signal \ids[0]_inferred__1/g0_b1_i_1_n_0\ : STD_LOGIC;
  signal \ids[0]_inferred__1/g0_b1_i_2_n_0\ : STD_LOGIC;
  signal \ids[0]_inferred__1/g0_b1_i_3_n_0\ : STD_LOGIC;
  signal \ids[0]_inferred__1/g0_b1_i_4_n_0\ : STD_LOGIC;
  signal \ids[0]_inferred__1/g0_b1_i_5_n_0\ : STD_LOGIC;
  signal \ids[0]_inferred__1/g0_b1_i_6_n_0\ : STD_LOGIC;
  signal plusOp : STD_LOGIC_VECTOR ( 9 downto 0 );
  signal \strnum_v[2][0]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v[2][0]_i_2_n_0\ : STD_LOGIC;
  signal \strnum_v[2][0]_i_3_n_0\ : STD_LOGIC;
  signal \strnum_v[2][0]_i_4_n_0\ : STD_LOGIC;
  signal \strnum_v[2][0]_i_5_n_0\ : STD_LOGIC;
  signal \strnum_v[2][0]_i_6_n_0\ : STD_LOGIC;
  signal \strnum_v[2][0]_i_7_n_0\ : STD_LOGIC;
  signal \strnum_v[2][0]_i_8_n_0\ : STD_LOGIC;
  signal \strnum_v[2][4]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v[3][0]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v[3][0]_i_2_n_0\ : STD_LOGIC;
  signal \strnum_v[3][0]_i_3_n_0\ : STD_LOGIC;
  signal \strnum_v[3][0]_i_4_n_0\ : STD_LOGIC;
  signal \strnum_v[3][0]_i_5_n_0\ : STD_LOGIC;
  signal \strnum_v[3][1]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v[3][1]_i_2_n_0\ : STD_LOGIC;
  signal \strnum_v[3][2]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v[3][3]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v[3][3]_i_2_n_0\ : STD_LOGIC;
  signal \strnum_v[3][4]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v[4][0]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v[4][0]_i_2_n_0\ : STD_LOGIC;
  signal \strnum_v[4][0]_i_3_n_0\ : STD_LOGIC;
  signal \strnum_v[4][1]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v[4][1]_i_2_n_0\ : STD_LOGIC;
  signal \strnum_v[4][1]_i_3_n_0\ : STD_LOGIC;
  signal \strnum_v[4][1]_i_4_n_0\ : STD_LOGIC;
  signal \strnum_v[4][2]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v[4][2]_i_2_n_0\ : STD_LOGIC;
  signal \strnum_v[4][3]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v[4][3]_i_2_n_0\ : STD_LOGIC;
  signal \strnum_v[4][4]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v[5][0]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v[5][1]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v[5][2]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v[5][3]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v[5][3]_i_2_n_0\ : STD_LOGIC;
  signal \strnum_v[5][4]_i_1_n_0\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[2][0]\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[2][4]\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[3][0]\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[3][1]\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[3][2]\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[3][3]\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[3][4]\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[4][0]\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[4][1]\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[4][2]\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[4][3]\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[4][4]\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[5][0]\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[5][1]\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[5][2]\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[5][3]\ : STD_LOGIC;
  signal \strnum_v_reg_n_0_[5][4]\ : STD_LOGIC;
  signal \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_61_n_0\ : STD_LOGIC;
  signal \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_66_n_0\ : STD_LOGIC;
  signal \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_71_n_0\ : STD_LOGIC;
  signal \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_77_n_0\ : STD_LOGIC;
  signal \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_83_n_0\ : STD_LOGIC;
  signal \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_89_n_0\ : STD_LOGIC;
  signal \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_95_n_0\ : STD_LOGIC;
  signal \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_111_n_0\ : STD_LOGIC;
  signal \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_143_n_0\ : STD_LOGIC;
  signal \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_63_n_0\ : STD_LOGIC;
  signal \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_71_n_0\ : STD_LOGIC;
  signal \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_79_n_0\ : STD_LOGIC;
  signal \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_86_n_0\ : STD_LOGIC;
  signal \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_97_n_0\ : STD_LOGIC;
  signal \vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_121_n_0\ : STD_LOGIC;
  signal \vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_143_n_0\ : STD_LOGIC;
  signal \vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_149_n_0\ : STD_LOGIC;
  signal \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_105_n_0\ : STD_LOGIC;
  signal \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_118_n_0\ : STD_LOGIC;
  signal \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_131_n_0\ : STD_LOGIC;
  signal \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_136_n_0\ : STD_LOGIC;
  signal \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_75_n_0\ : STD_LOGIC;
  signal \vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_120_n_0\ : STD_LOGIC;
  signal \vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_142_n_0\ : STD_LOGIC;
  signal \vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_148_n_0\ : STD_LOGIC;
  signal \vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_104_n_0\ : STD_LOGIC;
  signal \vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_117_n_0\ : STD_LOGIC;
  signal \vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_94_n_0\ : STD_LOGIC;
  signal \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_118_n_0\ : STD_LOGIC;
  signal \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_126_n_0\ : STD_LOGIC;
  signal \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_130_n_0\ : STD_LOGIC;
  signal \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_134_n_0\ : STD_LOGIC;
  signal \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_138_n_0\ : STD_LOGIC;
  signal \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_140_n_0\ : STD_LOGIC;
  signal \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_146_n_0\ : STD_LOGIC;
  signal \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_102_n_0\ : STD_LOGIC;
  signal \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_115_n_0\ : STD_LOGIC;
  signal \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_135_n_0\ : STD_LOGIC;
  signal \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_140_n_0\ : STD_LOGIC;
  signal \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_68_n_0\ : STD_LOGIC;
  signal \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_77_n_0\ : STD_LOGIC;
  signal \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_92_n_0\ : STD_LOGIC;
  signal \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_123_n_0\ : STD_LOGIC;
  signal \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_127_n_0\ : STD_LOGIC;
  signal \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_131_n_0\ : STD_LOGIC;
  signal \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_135_n_0\ : STD_LOGIC;
  signal \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_81_n_0\ : STD_LOGIC;
  signal \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_87_n_0\ : STD_LOGIC;
  signal \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_93_n_0\ : STD_LOGIC;
  signal \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_128_n_0\ : STD_LOGIC;
  signal \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_144_n_0\ : STD_LOGIC;
  signal \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_65_n_0\ : STD_LOGIC;
  signal \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_73_n_0\ : STD_LOGIC;
  signal \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_88_n_0\ : STD_LOGIC;
  signal \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_99_n_0\ : STD_LOGIC;
  signal \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_124_n_0\ : STD_LOGIC;
  signal \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_128_n_0\ : STD_LOGIC;
  signal \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_132_n_0\ : STD_LOGIC;
  signal \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_136_n_0\ : STD_LOGIC;
  signal \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_82_n_0\ : STD_LOGIC;
  signal \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_88_n_0\ : STD_LOGIC;
  signal \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_94_n_0\ : STD_LOGIC;
  signal \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_129_n_0\ : STD_LOGIC;
  signal \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_145_n_0\ : STD_LOGIC;
  signal \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_64_n_0\ : STD_LOGIC;
  signal \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_72_n_0\ : STD_LOGIC;
  signal \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_89_n_0\ : STD_LOGIC;
  signal \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_98_n_0\ : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \BTN_CNTR[1]_i_1\ : label is "soft_lutpair66";
  attribute SOFT_HLUTNM of \BTN_CNTR[2]_i_1\ : label is "soft_lutpair66";
  attribute SOFT_HLUTNM of \BTN_CNTR[3]_i_1\ : label is "soft_lutpair46";
  attribute SOFT_HLUTNM of \BTN_CNTR[4]_i_1\ : label is "soft_lutpair46";
  attribute SOFT_HLUTNM of \BTN_CNTR[6]_i_1\ : label is "soft_lutpair67";
  attribute SOFT_HLUTNM of \BTN_CNTR[7]_i_1\ : label is "soft_lutpair67";
  attribute SOFT_HLUTNM of \BTN_CNTR[8]_i_1\ : label is "soft_lutpair48";
  attribute SOFT_HLUTNM of \BTN_CNTR[9]_i_1\ : label is "soft_lutpair48";
  attribute SOFT_HLUTNM of \B_OUT[3]_i_8\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_100\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_109\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_110\ : label is "soft_lutpair41";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_112\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_113\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_120\ : label is "soft_lutpair40";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_141\ : label is "soft_lutpair56";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_142\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_146\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_147\ : label is "soft_lutpair40";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_148\ : label is "soft_lutpair55";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_149\ : label is "soft_lutpair55";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_25\ : label is "soft_lutpair50";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_3\ : label is "soft_lutpair59";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_31\ : label is "soft_lutpair56";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_58\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_59\ : label is "soft_lutpair41";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_66\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \G_OUT[3]_i_70\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_17\ : label is "soft_lutpair50";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_18\ : label is "soft_lutpair59";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_19\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_22\ : label is "soft_lutpair47";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_23\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_25\ : label is "soft_lutpair42";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_27\ : label is "soft_lutpair39";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_28\ : label is "soft_lutpair53";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_33\ : label is "soft_lutpair64";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_39\ : label is "soft_lutpair53";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_40\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_41\ : label is "soft_lutpair61";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_42\ : label is "soft_lutpair61";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_44\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_46\ : label is "soft_lutpair64";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_48\ : label is "soft_lutpair72";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_49\ : label is "soft_lutpair71";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_52\ : label is "soft_lutpair70";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_54\ : label is "soft_lutpair58";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_56\ : label is "soft_lutpair70";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_57\ : label is "soft_lutpair44";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_58\ : label is "soft_lutpair52";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_59\ : label is "soft_lutpair44";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_60\ : label is "soft_lutpair52";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_62\ : label is "soft_lutpair72";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_66\ : label is "soft_lutpair43";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_67\ : label is "soft_lutpair49";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_70\ : label is "soft_lutpair49";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_71\ : label is "soft_lutpair43";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_72\ : label is "soft_lutpair47";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_76\ : label is "soft_lutpair71";
  attribute SOFT_HLUTNM of \R_OUT[3]_i_78\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \g0_b1__18\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \g0_b1__19\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \g0_b1__20\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \g0_b1__21\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \g0_b1__22\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \g0_b1__23\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \g0_b1__24\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \g0_b1__25\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \g0_b1__26\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \g0_b2__18\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \g0_b2__19\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \g0_b2__20\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \g0_b2__21\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \g0_b2__22\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \g0_b2__23\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \g0_b2__24\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \g0_b2__25\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \g0_b2__26\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \g0_b2__35\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \g0_b3__18\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \g0_b3__19\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \g0_b3__20\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \g0_b3__21\ : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of \g0_b3__22\ : label is "soft_lutpair39";
  attribute SOFT_HLUTNM of \g0_b3__23\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \g0_b3__24\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \g0_b3__25\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \g0_b3__26\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \g0_b4__18\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \g0_b4__19\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \g0_b4__20\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \g0_b4__21\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of \g0_b4__22\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \g0_b4__23\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of \g0_b4__24\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \g0_b4__25\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \g0_b4__26\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \g0_b5__18\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \g0_b5__19\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \g0_b5__20\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \g0_b5__21\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \g0_b5__22\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \g0_b5__23\ : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of \g0_b5__24\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \g0_b5__25\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \g0_b5__26\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \g0_b6__18\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \g0_b6__19\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \g0_b6__20\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \g0_b6__21\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \g0_b6__22\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \g0_b6__23\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \g0_b6__24\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \g0_b6__25\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \g0_b6__26\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of g0_b7 : label is "soft_lutpair58";
  attribute SOFT_HLUTNM of \g0_b7__18\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \g0_b7__19\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \g0_b7__20\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \g0_b7__21\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \g0_b7__22\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \g0_b7__23\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \g0_b7__24\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \g0_b7__25\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of g0_b7_i_12 : label is "soft_lutpair69";
  attribute SOFT_HLUTNM of g0_b7_i_13 : label is "soft_lutpair62";
  attribute SOFT_HLUTNM of g0_b7_i_15 : label is "soft_lutpair63";
  attribute SOFT_HLUTNM of g0_b7_i_7 : label is "soft_lutpair42";
  attribute SOFT_HLUTNM of g0_b7_i_8 : label is "soft_lutpair69";
  attribute SOFT_HLUTNM of \g1_b1__16\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \strnum_v[2][0]_i_1\ : label is "soft_lutpair57";
  attribute SOFT_HLUTNM of \strnum_v[2][0]_i_2\ : label is "soft_lutpair45";
  attribute SOFT_HLUTNM of \strnum_v[2][0]_i_6\ : label is "soft_lutpair45";
  attribute SOFT_HLUTNM of \strnum_v[2][4]_i_1\ : label is "soft_lutpair68";
  attribute SOFT_HLUTNM of \strnum_v[3][0]_i_1\ : label is "soft_lutpair54";
  attribute SOFT_HLUTNM of \strnum_v[3][0]_i_4\ : label is "soft_lutpair51";
  attribute SOFT_HLUTNM of \strnum_v[3][0]_i_5\ : label is "soft_lutpair51";
  attribute SOFT_HLUTNM of \strnum_v[3][2]_i_1\ : label is "soft_lutpair62";
  attribute SOFT_HLUTNM of \strnum_v[4][0]_i_1\ : label is "soft_lutpair60";
  attribute SOFT_HLUTNM of \strnum_v[4][1]_i_1\ : label is "soft_lutpair54";
  attribute SOFT_HLUTNM of \strnum_v[4][3]_i_1\ : label is "soft_lutpair65";
  attribute SOFT_HLUTNM of \strnum_v[4][4]_i_1\ : label is "soft_lutpair57";
  attribute SOFT_HLUTNM of \strnum_v[5][0]_i_1\ : label is "soft_lutpair68";
  attribute SOFT_HLUTNM of \strnum_v[5][1]_i_1\ : label is "soft_lutpair60";
  attribute SOFT_HLUTNM of \strnum_v[5][3]_i_1\ : label is "soft_lutpair63";
  attribute SOFT_HLUTNM of \strnum_v[5][4]_i_1\ : label is "soft_lutpair65";
begin
\BTN_CNTR[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => BTN_CNTR_reg(0),
      O => plusOp(0)
    );
\BTN_CNTR[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => BTN_CNTR_reg(0),
      I1 => BTN_CNTR_reg(1),
      O => plusOp(1)
    );
\BTN_CNTR[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => BTN_CNTR_reg(2),
      I1 => BTN_CNTR_reg(1),
      I2 => BTN_CNTR_reg(0),
      O => plusOp(2)
    );
\BTN_CNTR[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6AAA"
    )
        port map (
      I0 => BTN_CNTR_reg(3),
      I1 => BTN_CNTR_reg(2),
      I2 => BTN_CNTR_reg(0),
      I3 => BTN_CNTR_reg(1),
      O => plusOp(3)
    );
\BTN_CNTR[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AAAAAAA"
    )
        port map (
      I0 => BTN_CNTR_reg(4),
      I1 => BTN_CNTR_reg(3),
      I2 => BTN_CNTR_reg(1),
      I3 => BTN_CNTR_reg(0),
      I4 => BTN_CNTR_reg(2),
      O => plusOp(4)
    );
\BTN_CNTR[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6AAAAAAAAAAAAAAA"
    )
        port map (
      I0 => BTN_CNTR_reg(5),
      I1 => BTN_CNTR_reg(4),
      I2 => BTN_CNTR_reg(2),
      I3 => BTN_CNTR_reg(0),
      I4 => BTN_CNTR_reg(1),
      I5 => BTN_CNTR_reg(3),
      O => plusOp(5)
    );
\BTN_CNTR[6]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => BTN_CNTR_reg(6),
      I1 => \BTN_CNTR[9]_i_2_n_0\,
      O => plusOp(6)
    );
\BTN_CNTR[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => BTN_CNTR_reg(7),
      I1 => BTN_CNTR_reg(6),
      I2 => \BTN_CNTR[9]_i_2_n_0\,
      O => plusOp(7)
    );
\BTN_CNTR[8]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6AAA"
    )
        port map (
      I0 => BTN_CNTR_reg(8),
      I1 => BTN_CNTR_reg(7),
      I2 => \BTN_CNTR[9]_i_2_n_0\,
      I3 => BTN_CNTR_reg(6),
      O => plusOp(8)
    );
\BTN_CNTR[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AAAAAAA"
    )
        port map (
      I0 => BTN_CNTR_reg(9),
      I1 => BTN_CNTR_reg(8),
      I2 => BTN_CNTR_reg(6),
      I3 => \BTN_CNTR[9]_i_2_n_0\,
      I4 => BTN_CNTR_reg(7),
      O => plusOp(9)
    );
\BTN_CNTR[9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => BTN_CNTR_reg(4),
      I1 => BTN_CNTR_reg(2),
      I2 => BTN_CNTR_reg(0),
      I3 => BTN_CNTR_reg(1),
      I4 => BTN_CNTR_reg(3),
      I5 => BTN_CNTR_reg(5),
      O => \BTN_CNTR[9]_i_2_n_0\
    );
\BTN_CNTR_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => BTN_PRESS_VALID_IN,
      D => plusOp(0),
      Q => BTN_CNTR_reg(0),
      R => '0'
    );
\BTN_CNTR_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => BTN_PRESS_VALID_IN,
      D => plusOp(1),
      Q => BTN_CNTR_reg(1),
      R => '0'
    );
\BTN_CNTR_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => BTN_PRESS_VALID_IN,
      D => plusOp(2),
      Q => BTN_CNTR_reg(2),
      R => '0'
    );
\BTN_CNTR_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => BTN_PRESS_VALID_IN,
      D => plusOp(3),
      Q => BTN_CNTR_reg(3),
      R => '0'
    );
\BTN_CNTR_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => BTN_PRESS_VALID_IN,
      D => plusOp(4),
      Q => BTN_CNTR_reg(4),
      R => '0'
    );
\BTN_CNTR_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => BTN_PRESS_VALID_IN,
      D => plusOp(5),
      Q => BTN_CNTR_reg(5),
      R => '0'
    );
\BTN_CNTR_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => BTN_PRESS_VALID_IN,
      D => plusOp(6),
      Q => BTN_CNTR_reg(6),
      R => '0'
    );
\BTN_CNTR_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => BTN_PRESS_VALID_IN,
      D => plusOp(7),
      Q => BTN_CNTR_reg(7),
      R => '0'
    );
\BTN_CNTR_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => BTN_PRESS_VALID_IN,
      D => plusOp(8),
      Q => BTN_CNTR_reg(8),
      R => '0'
    );
\BTN_CNTR_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => BTN_PRESS_VALID_IN,
      D => plusOp(9),
      Q => BTN_CNTR_reg(9),
      R => '0'
    );
\B_OUT[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0001FFFF00010001"
    )
        port map (
      I0 => \R_OUT[3]_i_2_n_0\,
      I1 => \B_OUT[3]_i_2_n_0\,
      I2 => X_IN(9),
      I3 => \B_OUT_reg[3]_i_3_n_0\,
      I4 => \B_OUT[3]_i_4_n_0\,
      I5 => \B_OUT_reg[3]_i_5_n_0\,
      O => B_OUT0
    );
\B_OUT[3]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \B_OUT_reg[3]_i_20_n_0\,
      I1 => \B_OUT_reg[3]_i_21_n_0\,
      I2 => X_IN(1),
      I3 => \B_OUT_reg[3]_i_22_n_0\,
      I4 => X_IN(0),
      I5 => \B_OUT_reg[3]_i_23_n_0\,
      O => \B_OUT[3]_i_10_n_0\
    );
\B_OUT[3]_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A0AFA0AFC0C0CFCF"
    )
        port map (
      I0 => \B_OUT[3]_i_24_n_0\,
      I1 => \B_OUT_reg[3]_i_25_n_0\,
      I2 => X_IN(1),
      I3 => \B_OUT_reg[3]_i_26_n_0\,
      I4 => \B_OUT_reg[3]_i_27_n_0\,
      I5 => X_IN(0),
      O => \B_OUT[3]_i_11_n_0\
    );
\B_OUT[3]_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFEFFFFFFFFFFF"
    )
        port map (
      I0 => Y_IN(0),
      I1 => Y_IN(3),
      I2 => Y_IN(2),
      I3 => Y_IN(1),
      I4 => \B_OUT[3]_i_36_n_0\,
      I5 => \g1_b1__14_n_0\,
      O => \B_OUT[3]_i_16_n_0\
    );
\B_OUT[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000800080000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(5),
      I4 => X_IN(4),
      I5 => X_IN(3),
      O => \B_OUT[3]_i_2_n_0\
    );
\B_OUT[3]_i_24\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000080"
    )
        port map (
      I0 => Y_IN(1),
      I1 => '0',
      I2 => Y_IN(2),
      I3 => Y_IN(0),
      I4 => Y_IN(3),
      O => \B_OUT[3]_i_24_n_0\
    );
\B_OUT[3]_i_28\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AFA0C0C0"
    )
        port map (
      I0 => \B_OUT_reg[3]_i_57_n_0\,
      I1 => \B_OUT_reg[3]_i_58_n_0\,
      I2 => Y_IN(2),
      I3 => \B_OUT_reg[3]_i_59_n_0\,
      I4 => Y_IN(1),
      O => \B_OUT[3]_i_28_n_0\
    );
\B_OUT[3]_i_29\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0A0A0A0A0CFF0C00"
    )
        port map (
      I0 => \B_OUT[3]_i_60_n_0\,
      I1 => \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_61_n_0\,
      I2 => Y_IN(0),
      I3 => Y_IN(1),
      I4 => \B_OUT_reg[3]_i_62_n_0\,
      I5 => Y_IN(2),
      O => \B_OUT[3]_i_29_n_0\
    );
\B_OUT[3]_i_30\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AFA0C0C0"
    )
        port map (
      I0 => \B_OUT_reg[3]_i_63_n_0\,
      I1 => \B_OUT[3]_i_64_n_0\,
      I2 => Y_IN(2),
      I3 => \B_OUT[3]_i_65_n_0\,
      I4 => Y_IN(1),
      O => \B_OUT[3]_i_30_n_0\
    );
\B_OUT[3]_i_31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"22222222B8FFB800"
    )
        port map (
      I0 => \B_OUT[3]_i_60_n_0\,
      I1 => Y_IN(0),
      I2 => \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_66_n_0\,
      I3 => Y_IN(1),
      I4 => \B_OUT_reg[3]_i_67_n_0\,
      I5 => Y_IN(2),
      O => \B_OUT[3]_i_31_n_0\
    );
\B_OUT[3]_i_32\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"303F5F5F"
    )
        port map (
      I0 => \B_OUT[3]_i_68_n_0\,
      I1 => \B_OUT_reg[3]_i_69_n_0\,
      I2 => Y_IN(1),
      I3 => \B_OUT[3]_i_70_n_0\,
      I4 => Y_IN(2),
      O => \B_OUT[3]_i_32_n_0\
    );
\B_OUT[3]_i_33\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B2B7A2A2B2B7F7F7"
    )
        port map (
      I0 => Y_IN(2),
      I1 => \B_OUT[3]_i_60_n_0\,
      I2 => Y_IN(0),
      I3 => \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_71_n_0\,
      I4 => Y_IN(1),
      I5 => \B_OUT_reg[3]_i_72_n_0\,
      O => \B_OUT[3]_i_33_n_0\
    );
\B_OUT[3]_i_34\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55330FFF"
    )
        port map (
      I0 => \B_OUT_reg[3]_i_73_n_0\,
      I1 => \B_OUT[3]_i_74_n_0\,
      I2 => \B_OUT[3]_i_75_n_0\,
      I3 => Y_IN(1),
      I4 => Y_IN(2),
      O => \B_OUT[3]_i_34_n_0\
    );
\B_OUT[3]_i_35\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF44FF77CF47CF47"
    )
        port map (
      I0 => \B_OUT[3]_i_60_n_0\,
      I1 => Y_IN(2),
      I2 => \B_OUT_reg[3]_i_76_n_0\,
      I3 => Y_IN(0),
      I4 => \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_77_n_0\,
      I5 => Y_IN(1),
      O => \B_OUT[3]_i_35_n_0\
    );
\B_OUT[3]_i_36\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"002AAA2AA8A2AA00"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(3),
      I2 => X_IN(4),
      I3 => X_IN(5),
      I4 => X_IN(6),
      I5 => X_IN(7),
      O => \B_OUT[3]_i_36_n_0\
    );
\B_OUT[3]_i_37\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"303F5F5F"
    )
        port map (
      I0 => \B_OUT[3]_i_78_n_0\,
      I1 => \B_OUT_reg[3]_i_79_n_0\,
      I2 => Y_IN(1),
      I3 => \B_OUT[3]_i_80_n_0\,
      I4 => Y_IN(2),
      O => \B_OUT[3]_i_37_n_0\
    );
\B_OUT[3]_i_38\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FAFAABFBFFFFABFB"
    )
        port map (
      I0 => Y_IN(2),
      I1 => \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_81_n_0\,
      I2 => Y_IN(0),
      I3 => \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_82_n_0\,
      I4 => Y_IN(1),
      I5 => \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_83_n_0\,
      O => \B_OUT[3]_i_38_n_0\
    );
\B_OUT[3]_i_39\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AFA0C0C0"
    )
        port map (
      I0 => \B_OUT_reg[3]_i_84_n_0\,
      I1 => \B_OUT_reg[3]_i_85_n_0\,
      I2 => Y_IN(2),
      I3 => \B_OUT_reg[3]_i_86_n_0\,
      I4 => Y_IN(1),
      O => \B_OUT[3]_i_39_n_0\
    );
\B_OUT[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFA888"
    )
        port map (
      I0 => \B_OUT[3]_i_8_n_0\,
      I1 => X_IN(5),
      I2 => X_IN(3),
      I3 => X_IN(4),
      I4 => \B_OUT[3]_i_9_n_0\,
      I5 => \R_OUT[3]_i_6_n_0\,
      O => \B_OUT[3]_i_4_n_0\
    );
\B_OUT[3]_i_40\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_87_n_0\,
      I1 => Y_IN(0),
      I2 => \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_88_n_0\,
      I3 => Y_IN(1),
      I4 => \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_89_n_0\,
      I5 => Y_IN(2),
      O => \B_OUT[3]_i_40_n_0\
    );
\B_OUT[3]_i_41\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AFA0C0C0"
    )
        port map (
      I0 => \B_OUT_reg[3]_i_90_n_0\,
      I1 => \B_OUT_reg[3]_i_91_n_0\,
      I2 => Y_IN(2),
      I3 => \B_OUT_reg[3]_i_92_n_0\,
      I4 => Y_IN(1),
      O => \B_OUT[3]_i_41_n_0\
    );
\B_OUT[3]_i_42\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_93_n_0\,
      I1 => Y_IN(0),
      I2 => \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_94_n_0\,
      I3 => Y_IN(1),
      I4 => \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_95_n_0\,
      I5 => Y_IN(2),
      O => \B_OUT[3]_i_42_n_0\
    );
\B_OUT[3]_i_43\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AFA0C0C0"
    )
        port map (
      I0 => \B_OUT_reg[3]_i_96_n_0\,
      I1 => \B_OUT_reg[3]_i_97_n_0\,
      I2 => Y_IN(2),
      I3 => \B_OUT_reg[3]_i_98_n_0\,
      I4 => Y_IN(1),
      O => \B_OUT[3]_i_43_n_0\
    );
\B_OUT[3]_i_44\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \g0_b4__34_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b4__27_n_0\,
      I3 => Y_IN(1),
      I4 => \g0_b4__35_n_0\,
      I5 => Y_IN(2),
      O => \B_OUT[3]_i_44_n_0\
    );
\B_OUT[3]_i_45\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AFA0C0C0"
    )
        port map (
      I0 => \B_OUT_reg[3]_i_99_n_0\,
      I1 => \B_OUT_reg[3]_i_100_n_0\,
      I2 => Y_IN(2),
      I3 => \B_OUT_reg[3]_i_101_n_0\,
      I4 => Y_IN(1),
      O => \B_OUT[3]_i_45_n_0\
    );
\B_OUT[3]_i_46\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => '0',
      I1 => Y_IN(0),
      I2 => \g0_b5__27_n_0\,
      I3 => Y_IN(1),
      I4 => \g0_b5__34_n_0\,
      I5 => Y_IN(2),
      O => \B_OUT[3]_i_46_n_0\
    );
\B_OUT[3]_i_47\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AFA0C0C0"
    )
        port map (
      I0 => \B_OUT_reg[3]_i_102_n_0\,
      I1 => \B_OUT_reg[3]_i_103_n_0\,
      I2 => Y_IN(2),
      I3 => \B_OUT_reg[3]_i_104_n_0\,
      I4 => Y_IN(1),
      O => \B_OUT[3]_i_47_n_0\
    );
\B_OUT[3]_i_48\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \g0_b6__34_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b6__27_n_0\,
      I3 => Y_IN(1),
      I4 => \g0_b6__35_n_0\,
      I5 => Y_IN(2),
      O => \B_OUT[3]_i_48_n_0\
    );
\B_OUT[3]_i_49\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AFA0C0C0"
    )
        port map (
      I0 => \B_OUT_reg[3]_i_105_n_0\,
      I1 => \B_OUT_reg[3]_i_106_n_0\,
      I2 => Y_IN(2),
      I3 => \B_OUT_reg[3]_i_107_n_0\,
      I4 => Y_IN(1),
      O => \B_OUT[3]_i_49_n_0\
    );
\B_OUT[3]_i_50\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \g0_b7__32_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b7__26_n_0\,
      I3 => Y_IN(1),
      I4 => '0',
      I5 => Y_IN(2),
      O => \B_OUT[3]_i_50_n_0\
    );
\B_OUT[3]_i_51\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AFA0C0C0"
    )
        port map (
      I0 => \B_OUT_reg[3]_i_108_n_0\,
      I1 => \B_OUT_reg[3]_i_109_n_0\,
      I2 => Y_IN(2),
      I3 => \B_OUT_reg[3]_i_110_n_0\,
      I4 => Y_IN(1),
      O => \B_OUT[3]_i_51_n_0\
    );
\B_OUT[3]_i_52\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \g0_b1__34_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b1__27_n_0\,
      I3 => Y_IN(1),
      I4 => \g0_b1__35_n_0\,
      I5 => Y_IN(2),
      O => \B_OUT[3]_i_52_n_0\
    );
\B_OUT[3]_i_53\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"503F5F3F"
    )
        port map (
      I0 => \B_OUT_reg[3]_i_111_n_0\,
      I1 => \B_OUT_reg[3]_i_112_n_0\,
      I2 => Y_IN(2),
      I3 => Y_IN(1),
      I4 => \B_OUT_reg[3]_i_113_n_0\,
      O => \B_OUT[3]_i_53_n_0\
    );
\B_OUT[3]_i_54\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FAFAABFBFFFFABFB"
    )
        port map (
      I0 => Y_IN(2),
      I1 => \g0_b2__34_n_0\,
      I2 => Y_IN(0),
      I3 => \g0_b2__27_n_0\,
      I4 => Y_IN(1),
      I5 => \g0_b2__35_n_0\,
      O => \B_OUT[3]_i_54_n_0\
    );
\B_OUT[3]_i_55\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"503F5F3F"
    )
        port map (
      I0 => \B_OUT_reg[3]_i_114_n_0\,
      I1 => \B_OUT_reg[3]_i_115_n_0\,
      I2 => Y_IN(2),
      I3 => Y_IN(1),
      I4 => \B_OUT_reg[3]_i_116_n_0\,
      O => \B_OUT[3]_i_55_n_0\
    );
\B_OUT[3]_i_56\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FAFAABFBFFFFABFB"
    )
        port map (
      I0 => Y_IN(2),
      I1 => \g0_b3__34_n_0\,
      I2 => Y_IN(0),
      I3 => \g0_b3__27_n_0\,
      I4 => Y_IN(1),
      I5 => \g0_b3__35_n_0\,
      O => \B_OUT[3]_i_56_n_0\
    );
\B_OUT[3]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F503F3F5F503030"
    )
        port map (
      I0 => \B_OUT_reg[3]_i_12_n_0\,
      I1 => \B_OUT_reg[3]_i_13_n_0\,
      I2 => X_IN(1),
      I3 => \B_OUT_reg[3]_i_14_n_0\,
      I4 => X_IN(0),
      I5 => \B_OUT_reg[3]_i_15_n_0\,
      O => \B_OUT[3]_i_6_n_0\
    );
\B_OUT[3]_i_60\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000200000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(3),
      O => \B_OUT[3]_i_60_n_0\
    );
\B_OUT[3]_i_64\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \g1_b5__0_n_0\,
      I1 => \g0_b5__2_n_0\,
      I2 => Y_IN(0),
      I3 => \g1_b5__14_n_0\,
      I4 => \B_OUT[3]_i_36_n_0\,
      I5 => \g0_b5__1_n_0\,
      O => \B_OUT[3]_i_64_n_0\
    );
\B_OUT[3]_i_65\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \g1_b5__14_n_0\,
      I1 => \g0_b5__0_n_0\,
      I2 => Y_IN(0),
      I3 => g1_b5_n_0,
      I4 => \B_OUT[3]_i_36_n_0\,
      I5 => g0_b5_n_0,
      O => \B_OUT[3]_i_65_n_0\
    );
\B_OUT[3]_i_68\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \g1_b6__14_n_0\,
      I1 => \g0_b6__0_n_0\,
      I2 => Y_IN(0),
      I3 => g1_b6_n_0,
      I4 => \B_OUT[3]_i_36_n_0\,
      I5 => g0_b6_n_0,
      O => \B_OUT[3]_i_68_n_0\
    );
\B_OUT[3]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A0AFC0C0A0AFCFCF"
    )
        port map (
      I0 => \B_OUT[3]_i_16_n_0\,
      I1 => \B_OUT_reg[3]_i_17_n_0\,
      I2 => X_IN(1),
      I3 => \B_OUT_reg[3]_i_18_n_0\,
      I4 => X_IN(0),
      I5 => \B_OUT_reg[3]_i_19_n_0\,
      O => \B_OUT[3]_i_7_n_0\
    );
\B_OUT[3]_i_70\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \g1_b6__0_n_0\,
      I1 => \g0_b6__2_n_0\,
      I2 => Y_IN(0),
      I3 => \g1_b6__14_n_0\,
      I4 => \B_OUT[3]_i_36_n_0\,
      I5 => \g0_b6__1_n_0\,
      O => \B_OUT[3]_i_70_n_0\
    );
\B_OUT[3]_i_74\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A0A0CFC0"
    )
        port map (
      I0 => \g1_b7__0_n_0\,
      I1 => \g0_b7__3_n_0\,
      I2 => Y_IN(0),
      I3 => \g0_b7__2_n_0\,
      I4 => \B_OUT[3]_i_36_n_0\,
      O => \B_OUT[3]_i_74_n_0\
    );
\B_OUT[3]_i_75\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => \g0_b7__1_n_0\,
      I1 => Y_IN(0),
      I2 => g1_b7_n_0,
      I3 => \B_OUT[3]_i_36_n_0\,
      I4 => \g0_b7__0_n_0\,
      O => \B_OUT[3]_i_75_n_0\
    );
\B_OUT[3]_i_78\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \g1_b1__14_n_0\,
      I1 => \g0_b1__0_n_0\,
      I2 => Y_IN(0),
      I3 => g1_b1_n_0,
      I4 => \B_OUT[3]_i_36_n_0\,
      I5 => g0_b1_n_0,
      O => \B_OUT[3]_i_78_n_0\
    );
\B_OUT[3]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => X_IN(6),
      I1 => X_IN(7),
      I2 => X_IN(8),
      O => \B_OUT[3]_i_8_n_0\
    );
\B_OUT[3]_i_80\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A0A0CFC0"
    )
        port map (
      I0 => \g1_b1__0_n_0\,
      I1 => \g0_b1__2_n_0\,
      I2 => Y_IN(0),
      I3 => \g0_b1__1_n_0\,
      I4 => \B_OUT[3]_i_36_n_0\,
      O => \B_OUT[3]_i_80_n_0\
    );
\B_OUT[3]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFF80"
    )
        port map (
      I0 => Y_IN(2),
      I1 => Y_IN(1),
      I2 => Y_IN(3),
      I3 => Y_IN(4),
      I4 => Y_IN(5),
      I5 => X_IN(9),
      O => \B_OUT[3]_i_9_n_0\
    );
\B_OUT_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => B_OUT0,
      Q => B_OUT(0),
      R => '0'
    );
\B_OUT_reg[3]_i_100\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b5__32_n_0\,
      I1 => \g0_b5__29_n_0\,
      O => \B_OUT_reg[3]_i_100_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_101\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b5__31_n_0\,
      I1 => \g0_b5__30_n_0\,
      O => \B_OUT_reg[3]_i_101_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_102\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b6__33_n_0\,
      I1 => \g0_b6__28_n_0\,
      O => \B_OUT_reg[3]_i_102_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_103\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b6__32_n_0\,
      I1 => \g0_b6__29_n_0\,
      O => \B_OUT_reg[3]_i_103_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_104\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b6__31_n_0\,
      I1 => \g0_b6__30_n_0\,
      O => \B_OUT_reg[3]_i_104_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_105\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b7__31_n_0\,
      I1 => \g0_b7__27_n_0\,
      O => \B_OUT_reg[3]_i_105_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_106\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b7__30_n_0\,
      I1 => \g0_b7__28_n_0\,
      O => \B_OUT_reg[3]_i_106_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_107\: unisim.vcomponents.MUXF7
     port map (
      I0 => '0',
      I1 => \g0_b7__29_n_0\,
      O => \B_OUT_reg[3]_i_107_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_108\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b1__33_n_0\,
      I1 => \g0_b1__28_n_0\,
      O => \B_OUT_reg[3]_i_108_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_109\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b1__32_n_0\,
      I1 => \g0_b1__29_n_0\,
      O => \B_OUT_reg[3]_i_109_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_110\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b1__31_n_0\,
      I1 => \g0_b1__30_n_0\,
      O => \B_OUT_reg[3]_i_110_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_111\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__33_n_0\,
      I1 => \g0_b2__28_n_0\,
      O => \B_OUT_reg[3]_i_111_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_112\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__32_n_0\,
      I1 => \g0_b2__29_n_0\,
      O => \B_OUT_reg[3]_i_112_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_113\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__31_n_0\,
      I1 => \g0_b2__30_n_0\,
      O => \B_OUT_reg[3]_i_113_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_114\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__33_n_0\,
      I1 => \g0_b3__28_n_0\,
      O => \B_OUT_reg[3]_i_114_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_115\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__32_n_0\,
      I1 => \g0_b3__29_n_0\,
      O => \B_OUT_reg[3]_i_115_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_116\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__31_n_0\,
      I1 => \g0_b3__30_n_0\,
      O => \B_OUT_reg[3]_i_116_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_117\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__3_n_0\,
      I1 => \g1_b4__3_n_0\,
      O => \B_OUT_reg[3]_i_117_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\B_OUT_reg[3]_i_119\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__1_n_0\,
      I1 => \g1_b4__1_n_0\,
      O => \B_OUT_reg[3]_i_119_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\B_OUT_reg[3]_i_12\: unisim.vcomponents.MUXF7
     port map (
      I0 => \B_OUT[3]_i_28_n_0\,
      I1 => \B_OUT[3]_i_29_n_0\,
      O => \B_OUT_reg[3]_i_12_n_0\,
      S => Y_IN(3)
    );
\B_OUT_reg[3]_i_122\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__0_n_0\,
      I1 => \g1_b4__0_n_0\,
      O => \B_OUT_reg[3]_i_122_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\B_OUT_reg[3]_i_125\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b5__3_n_0\,
      I1 => \g1_b5__1_n_0\,
      O => \B_OUT_reg[3]_i_125_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\B_OUT_reg[3]_i_129\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b6__3_n_0\,
      I1 => \g1_b6__1_n_0\,
      O => \B_OUT_reg[3]_i_129_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\B_OUT_reg[3]_i_13\: unisim.vcomponents.MUXF7
     port map (
      I0 => \B_OUT[3]_i_30_n_0\,
      I1 => \B_OUT[3]_i_31_n_0\,
      O => \B_OUT_reg[3]_i_13_n_0\,
      S => Y_IN(3)
    );
\B_OUT_reg[3]_i_133\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b7__4_n_0\,
      I1 => \g1_b7__1_n_0\,
      O => \B_OUT_reg[3]_i_133_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\B_OUT_reg[3]_i_137\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b1__3_n_0\,
      I1 => \g1_b1__1_n_0\,
      O => \B_OUT_reg[3]_i_137_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\B_OUT_reg[3]_i_139\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__3_n_0\,
      I1 => \g1_b2__3_n_0\,
      O => \B_OUT_reg[3]_i_139_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\B_OUT_reg[3]_i_14\: unisim.vcomponents.MUXF7
     port map (
      I0 => \B_OUT[3]_i_32_n_0\,
      I1 => \B_OUT[3]_i_33_n_0\,
      O => \B_OUT_reg[3]_i_14_n_0\,
      S => Y_IN(3)
    );
\B_OUT_reg[3]_i_141\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__1_n_0\,
      I1 => \g1_b2__1_n_0\,
      O => \B_OUT_reg[3]_i_141_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\B_OUT_reg[3]_i_144\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__0_n_0\,
      I1 => \g1_b2__0_n_0\,
      O => \B_OUT_reg[3]_i_144_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\B_OUT_reg[3]_i_145\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__3_n_0\,
      I1 => \g1_b3__3_n_0\,
      O => \B_OUT_reg[3]_i_145_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\B_OUT_reg[3]_i_147\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__1_n_0\,
      I1 => \g1_b3__1_n_0\,
      O => \B_OUT_reg[3]_i_147_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\B_OUT_reg[3]_i_15\: unisim.vcomponents.MUXF7
     port map (
      I0 => \B_OUT[3]_i_34_n_0\,
      I1 => \B_OUT[3]_i_35_n_0\,
      O => \B_OUT_reg[3]_i_15_n_0\,
      S => Y_IN(3)
    );
\B_OUT_reg[3]_i_150\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__0_n_0\,
      I1 => \g1_b3__0_n_0\,
      O => \B_OUT_reg[3]_i_150_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\B_OUT_reg[3]_i_17\: unisim.vcomponents.MUXF7
     port map (
      I0 => \B_OUT[3]_i_37_n_0\,
      I1 => \B_OUT[3]_i_38_n_0\,
      O => \B_OUT_reg[3]_i_17_n_0\,
      S => Y_IN(3)
    );
\B_OUT_reg[3]_i_18\: unisim.vcomponents.MUXF7
     port map (
      I0 => \B_OUT[3]_i_39_n_0\,
      I1 => \B_OUT[3]_i_40_n_0\,
      O => \B_OUT_reg[3]_i_18_n_0\,
      S => Y_IN(3)
    );
\B_OUT_reg[3]_i_19\: unisim.vcomponents.MUXF7
     port map (
      I0 => \B_OUT[3]_i_41_n_0\,
      I1 => \B_OUT[3]_i_42_n_0\,
      O => \B_OUT_reg[3]_i_19_n_0\,
      S => Y_IN(3)
    );
\B_OUT_reg[3]_i_20\: unisim.vcomponents.MUXF7
     port map (
      I0 => \B_OUT[3]_i_43_n_0\,
      I1 => \B_OUT[3]_i_44_n_0\,
      O => \B_OUT_reg[3]_i_20_n_0\,
      S => Y_IN(3)
    );
\B_OUT_reg[3]_i_21\: unisim.vcomponents.MUXF7
     port map (
      I0 => \B_OUT[3]_i_45_n_0\,
      I1 => \B_OUT[3]_i_46_n_0\,
      O => \B_OUT_reg[3]_i_21_n_0\,
      S => Y_IN(3)
    );
\B_OUT_reg[3]_i_22\: unisim.vcomponents.MUXF7
     port map (
      I0 => \B_OUT[3]_i_47_n_0\,
      I1 => \B_OUT[3]_i_48_n_0\,
      O => \B_OUT_reg[3]_i_22_n_0\,
      S => Y_IN(3)
    );
\B_OUT_reg[3]_i_23\: unisim.vcomponents.MUXF7
     port map (
      I0 => \B_OUT[3]_i_49_n_0\,
      I1 => \B_OUT[3]_i_50_n_0\,
      O => \B_OUT_reg[3]_i_23_n_0\,
      S => Y_IN(3)
    );
\B_OUT_reg[3]_i_25\: unisim.vcomponents.MUXF7
     port map (
      I0 => \B_OUT[3]_i_51_n_0\,
      I1 => \B_OUT[3]_i_52_n_0\,
      O => \B_OUT_reg[3]_i_25_n_0\,
      S => Y_IN(3)
    );
\B_OUT_reg[3]_i_26\: unisim.vcomponents.MUXF7
     port map (
      I0 => \B_OUT[3]_i_53_n_0\,
      I1 => \B_OUT[3]_i_54_n_0\,
      O => \B_OUT_reg[3]_i_26_n_0\,
      S => Y_IN(3)
    );
\B_OUT_reg[3]_i_27\: unisim.vcomponents.MUXF7
     port map (
      I0 => \B_OUT[3]_i_55_n_0\,
      I1 => \B_OUT[3]_i_56_n_0\,
      O => \B_OUT_reg[3]_i_27_n_0\,
      S => Y_IN(3)
    );
\B_OUT_reg[3]_i_3\: unisim.vcomponents.MUXF7
     port map (
      I0 => \B_OUT[3]_i_6_n_0\,
      I1 => \B_OUT[3]_i_7_n_0\,
      O => \B_OUT_reg[3]_i_3_n_0\,
      S => X_IN(2)
    );
\B_OUT_reg[3]_i_5\: unisim.vcomponents.MUXF7
     port map (
      I0 => \B_OUT[3]_i_10_n_0\,
      I1 => \B_OUT[3]_i_11_n_0\,
      O => \B_OUT_reg[3]_i_5_n_0\,
      S => X_IN(2)
    );
\B_OUT_reg[3]_i_57\: unisim.vcomponents.MUXF8
     port map (
      I0 => \B_OUT_reg[3]_i_117_n_0\,
      I1 => \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_118_n_0\,
      O => \B_OUT_reg[3]_i_57_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_58\: unisim.vcomponents.MUXF8
     port map (
      I0 => \B_OUT_reg[3]_i_119_n_0\,
      I1 => \vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_120_n_0\,
      O => \B_OUT_reg[3]_i_58_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_59\: unisim.vcomponents.MUXF8
     port map (
      I0 => \vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_121_n_0\,
      I1 => \B_OUT_reg[3]_i_122_n_0\,
      O => \B_OUT_reg[3]_i_59_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_62\: unisim.vcomponents.MUXF8
     port map (
      I0 => \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_123_n_0\,
      I1 => \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_124_n_0\,
      O => \B_OUT_reg[3]_i_62_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_63\: unisim.vcomponents.MUXF8
     port map (
      I0 => \B_OUT_reg[3]_i_125_n_0\,
      I1 => \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_126_n_0\,
      O => \B_OUT_reg[3]_i_63_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_67\: unisim.vcomponents.MUXF8
     port map (
      I0 => \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_127_n_0\,
      I1 => \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_128_n_0\,
      O => \B_OUT_reg[3]_i_67_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_69\: unisim.vcomponents.MUXF8
     port map (
      I0 => \B_OUT_reg[3]_i_129_n_0\,
      I1 => \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_130_n_0\,
      O => \B_OUT_reg[3]_i_69_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_72\: unisim.vcomponents.MUXF8
     port map (
      I0 => \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_131_n_0\,
      I1 => \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_132_n_0\,
      O => \B_OUT_reg[3]_i_72_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_73\: unisim.vcomponents.MUXF8
     port map (
      I0 => \B_OUT_reg[3]_i_133_n_0\,
      I1 => \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_134_n_0\,
      O => \B_OUT_reg[3]_i_73_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_76\: unisim.vcomponents.MUXF8
     port map (
      I0 => \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_135_n_0\,
      I1 => \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_136_n_0\,
      O => \B_OUT_reg[3]_i_76_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_79\: unisim.vcomponents.MUXF8
     port map (
      I0 => \B_OUT_reg[3]_i_137_n_0\,
      I1 => \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_138_n_0\,
      O => \B_OUT_reg[3]_i_79_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_84\: unisim.vcomponents.MUXF8
     port map (
      I0 => \B_OUT_reg[3]_i_139_n_0\,
      I1 => \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_140_n_0\,
      O => \B_OUT_reg[3]_i_84_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_85\: unisim.vcomponents.MUXF8
     port map (
      I0 => \B_OUT_reg[3]_i_141_n_0\,
      I1 => \vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_142_n_0\,
      O => \B_OUT_reg[3]_i_85_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_86\: unisim.vcomponents.MUXF8
     port map (
      I0 => \vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_143_n_0\,
      I1 => \B_OUT_reg[3]_i_144_n_0\,
      O => \B_OUT_reg[3]_i_86_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_90\: unisim.vcomponents.MUXF8
     port map (
      I0 => \B_OUT_reg[3]_i_145_n_0\,
      I1 => \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_146_n_0\,
      O => \B_OUT_reg[3]_i_90_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_91\: unisim.vcomponents.MUXF8
     port map (
      I0 => \B_OUT_reg[3]_i_147_n_0\,
      I1 => \vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_148_n_0\,
      O => \B_OUT_reg[3]_i_91_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_92\: unisim.vcomponents.MUXF8
     port map (
      I0 => \vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_149_n_0\,
      I1 => \B_OUT_reg[3]_i_150_n_0\,
      O => \B_OUT_reg[3]_i_92_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_96\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__33_n_0\,
      I1 => \g0_b4__28_n_0\,
      O => \B_OUT_reg[3]_i_96_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_97\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__32_n_0\,
      I1 => \g0_b4__29_n_0\,
      O => \B_OUT_reg[3]_i_97_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_98\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__31_n_0\,
      I1 => \g0_b4__30_n_0\,
      O => \B_OUT_reg[3]_i_98_n_0\,
      S => Y_IN(0)
    );
\B_OUT_reg[3]_i_99\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b5__33_n_0\,
      I1 => \g0_b5__28_n_0\,
      O => \B_OUT_reg[3]_i_99_n_0\,
      S => Y_IN(0)
    );
\G_OUT[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF0100"
    )
        port map (
      I0 => \G_OUT[3]_i_2_n_0\,
      I1 => \G_OUT[3]_i_3_n_0\,
      I2 => \G_OUT[3]_i_4_n_0\,
      I3 => \G_OUT_reg[3]_i_5_n_0\,
      I4 => B_OUT0,
      O => G_OUT0
    );
\G_OUT[3]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \G_OUT_reg[3]_i_19_n_0\,
      I1 => \G_OUT[3]_i_20_n_0\,
      I2 => X_IN(0),
      I3 => \G_OUT[3]_i_21_n_0\,
      I4 => Y_IN(3),
      I5 => \G_OUT[3]_i_22_n_0\,
      O => \G_OUT[3]_i_10_n_0\
    );
\G_OUT[3]_i_100\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7EFFFFF3"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      O => \G_OUT[3]_i_100_n_0\
    );
\G_OUT[3]_i_107\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFBFFFFFFFFFFFD"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I5 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      O => \G_OUT[3]_i_107_n_0\
    );
\G_OUT[3]_i_108\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F7FFEFFFFFCFFFFF"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I2 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      O => \G_OUT[3]_i_108_n_0\
    );
\G_OUT[3]_i_109\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FCFFBFFF"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      O => \G_OUT[3]_i_109_n_0\
    );
\G_OUT[3]_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAEFFFFAAAE0000"
    )
        port map (
      I0 => \G_OUT[3]_i_23_n_0\,
      I1 => \g1_b1__15_n_0\,
      I2 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I3 => \G_OUT[3]_i_25_n_0\,
      I4 => X_IN(0),
      I5 => \G_OUT_reg[3]_i_26_n_0\,
      O => \G_OUT[3]_i_11_n_0\
    );
\G_OUT[3]_i_110\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00F02000"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I2 => Y_IN(0),
      I3 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I4 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      O => \G_OUT[3]_i_110_n_0\
    );
\G_OUT[3]_i_112\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFEF"
    )
        port map (
      I0 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      O => \G_OUT[3]_i_112_n_0\
    );
\G_OUT[3]_i_113\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      O => \G_OUT[3]_i_113_n_0\
    );
\G_OUT[3]_i_120\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFFFFFC"
    )
        port map (
      I0 => Y_IN(0),
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      O => \G_OUT[3]_i_120_n_0\
    );
\G_OUT[3]_i_122\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A0A0CFC0"
    )
        port map (
      I0 => \g1_b1__8_n_0\,
      I1 => \g0_b1__12_n_0\,
      I2 => Y_IN(0),
      I3 => \g0_b1__11_n_0\,
      I4 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      O => \G_OUT[3]_i_122_n_0\
    );
\G_OUT[3]_i_123\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \g1_b1__15_n_0\,
      I1 => \g0_b1__10_n_0\,
      I2 => Y_IN(0),
      I3 => \g1_b1__7_n_0\,
      I4 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I5 => \g0_b1__9_n_0\,
      O => \G_OUT[3]_i_123_n_0\
    );
\G_OUT[3]_i_124\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF7FFFFFFDFFFF"
    )
        port map (
      I0 => \G_OUT[3]_i_141_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I4 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \G_OUT[3]_i_124_n_0\
    );
\G_OUT[3]_i_125\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0028FFFF00280000"
    )
        port map (
      I0 => \G_OUT[3]_i_142_n_0\,
      I1 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I4 => Y_IN(0),
      I5 => \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_143_n_0\,
      O => \G_OUT[3]_i_125_n_0\
    );
\G_OUT[3]_i_127\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \G_OUT[3]_i_127_n_0\
    );
\G_OUT[3]_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFAFCFC0AFA0CFC0"
    )
        port map (
      I0 => \G_OUT_reg[3]_i_29_n_0\,
      I1 => \G_OUT[3]_i_30_n_0\,
      I2 => Y_IN(2),
      I3 => \G_OUT[3]_i_31_n_0\,
      I4 => Y_IN(1),
      I5 => \G_OUT[3]_i_32_n_0\,
      O => \G_OUT[3]_i_13_n_0\
    );
\G_OUT[3]_i_130\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEFEFE00FEFEFEFE"
    )
        port map (
      I0 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I2 => \G_OUT[3]_i_146_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I4 => \G_OUT[3]_i_147_n_0\,
      I5 => \G_OUT[3]_i_148_n_0\,
      O => \G_OUT[3]_i_130_n_0\
    );
\G_OUT[3]_i_132\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EAAAEAEAEAAAAAAA"
    )
        port map (
      I0 => Y_IN(2),
      I1 => Y_IN(0),
      I2 => Y_IN(1),
      I3 => \g1_b5__15_n_0\,
      I4 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I5 => \g0_b5__10_n_0\,
      O => \G_OUT[3]_i_132_n_0\
    );
\G_OUT[3]_i_133\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000200000000"
    )
        port map (
      I0 => \G_OUT[3]_i_149_n_0\,
      I1 => Y_IN(1),
      I2 => Y_IN(0),
      I3 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \G_OUT[3]_i_127_n_0\,
      O => \G_OUT[3]_i_133_n_0\
    );
\G_OUT[3]_i_138\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF7FFFFFFFFFF"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I2 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      O => \G_OUT[3]_i_138_n_0\
    );
\G_OUT[3]_i_141\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      O => \G_OUT[3]_i_141_n_0\
    );
\G_OUT[3]_i_142\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00024000"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      O => \G_OUT[3]_i_142_n_0\
    );
\G_OUT[3]_i_146\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFF7FFFF"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      O => \G_OUT[3]_i_146_n_0\
    );
\G_OUT[3]_i_147\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7E"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      O => \G_OUT[3]_i_147_n_0\
    );
\G_OUT[3]_i_148\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4006"
    )
        port map (
      I0 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      O => \G_OUT[3]_i_148_n_0\
    );
\G_OUT[3]_i_149\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      O => \G_OUT[3]_i_149_n_0\
    );
\G_OUT[3]_i_15\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EFEAAAAA"
    )
        port map (
      I0 => \G_OUT[3]_i_35_n_0\,
      I1 => \G_OUT_reg[3]_i_36_n_0\,
      I2 => Y_IN(1),
      I3 => \G_OUT[3]_i_37_n_0\,
      I4 => Y_IN(2),
      O => \G_OUT[3]_i_15_n_0\
    );
\G_OUT[3]_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3313331333130313"
    )
        port map (
      I0 => \G_OUT[3]_i_38_n_0\,
      I1 => \G_OUT[3]_i_39_n_0\,
      I2 => Y_IN(3),
      I3 => Y_IN(2),
      I4 => Y_IN(0),
      I5 => \G_OUT_reg[3]_i_40_n_0\,
      O => \G_OUT[3]_i_16_n_0\
    );
\G_OUT[3]_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0E020E020000FFFF"
    )
        port map (
      I0 => \G_OUT[3]_i_41_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => Y_IN(0),
      I3 => \G_OUT[3]_i_42_n_0\,
      I4 => \G_OUT[3]_i_43_n_0\,
      I5 => Y_IN(2),
      O => \G_OUT[3]_i_17_n_0\
    );
\G_OUT[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEFFFFFFFFFF"
    )
        port map (
      I0 => Y_IN(8),
      I1 => Y_IN(9),
      I2 => Y_IN(6),
      I3 => Y_IN(5),
      I4 => Y_IN(4),
      I5 => Y_IN(7),
      O => \G_OUT[3]_i_2_n_0\
    );
\G_OUT[3]_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFAFCFC0AFA0CFC0"
    )
        port map (
      I0 => \G_OUT_reg[3]_i_48_n_0\,
      I1 => \G_OUT_reg[3]_i_49_n_0\,
      I2 => Y_IN(2),
      I3 => \G_OUT[3]_i_31_n_0\,
      I4 => Y_IN(1),
      I5 => \G_OUT_reg[3]_i_50_n_0\,
      O => \G_OUT[3]_i_20_n_0\
    );
\G_OUT[3]_i_21\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"111111110F000FFF"
    )
        port map (
      I0 => \G_OUT_reg[3]_i_51_n_0\,
      I1 => Y_IN(0),
      I2 => \G_OUT[3]_i_52_n_0\,
      I3 => Y_IN(1),
      I4 => \G_OUT[3]_i_53_n_0\,
      I5 => Y_IN(2),
      O => \G_OUT[3]_i_21_n_0\
    );
\G_OUT[3]_i_22\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFC0A0C0AFCFAFCF"
    )
        port map (
      I0 => \G_OUT_reg[3]_i_54_n_0\,
      I1 => \G_OUT_reg[3]_i_55_n_0\,
      I2 => Y_IN(2),
      I3 => Y_IN(1),
      I4 => \G_OUT_reg[3]_i_56_n_0\,
      I5 => \G_OUT[3]_i_57_n_0\,
      O => \G_OUT[3]_i_22_n_0\
    );
\G_OUT[3]_i_23\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080000000"
    )
        port map (
      I0 => \G_OUT[3]_i_58_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I5 => \G_OUT[3]_i_59_n_0\,
      O => \G_OUT[3]_i_23_n_0\
    );
\G_OUT[3]_i_25\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFF7"
    )
        port map (
      I0 => Y_IN(1),
      I1 => Y_IN(2),
      I2 => Y_IN(3),
      I3 => Y_IN(0),
      O => \G_OUT[3]_i_25_n_0\
    );
\G_OUT[3]_i_27\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \G_OUT[3]_i_62_n_0\,
      I1 => \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_63_n_0\,
      I2 => Y_IN(1),
      I3 => \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_64_n_0\,
      I4 => Y_IN(0),
      I5 => \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_65_n_0\,
      O => \G_OUT[3]_i_27_n_0\
    );
\G_OUT[3]_i_28\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000144000"
    )
        port map (
      I0 => Y_IN(0),
      I1 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I4 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I5 => \G_OUT[3]_i_66_n_0\,
      O => \G_OUT[3]_i_28_n_0\
    );
\G_OUT[3]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => Y_IN(3),
      I1 => Y_IN(1),
      I2 => Y_IN(2),
      O => \G_OUT[3]_i_3_n_0\
    );
\G_OUT[3]_i_30\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \g1_b6__8_n_0\,
      I1 => \g0_b6__12_n_0\,
      I2 => Y_IN(0),
      I3 => \g1_b6__15_n_0\,
      I4 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I5 => \g0_b6__11_n_0\,
      O => \G_OUT[3]_i_30_n_0\
    );
\G_OUT[3]_i_31\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0002"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I3 => \G_OUT[3]_i_69_n_0\,
      O => \G_OUT[3]_i_31_n_0\
    );
\G_OUT[3]_i_32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \g1_b6__15_n_0\,
      I1 => \g0_b6__10_n_0\,
      I2 => Y_IN(0),
      I3 => \g1_b6__7_n_0\,
      I4 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I5 => \g0_b6__9_n_0\,
      O => \G_OUT[3]_i_32_n_0\
    );
\G_OUT[3]_i_33\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \G_OUT[3]_i_70_n_0\,
      I1 => \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_71_n_0\,
      I2 => Y_IN(1),
      I3 => \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_72_n_0\,
      I4 => Y_IN(0),
      I5 => \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_73_n_0\,
      O => \G_OUT[3]_i_33_n_0\
    );
\G_OUT[3]_i_34\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00004100"
    )
        port map (
      I0 => Y_IN(0),
      I1 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I4 => \G_OUT[3]_i_74_n_0\,
      O => \G_OUT[3]_i_34_n_0\
    );
\G_OUT[3]_i_35\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000002F200000"
    )
        port map (
      I0 => \g0_b7__10_n_0\,
      I1 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I2 => Y_IN(0),
      I3 => \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_75_n_0\,
      I4 => Y_IN(1),
      I5 => Y_IN(2),
      O => \G_OUT[3]_i_35_n_0\
    );
\G_OUT[3]_i_37\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A0A0CFC0"
    )
        port map (
      I0 => \g1_b7__7_n_0\,
      I1 => \g0_b7__12_n_0\,
      I2 => Y_IN(0),
      I3 => \g0_b7__11_n_0\,
      I4 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      O => \G_OUT[3]_i_37_n_0\
    );
\G_OUT[3]_i_38\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2F20FFFF2F200000"
    )
        port map (
      I0 => \G_OUT[3]_i_78_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I2 => Y_IN(0),
      I3 => \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_79_n_0\,
      I4 => Y_IN(1),
      I5 => \G_OUT_reg[3]_i_80_n_0\,
      O => \G_OUT[3]_i_38_n_0\
    );
\G_OUT[3]_i_39\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000AAA222A2"
    )
        port map (
      I0 => \G_OUT[3]_i_81_n_0\,
      I1 => Y_IN(2),
      I2 => \G_OUT[3]_i_82_n_0\,
      I3 => Y_IN(1),
      I4 => \G_OUT_reg[3]_i_83_n_0\,
      I5 => Y_IN(3),
      O => \G_OUT[3]_i_39_n_0\
    );
\G_OUT[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F0F0F0F0F08000"
    )
        port map (
      I0 => X_IN(5),
      I1 => X_IN(4),
      I2 => X_IN(9),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => \G_OUT[3]_i_4_n_0\
    );
\G_OUT[3]_i_41\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0200000002000210"
    )
        port map (
      I0 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      O => \G_OUT[3]_i_41_n_0\
    );
\G_OUT[3]_i_42\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2004000000000040"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I1 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      O => \G_OUT[3]_i_42_n_0\
    );
\G_OUT[3]_i_43\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0C0CFCF505F505F"
    )
        port map (
      I0 => \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_86_n_0\,
      I1 => \G_OUT[3]_i_87_n_0\,
      I2 => Y_IN(1),
      I3 => \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_88_n_0\,
      I4 => \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_89_n_0\,
      I5 => Y_IN(0),
      O => \G_OUT[3]_i_43_n_0\
    );
\G_OUT[3]_i_44\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"88888BB8"
    )
        port map (
      I0 => \G_OUT_reg[3]_i_90_n_0\,
      I1 => Y_IN(1),
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I4 => \G_OUT[3]_i_91_n_0\,
      O => \G_OUT[3]_i_44_n_0\
    );
\G_OUT[3]_i_45\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_92_n_0\,
      I1 => \G_OUT_reg[3]_i_93_n_0\,
      I2 => Y_IN(1),
      I3 => \vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_94_n_0\,
      I4 => Y_IN(0),
      I5 => \G_OUT_reg[3]_i_95_n_0\,
      O => \G_OUT[3]_i_45_n_0\
    );
\G_OUT[3]_i_46\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0EFEFAFA0E0E0"
    )
        port map (
      I0 => \G_OUT[3]_i_96_n_0\,
      I1 => \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_97_n_0\,
      I2 => Y_IN(1),
      I3 => \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_98_n_0\,
      I4 => Y_IN(0),
      I5 => \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_99_n_0\,
      O => \G_OUT[3]_i_46_n_0\
    );
\G_OUT[3]_i_47\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000144000"
    )
        port map (
      I0 => Y_IN(0),
      I1 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I4 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I5 => \G_OUT[3]_i_100_n_0\,
      O => \G_OUT[3]_i_47_n_0\
    );
\G_OUT[3]_i_52\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BB0B000BBB0BBB0B"
    )
        port map (
      I0 => \G_OUT[3]_i_109_n_0\,
      I1 => \G_OUT[3]_i_110_n_0\,
      I2 => \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_111_n_0\,
      I3 => Y_IN(0),
      I4 => \G_OUT[3]_i_112_n_0\,
      I5 => \G_OUT[3]_i_113_n_0\,
      O => \G_OUT[3]_i_52_n_0\
    );
\G_OUT[3]_i_53\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0F000FFF55335533"
    )
        port map (
      I0 => \g1_b3__15_n_0\,
      I1 => \g0_b3__15_n_0\,
      I2 => \g1_b3__16_n_0\,
      I3 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I4 => \g0_b3__16_n_0\,
      I5 => Y_IN(0),
      O => \G_OUT[3]_i_53_n_0\
    );
\G_OUT[3]_i_57\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFB"
    )
        port map (
      I0 => \G_OUT[3]_i_120_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I2 => Y_IN(1),
      I3 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      O => \G_OUT[3]_i_57_n_0\
    );
\G_OUT[3]_i_58\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => Y_IN(0),
      I1 => Y_IN(2),
      I2 => Y_IN(3),
      O => \G_OUT[3]_i_58_n_0\
    );
\G_OUT[3]_i_59\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"BF"
    )
        port map (
      I0 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      O => \G_OUT[3]_i_59_n_0\
    );
\G_OUT[3]_i_60\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFAFCFC0AFA0CFC0"
    )
        port map (
      I0 => \G_OUT_reg[3]_i_121_n_0\,
      I1 => \G_OUT[3]_i_122_n_0\,
      I2 => Y_IN(2),
      I3 => \G_OUT[3]_i_31_n_0\,
      I4 => Y_IN(1),
      I5 => \G_OUT[3]_i_123_n_0\,
      O => \G_OUT[3]_i_60_n_0\
    );
\G_OUT[3]_i_61\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1F101F1F1F101010"
    )
        port map (
      I0 => Y_IN(0),
      I1 => \G_OUT[3]_i_124_n_0\,
      I2 => Y_IN(2),
      I3 => \G_OUT[3]_i_125_n_0\,
      I4 => Y_IN(1),
      I5 => \G_OUT_reg[3]_i_126_n_0\,
      O => \G_OUT[3]_i_61_n_0\
    );
\G_OUT[3]_i_62\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000010002008000"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I3 => \G_OUT[3]_i_127_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      O => \G_OUT[3]_i_62_n_0\
    );
\G_OUT[3]_i_66\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7BFFFF78"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      O => \G_OUT[3]_i_66_n_0\
    );
\G_OUT[3]_i_69\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFFFFFFFF"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I2 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I4 => Y_IN(1),
      I5 => Y_IN(0),
      O => \G_OUT[3]_i_69_n_0\
    );
\G_OUT[3]_i_70\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => \G_OUT[3]_i_113_n_0\,
      I1 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      O => \G_OUT[3]_i_70_n_0\
    );
\G_OUT[3]_i_74\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF5EFFFF5EFFFF"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I4 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      O => \G_OUT[3]_i_74_n_0\
    );
\G_OUT[3]_i_78\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000012000000040"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I5 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      O => \G_OUT[3]_i_78_n_0\
    );
\G_OUT[3]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \G_OUT_reg[3]_i_12_n_0\,
      I1 => \G_OUT[3]_i_13_n_0\,
      I2 => X_IN(0),
      I3 => \G_OUT_reg[3]_i_14_n_0\,
      I4 => Y_IN(3),
      I5 => \G_OUT[3]_i_15_n_0\,
      O => \G_OUT[3]_i_8_n_0\
    );
\G_OUT[3]_i_81\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFF3404"
    )
        port map (
      I0 => \G_OUT[3]_i_130_n_0\,
      I1 => Y_IN(0),
      I2 => Y_IN(1),
      I3 => \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_131_n_0\,
      I4 => \G_OUT[3]_i_132_n_0\,
      I5 => \G_OUT[3]_i_133_n_0\,
      O => \G_OUT[3]_i_81_n_0\
    );
\G_OUT[3]_i_82\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \g1_b5__8_n_0\,
      I1 => \g0_b5__12_n_0\,
      I2 => Y_IN(0),
      I3 => \g1_b5__15_n_0\,
      I4 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I5 => \g0_b5__11_n_0\,
      O => \G_OUT[3]_i_82_n_0\
    );
\G_OUT[3]_i_84\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFDBFFFF"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I4 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      O => \G_OUT[3]_i_84_n_0\
    );
\G_OUT[3]_i_85\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BFFDFFFFFFFFDFFF"
    )
        port map (
      I0 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      O => \G_OUT[3]_i_85_n_0\
    );
\G_OUT[3]_i_87\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFB"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I3 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      O => \G_OUT[3]_i_87_n_0\
    );
\G_OUT[3]_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"D1DDD111"
    )
        port map (
      I0 => \G_OUT[3]_i_16_n_0\,
      I1 => X_IN(0),
      I2 => \G_OUT[3]_i_17_n_0\,
      I3 => Y_IN(3),
      I4 => \G_OUT_reg[3]_i_18_n_0\,
      O => \G_OUT[3]_i_9_n_0\
    );
\G_OUT[3]_i_91\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A8AA28AAA8AAA8AA"
    )
        port map (
      I0 => \G_OUT[3]_i_138_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I3 => \G_OUT[3]_i_113_n_0\,
      I4 => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      I5 => Y_IN(0),
      O => \G_OUT[3]_i_91_n_0\
    );
\G_OUT[3]_i_96\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"020000A000080000"
    )
        port map (
      I0 => \G_OUT[3]_i_110_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      O => \G_OUT[3]_i_96_n_0\
    );
\G_OUT_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => G_OUT0,
      Q => G_OUT(0),
      R => '0'
    );
\G_OUT_reg[3]_i_101\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__13_n_0\,
      I1 => \g1_b2__13_n_0\,
      O => \G_OUT_reg[3]_i_101_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\G_OUT_reg[3]_i_103\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__11_n_0\,
      I1 => \g1_b2__11_n_0\,
      O => \G_OUT_reg[3]_i_103_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\G_OUT_reg[3]_i_106\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__10_n_0\,
      I1 => \g1_b2__10_n_0\,
      O => \G_OUT_reg[3]_i_106_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\G_OUT_reg[3]_i_114\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__13_n_0\,
      I1 => \g1_b3__13_n_0\,
      O => \G_OUT_reg[3]_i_114_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\G_OUT_reg[3]_i_116\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__11_n_0\,
      I1 => \g1_b3__11_n_0\,
      O => \G_OUT_reg[3]_i_116_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\G_OUT_reg[3]_i_119\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__10_n_0\,
      I1 => \g1_b3__10_n_0\,
      O => \G_OUT_reg[3]_i_119_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\G_OUT_reg[3]_i_12\: unisim.vcomponents.MUXF7
     port map (
      I0 => \G_OUT[3]_i_27_n_0\,
      I1 => \G_OUT[3]_i_28_n_0\,
      O => \G_OUT_reg[3]_i_12_n_0\,
      S => Y_IN(2)
    );
\G_OUT_reg[3]_i_121\: unisim.vcomponents.MUXF8
     port map (
      I0 => \G_OUT_reg[3]_i_139_n_0\,
      I1 => \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_140_n_0\,
      O => \G_OUT_reg[3]_i_121_n_0\,
      S => Y_IN(0)
    );
\G_OUT_reg[3]_i_126\: unisim.vcomponents.MUXF8
     port map (
      I0 => \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_144_n_0\,
      I1 => \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_145_n_0\,
      O => \G_OUT_reg[3]_i_126_n_0\,
      S => Y_IN(0)
    );
\G_OUT_reg[3]_i_134\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b5__13_n_0\,
      I1 => \g1_b5__9_n_0\,
      O => \G_OUT_reg[3]_i_134_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\G_OUT_reg[3]_i_137\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__10_n_0\,
      I1 => \g1_b4__10_n_0\,
      O => \G_OUT_reg[3]_i_137_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\G_OUT_reg[3]_i_139\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b1__13_n_0\,
      I1 => \g1_b1__9_n_0\,
      O => \G_OUT_reg[3]_i_139_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\G_OUT_reg[3]_i_14\: unisim.vcomponents.MUXF7
     port map (
      I0 => \G_OUT[3]_i_33_n_0\,
      I1 => \G_OUT[3]_i_34_n_0\,
      O => \G_OUT_reg[3]_i_14_n_0\,
      S => Y_IN(2)
    );
\G_OUT_reg[3]_i_18\: unisim.vcomponents.MUXF7
     port map (
      I0 => \G_OUT[3]_i_44_n_0\,
      I1 => \G_OUT[3]_i_45_n_0\,
      O => \G_OUT_reg[3]_i_18_n_0\,
      S => Y_IN(2)
    );
\G_OUT_reg[3]_i_19\: unisim.vcomponents.MUXF7
     port map (
      I0 => \G_OUT[3]_i_46_n_0\,
      I1 => \G_OUT[3]_i_47_n_0\,
      O => \G_OUT_reg[3]_i_19_n_0\,
      S => Y_IN(2)
    );
\G_OUT_reg[3]_i_26\: unisim.vcomponents.MUXF7
     port map (
      I0 => \G_OUT[3]_i_60_n_0\,
      I1 => \G_OUT[3]_i_61_n_0\,
      O => \G_OUT_reg[3]_i_26_n_0\,
      S => Y_IN(3)
    );
\G_OUT_reg[3]_i_29\: unisim.vcomponents.MUXF8
     port map (
      I0 => \G_OUT_reg[3]_i_67_n_0\,
      I1 => \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_68_n_0\,
      O => \G_OUT_reg[3]_i_29_n_0\,
      S => Y_IN(0)
    );
\G_OUT_reg[3]_i_36\: unisim.vcomponents.MUXF8
     port map (
      I0 => \G_OUT_reg[3]_i_76_n_0\,
      I1 => \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_77_n_0\,
      O => \G_OUT_reg[3]_i_36_n_0\,
      S => Y_IN(0)
    );
\G_OUT_reg[3]_i_40\: unisim.vcomponents.MUXF7
     port map (
      I0 => \G_OUT[3]_i_84_n_0\,
      I1 => \G_OUT[3]_i_85_n_0\,
      O => \G_OUT_reg[3]_i_40_n_0\,
      S => \ids[0]_inferred__1/g0_b1_i_1_n_0\
    );
\G_OUT_reg[3]_i_48\: unisim.vcomponents.MUXF8
     port map (
      I0 => \G_OUT_reg[3]_i_101_n_0\,
      I1 => \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_102_n_0\,
      O => \G_OUT_reg[3]_i_48_n_0\,
      S => Y_IN(0)
    );
\G_OUT_reg[3]_i_49\: unisim.vcomponents.MUXF8
     port map (
      I0 => \G_OUT_reg[3]_i_103_n_0\,
      I1 => \vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_104_n_0\,
      O => \G_OUT_reg[3]_i_49_n_0\,
      S => Y_IN(0)
    );
\G_OUT_reg[3]_i_5\: unisim.vcomponents.MUXF8
     port map (
      I0 => \G_OUT_reg[3]_i_6_n_0\,
      I1 => \G_OUT_reg[3]_i_7_n_0\,
      O => \G_OUT_reg[3]_i_5_n_0\,
      S => X_IN(2)
    );
\G_OUT_reg[3]_i_50\: unisim.vcomponents.MUXF8
     port map (
      I0 => \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_105_n_0\,
      I1 => \G_OUT_reg[3]_i_106_n_0\,
      O => \G_OUT_reg[3]_i_50_n_0\,
      S => Y_IN(0)
    );
\G_OUT_reg[3]_i_51\: unisim.vcomponents.MUXF7
     port map (
      I0 => \G_OUT[3]_i_107_n_0\,
      I1 => \G_OUT[3]_i_108_n_0\,
      O => \G_OUT_reg[3]_i_51_n_0\,
      S => \ids[0]_inferred__1/g0_b1_i_1_n_0\
    );
\G_OUT_reg[3]_i_54\: unisim.vcomponents.MUXF8
     port map (
      I0 => \G_OUT_reg[3]_i_114_n_0\,
      I1 => \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_115_n_0\,
      O => \G_OUT_reg[3]_i_54_n_0\,
      S => Y_IN(0)
    );
\G_OUT_reg[3]_i_55\: unisim.vcomponents.MUXF8
     port map (
      I0 => \G_OUT_reg[3]_i_116_n_0\,
      I1 => \vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_117_n_0\,
      O => \G_OUT_reg[3]_i_55_n_0\,
      S => Y_IN(0)
    );
\G_OUT_reg[3]_i_56\: unisim.vcomponents.MUXF8
     port map (
      I0 => \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_118_n_0\,
      I1 => \G_OUT_reg[3]_i_119_n_0\,
      O => \G_OUT_reg[3]_i_56_n_0\,
      S => Y_IN(0)
    );
\G_OUT_reg[3]_i_6\: unisim.vcomponents.MUXF7
     port map (
      I0 => \G_OUT[3]_i_8_n_0\,
      I1 => \G_OUT[3]_i_9_n_0\,
      O => \G_OUT_reg[3]_i_6_n_0\,
      S => X_IN(1)
    );
\G_OUT_reg[3]_i_67\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b6__13_n_0\,
      I1 => \g1_b6__9_n_0\,
      O => \G_OUT_reg[3]_i_67_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\G_OUT_reg[3]_i_7\: unisim.vcomponents.MUXF7
     port map (
      I0 => \G_OUT[3]_i_10_n_0\,
      I1 => \G_OUT[3]_i_11_n_0\,
      O => \G_OUT_reg[3]_i_7_n_0\,
      S => X_IN(1)
    );
\G_OUT_reg[3]_i_76\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b7__13_n_0\,
      I1 => \g1_b7__8_n_0\,
      O => \G_OUT_reg[3]_i_76_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\G_OUT_reg[3]_i_80\: unisim.vcomponents.MUXF8
     port map (
      I0 => \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_128_n_0\,
      I1 => \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_129_n_0\,
      O => \G_OUT_reg[3]_i_80_n_0\,
      S => Y_IN(0)
    );
\G_OUT_reg[3]_i_83\: unisim.vcomponents.MUXF8
     port map (
      I0 => \G_OUT_reg[3]_i_134_n_0\,
      I1 => \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_135_n_0\,
      O => \G_OUT_reg[3]_i_83_n_0\,
      S => Y_IN(0)
    );
\G_OUT_reg[3]_i_90\: unisim.vcomponents.MUXF8
     port map (
      I0 => \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_136_n_0\,
      I1 => \G_OUT_reg[3]_i_137_n_0\,
      O => \G_OUT_reg[3]_i_90_n_0\,
      S => Y_IN(0)
    );
\G_OUT_reg[3]_i_93\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__13_n_0\,
      I1 => \g1_b4__13_n_0\,
      O => \G_OUT_reg[3]_i_93_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\G_OUT_reg[3]_i_95\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__11_n_0\,
      I1 => \g1_b4__11_n_0\,
      O => \G_OUT_reg[3]_i_95_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\R_OUT[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"ABAAABABABAAAAAA"
    )
        port map (
      I0 => G_OUT0,
      I1 => \R_OUT[3]_i_2_n_0\,
      I2 => \R_OUT[3]_i_3_n_0\,
      I3 => \R_OUT[3]_i_4_n_0\,
      I4 => X_IN(2),
      I5 => \R_OUT[3]_i_5_n_0\,
      O => R_OUT0
    );
\R_OUT[3]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0F0F3F3FAF0F3F3F"
    )
        port map (
      I0 => \R_OUT[3]_i_25_n_0\,
      I1 => \R_OUT[3]_i_26_n_0\,
      I2 => Y_IN(3),
      I3 => \R_OUT[3]_i_27_n_0\,
      I4 => Y_IN(2),
      I5 => Y_IN(0),
      O => \R_OUT[3]_i_10_n_0\
    );
\R_OUT[3]_i_11\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00005D00"
    )
        port map (
      I0 => Y_IN(3),
      I1 => \R_OUT[3]_i_28_n_0\,
      I2 => \R_OUT[3]_i_29_n_0\,
      I3 => X_IN(0),
      I4 => \R_OUT[3]_i_30_n_0\,
      O => \R_OUT[3]_i_11_n_0\
    );
\R_OUT[3]_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F0202000F02020"
    )
        port map (
      I0 => \R_OUT[3]_i_31_n_0\,
      I1 => \R_OUT[3]_i_32_n_0\,
      I2 => X_IN(0),
      I3 => \R_OUT[3]_i_33_n_0\,
      I4 => Y_IN(3),
      I5 => \R_OUT[3]_i_34_n_0\,
      O => \R_OUT[3]_i_12_n_0\
    );
\R_OUT[3]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"BA"
    )
        port map (
      I0 => X_IN(0),
      I1 => \R_OUT[3]_i_35_n_0\,
      I2 => \R_OUT[3]_i_36_n_0\,
      O => \R_OUT[3]_i_13_n_0\
    );
\R_OUT[3]_i_14\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBFBFBAA"
    )
        port map (
      I0 => Y_IN(3),
      I1 => Y_IN(2),
      I2 => \R_OUT_reg[3]_i_37_n_0\,
      I3 => \R_OUT[3]_i_38_n_0\,
      I4 => \R_OUT[3]_i_39_n_0\,
      O => \R_OUT[3]_i_14_n_0\
    );
\R_OUT[3]_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CFCCCFCD"
    )
        port map (
      I0 => Y_IN(0),
      I1 => \R_OUT[3]_i_40_n_0\,
      I2 => Y_IN(2),
      I3 => \R_OUT[3]_i_41_n_0\,
      I4 => \R_OUT[3]_i_42_n_0\,
      I5 => \R_OUT[3]_i_43_n_0\,
      O => \R_OUT[3]_i_15_n_0\
    );
\R_OUT[3]_i_16\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000075"
    )
        port map (
      I0 => Y_IN(3),
      I1 => Y_IN(2),
      I2 => \R_OUT[3]_i_44_n_0\,
      I3 => \R_OUT[3]_i_45_n_0\,
      I4 => X_IN(0),
      O => \R_OUT[3]_i_16_n_0\
    );
\R_OUT[3]_i_17\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EFFFFFFF"
    )
        port map (
      I0 => Y_IN(0),
      I1 => Y_IN(3),
      I2 => Y_IN(2),
      I3 => Y_IN(1),
      I4 => \g1_b1__16_n_0\,
      O => \R_OUT[3]_i_17_n_0\
    );
\R_OUT[3]_i_18\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0400"
    )
        port map (
      I0 => Y_IN(2),
      I1 => Y_IN(1),
      I2 => Y_IN(0),
      I3 => \g0_b1__18_n_0\,
      O => \R_OUT[3]_i_18_n_0\
    );
\R_OUT[3]_i_19\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"000000B8"
    )
        port map (
      I0 => \g0_b1__19_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b1__20_n_0\,
      I3 => Y_IN(1),
      I4 => Y_IN(2),
      O => \R_OUT[3]_i_19_n_0\
    );
\R_OUT[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF80FFFFFF"
    )
        port map (
      I0 => Y_IN(2),
      I1 => Y_IN(1),
      I2 => Y_IN(3),
      I3 => Y_IN(4),
      I4 => Y_IN(5),
      I5 => \R_OUT[3]_i_6_n_0\,
      O => \R_OUT[3]_i_2_n_0\
    );
\R_OUT[3]_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0FFF000EECCEECC"
    )
        port map (
      I0 => \R_OUT[3]_i_46_n_0\,
      I1 => \R_OUT[3]_i_47_n_0\,
      I2 => \R_OUT[3]_i_48_n_0\,
      I3 => Y_IN(1),
      I4 => \R_OUT[3]_i_49_n_0\,
      I5 => Y_IN(2),
      O => \R_OUT[3]_i_20_n_0\
    );
\R_OUT[3]_i_22\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFF7FFFF"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \ids[0]_0\(2),
      I2 => \ids[0]_0\(4),
      I3 => \ids[0]_0\(3),
      I4 => \R_OUT[3]_i_25_n_0\,
      O => \R_OUT[3]_i_22_n_0\
    );
\R_OUT[3]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => Y_IN(0),
      I1 => Y_IN(1),
      O => \R_OUT[3]_i_23_n_0\
    );
\R_OUT[3]_i_24\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8FFF8F8"
    )
        port map (
      I0 => \R_OUT[3]_i_52_n_0\,
      I1 => Y_IN(1),
      I2 => Y_IN(2),
      I3 => \R_OUT[3]_i_53_n_0\,
      I4 => \R_OUT[3]_i_54_n_0\,
      O => \R_OUT[3]_i_24_n_0\
    );
\R_OUT[3]_i_25\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBC8FFFF"
    )
        port map (
      I0 => g0_b7_i_6_n_0,
      I1 => X_IN(5),
      I2 => X_IN(4),
      I3 => \g0_b7_i_5__0_n_0\,
      I4 => X_IN(9),
      O => \R_OUT[3]_i_25_n_0\
    );
\R_OUT[3]_i_26\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"D0D3DCDF10131C1F"
    )
        port map (
      I0 => \g0_b3__19_n_0\,
      I1 => Y_IN(0),
      I2 => Y_IN(1),
      I3 => \g0_b3__18_n_0\,
      I4 => \g0_b3__20_n_0\,
      I5 => \R_OUT[3]_i_22_n_0\,
      O => \R_OUT[3]_i_26_n_0\
    );
\R_OUT[3]_i_27\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"ABAAAAAA"
    )
        port map (
      I0 => \g0_b7_i_1__0_n_0\,
      I1 => \ids[0]_0\(4),
      I2 => \ids[0]_0\(3),
      I3 => g0_b7_i_1_n_0,
      I4 => \ids[0]_0\(2),
      O => \R_OUT[3]_i_27_n_0\
    );
\R_OUT[3]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"4F"
    )
        port map (
      I0 => Y_IN(0),
      I1 => \g0_b2__18_n_0\,
      I2 => Y_IN(1),
      O => \R_OUT[3]_i_28_n_0\
    );
\R_OUT[3]_i_29\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF0131"
    )
        port map (
      I0 => \g0_b2__20_n_0\,
      I1 => Y_IN(1),
      I2 => Y_IN(0),
      I3 => \g0_b2__19_n_0\,
      I4 => Y_IN(2),
      O => \R_OUT[3]_i_29_n_0\
    );
\R_OUT[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAA80"
    )
        port map (
      I0 => X_IN(9),
      I1 => \R_OUT[3]_i_7_n_0\,
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => \R_OUT[3]_i_3_n_0\
    );
\R_OUT[3]_i_30\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0404041504150415"
    )
        port map (
      I0 => Y_IN(3),
      I1 => Y_IN(2),
      I2 => \R_OUT_reg[3]_i_55_n_0\,
      I3 => \R_OUT[3]_i_47_n_0\,
      I4 => \R_OUT[3]_i_56_n_0\,
      I5 => Y_IN(1),
      O => \R_OUT[3]_i_30_n_0\
    );
\R_OUT[3]_i_31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF00001F11"
    )
        port map (
      I0 => \R_OUT[3]_i_57_n_0\,
      I1 => \R_OUT[3]_i_58_n_0\,
      I2 => \R_OUT[3]_i_59_n_0\,
      I3 => \R_OUT[3]_i_60_n_0\,
      I4 => Y_IN(1),
      I5 => \R_OUT[3]_i_61_n_0\,
      O => \R_OUT[3]_i_31_n_0\
    );
\R_OUT[3]_i_32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00004700FF004700"
    )
        port map (
      I0 => \g0_b4__23_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b4__24_n_0\,
      I3 => Y_IN(2),
      I4 => Y_IN(1),
      I5 => \R_OUT[3]_i_62_n_0\,
      O => \R_OUT[3]_i_32_n_0\
    );
\R_OUT[3]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"DF"
    )
        port map (
      I0 => Y_IN(2),
      I1 => Y_IN(0),
      I2 => \R_OUT[3]_i_63_n_0\,
      O => \R_OUT[3]_i_33_n_0\
    );
\R_OUT[3]_i_34\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4454444444444444"
    )
        port map (
      I0 => Y_IN(2),
      I1 => \R_OUT[3]_i_64_n_0\,
      I2 => \R_OUT[3]_i_65_n_0\,
      I3 => \R_OUT[3]_i_66_n_0\,
      I4 => Y_IN(0),
      I5 => Y_IN(1),
      O => \R_OUT[3]_i_34_n_0\
    );
\R_OUT[3]_i_35\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000B8FFFFFFFF"
    )
        port map (
      I0 => \g0_b5__19_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b5__20_n_0\,
      I3 => Y_IN(1),
      I4 => Y_IN(2),
      I5 => Y_IN(3),
      O => \R_OUT[3]_i_35_n_0\
    );
\R_OUT[3]_i_36\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFC8FBFFFFFFFF"
    )
        port map (
      I0 => \g0_b7_i_1__0_n_0\,
      I1 => Y_IN(0),
      I2 => \R_OUT[3]_i_67_n_0\,
      I3 => \g0_b5__18_n_0\,
      I4 => Y_IN(2),
      I5 => Y_IN(1),
      O => \R_OUT[3]_i_36_n_0\
    );
\R_OUT[3]_i_38\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FABAEAAA"
    )
        port map (
      I0 => Y_IN(2),
      I1 => Y_IN(0),
      I2 => Y_IN(1),
      I3 => \g0_b5__25_n_0\,
      I4 => \g0_b5__26_n_0\,
      O => \R_OUT[3]_i_38_n_0\
    );
\R_OUT[3]_i_39\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4440"
    )
        port map (
      I0 => Y_IN(1),
      I1 => Y_IN(0),
      I2 => \R_OUT[3]_i_70_n_0\,
      I3 => \R_OUT[3]_i_71_n_0\,
      O => \R_OUT[3]_i_39_n_0\
    );
\R_OUT[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBBB888B8888"
    )
        port map (
      I0 => \R_OUT[3]_i_8_n_0\,
      I1 => X_IN(1),
      I2 => X_IN(0),
      I3 => \R_OUT[3]_i_9_n_0\,
      I4 => \R_OUT[3]_i_10_n_0\,
      I5 => \R_OUT[3]_i_11_n_0\,
      O => \R_OUT[3]_i_4_n_0\
    );
\R_OUT[3]_i_40\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"1000FFFF"
    )
        port map (
      I0 => \R_OUT[3]_i_72_n_0\,
      I1 => Y_IN(0),
      I2 => Y_IN(2),
      I3 => \ids[0]_0\(2),
      I4 => Y_IN(3),
      O => \R_OUT[3]_i_40_n_0\
    );
\R_OUT[3]_i_41\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00E2"
    )
        port map (
      I0 => \g0_b6__18_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b6__20_n_0\,
      I3 => Y_IN(1),
      O => \R_OUT[3]_i_41_n_0\
    );
\R_OUT[3]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"1F"
    )
        port map (
      I0 => \g0_b6__19_n_0\,
      I1 => Y_IN(0),
      I2 => Y_IN(1),
      O => \R_OUT[3]_i_42_n_0\
    );
\R_OUT[3]_i_43\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00001F11FFFFFFFF"
    )
        port map (
      I0 => \R_OUT[3]_i_47_n_0\,
      I1 => \R_OUT[3]_i_73_n_0\,
      I2 => \R_OUT_reg[3]_i_74_n_0\,
      I3 => Y_IN(2),
      I4 => Y_IN(3),
      I5 => X_IN(0),
      O => \R_OUT[3]_i_43_n_0\
    );
\R_OUT[3]_i_44\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"3300B8B8"
    )
        port map (
      I0 => \g0_b7__19_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b7__20_n_0\,
      I3 => \g0_b7__18_n_0\,
      I4 => Y_IN(1),
      O => \R_OUT[3]_i_44_n_0\
    );
\R_OUT[3]_i_45\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000000047FF"
    )
        port map (
      I0 => \R_OUT[3]_i_75_n_0\,
      I1 => Y_IN(1),
      I2 => \R_OUT[3]_i_76_n_0\,
      I3 => Y_IN(2),
      I4 => \R_OUT[3]_i_77_n_0\,
      I5 => Y_IN(3),
      O => \R_OUT[3]_i_45_n_0\
    );
\R_OUT[3]_i_46\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \g0_b1__25_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b1__26_n_0\,
      O => \R_OUT[3]_i_46_n_0\
    );
\R_OUT[3]_i_47\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000004"
    )
        port map (
      I0 => \ids[0]_0\(4),
      I1 => \R_OUT[3]_i_25_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \R_OUT[3]_i_78_n_0\,
      I4 => g0_b7_i_1_n_0,
      I5 => \ids[0]_0\(3),
      O => \R_OUT[3]_i_47_n_0\
    );
\R_OUT[3]_i_48\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \g0_b1__21_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b1__22_n_0\,
      O => \R_OUT[3]_i_48_n_0\
    );
\R_OUT[3]_i_49\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \g0_b1__23_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b1__24_n_0\,
      O => \R_OUT[3]_i_49_n_0\
    );
\R_OUT[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BAFFBAFFBAFFBA00"
    )
        port map (
      I0 => \R_OUT[3]_i_12_n_0\,
      I1 => \R_OUT[3]_i_13_n_0\,
      I2 => \R_OUT[3]_i_14_n_0\,
      I3 => X_IN(1),
      I4 => \R_OUT[3]_i_15_n_0\,
      I5 => \R_OUT[3]_i_16_n_0\,
      O => \R_OUT[3]_i_5_n_0\
    );
\R_OUT[3]_i_50\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \g0_b3__23_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b3__24_n_0\,
      O => \R_OUT[3]_i_50_n_0\
    );
\R_OUT[3]_i_51\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \g0_b3__21_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b3__22_n_0\,
      O => \R_OUT[3]_i_51_n_0\
    );
\R_OUT[3]_i_52\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \g0_b3__25_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b3__26_n_0\,
      O => \R_OUT[3]_i_52_n_0\
    );
\R_OUT[3]_i_53\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBBBFBFF"
    )
        port map (
      I0 => Y_IN(1),
      I1 => \ids[0]_0\(2),
      I2 => g0_b7_i_14_n_0,
      I3 => \ids[0]_0\(3),
      I4 => g0_b7_i_1_n_0,
      O => \R_OUT[3]_i_53_n_0\
    );
\R_OUT[3]_i_54\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => \g0_b7_i_1__0_n_0\,
      I1 => Y_IN(0),
      I2 => \ids[0]_0\(4),
      O => \R_OUT[3]_i_54_n_0\
    );
\R_OUT[3]_i_56\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \g0_b2__25_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b2__26_n_0\,
      O => \R_OUT[3]_i_56_n_0\
    );
\R_OUT[3]_i_57\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CFFFFF9F"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => Y_IN(0),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \R_OUT[3]_i_57_n_0\
    );
\R_OUT[3]_i_58\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FBBB"
    )
        port map (
      I0 => \ids[0]_0\(4),
      I1 => \ids[0]_0\(2),
      I2 => g0_b7_i_1_n_0,
      I3 => \ids[0]_0\(3),
      O => \R_OUT[3]_i_58_n_0\
    );
\R_OUT[3]_i_59\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \ids[0]_0\(4),
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => Y_IN(0),
      O => \R_OUT[3]_i_59_n_0\
    );
\R_OUT[3]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFFF"
    )
        port map (
      I0 => Y_IN(8),
      I1 => Y_IN(9),
      I2 => Y_IN(7),
      I3 => Y_IN(6),
      O => \R_OUT[3]_i_6_n_0\
    );
\R_OUT[3]_i_60\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4020"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \ids[0]_0\(3),
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(4),
      O => \R_OUT[3]_i_60_n_0\
    );
\R_OUT[3]_i_61\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFB8FF00"
    )
        port map (
      I0 => \g0_b4__25_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b4__26_n_0\,
      I3 => Y_IN(2),
      I4 => Y_IN(1),
      O => \R_OUT[3]_i_61_n_0\
    );
\R_OUT[3]_i_62\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \g0_b4__21_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b4__22_n_0\,
      O => \R_OUT[3]_i_62_n_0\
    );
\R_OUT[3]_i_63\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0400000004040000"
    )
        port map (
      I0 => \ids[0]_0\(4),
      I1 => g0_b7_i_1_n_0,
      I2 => \ids[0]_0\(3),
      I3 => \R_OUT[3]_i_81_n_0\,
      I4 => \ids[0]_0\(2),
      I5 => X_IN(9),
      O => \R_OUT[3]_i_63_n_0\
    );
\R_OUT[3]_i_64\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0FCA00CA"
    )
        port map (
      I0 => \g0_b4__20_n_0\,
      I1 => \g0_b4__18_n_0\,
      I2 => Y_IN(1),
      I3 => Y_IN(0),
      I4 => \g0_b4__19_n_0\,
      O => \R_OUT[3]_i_64_n_0\
    );
\R_OUT[3]_i_65\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \R_OUT[3]_i_25_n_0\,
      I1 => \ids[0]_0\(4),
      O => \R_OUT[3]_i_65_n_0\
    );
\R_OUT[3]_i_66\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \ids[0]_0\(2),
      I1 => g0_b7_i_1_n_0,
      O => \R_OUT[3]_i_66_n_0\
    );
\R_OUT[3]_i_67\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"BFFF"
    )
        port map (
      I0 => \ids[0]_0\(4),
      I1 => g0_b7_i_1_n_0,
      I2 => \ids[0]_0\(3),
      I3 => \ids[0]_0\(2),
      O => \R_OUT[3]_i_67_n_0\
    );
\R_OUT[3]_i_68\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \g0_b5__23_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b5__24_n_0\,
      O => \R_OUT[3]_i_68_n_0\
    );
\R_OUT[3]_i_69\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \g0_b5__21_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b5__22_n_0\,
      O => \R_OUT[3]_i_69_n_0\
    );
\R_OUT[3]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => X_IN(4),
      I1 => X_IN(3),
      O => \R_OUT[3]_i_7_n_0\
    );
\R_OUT[3]_i_70\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => \ids[0]_0\(2),
      I1 => g0_b7_i_1_n_0,
      I2 => \ids[0]_0\(4),
      I3 => \ids[0]_0\(3),
      I4 => \g0_b7_i_1__0_n_0\,
      O => \R_OUT[3]_i_70_n_0\
    );
\R_OUT[3]_i_71\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00200000"
    )
        port map (
      I0 => \g0_b7_i_1__0_n_0\,
      I1 => g0_b7_i_1_n_0,
      I2 => g0_b7_i_14_n_0,
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(2),
      O => \R_OUT[3]_i_71_n_0\
    );
\R_OUT[3]_i_72\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFCFFF6F"
    )
        port map (
      I0 => \ids[0]_0\(4),
      I1 => \ids[0]_0\(3),
      I2 => g0_b7_i_1_n_0,
      I3 => \ids[0]_0\(2),
      I4 => \R_OUT[3]_i_25_n_0\,
      O => \R_OUT[3]_i_72_n_0\
    );
\R_OUT[3]_i_73\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFB8FF00"
    )
        port map (
      I0 => \g0_b6__25_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b6__26_n_0\,
      I3 => Y_IN(2),
      I4 => Y_IN(1),
      O => \R_OUT[3]_i_73_n_0\
    );
\R_OUT[3]_i_75\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \g0_b7__21_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b7__22_n_0\,
      O => \R_OUT[3]_i_75_n_0\
    );
\R_OUT[3]_i_76\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \g0_b7__23_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b7__24_n_0\,
      O => \R_OUT[3]_i_76_n_0\
    );
\R_OUT[3]_i_77\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000B800"
    )
        port map (
      I0 => \g0_b7__25_n_0\,
      I1 => Y_IN(0),
      I2 => g0_b7_n_0,
      I3 => Y_IN(1),
      I4 => Y_IN(2),
      O => \R_OUT[3]_i_77_n_0\
    );
\R_OUT[3]_i_78\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => Y_IN(1),
      I1 => Y_IN(0),
      O => \R_OUT[3]_i_78_n_0\
    );
\R_OUT[3]_i_79\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \g0_b2__23_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b2__24_n_0\,
      O => \R_OUT[3]_i_79_n_0\
    );
\R_OUT[3]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7774777777744444"
    )
        port map (
      I0 => \R_OUT[3]_i_17_n_0\,
      I1 => X_IN(0),
      I2 => \R_OUT[3]_i_18_n_0\,
      I3 => \R_OUT[3]_i_19_n_0\,
      I4 => Y_IN(3),
      I5 => \R_OUT[3]_i_20_n_0\,
      O => \R_OUT[3]_i_8_n_0\
    );
\R_OUT[3]_i_80\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \g0_b2__21_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b2__22_n_0\,
      O => \R_OUT[3]_i_80_n_0\
    );
\R_OUT[3]_i_81\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF53FFFF0053FF"
    )
        port map (
      I0 => \strnum_v[3][0]_i_1_n_0\,
      I1 => \strnum_v[2][0]_i_1_n_0\,
      I2 => X_IN(3),
      I3 => X_IN(4),
      I4 => X_IN(5),
      I5 => g0_b7_i_6_n_0,
      O => \R_OUT[3]_i_81_n_0\
    );
\R_OUT[3]_i_82\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \g0_b6__23_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b6__24_n_0\,
      O => \R_OUT[3]_i_82_n_0\
    );
\R_OUT[3]_i_83\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \g0_b6__21_n_0\,
      I1 => Y_IN(0),
      I2 => \g0_b6__22_n_0\,
      O => \R_OUT[3]_i_83_n_0\
    );
\R_OUT[3]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0404040455045555"
    )
        port map (
      I0 => Y_IN(3),
      I1 => Y_IN(2),
      I2 => \R_OUT_reg[3]_i_21_n_0\,
      I3 => \R_OUT[3]_i_22_n_0\,
      I4 => \R_OUT[3]_i_23_n_0\,
      I5 => \R_OUT[3]_i_24_n_0\,
      O => \R_OUT[3]_i_9_n_0\
    );
\R_OUT_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => R_OUT0,
      Q => R_OUT(0),
      R => '0'
    );
\R_OUT_reg[3]_i_21\: unisim.vcomponents.MUXF7
     port map (
      I0 => \R_OUT[3]_i_50_n_0\,
      I1 => \R_OUT[3]_i_51_n_0\,
      O => \R_OUT_reg[3]_i_21_n_0\,
      S => Y_IN(1)
    );
\R_OUT_reg[3]_i_37\: unisim.vcomponents.MUXF7
     port map (
      I0 => \R_OUT[3]_i_68_n_0\,
      I1 => \R_OUT[3]_i_69_n_0\,
      O => \R_OUT_reg[3]_i_37_n_0\,
      S => Y_IN(1)
    );
\R_OUT_reg[3]_i_55\: unisim.vcomponents.MUXF7
     port map (
      I0 => \R_OUT[3]_i_79_n_0\,
      I1 => \R_OUT[3]_i_80_n_0\,
      O => \R_OUT_reg[3]_i_55_n_0\,
      S => Y_IN(1)
    );
\R_OUT_reg[3]_i_74\: unisim.vcomponents.MUXF7
     port map (
      I0 => \R_OUT[3]_i_82_n_0\,
      I1 => \R_OUT[3]_i_83_n_0\,
      O => \R_OUT_reg[3]_i_74_n_0\,
      S => Y_IN(1)
    );
g0_b0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"441144F3C5240000"
    )
        port map (
      I0 => X_IN(3),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => g0_b0_n_0
    );
g0_b1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"07F06D6010A08004"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => g0_b1_n_0
    );
\g0_b1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"47FF69ED838D8014"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b1__0_n_0\
    );
\g0_b1__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"02FFE1FD838D0438"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b1__1_n_0\
    );
\g0_b1__10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"47FF69ED838D8014"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b1__10_n_0\
    );
\g0_b1__11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"02FFE1FD838D0438"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b1__11_n_0\
    );
\g0_b1__12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"02E7E11723090020"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b1__12_n_0\
    );
\g0_b1__13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2E11342012C40"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b1__13_n_0\
    );
\g0_b1__14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2E19703790010"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b1__14_n_0\
    );
\g0_b1__15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"14AEF1BE23690418"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b1__15_n_0\
    );
\g0_b1__16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"152C79AE016D0030"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b1__16_n_0\
    );
\g0_b1__17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"150479A210160060"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b1__17_n_0\
    );
\g0_b1__18\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"20290090"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b1__18_n_0\
    );
\g0_b1__19\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"029700A0"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b1__19_n_0\
    );
\g0_b1__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"02E7E11723090020"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b1__2_n_0\
    );
\g0_b1__20\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8A960124"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b1__20_n_0\
    );
\g0_b1__21\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0AB60020"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b1__21_n_0\
    );
\g0_b1__22\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"18028510"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b1__22_n_0\
    );
\g0_b1__23\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8A060080"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b1__23_n_0\
    );
\g0_b1__24\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4A4701A4"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b1__24_n_0\
    );
\g0_b1__25\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4A474021"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b1__25_n_0\
    );
\g0_b1__26\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"20C04001"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b1__26_n_0\
    );
\g0_b1__27\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b1__27_n_0\
    );
\g0_b1__28\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b1__28_n_0\
    );
\g0_b1__29\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b1__29_n_0\
    );
\g0_b1__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2E11342012C40"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b1__3_n_0\
    );
\g0_b1__30\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80007FFF80000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b1__30_n_0\
    );
\g0_b1__31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b1__31_n_0\
    );
\g0_b1__32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b1__32_n_0\
    );
\g0_b1__33\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"4"
    )
        port map (
      I0 => g0_b1_i_1_n_0,
      I1 => g0_b1_i_2_n_0,
      O => \g0_b1__33_n_0\
    );
\g0_b1__34\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b1__34_n_0\
    );
\g0_b1__35\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFF000000000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b1__35_n_0\
    );
\g0_b1__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2E19703790010"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b1__4_n_0\
    );
\g0_b1__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"14AEF1BE23690418"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b1__5_n_0\
    );
\g0_b1__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"152C79AE016D0030"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b1__6_n_0\
    );
\g0_b1__7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"150479A210160060"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b1__7_n_0\
    );
\g0_b1__8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"054050C1A7100000"
    )
        port map (
      I0 => X_IN(3),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => \g0_b1__8_n_0\
    );
\g0_b1__9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"07F06D6010A08004"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b1__9_n_0\
    );
g0_b1_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C808C0C0C8080000"
    )
        port map (
      I0 => g0_b1_i_3_n_0,
      I1 => X_IN(8),
      I2 => X_IN(7),
      I3 => \g0_b1_i_4__0_n_0\,
      I4 => X_IN(6),
      I5 => \g0_b1_i_5__0_n_0\,
      O => g0_b1_i_1_n_0
    );
\g0_b1_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"202220820A008880"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(6),
      I2 => X_IN(4),
      I3 => X_IN(7),
      I4 => X_IN(3),
      I5 => X_IN(5),
      O => \g0_b1_i_1__0_n_0\
    );
g0_b1_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0CC8C0C0"
    )
        port map (
      I0 => X_IN(5),
      I1 => X_IN(8),
      I2 => X_IN(7),
      I3 => X_IN(4),
      I4 => X_IN(6),
      O => g0_b1_i_2_n_0
    );
\g0_b1_i_2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"220882A022222800"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(5),
      I2 => X_IN(7),
      I3 => X_IN(4),
      I4 => X_IN(6),
      I5 => X_IN(3),
      O => \g0_b1_i_2__0_n_0\
    );
g0_b1_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFB0800000B080"
    )
        port map (
      I0 => BUTTONS_IN(1),
      I1 => X_IN(3),
      I2 => X_IN(4),
      I3 => BUTTONS_IN(0),
      I4 => X_IN(5),
      I5 => \g0_b1_i_6__0_n_0\,
      O => g0_b1_i_3_n_0
    );
\g0_b1_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"020288A8008A8820"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(3),
      O => \g0_b1_i_3__0_n_0\
    );
g0_b1_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0802022002080000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(6),
      I2 => X_IN(5),
      I3 => X_IN(7),
      I4 => X_IN(4),
      I5 => X_IN(3),
      O => g0_b1_i_4_n_0
    );
\g0_b1_i_4__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4747470000004700"
    )
        port map (
      I0 => X_IN(4),
      I1 => X_IN(6),
      I2 => X_IN(5),
      I3 => BUTTONS_IN(14),
      I4 => X_IN(3),
      I5 => BUTTONS_IN(15),
      O => \g0_b1_i_4__0_n_0\
    );
g0_b1_i_5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"008AA202A0020200"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(3),
      I2 => X_IN(4),
      I3 => X_IN(6),
      I4 => X_IN(5),
      I5 => X_IN(7),
      O => g0_b1_i_5_n_0
    );
\g0_b1_i_5__0\: unisim.vcomponents.MUXF7
     port map (
      I0 => g0_b1_i_8_n_0,
      I1 => g0_b1_i_9_n_0,
      O => \g0_b1_i_5__0_n_0\,
      S => g0_b1_i_7_n_0
    );
g0_b1_i_6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => X_IN(3),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => g0_b1_i_6_n_0
    );
\g0_b1_i_6__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => BUTTONS_IN(5),
      I1 => BUTTONS_IN(4),
      I2 => X_IN(4),
      I3 => BUTTONS_IN(3),
      I4 => X_IN(3),
      I5 => BUTTONS_IN(2),
      O => \g0_b1_i_6__0_n_0\
    );
g0_b1_i_7: unisim.vcomponents.LUT3
    generic map(
      INIT => X"1D"
    )
        port map (
      I0 => X_IN(5),
      I1 => X_IN(6),
      I2 => X_IN(4),
      O => g0_b1_i_7_n_0
    );
g0_b1_i_8: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => BUTTONS_IN(13),
      I1 => BUTTONS_IN(12),
      I2 => X_IN(4),
      I3 => BUTTONS_IN(11),
      I4 => X_IN(3),
      I5 => BUTTONS_IN(10),
      O => g0_b1_i_8_n_0
    );
g0_b1_i_9: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => BUTTONS_IN(9),
      I1 => BUTTONS_IN(8),
      I2 => X_IN(4),
      I3 => BUTTONS_IN(7),
      I4 => X_IN(3),
      I5 => BUTTONS_IN(6),
      O => g0_b1_i_9_n_0
    );
g0_b2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6FFF6FED93BD011C"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => g0_b2_n_0
    );
\g0_b2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"67FFEDFD939D805E"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b2__0_n_0\
    );
\g0_b2__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"27EFED17839D864E"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b2__1_n_0\
    );
\g0_b2__10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"67FFEDFD939D805E"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b2__10_n_0\
    );
\g0_b2__11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"27EFED17839D864E"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b2__11_n_0\
    );
\g0_b2__12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"22E7ED17E39D062A"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b2__12_n_0\
    );
\g0_b2__13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"22E7E51743792E78"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b2__13_n_0\
    );
\g0_b2__14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"30EEED9743790658"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b2__14_n_0\
    );
\g0_b2__15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"31EEED9723790658"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b2__15_n_0\
    );
\g0_b2__16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"35AEFDBE137D0078"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b2__16_n_0\
    );
\g0_b2__17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2FBE7B2F117F0178"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b2__17_n_0\
    );
\g0_b2__18\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"22BF02B4"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b2__18_n_0\
    );
\g0_b2__19\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"2AB700B4"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b2__19_n_0\
    );
\g0_b2__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"22E7ED17E39D062A"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b2__2_n_0\
    );
\g0_b2__20\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8AB60934"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b2__20_n_0\
    );
\g0_b2__21\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"1AB60934"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b2__21_n_0\
    );
\g0_b2__22\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"1AB68DB4"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b2__22_n_0\
    );
\g0_b2__23\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"DA67098C"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b2__23_n_0\
    );
\g0_b2__24\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4A67491D"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b2__24_n_0\
    );
\g0_b2__25\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6A67403D"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b2__25_n_0\
    );
\g0_b2__26\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AE70225"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b2__26_n_0\
    );
\g0_b2__27\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b2__27_n_0\
    );
\g0_b2__28\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"4"
    )
        port map (
      I0 => g0_b1_i_1_n_0,
      I1 => g0_b1_i_2_n_0,
      O => \g0_b2__28_n_0\
    );
\g0_b2__29\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000FFFF7FFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b2__29_n_0\
    );
\g0_b2__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"22E7E51743792E78"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b2__3_n_0\
    );
\g0_b2__30\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80007FFFFFFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b2__30_n_0\
    );
\g0_b2__31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b2__31_n_0\
    );
\g0_b2__32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80007FFFFFFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b2__32_n_0\
    );
\g0_b2__33\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"4"
    )
        port map (
      I0 => g0_b1_i_1_n_0,
      I1 => g0_b1_i_2_n_0,
      O => \g0_b2__33_n_0\
    );
\g0_b2__34\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b2__34_n_0\
    );
\g0_b2__35\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_2_n_0,
      O => \g0_b2__35_n_0\
    );
\g0_b2__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"30EEED9743790658"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b2__4_n_0\
    );
\g0_b2__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"31EEED9723790658"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b2__5_n_0\
    );
\g0_b2__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"35AEFDBE137D0078"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b2__6_n_0\
    );
\g0_b2__7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2FBE7B2F117F0178"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b2__7_n_0\
    );
\g0_b2__8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AEFEA81643E50000"
    )
        port map (
      I0 => X_IN(3),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => \g0_b2__8_n_0\
    );
\g0_b2__9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6FFF6FED93BD011C"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b2__9_n_0\
    );
g0_b3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6C1F86FD83FF015A"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => g0_b3_n_0
    );
\g0_b3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2010A6121C12034A"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b3__0_n_0\
    );
\g0_b3__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"25102E025C138A4A"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b3__1_n_0\
    );
\g0_b3__10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2010A6121C12034A"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b3__10_n_0\
    );
\g0_b3__11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"25102E025C138A4A"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b3__11_n_0\
    );
\g0_b3__12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"25106E61E0978E4A"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b3__12_n_0\
    );
\g0_b3__13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"331D4F6583FE2E3A"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b3__13_n_0\
    );
\g0_b3__14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"331C4EE3C0120E6A"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b3__14_n_0\
    );
\g0_b3__15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"33D20E017C121A48"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b3__15_n_0\
    );
\g0_b3__16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"22D286109E12534A"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b3__16_n_0\
    );
\g0_b3__17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2EBA96BD837F511A"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b3__17_n_0\
    );
\g0_b3__18\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B5282C14"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b3__18_n_0\
    );
\g0_b3__19\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4ABF322C"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b3__19_n_0\
    );
\g0_b3__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"25106E61E0978E4A"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b3__2_n_0\
    );
\g0_b3__20\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6D283A1C"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b3__20_n_0\
    );
\g0_b3__21\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"50280D9C"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b3__21_n_0\
    );
\g0_b3__22\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4AFD8DAC"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b3__22_n_0\
    );
\g0_b3__23\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"D06B4D1C"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b3__23_n_0\
    );
\g0_b3__24\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"352A4C1C"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b3__24_n_0\
    );
\g0_b3__25\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"25280A1C"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b3__25_n_0\
    );
\g0_b3__26\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4AFF023C"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b3__26_n_0\
    );
\g0_b3__27\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF00007FFF8000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b3__27_n_0\
    );
\g0_b3__28\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF80007FFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b3__28_n_0\
    );
\g0_b3__29\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => g0_b1_i_1_n_0,
      I1 => g0_b1_i_2_n_0,
      O => \g0_b3__29_n_0\
    );
\g0_b3__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"331D4F6583FE2E3A"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b3__3_n_0\
    );
\g0_b3__30\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      O => \g0_b3__30_n_0\
    );
\g0_b3__31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF7FFF7FFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b3__31_n_0\
    );
\g0_b3__32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFFFFFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b3__32_n_0\
    );
\g0_b3__33\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF00007FFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b3__33_n_0\
    );
\g0_b3__34\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFF800000000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b3__34_n_0\
    );
\g0_b3__35\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF7FFF7FFF8000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b3__35_n_0\
    );
\g0_b3__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"331C4EE3C0120E6A"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b3__4_n_0\
    );
\g0_b3__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"33D20E017C121A48"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b3__5_n_0\
    );
\g0_b3__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"22D286109E12534A"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b3__6_n_0\
    );
\g0_b3__7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2EBA96BD837F511A"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b3__7_n_0\
    );
\g0_b3__8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FAAAAA9003020000"
    )
        port map (
      I0 => X_IN(3),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => \g0_b3__8_n_0\
    );
\g0_b3__9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6C1F86FD83FF015A"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b3__9_n_0\
    );
g0_b4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2C1F96FF83EF02D2"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => g0_b4_n_0
    );
\g0_b4__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"081002024C120382"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b4__0_n_0\
    );
\g0_b4__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"081062005C12090A"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b4__1_n_0\
    );
\g0_b4__10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"081002024C120382"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b4__10_n_0\
    );
\g0_b4__11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"081062005C12090A"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b4__11_n_0\
    );
\g0_b4__12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1D10620130038D42"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b4__12_n_0\
    );
\g0_b4__13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1F9D6B6583EFAD52"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b4__13_n_0\
    );
\g0_b4__14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1B92028390960D62"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b4__14_n_0\
    );
\g0_b4__15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0A9202017C821928"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b4__15_n_0\
    );
\g0_b4__16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0AD20200CC825302"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b4__16_n_0\
    );
\g0_b4__17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2E7996FD8BFF5252"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b4__17_n_0\
    );
\g0_b4__18\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4EFF3838"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b4__18_n_0\
    );
\g0_b4__19\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55483A08"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b4__19_n_0\
    );
\g0_b4__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1D10620130038D42"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b4__2_n_0\
    );
\g0_b4__20\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B5482684"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b4__20_n_0\
    );
\g0_b4__21\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"60690798"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b4__21_n_0\
    );
\g0_b4__22\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4ADFC738"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b4__22_n_0\
    );
\g0_b4__23\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A00A4718"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b4__23_n_0\
    );
\g0_b4__24\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"3528060C"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b4__24_n_0\
    );
\g0_b4__25\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"15280A48"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b4__25_n_0\
    );
\g0_b4__26\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4ADF0878"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b4__26_n_0\
    );
\g0_b4__27\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF80007FFF8000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b4__27_n_0\
    );
\g0_b4__28\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF00007FFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b4__28_n_0\
    );
\g0_b4__29\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFF7FFFFFFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b4__29_n_0\
    );
\g0_b4__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1F9D6B6583EFAD52"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b4__3_n_0\
    );
\g0_b4__30\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFF80007FFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b4__30_n_0\
    );
\g0_b4__31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF7FFF7FFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b4__31_n_0\
    );
\g0_b4__32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFF80007FFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b4__32_n_0\
    );
\g0_b4__33\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF7FFFFFFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b4__33_n_0\
    );
\g0_b4__34\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFF800000000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b4__34_n_0\
    );
\g0_b4__35\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF7FFF7FFF8000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b4__35_n_0\
    );
\g0_b4__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1B92028390960D62"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b4__4_n_0\
    );
\g0_b4__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0A9202017C821928"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b4__5_n_0\
    );
\g0_b4__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0AD20200CC825302"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b4__6_n_0\
    );
\g0_b4__7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2E7996FD8BFF5252"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b4__7_n_0\
    );
\g0_b4__8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"54545441B4E10000"
    )
        port map (
      I0 => X_IN(3),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => \g0_b4__8_n_0\
    );
\g0_b4__9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2C1F96FF83EF02D2"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b4__9_n_0\
    );
g0_b5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6E1F9AFDC3ED02DC"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => g0_b5_n_0
    );
\g0_b5__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0A15F8FE404200CE"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b5__0_n_0\
    );
\g0_b5__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1B057876001205CE"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b5__1_n_0\
    );
\g0_b5__10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0A15F8FE404200CE"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b5__10_n_0\
    );
\g0_b5__11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1B057876001205CE"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b5__11_n_0\
    );
\g0_b5__12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1B0D78743010054A"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b5__12_n_0\
    );
\g0_b5__13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1F0D19741369AD58"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b5__13_n_0\
    );
\g0_b5__14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0D05187610958508"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b5__14_n_0\
    );
\g0_b5__15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"09C5187420840528"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b5__15_n_0\
    );
\g0_b5__16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"08C798FC40800028"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b5__16_n_0\
    );
\g0_b5__17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2EBD9EFD4BEF0258"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b5__17_n_0\
    );
\g0_b5__18\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"1EDF0834"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b5__18_n_0\
    );
\g0_b5__19\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"10400084"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b5__19_n_0\
    );
\g0_b5__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1B0D78743010054A"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b5__2_n_0\
    );
\g0_b5__20\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80410384"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b5__20_n_0\
    );
\g0_b5__21\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"20634304"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b5__21_n_0\
    );
\g0_b5__22\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"2A96C734"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b5__22_n_0\
    );
\g0_b5__23\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A020031C"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b5__23_n_0\
    );
\g0_b5__24\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0028035D"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b5__24_n_0\
    );
\g0_b5__25\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"1018005D"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b5__25_n_0\
    );
\g0_b5__26\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"5AD70875"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b5__26_n_0\
    );
\g0_b5__27\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000800000000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b5__27_n_0\
    );
\g0_b5__28\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF80000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b5__28_n_0\
    );
\g0_b5__29\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000007FFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b5__29_n_0\
    );
\g0_b5__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1F0D19741369AD58"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b5__3_n_0\
    );
\g0_b5__30\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFF80007FFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b5__30_n_0\
    );
\g0_b5__31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000FFFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b5__31_n_0\
    );
\g0_b5__32\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF0000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      O => \g0_b5__32_n_0\
    );
\g0_b5__33\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF80000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b5__33_n_0\
    );
\g0_b5__34\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b5__34_n_0\
    );
\g0_b5__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0D05187610958508"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b5__4_n_0\
    );
\g0_b5__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"09C5187420840528"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b5__5_n_0\
    );
\g0_b5__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"08C798FC40800028"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b5__6_n_0\
    );
\g0_b5__7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2EBD9EFD4BEF0258"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b5__7_n_0\
    );
\g0_b5__8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0101000000010000"
    )
        port map (
      I0 => X_IN(3),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => \g0_b5__8_n_0\
    );
\g0_b5__9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6E1F9AFDC3ED02DC"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b5__9_n_0\
    );
g0_b6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"47FF7975C3AD001C"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => g0_b6_n_0
    );
\g0_b6__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"57FFF9FD83ED005C"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b6__0_n_0\
    );
\g0_b6__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"13FFF9FF836304F8"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b6__1_n_0\
    );
\g0_b6__10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"57FFF9FD83ED005C"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b6__10_n_0\
    );
\g0_b6__11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"13FFF9FF836304F8"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b6__11_n_0\
    );
\g0_b6__12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"12EFF9FF23710038"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b6__12_n_0\
    );
\g0_b6__13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E7F9FF13712C58"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b6__13_n_0\
    );
\g0_b6__14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04E7F9FF01518048"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b6__14_n_0\
    );
\g0_b6__15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"05EFFDFF21458448"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b6__15_n_0\
    );
\g0_b6__16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"05AFFDFF016D0078"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b6__16_n_0\
    );
\g0_b6__17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"05AD7D77436F0078"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b6__17_n_0\
    );
\g0_b6__18\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"82134114"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b6__18_n_0\
    );
\g0_b6__19\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"1A9F00B4"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b6__19_n_0\
    );
\g0_b6__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"12EFF9FF23710038"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b6__2_n_0\
    );
\g0_b6__20\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"029700B4"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b6__20_n_0\
    );
\g0_b6__21\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"02324014"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b6__21_n_0\
    );
\g0_b6__22\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"2AB28534"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b6__22_n_0\
    );
\g0_b6__23\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8AB200A4"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b6__23_n_0\
    );
\g0_b6__24\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4A9A01F4"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b6__24_n_0\
    );
\g0_b6__25\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4AD70035"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b6__25_n_0\
    );
\g0_b6__26\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"5AC70025"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b6__26_n_0\
    );
\g0_b6__27\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b6__27_n_0\
    );
\g0_b6__28\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF80000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b6__28_n_0\
    );
\g0_b6__29\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b6__29_n_0\
    );
\g0_b6__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E7F9FF13712C58"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b6__3_n_0\
    );
\g0_b6__30\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b6__30_n_0\
    );
\g0_b6__31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000FFFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b6__31_n_0\
    );
\g0_b6__32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF7FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b6__32_n_0\
    );
\g0_b6__33\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b6__33_n_0\
    );
\g0_b6__34\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF80000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b6__34_n_0\
    );
\g0_b6__35\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b6__35_n_0\
    );
\g0_b6__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04E7F9FF01518048"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b6__4_n_0\
    );
\g0_b6__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"05EFFDFF21458448"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b6__5_n_0\
    );
\g0_b6__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"05AFFDFF016D0078"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b6__6_n_0\
    );
\g0_b6__7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"05AD7D77436F0078"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b6__7_n_0\
    );
\g0_b6__8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000F7F7F60000"
    )
        port map (
      I0 => X_IN(3),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => \g0_b6__8_n_0\
    );
\g0_b6__9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"47FF7975C3AD001C"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b6__9_n_0\
    );
g0_b7: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0800"
    )
        port map (
      I0 => \g0_b7_i_1__0_n_0\,
      I1 => \ids[0]_0\(2),
      I2 => \ids[0]_0\(3),
      I3 => \ids[0]_0\(4),
      O => g0_b7_n_0
    );
\g0_b7__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"15E5797400A00000"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b7__0_n_0\
    );
\g0_b7__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55EA610183AD0010"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b7__1_n_0\
    );
\g0_b7__10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55EA610183AD0010"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b7__10_n_0\
    );
\g0_b7__11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"14EAE18983610038"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b7__11_n_0\
    );
\g0_b7__12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2E18B03610030"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b7__12_n_0\
    );
\g0_b7__13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2E18B00712400"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b7__13_n_0\
    );
\g0_b7__14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2E18B01510040"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b7__14_n_0\
    );
\g0_b7__15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04AAE58B01418058"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b7__15_n_0\
    );
\g0_b7__16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"05286503016D8050"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b7__16_n_0\
    );
\g0_b7__17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0505797600040020"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b7__17_n_0\
    );
\g0_b7__18\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010080"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b7__18_n_0\
    );
\g0_b7__19\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"02974030"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b7__19_n_0\
    );
\g0_b7__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"14EAE18983610038"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b7__2_n_0\
    );
\g0_b7__20\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"02124034"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b7__20_n_0\
    );
\g0_b7__21\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"02320010"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b7__21_n_0\
    );
\g0_b7__22\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00B28100"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b7__22_n_0\
    );
\g0_b7__23\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0A9200A0"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b7__23_n_0\
    );
\g0_b7__24\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4A9200A4"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b7__24_n_0\
    );
\g0_b7__25\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4AC70020"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g0_b7__25_n_0\
    );
\g0_b7__26\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF80000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b7__26_n_0\
    );
\g0_b7__27\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b7__27_n_0\
    );
\g0_b7__28\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b7__28_n_0\
    );
\g0_b7__29\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b7__29_n_0\
    );
\g0_b7__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2E18B03610030"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b7__3_n_0\
    );
\g0_b7__30\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b7__30_n_0\
    );
\g0_b7__31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF00000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b7__31_n_0\
    );
\g0_b7__32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF80000000"
    )
        port map (
      I0 => X_IN(8),
      I1 => X_IN(7),
      I2 => X_IN(6),
      I3 => X_IN(4),
      I4 => g0_b1_i_1_n_0,
      I5 => g0_b1_i_2_n_0,
      O => \g0_b7__32_n_0\
    );
\g0_b7__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2E18B00712400"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b7__4_n_0\
    );
\g0_b7__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2E18B01510040"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b7__5_n_0\
    );
\g0_b7__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04AAE58B01418058"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b7__6_n_0\
    );
\g0_b7__7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"05286503016D8050"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b7__7_n_0\
    );
\g0_b7__8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0505797600040020"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g0_b7__8_n_0\
    );
\g0_b7__9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"15E5797400A00000"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g0_b7__9_n_0\
    );
g0_b7_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAABBBFFFBF"
    )
        port map (
      I0 => \g0_b7_i_2__0_n_0\,
      I1 => g0_b7_i_8_n_0,
      I2 => \strnum_v_reg_n_0_[4][1]\,
      I3 => BTN_PRESS_VALID_IN,
      I4 => g0_b7_i_3_n_0,
      I5 => \g0_b7_i_4__0_n_0\,
      O => g0_b7_i_1_n_0
    );
g0_b7_i_10: unisim.vcomponents.LUT6
    generic map(
      INIT => X"004700FFFFFFFFFF"
    )
        port map (
      I0 => \strnum_v[3][3]_i_2_n_0\,
      I1 => BTN_PRESS_VALID_IN,
      I2 => \strnum_v_reg_n_0_[3][2]\,
      I3 => X_IN(5),
      I4 => \R_OUT[3]_i_7_n_0\,
      I5 => X_IN(9),
      O => g0_b7_i_10_n_0
    );
g0_b7_i_11: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEFEFECECECEFECE"
    )
        port map (
      I0 => g0_b7_i_15_n_0,
      I1 => g0_b7_i_7_n_0,
      I2 => g0_b7_i_8_n_0,
      I3 => \strnum_v_reg_n_0_[4][3]\,
      I4 => BTN_PRESS_VALID_IN,
      I5 => \strnum_v[4][3]_i_2_n_0\,
      O => g0_b7_i_11_n_0
    );
g0_b7_i_12: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => \strnum_v[3][3]_i_1_n_0\,
      I1 => X_IN(3),
      I2 => X_IN(4),
      O => g0_b7_i_12_n_0
    );
g0_b7_i_13: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => \strnum_v[3][3]_i_1_n_0\,
      I1 => \strnum_v_reg_n_0_[3][4]\,
      I2 => BTN_PRESS_VALID_IN,
      O => g0_b7_i_13_n_0
    );
g0_b7_i_14: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FF01FF31"
    )
        port map (
      I0 => \strnum_v_reg_n_0_[5][4]\,
      I1 => BTN_PRESS_VALID_IN,
      I2 => g0_b7_i_8_n_0,
      I3 => g0_b7_i_7_n_0,
      I4 => \strnum_v_reg_n_0_[4][4]\,
      I5 => g0_b7_i_16_n_0,
      O => g0_b7_i_14_n_0
    );
g0_b7_i_15: unisim.vcomponents.LUT3
    generic map(
      INIT => X"CA"
    )
        port map (
      I0 => \strnum_v_reg_n_0_[5][3]\,
      I1 => \strnum_v[5][3]_i_2_n_0\,
      I2 => BTN_PRESS_VALID_IN,
      O => g0_b7_i_15_n_0
    );
g0_b7_i_16: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5500540050005400"
    )
        port map (
      I0 => X_IN(5),
      I1 => \strnum_v_reg_n_0_[2][4]\,
      I2 => BTN_PRESS_VALID_IN,
      I3 => X_IN(4),
      I4 => X_IN(3),
      I5 => \strnum_v_reg_n_0_[3][4]\,
      O => g0_b7_i_16_n_0
    );
\g0_b7_i_1__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00220A22"
    )
        port map (
      I0 => X_IN(9),
      I1 => \g0_b7_i_5__0_n_0\,
      I2 => X_IN(4),
      I3 => X_IN(5),
      I4 => g0_b7_i_6_n_0,
      O => \g0_b7_i_1__0_n_0\
    );
g0_b7_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000BFBA"
    )
        port map (
      I0 => g0_b7_i_7_n_0,
      I1 => \strnum_v[4][2]_i_2_n_0\,
      I2 => g0_b7_i_8_n_0,
      I3 => g0_b7_i_9_n_0,
      I4 => g0_b7_i_10_n_0,
      O => \ids[0]_0\(2)
    );
\g0_b7_i_2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"10155555FFFFFFFF"
    )
        port map (
      I0 => X_IN(5),
      I1 => g0_b7_i_5_n_0,
      I2 => BTN_PRESS_VALID_IN,
      I3 => \strnum_v_reg_n_0_[3][1]\,
      I4 => \R_OUT[3]_i_7_n_0\,
      I5 => X_IN(9),
      O => \g0_b7_i_2__0_n_0\
    );
g0_b7_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"555A1AAA55511AAA"
    )
        port map (
      I0 => \strnum_v[4][1]_i_2_n_0\,
      I1 => \strnum_v[2][0]_i_5_n_0\,
      I2 => \strnum_v[3][0]_i_5_n_0\,
      I3 => \strnum_v[3][1]_i_2_n_0\,
      I4 => \strnum_v[3][0]_i_4_n_0\,
      I5 => \strnum_v[3][0]_i_3_n_0\,
      O => g0_b7_i_3_n_0
    );
\g0_b7_i_3__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"88880008"
    )
        port map (
      I0 => g0_b7_i_11_n_0,
      I1 => X_IN(9),
      I2 => g0_b7_i_12_n_0,
      I3 => g0_b7_i_13_n_0,
      I4 => X_IN(5),
      O => \ids[0]_0\(3)
    );
g0_b7_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => X_IN(9),
      I1 => g0_b7_i_14_n_0,
      O => \ids[0]_0\(4)
    );
\g0_b7_i_4__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"ABBABBBBABBAAAAA"
    )
        port map (
      I0 => g0_b7_i_7_n_0,
      I1 => g0_b7_i_8_n_0,
      I2 => \strnum_v[4][0]_i_2_n_0\,
      I3 => BTN_CNTR_reg(1),
      I4 => BTN_PRESS_VALID_IN,
      I5 => \strnum_v_reg_n_0_[5][1]\,
      O => \g0_b7_i_4__0_n_0\
    );
g0_b7_i_5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0484D544880054DD"
    )
        port map (
      I0 => \strnum_v[2][0]_i_4_n_0\,
      I1 => \strnum_v[3][3]_i_2_n_0\,
      I2 => \strnum_v[2][0]_i_5_n_0\,
      I3 => \strnum_v[2][0]_i_6_n_0\,
      I4 => \strnum_v[2][0]_i_2_n_0\,
      I5 => \strnum_v[2][0]_i_7_n_0\,
      O => g0_b7_i_5_n_0
    );
\g0_b7_i_5__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1B111BBBFFFFFFFF"
    )
        port map (
      I0 => X_IN(3),
      I1 => \strnum_v[2][0]_i_1_n_0\,
      I2 => \strnum_v[3][0]_i_2_n_0\,
      I3 => BTN_PRESS_VALID_IN,
      I4 => \strnum_v_reg_n_0_[3][0]\,
      I5 => X_IN(4),
      O => \g0_b7_i_5__0_n_0\
    );
g0_b7_i_6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55335533000FFF0F"
    )
        port map (
      I0 => \strnum_v[4][0]_i_2_n_0\,
      I1 => \strnum_v_reg_n_0_[4][0]\,
      I2 => \strnum_v_reg_n_0_[5][0]\,
      I3 => BTN_PRESS_VALID_IN,
      I4 => BTN_CNTR_reg(0),
      I5 => g0_b7_i_8_n_0,
      O => g0_b7_i_6_n_0
    );
g0_b7_i_7: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => X_IN(4),
      I1 => X_IN(5),
      O => g0_b7_i_7_n_0
    );
g0_b7_i_8: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8A"
    )
        port map (
      I0 => X_IN(5),
      I1 => X_IN(4),
      I2 => X_IN(3),
      O => g0_b7_i_8_n_0
    );
g0_b7_i_9: unisim.vcomponents.LUT6
    generic map(
      INIT => X"22E2EE2EEE2E22E2"
    )
        port map (
      I0 => \strnum_v_reg_n_0_[5][2]\,
      I1 => BTN_PRESS_VALID_IN,
      I2 => \strnum_v[4][0]_i_2_n_0\,
      I3 => BTN_CNTR_reg(1),
      I4 => \strnum_v[4][1]_i_2_n_0\,
      I5 => BTN_CNTR_reg(2),
      O => g0_b7_i_9_n_0
    );
g1_b0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000001A41"
    )
        port map (
      I0 => X_IN(3),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => g1_b0_n_0
    );
g1_b1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000008000400"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => g1_b1_n_0
    );
\g1_b1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000007C20C80"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b1__0_n_0\
    );
\g1_b1__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000012CDE528"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b1__1_n_0\
    );
\g1_b1__10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002C5E524"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b1__10_n_0\
    );
\g1_b1__11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002C1E504"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b1__11_n_0\
    );
\g1_b1__12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000698ED2C"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b1__12_n_0\
    );
\g1_b1__13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000F206D12"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b1__13_n_0\
    );
\g1_b1__14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000400"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b1__14_n_0\
    );
\g1_b1__15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000400"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b1__15_n_0\
    );
\g1_b1__16\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000100"
    )
        port map (
      I0 => g0_b7_i_1_n_0,
      I1 => \g0_b7_i_1__0_n_0\,
      I2 => \ids[0]_0\(2),
      I3 => \ids[0]_0\(3),
      I4 => \ids[0]_0\(4),
      O => \g1_b1__16_n_0\
    );
\g1_b1__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002C5E524"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b1__2_n_0\
    );
\g1_b1__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002C1E504"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b1__3_n_0\
    );
\g1_b1__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000698ED2C"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b1__4_n_0\
    );
\g1_b1__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000F206D12"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b1__5_n_0\
    );
\g1_b1__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000003011"
    )
        port map (
      I0 => X_IN(3),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => \g1_b1__6_n_0\
    );
\g1_b1__7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000008000400"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b1__7_n_0\
    );
\g1_b1__8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000007C20C80"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b1__8_n_0\
    );
\g1_b1__9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000012CDE528"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b1__9_n_0\
    );
g1_b2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000008000410"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => g1_b2_n_0
    );
\g1_b2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000450"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b2__0_n_0\
    );
\g1_b2__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000004"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_3__0_n_0\,
      I2 => g0_b1_i_4_n_0,
      I3 => g0_b1_i_5_n_0,
      I4 => g0_b1_i_6_n_0,
      O => \g1_b2__1_n_0\
    );
\g1_b2__10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000450"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b2__10_n_0\
    );
\g1_b2__11\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000004"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b2__11_n_0\
    );
\g1_b2__12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000007FFEDB8"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b2__12_n_0\
    );
\g1_b2__13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000017EFEDBE"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b2__13_n_0\
    );
\g1_b2__14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002E7E5B6"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b2__14_n_0\
    );
\g1_b2__15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002EBED96"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b2__15_n_0\
    );
\g1_b2__16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000007FBEDBE"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b2__16_n_0\
    );
\g1_b2__17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000FBAFFBE"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b2__17_n_0\
    );
\g1_b2__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000007FFEDB8"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b2__2_n_0\
    );
\g1_b2__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000017EFEDBE"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b2__3_n_0\
    );
\g1_b2__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002E7E5B6"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b2__4_n_0\
    );
\g1_b2__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002EBED96"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b2__5_n_0\
    );
\g1_b2__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000007FBEDBE"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b2__6_n_0\
    );
\g1_b2__7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000FBAFFBE"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b2__7_n_0\
    );
\g1_b2__8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000000001FA"
    )
        port map (
      I0 => X_IN(3),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => \g1_b2__8_n_0\
    );
\g1_b2__9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000008000410"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b2__9_n_0\
    );
g1_b3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000008001251"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => g1_b3_n_0
    );
\g1_b3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000018001250"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b3__0_n_0\
    );
\g1_b3__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000018001010"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b3__1_n_0\
    );
\g1_b3__10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000018001250"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b3__10_n_0\
    );
\g1_b3__11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000018001010"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b3__11_n_0\
    );
\g1_b3__12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000001C3DF73E"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b3__12_n_0\
    );
\g1_b3__13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000015223A96"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b3__13_n_0\
    );
\g1_b3__14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000001D221AB2"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b3__14_n_0\
    );
\g1_b3__15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000192A1A92"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b3__15_n_0\
    );
\g1_b3__16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000001BE31292"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b3__16_n_0\
    );
\g1_b3__17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000CDA92AC"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b3__17_n_0\
    );
\g1_b3__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000001C3DF73E"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b3__2_n_0\
    );
\g1_b3__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000015223A96"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b3__3_n_0\
    );
\g1_b3__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000001D221AB2"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b3__4_n_0\
    );
\g1_b3__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000192A1A92"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b3__5_n_0\
    );
\g1_b3__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000001BE31292"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b3__6_n_0\
    );
\g1_b3__7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000CDA92AC"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b3__7_n_0\
    );
\g1_b3__8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000002AAA"
    )
        port map (
      I0 => X_IN(3),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => \g1_b3__8_n_0\
    );
\g1_b3__9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000008001251"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b3__9_n_0\
    );
g1_b4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000010101251"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => g1_b4_n_0
    );
\g1_b4__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000018101200"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b4__0_n_0\
    );
\g1_b4__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000018101000"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b4__1_n_0\
    );
\g1_b4__10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000018101200"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b4__10_n_0\
    );
\g1_b4__11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000018101000"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b4__11_n_0\
    );
\g1_b4__12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000001C1FD2BE"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b4__12_n_0\
    );
\g1_b4__13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000008143340"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b4__13_n_0\
    );
\g1_b4__14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000001D983A22"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b4__14_n_0\
    );
\g1_b4__15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000001D983200"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b4__15_n_0\
    );
\g1_b4__16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000001AD33280"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b4__16_n_0\
    );
\g1_b4__17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000147C927E"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b4__17_n_0\
    );
\g1_b4__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000001C1FD2BE"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b4__2_n_0\
    );
\g1_b4__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000008143340"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b4__3_n_0\
    );
\g1_b4__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000001D983A22"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b4__4_n_0\
    );
\g1_b4__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000001D983200"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b4__5_n_0\
    );
\g1_b4__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000001AD33280"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b4__6_n_0\
    );
\g1_b4__7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000147C927E"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b4__7_n_0\
    );
\g1_b4__8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000003004"
    )
        port map (
      I0 => X_IN(3),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => \g1_b4__8_n_0\
    );
\g1_b4__9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000010101251"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b4__9_n_0\
    );
g1_b5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000010001944"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => g1_b5_n_0
    );
\g1_b5__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000045AABFE"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b5__0_n_0\
    );
\g1_b5__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000009556954"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b5__1_n_0\
    );
\g1_b5__10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000015D4966"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b5__10_n_0\
    );
\g1_b5__11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000005554944"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b5__11_n_0\
    );
\g1_b5__12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000007D749C4"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b5__12_n_0\
    );
\g1_b5__13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000014ADDF7E"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b5__13_n_0\
    );
\g1_b5__14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000100944"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b5__14_n_0\
    );
\g1_b5__15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000100944"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b5__15_n_0\
    );
\g1_b5__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000015D4966"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b5__2_n_0\
    );
\g1_b5__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000005554944"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b5__3_n_0\
    );
\g1_b5__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000007D749C4"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b5__4_n_0\
    );
\g1_b5__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000014ADDF7E"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b5__5_n_0\
    );
\g1_b5__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000151"
    )
        port map (
      I0 => X_IN(3),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => \g1_b5__6_n_0\
    );
\g1_b5__7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000010001944"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b5__7_n_0\
    );
\g1_b5__8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000045AABFE"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b5__8_n_0\
    );
\g1_b5__9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000009556954"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b5__9_n_0\
    );
g1_b6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000010000904"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => g1_b6_n_0
    );
\g1_b6__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000007FFE9EE"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b6__0_n_0\
    );
\g1_b6__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000FEFE9FC"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b6__1_n_0\
    );
\g1_b6__10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002EFE9FE"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b6__10_n_0\
    );
\g1_b6__11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002E7E9FE"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b6__11_n_0\
    );
\g1_b6__12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000007AFE9FE"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b6__12_n_0\
    );
\g1_b6__13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000015ADED7E"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b6__13_n_0\
    );
\g1_b6__14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000944"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b6__14_n_0\
    );
\g1_b6__15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000944"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b6__15_n_0\
    );
\g1_b6__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002EFE9FE"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b6__2_n_0\
    );
\g1_b6__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002E7E9FE"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b6__3_n_0\
    );
\g1_b6__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000007AFE9FE"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b6__4_n_0\
    );
\g1_b6__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000015ADED7E"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b6__5_n_0\
    );
\g1_b6__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000001800"
    )
        port map (
      I0 => X_IN(3),
      I1 => X_IN(4),
      I2 => X_IN(5),
      I3 => X_IN(6),
      I4 => X_IN(7),
      I5 => X_IN(8),
      O => \g1_b6__6_n_0\
    );
\g1_b6__7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000010000904"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b6__7_n_0\
    );
\g1_b6__8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000007FFE9EE"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b6__8_n_0\
    );
\g1_b6__9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000FEFE9FC"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b6__9_n_0\
    );
g1_b7: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000904"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => g1_b7_n_0
    );
\g1_b7__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000007B56000"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b7__0_n_0\
    );
\g1_b7__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000006AAA0E8"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b7__1_n_0\
    );
\g1_b7__10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002A2A0BA"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b7__10_n_0\
    );
\g1_b7__11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000A8A03A"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b7__11_n_0\
    );
\g1_b7__12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000005042940"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b7__12_n_0\
    );
\g1_b7__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002A2A0B8"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b7__2_n_0\
    );
\g1_b7__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002A2A0BA"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b7__3_n_0\
    );
\g1_b7__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000A8A03A"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b7__4_n_0\
    );
\g1_b7__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000005042940"
    )
        port map (
      I0 => \g0_b1_i_1__0_n_0\,
      I1 => \g0_b1_i_2__0_n_0\,
      I2 => \g0_b1_i_3__0_n_0\,
      I3 => g0_b1_i_4_n_0,
      I4 => g0_b1_i_5_n_0,
      I5 => g0_b1_i_6_n_0,
      O => \g1_b7__5_n_0\
    );
\g1_b7__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000904"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b7__6_n_0\
    );
\g1_b7__7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000007B56000"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b7__7_n_0\
    );
\g1_b7__8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000006AAA0E8"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b7__8_n_0\
    );
\g1_b7__9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002A2A0B8"
    )
        port map (
      I0 => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      I1 => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      I2 => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      I3 => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      I4 => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      I5 => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      O => \g1_b7__9_n_0\
    );
\ids[0]_inferred__1/G_OUT_reg[3]_i_24\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b6__8_n_0\,
      I1 => \g1_b6__6_n_0\,
      O => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\,
      S => X_IN(9)
    );
\ids[0]_inferred__1/g0_b1_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => g0_b0_n_0,
      I1 => g1_b0_n_0,
      O => \ids[0]_inferred__1/g0_b1_i_1_n_0\,
      S => X_IN(9)
    );
\ids[0]_inferred__1/g0_b1_i_2\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b1__8_n_0\,
      I1 => \g1_b1__6_n_0\,
      O => \ids[0]_inferred__1/g0_b1_i_2_n_0\,
      S => X_IN(9)
    );
\ids[0]_inferred__1/g0_b1_i_3\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__8_n_0\,
      I1 => \g1_b2__8_n_0\,
      O => \ids[0]_inferred__1/g0_b1_i_3_n_0\,
      S => X_IN(9)
    );
\ids[0]_inferred__1/g0_b1_i_4\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__8_n_0\,
      I1 => \g1_b3__8_n_0\,
      O => \ids[0]_inferred__1/g0_b1_i_4_n_0\,
      S => X_IN(9)
    );
\ids[0]_inferred__1/g0_b1_i_5\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__8_n_0\,
      I1 => \g1_b4__8_n_0\,
      O => \ids[0]_inferred__1/g0_b1_i_5_n_0\,
      S => X_IN(9)
    );
\ids[0]_inferred__1/g0_b1_i_6\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b5__8_n_0\,
      I1 => \g1_b5__6_n_0\,
      O => \ids[0]_inferred__1/g0_b1_i_6_n_0\,
      S => X_IN(9)
    );
\strnum_v[2][0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F20"
    )
        port map (
      I0 => \strnum_v[2][0]_i_2_n_0\,
      I1 => \strnum_v[2][0]_i_3_n_0\,
      I2 => BTN_PRESS_VALID_IN,
      I3 => \strnum_v_reg_n_0_[2][0]\,
      O => \strnum_v[2][0]_i_1_n_0\
    );
\strnum_v[2][0]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F000E000"
    )
        port map (
      I0 => BTN_CNTR_reg(5),
      I1 => BTN_CNTR_reg(6),
      I2 => BTN_CNTR_reg(8),
      I3 => BTN_CNTR_reg(9),
      I4 => BTN_CNTR_reg(7),
      O => \strnum_v[2][0]_i_2_n_0\
    );
\strnum_v[2][0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BFAEAEBFAAABABAA"
    )
        port map (
      I0 => \strnum_v[2][0]_i_4_n_0\,
      I1 => \strnum_v[3][3]_i_2_n_0\,
      I2 => \strnum_v[2][0]_i_5_n_0\,
      I3 => \strnum_v[2][0]_i_6_n_0\,
      I4 => \strnum_v[2][0]_i_2_n_0\,
      I5 => \strnum_v[2][0]_i_7_n_0\,
      O => \strnum_v[2][0]_i_3_n_0\
    );
\strnum_v[2][0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1C303CF33C7108F3"
    )
        port map (
      I0 => BTN_CNTR_reg(4),
      I1 => BTN_CNTR_reg(7),
      I2 => BTN_CNTR_reg(9),
      I3 => BTN_CNTR_reg(8),
      I4 => BTN_CNTR_reg(6),
      I5 => BTN_CNTR_reg(5),
      O => \strnum_v[2][0]_i_4_n_0\
    );
\strnum_v[2][0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F6DB34D0F4D32490"
    )
        port map (
      I0 => BTN_CNTR_reg(4),
      I1 => BTN_CNTR_reg(5),
      I2 => \strnum_v[2][0]_i_8_n_0\,
      I3 => \strnum_v[2][0]_i_6_n_0\,
      I4 => \strnum_v[2][0]_i_7_n_0\,
      I5 => BTN_CNTR_reg(3),
      O => \strnum_v[2][0]_i_5_n_0\
    );
\strnum_v[2][0]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"66D64694"
    )
        port map (
      I0 => BTN_CNTR_reg(7),
      I1 => BTN_CNTR_reg(9),
      I2 => BTN_CNTR_reg(8),
      I3 => BTN_CNTR_reg(6),
      I4 => BTN_CNTR_reg(5),
      O => \strnum_v[2][0]_i_6_n_0\
    );
\strnum_v[2][0]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"37C993EC368113C8"
    )
        port map (
      I0 => BTN_CNTR_reg(5),
      I1 => BTN_CNTR_reg(6),
      I2 => BTN_CNTR_reg(9),
      I3 => BTN_CNTR_reg(8),
      I4 => BTN_CNTR_reg(7),
      I5 => BTN_CNTR_reg(4),
      O => \strnum_v[2][0]_i_7_n_0\
    );
\strnum_v[2][0]_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A6DB5924"
    )
        port map (
      I0 => BTN_CNTR_reg(8),
      I1 => BTN_CNTR_reg(9),
      I2 => BTN_CNTR_reg(7),
      I3 => BTN_CNTR_reg(6),
      I4 => BTN_CNTR_reg(5),
      O => \strnum_v[2][0]_i_8_n_0\
    );
\strnum_v[2][4]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \strnum_v_reg_n_0_[2][4]\,
      I1 => BTN_PRESS_VALID_IN,
      O => \strnum_v[2][4]_i_1_n_0\
    );
\strnum_v[3][0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \strnum_v[3][0]_i_2_n_0\,
      I1 => BTN_PRESS_VALID_IN,
      I2 => \strnum_v_reg_n_0_[3][0]\,
      O => \strnum_v[3][0]_i_1_n_0\
    );
\strnum_v[3][0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCC4FCC4CCC0FCC4"
    )
        port map (
      I0 => \strnum_v[3][0]_i_3_n_0\,
      I1 => \strnum_v[3][0]_i_4_n_0\,
      I2 => \strnum_v[3][1]_i_2_n_0\,
      I3 => \strnum_v[3][0]_i_5_n_0\,
      I4 => \strnum_v[2][0]_i_5_n_0\,
      I5 => \strnum_v[4][1]_i_2_n_0\,
      O => \strnum_v[3][0]_i_2_n_0\
    );
\strnum_v[3][0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F2FFFB0F2FFFB0FF"
    )
        port map (
      I0 => \strnum_v[2][0]_i_5_n_0\,
      I1 => BTN_CNTR_reg(2),
      I2 => \strnum_v[2][0]_i_7_n_0\,
      I3 => \strnum_v[4][1]_i_3_n_0\,
      I4 => BTN_CNTR_reg(3),
      I5 => BTN_CNTR_reg(4),
      O => \strnum_v[3][0]_i_3_n_0\
    );
\strnum_v[3][0]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8778E11E"
    )
        port map (
      I0 => \strnum_v[2][0]_i_5_n_0\,
      I1 => \strnum_v[2][0]_i_7_n_0\,
      I2 => \strnum_v[2][0]_i_2_n_0\,
      I3 => \strnum_v[2][0]_i_6_n_0\,
      I4 => \strnum_v[3][3]_i_2_n_0\,
      O => \strnum_v[3][0]_i_4_n_0\
    );
\strnum_v[3][0]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \strnum_v[2][0]_i_5_n_0\,
      I1 => \strnum_v[3][3]_i_2_n_0\,
      I2 => \strnum_v[2][0]_i_7_n_0\,
      O => \strnum_v[3][0]_i_5_n_0\
    );
\strnum_v[3][1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8AFF8A00"
    )
        port map (
      I0 => \strnum_v[3][1]_i_2_n_0\,
      I1 => \strnum_v[2][0]_i_3_n_0\,
      I2 => \strnum_v[2][0]_i_2_n_0\,
      I3 => BTN_PRESS_VALID_IN,
      I4 => \strnum_v_reg_n_0_[3][1]\,
      O => \strnum_v[3][1]_i_1_n_0\
    );
\strnum_v[3][1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"69410000FFFF7D69"
    )
        port map (
      I0 => \strnum_v[2][0]_i_7_n_0\,
      I1 => \strnum_v[2][0]_i_2_n_0\,
      I2 => \strnum_v[2][0]_i_6_n_0\,
      I3 => \strnum_v[2][0]_i_5_n_0\,
      I4 => \strnum_v[3][3]_i_2_n_0\,
      I5 => \strnum_v[2][0]_i_4_n_0\,
      O => \strnum_v[3][1]_i_2_n_0\
    );
\strnum_v[3][2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \strnum_v[3][3]_i_2_n_0\,
      I1 => BTN_PRESS_VALID_IN,
      I2 => \strnum_v_reg_n_0_[3][2]\,
      O => \strnum_v[3][2]_i_1_n_0\
    );
\strnum_v[3][3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A8FFA800"
    )
        port map (
      I0 => \strnum_v[2][0]_i_2_n_0\,
      I1 => \strnum_v[2][0]_i_3_n_0\,
      I2 => \strnum_v[3][3]_i_2_n_0\,
      I3 => BTN_PRESS_VALID_IN,
      I4 => \strnum_v_reg_n_0_[3][3]\,
      O => \strnum_v[3][3]_i_1_n_0\
    );
\strnum_v[3][3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3C0C3C0C3C0C2CCC"
    )
        port map (
      I0 => BTN_CNTR_reg(4),
      I1 => BTN_CNTR_reg(9),
      I2 => BTN_CNTR_reg(8),
      I3 => BTN_CNTR_reg(7),
      I4 => BTN_CNTR_reg(6),
      I5 => BTN_CNTR_reg(5),
      O => \strnum_v[3][3]_i_2_n_0\
    );
\strnum_v[3][4]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \strnum_v_reg_n_0_[3][4]\,
      I1 => BTN_PRESS_VALID_IN,
      O => \strnum_v[3][4]_i_1_n_0\
    );
\strnum_v[4][0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"CA"
    )
        port map (
      I0 => \strnum_v_reg_n_0_[4][0]\,
      I1 => \strnum_v[4][0]_i_2_n_0\,
      I2 => BTN_PRESS_VALID_IN,
      O => \strnum_v[4][0]_i_1_n_0\
    );
\strnum_v[4][0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6FDB2F5B250B2409"
    )
        port map (
      I0 => BTN_CNTR_reg(3),
      I1 => BTN_CNTR_reg(2),
      I2 => \strnum_v[4][0]_i_3_n_0\,
      I3 => \strnum_v[2][0]_i_5_n_0\,
      I4 => BTN_CNTR_reg(1),
      I5 => \strnum_v[4][1]_i_2_n_0\,
      O => \strnum_v[4][0]_i_2_n_0\
    );
\strnum_v[4][0]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => BTN_CNTR_reg(3),
      I1 => \strnum_v[2][0]_i_7_n_0\,
      I2 => BTN_CNTR_reg(4),
      O => \strnum_v[4][0]_i_3_n_0\
    );
\strnum_v[4][1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6F60"
    )
        port map (
      I0 => \strnum_v[4][1]_i_2_n_0\,
      I1 => \strnum_v[3][0]_i_2_n_0\,
      I2 => BTN_PRESS_VALID_IN,
      I3 => \strnum_v_reg_n_0_[4][1]\,
      O => \strnum_v[4][1]_i_1_n_0\
    );
\strnum_v[4][1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F6BD56B0F2954290"
    )
        port map (
      I0 => BTN_CNTR_reg(4),
      I1 => BTN_CNTR_reg(3),
      I2 => \strnum_v[4][1]_i_3_n_0\,
      I3 => \strnum_v[2][0]_i_7_n_0\,
      I4 => \strnum_v[4][1]_i_4_n_0\,
      I5 => BTN_CNTR_reg(2),
      O => \strnum_v[4][1]_i_2_n_0\
    );
\strnum_v[4][1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"66D6B96B99294694"
    )
        port map (
      I0 => BTN_CNTR_reg(7),
      I1 => BTN_CNTR_reg(9),
      I2 => BTN_CNTR_reg(8),
      I3 => BTN_CNTR_reg(6),
      I4 => BTN_CNTR_reg(5),
      I5 => BTN_CNTR_reg(4),
      O => \strnum_v[4][1]_i_3_n_0\
    );
\strnum_v[4][1]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C96CB29B9BC926B2"
    )
        port map (
      I0 => BTN_CNTR_reg(4),
      I1 => BTN_CNTR_reg(8),
      I2 => BTN_CNTR_reg(9),
      I3 => BTN_CNTR_reg(7),
      I4 => BTN_CNTR_reg(6),
      I5 => BTN_CNTR_reg(5),
      O => \strnum_v[4][1]_i_4_n_0\
    );
\strnum_v[4][2]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \strnum_v[4][2]_i_2_n_0\,
      O => \strnum_v[4][2]_i_1_n_0\
    );
\strnum_v[4][2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B44B0000B44BFFFF"
    )
        port map (
      I0 => \strnum_v[4][1]_i_2_n_0\,
      I1 => \strnum_v[3][0]_i_2_n_0\,
      I2 => \strnum_v[3][1]_i_2_n_0\,
      I3 => \strnum_v[2][0]_i_5_n_0\,
      I4 => BTN_PRESS_VALID_IN,
      I5 => \strnum_v_reg_n_0_[4][2]\,
      O => \strnum_v[4][2]_i_2_n_0\
    );
\strnum_v[4][3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \strnum_v[4][3]_i_2_n_0\,
      I1 => BTN_PRESS_VALID_IN,
      I2 => \strnum_v_reg_n_0_[4][3]\,
      O => \strnum_v[4][3]_i_1_n_0\
    );
\strnum_v[4][3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"07C004CBF30004CB"
    )
        port map (
      I0 => \strnum_v[3][0]_i_3_n_0\,
      I1 => \strnum_v[3][0]_i_4_n_0\,
      I2 => \strnum_v[3][1]_i_2_n_0\,
      I3 => \strnum_v[3][0]_i_5_n_0\,
      I4 => \strnum_v[2][0]_i_5_n_0\,
      I5 => \strnum_v[4][1]_i_2_n_0\,
      O => \strnum_v[4][3]_i_2_n_0\
    );
\strnum_v[4][4]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \strnum_v_reg_n_0_[4][4]\,
      I1 => BTN_PRESS_VALID_IN,
      O => \strnum_v[4][4]_i_1_n_0\
    );
\strnum_v[5][0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => BTN_CNTR_reg(0),
      I1 => BTN_PRESS_VALID_IN,
      I2 => \strnum_v_reg_n_0_[5][0]\,
      O => \strnum_v[5][0]_i_1_n_0\
    );
\strnum_v[5][1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6F60"
    )
        port map (
      I0 => \strnum_v[4][0]_i_2_n_0\,
      I1 => BTN_CNTR_reg(1),
      I2 => BTN_PRESS_VALID_IN,
      I3 => \strnum_v_reg_n_0_[5][1]\,
      O => \strnum_v[5][1]_i_1_n_0\
    );
\strnum_v[5][2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"22E2EE2EEE2E22E2"
    )
        port map (
      I0 => \strnum_v_reg_n_0_[5][2]\,
      I1 => BTN_PRESS_VALID_IN,
      I2 => \strnum_v[4][0]_i_2_n_0\,
      I3 => BTN_CNTR_reg(1),
      I4 => \strnum_v[4][1]_i_2_n_0\,
      I5 => BTN_CNTR_reg(2),
      O => \strnum_v[5][2]_i_1_n_0\
    );
\strnum_v[5][3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \strnum_v[5][3]_i_2_n_0\,
      I1 => BTN_PRESS_VALID_IN,
      I2 => \strnum_v_reg_n_0_[5][3]\,
      O => \strnum_v[5][3]_i_1_n_0\
    );
\strnum_v[5][3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04482FF087700112"
    )
        port map (
      I0 => BTN_CNTR_reg(1),
      I1 => BTN_CNTR_reg(2),
      I2 => \strnum_v[2][0]_i_5_n_0\,
      I3 => BTN_CNTR_reg(3),
      I4 => \strnum_v[4][1]_i_2_n_0\,
      I5 => \strnum_v[4][0]_i_3_n_0\,
      O => \strnum_v[5][3]_i_2_n_0\
    );
\strnum_v[5][4]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \strnum_v_reg_n_0_[5][4]\,
      I1 => BTN_PRESS_VALID_IN,
      O => \strnum_v[5][4]_i_1_n_0\
    );
\strnum_v_reg[2][0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[2][0]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[2][0]\,
      R => '0'
    );
\strnum_v_reg[2][4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[2][4]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[2][4]\,
      R => '0'
    );
\strnum_v_reg[3][0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[3][0]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[3][0]\,
      R => '0'
    );
\strnum_v_reg[3][1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[3][1]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[3][1]\,
      R => '0'
    );
\strnum_v_reg[3][2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[3][2]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[3][2]\,
      R => '0'
    );
\strnum_v_reg[3][3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[3][3]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[3][3]\,
      R => '0'
    );
\strnum_v_reg[3][4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[3][4]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[3][4]\,
      R => '0'
    );
\strnum_v_reg[4][0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[4][0]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[4][0]\,
      R => '0'
    );
\strnum_v_reg[4][1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[4][1]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[4][1]\,
      R => '0'
    );
\strnum_v_reg[4][2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[4][2]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[4][2]\,
      R => '0'
    );
\strnum_v_reg[4][3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[4][3]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[4][3]\,
      R => '0'
    );
\strnum_v_reg[4][4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[4][4]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[4][4]\,
      R => '0'
    );
\strnum_v_reg[5][0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[5][0]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[5][0]\,
      R => '0'
    );
\strnum_v_reg[5][1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[5][1]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[5][1]\,
      R => '0'
    );
\strnum_v_reg[5][2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[5][2]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[5][2]\,
      R => '0'
    );
\strnum_v_reg[5][3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[5][3]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[5][3]\,
      R => '0'
    );
\strnum_v_reg[5][4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \strnum_v[5][4]_i_1_n_0\,
      Q => \strnum_v_reg_n_0_[5][4]\,
      R => '0'
    );
\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_61\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__7_n_0\,
      I1 => \g1_b4__7_n_0\,
      O => \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_61_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_66\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b5__7_n_0\,
      I1 => \g1_b5__5_n_0\,
      O => \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_66_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_71\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b6__7_n_0\,
      I1 => \g1_b6__5_n_0\,
      O => \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_71_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_77\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b7__8_n_0\,
      I1 => \g1_b7__5_n_0\,
      O => \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_77_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_83\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b1__7_n_0\,
      I1 => \g1_b1__5_n_0\,
      O => \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_83_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_89\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__7_n_0\,
      I1 => \g1_b2__7_n_0\,
      O => \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_89_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_95\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__7_n_0\,
      I1 => \g1_b3__7_n_0\,
      O => \vga_table[0][10]_inferred__0/B_OUT_reg[3]_i_95_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_111\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__17_n_0\,
      I1 => \g1_b3__17_n_0\,
      O => \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_111_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_143\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b1__17_n_0\,
      I1 => \g1_b1__13_n_0\,
      O => \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_143_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_63\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b6__17_n_0\,
      I1 => \g1_b6__13_n_0\,
      O => \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_63_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_71\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b7__17_n_0\,
      I1 => \g1_b7__12_n_0\,
      O => \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_71_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_79\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b5__17_n_0\,
      I1 => \g1_b5__13_n_0\,
      O => \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_79_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_86\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__17_n_0\,
      I1 => \g1_b4__17_n_0\,
      O => \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_86_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_97\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__17_n_0\,
      I1 => \g1_b2__17_n_0\,
      O => \vga_table[0][10]_inferred__1/G_OUT_reg[3]_i_97_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_121\: unisim.vcomponents.MUXF7
     port map (
      I0 => g0_b4_n_0,
      I1 => g1_b4_n_0,
      O => \vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_121_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_143\: unisim.vcomponents.MUXF7
     port map (
      I0 => g0_b2_n_0,
      I1 => g1_b2_n_0,
      O => \vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_143_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_149\: unisim.vcomponents.MUXF7
     port map (
      I0 => g0_b3_n_0,
      I1 => g1_b3_n_0,
      O => \vga_table[0][2]_inferred__0/B_OUT_reg[3]_i_149_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_105\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__9_n_0\,
      I1 => \g1_b2__9_n_0\,
      O => \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_105_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_118\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__9_n_0\,
      I1 => \g1_b3__9_n_0\,
      O => \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_118_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_131\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b5__9_n_0\,
      I1 => \g1_b5__7_n_0\,
      O => \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_131_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_136\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__9_n_0\,
      I1 => \g1_b4__9_n_0\,
      O => \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_136_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_75\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b7__9_n_0\,
      I1 => \g1_b7__6_n_0\,
      O => \vga_table[0][2]_inferred__1/G_OUT_reg[3]_i_75_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_120\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__2_n_0\,
      I1 => \g1_b4__2_n_0\,
      O => \vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_120_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_142\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__2_n_0\,
      I1 => \g1_b2__2_n_0\,
      O => \vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_142_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_148\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__2_n_0\,
      I1 => \g1_b3__2_n_0\,
      O => \vga_table[0][5]_inferred__0/B_OUT_reg[3]_i_148_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_104\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__12_n_0\,
      I1 => \g1_b2__12_n_0\,
      O => \vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_104_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_117\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__12_n_0\,
      I1 => \g1_b3__12_n_0\,
      O => \vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_117_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_94\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__12_n_0\,
      I1 => \g1_b4__12_n_0\,
      O => \vga_table[0][5]_inferred__1/G_OUT_reg[3]_i_94_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_118\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__4_n_0\,
      I1 => \g1_b4__4_n_0\,
      O => \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_118_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_126\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b5__4_n_0\,
      I1 => \g1_b5__2_n_0\,
      O => \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_126_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_130\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b6__4_n_0\,
      I1 => \g1_b6__2_n_0\,
      O => \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_130_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_134\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b7__5_n_0\,
      I1 => \g1_b7__2_n_0\,
      O => \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_134_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_138\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b1__4_n_0\,
      I1 => \g1_b1__2_n_0\,
      O => \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_138_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_140\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__4_n_0\,
      I1 => \g1_b2__4_n_0\,
      O => \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_140_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_146\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__4_n_0\,
      I1 => \g1_b3__4_n_0\,
      O => \vga_table[0][7]_inferred__0/B_OUT_reg[3]_i_146_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_102\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__14_n_0\,
      I1 => \g1_b2__14_n_0\,
      O => \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_102_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_115\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__14_n_0\,
      I1 => \g1_b3__14_n_0\,
      O => \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_115_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_135\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b5__14_n_0\,
      I1 => \g1_b5__10_n_0\,
      O => \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_135_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_140\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b1__14_n_0\,
      I1 => \g1_b1__10_n_0\,
      O => \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_140_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_68\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b6__14_n_0\,
      I1 => \g1_b6__10_n_0\,
      O => \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_68_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_77\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b7__14_n_0\,
      I1 => \g1_b7__9_n_0\,
      O => \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_77_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_92\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__14_n_0\,
      I1 => \g1_b4__14_n_0\,
      O => \vga_table[0][7]_inferred__1/G_OUT_reg[3]_i_92_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_123\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__5_n_0\,
      I1 => \g1_b4__5_n_0\,
      O => \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_123_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_127\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b5__5_n_0\,
      I1 => \g1_b5__3_n_0\,
      O => \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_127_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_131\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b6__5_n_0\,
      I1 => \g1_b6__3_n_0\,
      O => \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_131_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_135\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b7__6_n_0\,
      I1 => \g1_b7__3_n_0\,
      O => \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_135_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_81\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b1__5_n_0\,
      I1 => \g1_b1__3_n_0\,
      O => \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_81_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_87\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__5_n_0\,
      I1 => \g1_b2__5_n_0\,
      O => \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_87_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_93\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__5_n_0\,
      I1 => \g1_b3__5_n_0\,
      O => \vga_table[0][8]_inferred__0/B_OUT_reg[3]_i_93_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_128\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b5__15_n_0\,
      I1 => \g1_b5__11_n_0\,
      O => \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_128_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_144\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b1__15_n_0\,
      I1 => \g1_b1__11_n_0\,
      O => \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_144_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_65\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b6__15_n_0\,
      I1 => \g1_b6__11_n_0\,
      O => \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_65_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_73\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b7__15_n_0\,
      I1 => \g1_b7__10_n_0\,
      O => \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_73_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_88\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__15_n_0\,
      I1 => \g1_b4__15_n_0\,
      O => \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_88_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_99\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__15_n_0\,
      I1 => \g1_b2__15_n_0\,
      O => \vga_table[0][8]_inferred__1/G_OUT_reg[3]_i_99_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_124\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__6_n_0\,
      I1 => \g1_b4__6_n_0\,
      O => \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_124_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_128\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b5__6_n_0\,
      I1 => \g1_b5__4_n_0\,
      O => \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_128_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_132\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b6__6_n_0\,
      I1 => \g1_b6__4_n_0\,
      O => \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_132_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_136\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b7__7_n_0\,
      I1 => \g1_b7__4_n_0\,
      O => \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_136_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_82\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b1__6_n_0\,
      I1 => \g1_b1__4_n_0\,
      O => \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_82_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_88\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__6_n_0\,
      I1 => \g1_b2__6_n_0\,
      O => \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_88_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_94\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__6_n_0\,
      I1 => \g1_b3__6_n_0\,
      O => \vga_table[0][9]_inferred__0/B_OUT_reg[3]_i_94_n_0\,
      S => \B_OUT[3]_i_36_n_0\
    );
\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_129\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b5__16_n_0\,
      I1 => \g1_b5__12_n_0\,
      O => \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_129_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_145\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b1__16_n_0\,
      I1 => \g1_b1__12_n_0\,
      O => \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_145_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_64\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b6__16_n_0\,
      I1 => \g1_b6__12_n_0\,
      O => \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_64_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_72\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b7__16_n_0\,
      I1 => \g1_b7__11_n_0\,
      O => \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_72_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_89\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b4__16_n_0\,
      I1 => \g1_b4__16_n_0\,
      O => \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_89_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
\vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_98\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b2__16_n_0\,
      I1 => \g1_b2__16_n_0\,
      O => \vga_table[0][9]_inferred__1/G_OUT_reg[3]_i_98_n_0\,
      S => \ids[0]_inferred__1/G_OUT_reg[3]_i_24_n_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity uvod_VGA_DRAW_0_0 is
  port (
    CLK : in STD_LOGIC;
    X_IN : in STD_LOGIC_VECTOR ( 10 downto 0 );
    Y_IN : in STD_LOGIC_VECTOR ( 10 downto 0 );
    BTN_PRESS_VALID_IN : in STD_LOGIC;
    BTN_RELEASE_VALID_IN : in STD_LOGIC;
    BUTTONS_IN : in STD_LOGIC_VECTOR ( 15 downto 0 );
    R_OUT : out STD_LOGIC_VECTOR ( 3 downto 0 );
    G_OUT : out STD_LOGIC_VECTOR ( 3 downto 0 );
    B_OUT : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of uvod_VGA_DRAW_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of uvod_VGA_DRAW_0_0 : entity is "uvod_VGA_DRAW_0_0,VGA_DRAW,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of uvod_VGA_DRAW_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of uvod_VGA_DRAW_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of uvod_VGA_DRAW_0_0 : entity is "VGA_DRAW,Vivado 2019.1";
end uvod_VGA_DRAW_0_0;

architecture STRUCTURE of uvod_VGA_DRAW_0_0 is
  signal \^b_out\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \^g_out\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \^r_out\ : STD_LOGIC_VECTOR ( 2 to 2 );
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of CLK : signal is "xilinx.com:signal:clock:1.0 CLK CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of CLK : signal is "XIL_INTERFACENAME CLK, FREQ_HZ 40000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0";
begin
  B_OUT(3) <= \^b_out\(2);
  B_OUT(2) <= \^b_out\(2);
  B_OUT(1) <= \^b_out\(2);
  B_OUT(0) <= \^b_out\(2);
  G_OUT(3) <= \^g_out\(2);
  G_OUT(2) <= \^g_out\(2);
  G_OUT(1) <= \^g_out\(2);
  G_OUT(0) <= \^g_out\(2);
  R_OUT(3) <= \^r_out\(2);
  R_OUT(2) <= \^r_out\(2);
  R_OUT(1) <= \^r_out\(2);
  R_OUT(0) <= \^r_out\(2);
inst: entity work.uvod_VGA_DRAW_0_0_VGA_DRAW
     port map (
      BTN_PRESS_VALID_IN => BTN_PRESS_VALID_IN,
      BUTTONS_IN(15 downto 0) => BUTTONS_IN(15 downto 0),
      B_OUT(0) => \^b_out\(2),
      CLK => CLK,
      G_OUT(0) => \^g_out\(2),
      R_OUT(0) => \^r_out\(2),
      X_IN(9 downto 0) => X_IN(9 downto 0),
      Y_IN(9 downto 0) => Y_IN(9 downto 0)
    );
end STRUCTURE;
