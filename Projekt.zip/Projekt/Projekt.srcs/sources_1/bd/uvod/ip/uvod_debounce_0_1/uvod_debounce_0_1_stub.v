// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2019.1 (win64) Build 2552052 Fri May 24 14:49:42 MDT 2019
// Date        : Tue Mar 17 23:09:42 2026
// Host        : DESKTOP-TPP71AQ running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               C:/workspace/PEV/uvod/uvod.srcs/sources_1/bd/uvod/ip/uvod_debounce_0_1/uvod_debounce_0_1_stub.v
// Design      : uvod_debounce_0_1
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7s25csga324-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "debounce,Vivado 2019.1" *)
module uvod_debounce_0_1(iw_clk, iw_button, ow_pressed)
/* synthesis syn_black_box black_box_pad_pin="iw_clk,iw_button,ow_pressed" */;
  input iw_clk;
  input iw_button;
  output ow_pressed;
endmodule
