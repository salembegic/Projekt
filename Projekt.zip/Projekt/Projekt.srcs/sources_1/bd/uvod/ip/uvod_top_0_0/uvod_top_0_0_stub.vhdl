-- Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2019.1 (win64) Build 2552052 Fri May 24 14:49:42 MDT 2019
-- Date        : Wed May  6 23:15:46 2026
-- Host        : DESKTOP-TPP71AQ running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               C:/workspace/PEV/uvod/uvod.srcs/sources_1/bd/uvod/ip/uvod_top_0_0/uvod_top_0_0_stub.vhdl
-- Design      : uvod_top_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7s25csga324-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity uvod_top_0_0 is
  Port ( 
    iw_clk : in STD_LOGIC;
    iw_btn0 : in STD_LOGIC;
    iw_btn1 : in STD_LOGIC;
    iw_btn2 : in STD_LOGIC;
    iw_btn3 : in STD_LOGIC;
    ow4_red : out STD_LOGIC_VECTOR ( 3 downto 0 );
    ow4_green : out STD_LOGIC_VECTOR ( 3 downto 0 );
    ow4_blue : out STD_LOGIC_VECTOR ( 3 downto 0 );
    ow4_result_left : out STD_LOGIC_VECTOR ( 3 downto 0 );
    ow4_result_right : out STD_LOGIC_VECTOR ( 3 downto 0 );
    ow11_x_pos : out STD_LOGIC_VECTOR ( 10 downto 0 );
    ow11_y_pos : out STD_LOGIC_VECTOR ( 10 downto 0 );
    ow11_block_left_pos : out STD_LOGIC_VECTOR ( 10 downto 0 );
    ow11_block_right_pos : out STD_LOGIC_VECTOR ( 10 downto 0 )
  );

end uvod_top_0_0;

architecture stub of uvod_top_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "iw_clk,iw_btn0,iw_btn1,iw_btn2,iw_btn3,ow4_red[3:0],ow4_green[3:0],ow4_blue[3:0],ow4_result_left[3:0],ow4_result_right[3:0],ow11_x_pos[10:0],ow11_y_pos[10:0],ow11_block_left_pos[10:0],ow11_block_right_pos[10:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "top,Vivado 2019.1";
begin
end;
