// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2019.1 (win64) Build 2552052 Fri May 24 14:49:42 MDT 2019
// Date        : Wed May  6 23:15:46 2026
// Host        : DESKTOP-TPP71AQ running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               C:/workspace/PEV/uvod/uvod.srcs/sources_1/bd/uvod/ip/uvod_top_0_0/uvod_top_0_0_stub.v
// Design      : uvod_top_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7s25csga324-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "top,Vivado 2019.1" *)
module uvod_top_0_0(iw_clk, iw_btn0, iw_btn1, iw_btn2, iw_btn3, 
  ow4_red, ow4_green, ow4_blue, ow4_result_left, ow4_result_right, ow11_x_pos, ow11_y_pos, 
  ow11_block_left_pos, ow11_block_right_pos)
/* synthesis syn_black_box black_box_pad_pin="iw_clk,iw_btn0,iw_btn1,iw_btn2,iw_btn3,ow4_red[3:0],ow4_green[3:0],ow4_blue[3:0],ow4_result_left[3:0],ow4_result_right[3:0],ow11_x_pos[10:0],ow11_y_pos[10:0],ow11_block_left_pos[10:0],ow11_block_right_pos[10:0]" */;
  input iw_clk;
  input iw_btn0;
  input iw_btn1;
  input iw_btn2;
  input iw_btn3;
  output [3:0]ow4_red;
  output [3:0]ow4_green;
  output [3:0]ow4_blue;
  output [3:0]ow4_result_left;
  output [3:0]ow4_result_right;
  output [10:0]ow11_x_pos;
  output [10:0]ow11_y_pos;
  output [10:0]ow11_block_left_pos;
  output [10:0]ow11_block_right_pos;
endmodule
