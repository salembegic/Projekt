`timescale 1ns / 1ps

module debounce(
    input wire iw_clk,
    input wire iw_button,
    output wire ow_pressed
    );

    localparam TIME_10ms = 120_000;

    reg r_pressed;
    reg[22:0] r23_counter;

    assign ow_pressed = r_pressed;

    initial begin 

        r_pressed <= 0;
        r23_counter <= 0;
    end 

    always @ ( posedge iw_clk ) begin 
        if ( r_pressed == 0 ) begin
            if ( iw_button == 1) begin
                r23_counter <= r23_counter+1;
                
                if( r23_counter >= TIME_10ms) begin 
                    r_pressed <= 1;
                    r23_counter <= 0;
                end 
            end
            else
                r23_counter <= 0;
        end
        else if( r_pressed == 1) begin 
            if(iw_button == 0) begin 
                r23_counter <= r23_counter + 1;
                if(r23_counter >= TIME_10ms) begin 
                    r_pressed <= 0;
                    r23_counter <= 0;
                end
            end
            else
                r23_counter <= 0;
        end
    end
endmodule
