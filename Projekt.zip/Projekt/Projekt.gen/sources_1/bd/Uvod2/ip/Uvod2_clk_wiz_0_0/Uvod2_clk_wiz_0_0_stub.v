// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
// Date        : Mon May 11 15:35:24 2026
// Host        : LRNV-INSTALL running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Users/vaje/Desktop/Salem/SalemPEV/11.5/PEV/Projekt/Projekt.gen/sources_1/bd/Uvod2/ip/Uvod2_clk_wiz_0_0/Uvod2_clk_wiz_0_0_stub.v
// Design      : Uvod2_clk_wiz_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7s25csga324-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CORE_GENERATION_INFO = "Uvod2_clk_wiz_0_0,clk_wiz_v6_0_16_0_0,{component_name=Uvod2_clk_wiz_0_0,use_phase_alignment=true,use_min_o_jitter=false,use_max_i_jitter=false,use_dyn_phase_shift=false,use_inclk_switchover=false,use_dyn_reconfig=false,enable_axi=0,feedback_source=FDBK_AUTO,PRIMITIVE=MMCM,num_out_clk=3,clkin1_period=83.333,clkin2_period=10.0,use_power_down=false,use_reset=false,use_locked=false,use_inclk_stopped=false,feedback_type=SINGLE,CLOCK_MGR_TYPE=NA,manual_override=false}" *) 
module Uvod2_clk_wiz_0_0(clk_200MHz, clk_40MHz, clk_out3, clk_in1)
/* synthesis syn_black_box black_box_pad_pin="clk_in1" */
/* synthesis syn_force_seq_prim="clk_200MHz" */
/* synthesis syn_force_seq_prim="clk_40MHz" */
/* synthesis syn_force_seq_prim="clk_out3" */;
  output clk_200MHz /* synthesis syn_isclock = 1 */;
  output clk_40MHz /* synthesis syn_isclock = 1 */;
  output clk_out3 /* synthesis syn_isclock = 1 */;
  input clk_in1;
endmodule
