-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
-- Date        : Mon May 11 15:35:25 2026
-- Host        : LRNV-INSTALL running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               c:/Users/vaje/Desktop/Salem/SalemPEV/11.5/PEV/Projekt/Projekt.gen/sources_1/bd/Uvod2/ip/Uvod2_BUTTON_MATRIX_0_0/Uvod2_BUTTON_MATRIX_0_0_stub.vhdl
-- Design      : Uvod2_BUTTON_MATRIX_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7s25csga324-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Uvod2_BUTTON_MATRIX_0_0 is
  Port ( 
    CLK_5M : in STD_LOGIC;
    CLK_40M : in STD_LOGIC;
    ROWS_IN : in STD_LOGIC_VECTOR ( 3 downto 0 );
    COLUMNS_OUT : out STD_LOGIC_VECTOR ( 3 downto 0 );
    BUTTONS_OUT : out STD_LOGIC_VECTOR ( 15 downto 0 );
    VALID_PRESS_OUT : out STD_LOGIC;
    VALID_RELEASE_OUT : out STD_LOGIC;
    TOP_BTN_0 : out STD_LOGIC;
    TOP_BTN_1 : out STD_LOGIC;
    TOP_BTN_2 : out STD_LOGIC;
    TOP_BTN_3 : out STD_LOGIC
  );

  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of Uvod2_BUTTON_MATRIX_0_0 : entity is "Uvod2_BUTTON_MATRIX_0_0,BUTTON_MATRIX,{}";
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of Uvod2_BUTTON_MATRIX_0_0 : entity is "Uvod2_BUTTON_MATRIX_0_0,BUTTON_MATRIX,{x_ipProduct=Vivado 2025.1,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=BUTTON_MATRIX,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED,G_ROW=4,G_CLK_DIV=64,G_DEBOUNCE_COUNTER_SIZE=16}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of Uvod2_BUTTON_MATRIX_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of Uvod2_BUTTON_MATRIX_0_0 : entity is "module_ref";
end Uvod2_BUTTON_MATRIX_0_0;

architecture stub of Uvod2_BUTTON_MATRIX_0_0 is
  attribute syn_black_box : boolean;
  attribute black_box_pad_pin : string;
  attribute syn_black_box of stub : architecture is true;
  attribute black_box_pad_pin of stub : architecture is "CLK_5M,CLK_40M,ROWS_IN[3:0],COLUMNS_OUT[3:0],BUTTONS_OUT[15:0],VALID_PRESS_OUT,VALID_RELEASE_OUT,TOP_BTN_0,TOP_BTN_1,TOP_BTN_2,TOP_BTN_3";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of stub : architecture is "BUTTON_MATRIX,Vivado 2025.1";
begin
end;
