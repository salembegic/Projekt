-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
-- Date        : Mon May 11 15:35:25 2026
-- Host        : LRNV-INSTALL running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/vaje/Desktop/Salem/SalemPEV/11.5/PEV/Projekt/Projekt.gen/sources_1/bd/Uvod2/ip/Uvod2_BUTTON_MATRIX_0_0/Uvod2_BUTTON_MATRIX_0_0_sim_netlist.vhdl
-- Design      : Uvod2_BUTTON_MATRIX_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7s25csga324-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity Uvod2_BUTTON_MATRIX_0_0_BUTTON_MATRIX is
  port (
    COLUMNS_OUT : out STD_LOGIC_VECTOR ( 3 downto 0 );
    VALID_PRESS_OUT : out STD_LOGIC;
    BUTTONS_OUT : out STD_LOGIC_VECTOR ( 15 downto 0 );
    VALID_RELEASE_OUT : out STD_LOGIC;
    ROWS_IN : in STD_LOGIC_VECTOR ( 3 downto 0 );
    CLK_40M : in STD_LOGIC;
    CLK_5M : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of Uvod2_BUTTON_MATRIX_0_0_BUTTON_MATRIX : entity is "BUTTON_MATRIX";
end Uvod2_BUTTON_MATRIX_0_0_BUTTON_MATRIX;

architecture STRUCTURE of Uvod2_BUTTON_MATRIX_0_0_BUTTON_MATRIX is
  signal BUTTONS_SIG : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal BUTTONS_SIG1 : STD_LOGIC;
  signal \BUTTONS_SIG[0]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG[10]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG[11]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG[12]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG[13]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG[14]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG[15]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG[1]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG[2]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG[3]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG[4]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG[5]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG[6]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG[7]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG[8]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG[9]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[0]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[0]_i_2_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[10]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[10]_i_2_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[11]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[11]_i_2_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[12]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[12]_i_2_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[13]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[13]_i_2_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[14]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[14]_i_2_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[15]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[15]_i_2_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[1]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[1]_i_2_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[2]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[2]_i_2_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[3]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[4]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[4]_i_2_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[5]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[5]_i_2_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[6]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[6]_i_2_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[7]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[8]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[8]_i_2_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[9]_i_1_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT[9]_i_2_n_0\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT_reg_n_0_[0]\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT_reg_n_0_[11]\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT_reg_n_0_[15]\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT_reg_n_0_[1]\ : STD_LOGIC;
  signal \BUTTONS_SIG_FILT_reg_n_0_[2]\ : STD_LOGIC;
  signal CLK_LOW_F : STD_LOGIC;
  signal CLK_LOW_F_i_1_n_0 : STD_LOGIC;
  signal \CNTR[0]_i_1_n_0\ : STD_LOGIC;
  signal \CNTR[2]_i_1_n_0\ : STD_LOGIC;
  signal CNTR_reg : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal DBNC_CNT : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal DBNC_CNT_reg_0_15_0_0_i_10_n_0 : STD_LOGIC;
  signal DBNC_CNT_reg_0_15_0_0_i_11_n_0 : STD_LOGIC;
  signal DBNC_CNT_reg_0_15_0_0_i_12_n_0 : STD_LOGIC;
  signal DBNC_CNT_reg_0_15_0_0_i_13_n_0 : STD_LOGIC;
  signal DBNC_CNT_reg_0_15_0_0_i_14_n_0 : STD_LOGIC;
  signal DBNC_CNT_reg_0_15_0_0_i_15_n_0 : STD_LOGIC;
  signal DBNC_CNT_reg_0_15_0_0_i_2_n_0 : STD_LOGIC;
  signal DBNC_CNT_reg_0_15_0_0_i_3_n_0 : STD_LOGIC;
  signal DBNC_CNT_reg_0_15_0_0_i_4_n_0 : STD_LOGIC;
  signal DBNC_CNT_reg_0_15_0_0_i_5_n_0 : STD_LOGIC;
  signal DBNC_CNT_reg_0_15_0_0_i_6_n_0 : STD_LOGIC;
  signal DBNC_CNT_reg_0_15_0_0_i_7_n_0 : STD_LOGIC;
  signal DBNC_CNT_reg_0_15_0_0_i_8_n_0 : STD_LOGIC;
  signal DBNC_CNT_reg_0_15_0_0_i_9_n_0 : STD_LOGIC;
  signal DBNC_CNT_reg_0_15_1_1_i_2_n_0 : STD_LOGIC;
  signal DBNC_CNT_reg_0_15_3_3_i_2_n_0 : STD_LOGIC;
  signal \LOW_F_CNT[0]_i_10_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[0]_i_11_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[0]_i_12_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[0]_i_1_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[0]_i_3_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[0]_i_4_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[0]_i_5_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[0]_i_6_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[0]_i_7_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[0]_i_8_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[0]_i_9_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[12]_i_2_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[12]_i_3_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[12]_i_4_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[12]_i_5_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[16]_i_2_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[16]_i_3_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[16]_i_4_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[16]_i_5_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[20]_i_2_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[20]_i_3_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[20]_i_4_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[20]_i_5_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[24]_i_2_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[24]_i_3_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[24]_i_4_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[24]_i_5_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[28]_i_2_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[28]_i_3_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[28]_i_4_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[28]_i_5_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[4]_i_2_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[4]_i_3_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[4]_i_4_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[4]_i_5_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[8]_i_2_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[8]_i_3_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[8]_i_4_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT[8]_i_5_n_0\ : STD_LOGIC;
  signal LOW_F_CNT_reg : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \LOW_F_CNT_reg[0]_i_2_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[0]_i_2_n_1\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[0]_i_2_n_2\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[0]_i_2_n_3\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[0]_i_2_n_4\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[0]_i_2_n_5\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[0]_i_2_n_6\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[0]_i_2_n_7\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[12]_i_1_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[12]_i_1_n_1\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[12]_i_1_n_2\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[12]_i_1_n_3\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[12]_i_1_n_4\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[12]_i_1_n_5\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[12]_i_1_n_6\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[12]_i_1_n_7\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[16]_i_1_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[16]_i_1_n_1\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[16]_i_1_n_2\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[16]_i_1_n_3\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[16]_i_1_n_4\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[16]_i_1_n_5\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[16]_i_1_n_6\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[16]_i_1_n_7\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[20]_i_1_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[20]_i_1_n_1\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[20]_i_1_n_2\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[20]_i_1_n_3\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[20]_i_1_n_4\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[20]_i_1_n_5\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[20]_i_1_n_6\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[20]_i_1_n_7\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[24]_i_1_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[24]_i_1_n_1\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[24]_i_1_n_2\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[24]_i_1_n_3\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[24]_i_1_n_4\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[24]_i_1_n_5\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[24]_i_1_n_6\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[24]_i_1_n_7\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[28]_i_1_n_1\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[28]_i_1_n_2\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[28]_i_1_n_3\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[28]_i_1_n_4\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[28]_i_1_n_5\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[28]_i_1_n_6\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[28]_i_1_n_7\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[4]_i_1_n_1\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[4]_i_1_n_2\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[4]_i_1_n_3\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[4]_i_1_n_4\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[4]_i_1_n_5\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[4]_i_1_n_6\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[4]_i_1_n_7\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[8]_i_1_n_0\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[8]_i_1_n_1\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[8]_i_1_n_2\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[8]_i_1_n_3\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[8]_i_1_n_4\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[8]_i_1_n_5\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[8]_i_1_n_6\ : STD_LOGIC;
  signal \LOW_F_CNT_reg[8]_i_1_n_7\ : STD_LOGIC;
  signal ROWS_FF1 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal ROWS_FF2 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \S_COLUMNS[0]_i_1_n_0\ : STD_LOGIC;
  signal \S_COLUMNS[1]_i_1_n_0\ : STD_LOGIC;
  signal \S_COLUMNS[2]_i_1_n_0\ : STD_LOGIC;
  signal \S_COLUMNS[3]_i_1_n_0\ : STD_LOGIC;
  signal VALID : STD_LOGIC;
  signal VALID_FF : STD_LOGIC;
  signal VALID_RELEASE_OUT0 : STD_LOGIC;
  signal VALID_RELEASE_OUT_i_1_n_0 : STD_LOGIC;
  signal VALID_i_1_n_0 : STD_LOGIC;
  signal clear : STD_LOGIC;
  signal p_0_in : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal p_0_in_0 : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal p_0_out : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal p_1_in : STD_LOGIC;
  signal p_2_in : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal p_3_in : STD_LOGIC;
  signal p_4_in : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_LOW_F_CNT_reg[28]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \BUTTONS_OUT[0]_INST_0\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \BUTTONS_OUT[10]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \BUTTONS_OUT[2]_INST_0\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \BUTTONS_OUT[5]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \BUTTONS_OUT[6]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \BUTTONS_OUT[8]_INST_0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \BUTTONS_OUT[9]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[0]_i_2\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[10]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[10]_i_2\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[11]_i_2\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[12]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[12]_i_2\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[13]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[13]_i_2\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[14]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[14]_i_2\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[15]_i_2\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[1]_i_2\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[2]_i_2\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[4]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[4]_i_2\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[5]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[5]_i_2\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[6]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[6]_i_2\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[8]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[8]_i_2\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[9]_i_1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \BUTTONS_SIG_FILT[9]_i_2\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \CNTR[1]_i_1\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \CNTR[2]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \CNTR[3]_i_2\ : label is "soft_lutpair10";
  attribute RTL_RAM_BITS : integer;
  attribute RTL_RAM_BITS of DBNC_CNT_reg_0_15_0_0 : label is 80;
  attribute RTL_RAM_NAME : string;
  attribute RTL_RAM_NAME of DBNC_CNT_reg_0_15_0_0 : label is "Uvod2_BUTTON_MATRIX_0_0/inst/DBNC_CNT_reg";
  attribute RTL_RAM_STYLE : string;
  attribute RTL_RAM_STYLE of DBNC_CNT_reg_0_15_0_0 : label is "auto";
  attribute RTL_RAM_TYPE : string;
  attribute RTL_RAM_TYPE of DBNC_CNT_reg_0_15_0_0 : label is "RAM_SP";
  attribute XILINX_LEGACY_PRIM : string;
  attribute XILINX_LEGACY_PRIM of DBNC_CNT_reg_0_15_0_0 : label is "RAM16X1S";
  attribute XILINX_TRANSFORM_PINMAP : string;
  attribute XILINX_TRANSFORM_PINMAP of DBNC_CNT_reg_0_15_0_0 : label is "GND:A4";
  attribute ram_addr_begin : integer;
  attribute ram_addr_begin of DBNC_CNT_reg_0_15_0_0 : label is 0;
  attribute ram_addr_end : integer;
  attribute ram_addr_end of DBNC_CNT_reg_0_15_0_0 : label is 15;
  attribute ram_offset : integer;
  attribute ram_offset of DBNC_CNT_reg_0_15_0_0 : label is 0;
  attribute ram_slice_begin : integer;
  attribute ram_slice_begin of DBNC_CNT_reg_0_15_0_0 : label is 0;
  attribute ram_slice_end : integer;
  attribute ram_slice_end of DBNC_CNT_reg_0_15_0_0 : label is 0;
  attribute SOFT_HLUTNM of DBNC_CNT_reg_0_15_0_0_i_5 : label is "soft_lutpair9";
  attribute RTL_RAM_BITS of DBNC_CNT_reg_0_15_1_1 : label is 80;
  attribute RTL_RAM_NAME of DBNC_CNT_reg_0_15_1_1 : label is "Uvod2_BUTTON_MATRIX_0_0/inst/DBNC_CNT_reg";
  attribute RTL_RAM_STYLE of DBNC_CNT_reg_0_15_1_1 : label is "auto";
  attribute RTL_RAM_TYPE of DBNC_CNT_reg_0_15_1_1 : label is "RAM_SP";
  attribute XILINX_LEGACY_PRIM of DBNC_CNT_reg_0_15_1_1 : label is "RAM16X1S";
  attribute XILINX_TRANSFORM_PINMAP of DBNC_CNT_reg_0_15_1_1 : label is "GND:A4";
  attribute ram_addr_begin of DBNC_CNT_reg_0_15_1_1 : label is 0;
  attribute ram_addr_end of DBNC_CNT_reg_0_15_1_1 : label is 15;
  attribute ram_offset of DBNC_CNT_reg_0_15_1_1 : label is 0;
  attribute ram_slice_begin of DBNC_CNT_reg_0_15_1_1 : label is 1;
  attribute ram_slice_end of DBNC_CNT_reg_0_15_1_1 : label is 1;
  attribute RTL_RAM_BITS of DBNC_CNT_reg_0_15_2_2 : label is 80;
  attribute RTL_RAM_NAME of DBNC_CNT_reg_0_15_2_2 : label is "Uvod2_BUTTON_MATRIX_0_0/inst/DBNC_CNT_reg";
  attribute RTL_RAM_STYLE of DBNC_CNT_reg_0_15_2_2 : label is "auto";
  attribute RTL_RAM_TYPE of DBNC_CNT_reg_0_15_2_2 : label is "RAM_SP";
  attribute XILINX_LEGACY_PRIM of DBNC_CNT_reg_0_15_2_2 : label is "RAM16X1S";
  attribute XILINX_TRANSFORM_PINMAP of DBNC_CNT_reg_0_15_2_2 : label is "GND:A4";
  attribute ram_addr_begin of DBNC_CNT_reg_0_15_2_2 : label is 0;
  attribute ram_addr_end of DBNC_CNT_reg_0_15_2_2 : label is 15;
  attribute ram_offset of DBNC_CNT_reg_0_15_2_2 : label is 0;
  attribute ram_slice_begin of DBNC_CNT_reg_0_15_2_2 : label is 2;
  attribute ram_slice_end of DBNC_CNT_reg_0_15_2_2 : label is 2;
  attribute RTL_RAM_BITS of DBNC_CNT_reg_0_15_3_3 : label is 80;
  attribute RTL_RAM_NAME of DBNC_CNT_reg_0_15_3_3 : label is "Uvod2_BUTTON_MATRIX_0_0/inst/DBNC_CNT_reg";
  attribute RTL_RAM_STYLE of DBNC_CNT_reg_0_15_3_3 : label is "auto";
  attribute RTL_RAM_TYPE of DBNC_CNT_reg_0_15_3_3 : label is "RAM_SP";
  attribute XILINX_LEGACY_PRIM of DBNC_CNT_reg_0_15_3_3 : label is "RAM16X1S";
  attribute XILINX_TRANSFORM_PINMAP of DBNC_CNT_reg_0_15_3_3 : label is "GND:A4";
  attribute ram_addr_begin of DBNC_CNT_reg_0_15_3_3 : label is 0;
  attribute ram_addr_end of DBNC_CNT_reg_0_15_3_3 : label is 15;
  attribute ram_offset of DBNC_CNT_reg_0_15_3_3 : label is 0;
  attribute ram_slice_begin of DBNC_CNT_reg_0_15_3_3 : label is 3;
  attribute ram_slice_end of DBNC_CNT_reg_0_15_3_3 : label is 3;
  attribute SOFT_HLUTNM of DBNC_CNT_reg_0_15_3_3_i_2 : label is "soft_lutpair9";
  attribute RTL_RAM_BITS of DBNC_CNT_reg_0_15_4_4 : label is 80;
  attribute RTL_RAM_NAME of DBNC_CNT_reg_0_15_4_4 : label is "Uvod2_BUTTON_MATRIX_0_0/inst/DBNC_CNT_reg";
  attribute RTL_RAM_STYLE of DBNC_CNT_reg_0_15_4_4 : label is "auto";
  attribute RTL_RAM_TYPE of DBNC_CNT_reg_0_15_4_4 : label is "RAM_SP";
  attribute XILINX_LEGACY_PRIM of DBNC_CNT_reg_0_15_4_4 : label is "RAM16X1S";
  attribute XILINX_TRANSFORM_PINMAP of DBNC_CNT_reg_0_15_4_4 : label is "GND:A4";
  attribute ram_addr_begin of DBNC_CNT_reg_0_15_4_4 : label is 0;
  attribute ram_addr_end of DBNC_CNT_reg_0_15_4_4 : label is 15;
  attribute ram_offset of DBNC_CNT_reg_0_15_4_4 : label is 0;
  attribute ram_slice_begin of DBNC_CNT_reg_0_15_4_4 : label is 4;
  attribute ram_slice_end of DBNC_CNT_reg_0_15_4_4 : label is 4;
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \LOW_F_CNT_reg[0]_i_2\ : label is 11;
  attribute ADDER_THRESHOLD of \LOW_F_CNT_reg[12]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \LOW_F_CNT_reg[16]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \LOW_F_CNT_reg[20]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \LOW_F_CNT_reg[24]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \LOW_F_CNT_reg[28]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \LOW_F_CNT_reg[4]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \LOW_F_CNT_reg[8]_i_1\ : label is 11;
  attribute SOFT_HLUTNM of \S_COLUMNS[0]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \S_COLUMNS[1]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \S_COLUMNS[2]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of TOP_BTN_0_INST_0 : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of TOP_BTN_1_INST_0 : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of VALID_PRESS_OUT_i_1 : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of VALID_RELEASE_OUT_i_1 : label is "soft_lutpair20";
begin
\BUTTONS_OUT[0]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => p_0_in_0(0),
      O => BUTTONS_OUT(0)
    );
\BUTTONS_OUT[10]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => p_4_in(2),
      O => BUTTONS_OUT(10)
    );
\BUTTONS_OUT[12]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \BUTTONS_SIG_FILT_reg_n_0_[0]\,
      O => BUTTONS_OUT(12)
    );
\BUTTONS_OUT[13]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \BUTTONS_SIG_FILT_reg_n_0_[1]\,
      O => BUTTONS_OUT(13)
    );
\BUTTONS_OUT[15]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \BUTTONS_SIG_FILT_reg_n_0_[15]\,
      O => BUTTONS_OUT(15)
    );
\BUTTONS_OUT[2]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => p_0_in_0(2),
      O => BUTTONS_OUT(2)
    );
\BUTTONS_OUT[3]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => p_1_in,
      O => BUTTONS_OUT(3)
    );
\BUTTONS_OUT[5]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => p_2_in(1),
      O => BUTTONS_OUT(5)
    );
\BUTTONS_OUT[6]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => p_2_in(2),
      O => BUTTONS_OUT(6)
    );
\BUTTONS_OUT[7]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => p_3_in,
      O => BUTTONS_OUT(7)
    );
\BUTTONS_OUT[8]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => p_4_in(0),
      O => BUTTONS_OUT(8)
    );
\BUTTONS_OUT[9]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => p_4_in(1),
      O => BUTTONS_OUT(9)
    );
\BUTTONS_SIG[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000002"
    )
        port map (
      I0 => BUTTONS_SIG1,
      I1 => CNTR_reg(2),
      I2 => CNTR_reg(3),
      I3 => CNTR_reg(0),
      I4 => CNTR_reg(1),
      I5 => BUTTONS_SIG(0),
      O => \BUTTONS_SIG[0]_i_1_n_0\
    );
\BUTTONS_SIG[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFBFF00000800"
    )
        port map (
      I0 => BUTTONS_SIG1,
      I1 => CNTR_reg(3),
      I2 => CNTR_reg(2),
      I3 => CNTR_reg(1),
      I4 => CNTR_reg(0),
      I5 => BUTTONS_SIG(10),
      O => \BUTTONS_SIG[10]_i_1_n_0\
    );
\BUTTONS_SIG[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FBFFFFFF08000000"
    )
        port map (
      I0 => BUTTONS_SIG1,
      I1 => CNTR_reg(3),
      I2 => CNTR_reg(2),
      I3 => CNTR_reg(0),
      I4 => CNTR_reg(1),
      I5 => BUTTONS_SIG(11),
      O => \BUTTONS_SIG[11]_i_1_n_0\
    );
\BUTTONS_SIG[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFBF00000080"
    )
        port map (
      I0 => BUTTONS_SIG1,
      I1 => CNTR_reg(2),
      I2 => CNTR_reg(3),
      I3 => CNTR_reg(0),
      I4 => CNTR_reg(1),
      I5 => BUTTONS_SIG(12),
      O => \BUTTONS_SIG[12]_i_1_n_0\
    );
\BUTTONS_SIG[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFBFFF00008000"
    )
        port map (
      I0 => BUTTONS_SIG1,
      I1 => CNTR_reg(2),
      I2 => CNTR_reg(3),
      I3 => CNTR_reg(0),
      I4 => CNTR_reg(1),
      I5 => BUTTONS_SIG(13),
      O => \BUTTONS_SIG[13]_i_1_n_0\
    );
\BUTTONS_SIG[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFBFFF00008000"
    )
        port map (
      I0 => BUTTONS_SIG1,
      I1 => CNTR_reg(2),
      I2 => CNTR_reg(3),
      I3 => CNTR_reg(1),
      I4 => CNTR_reg(0),
      I5 => BUTTONS_SIG(14),
      O => \BUTTONS_SIG[14]_i_1_n_0\
    );
\BUTTONS_SIG[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BFFFFFFF80000000"
    )
        port map (
      I0 => BUTTONS_SIG1,
      I1 => CNTR_reg(2),
      I2 => CNTR_reg(3),
      I3 => CNTR_reg(0),
      I4 => CNTR_reg(1),
      I5 => BUTTONS_SIG(15),
      O => \BUTTONS_SIG[15]_i_1_n_0\
    );
\BUTTONS_SIG[15]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AACCAACCF0FFF000"
    )
        port map (
      I0 => ROWS_FF2(3),
      I1 => ROWS_FF2(2),
      I2 => ROWS_FF2(1),
      I3 => CNTR_reg(0),
      I4 => ROWS_FF2(0),
      I5 => CNTR_reg(1),
      O => BUTTONS_SIG1
    );
\BUTTONS_SIG[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEFF00000200"
    )
        port map (
      I0 => BUTTONS_SIG1,
      I1 => CNTR_reg(2),
      I2 => CNTR_reg(3),
      I3 => CNTR_reg(0),
      I4 => CNTR_reg(1),
      I5 => BUTTONS_SIG(1),
      O => \BUTTONS_SIG[1]_i_1_n_0\
    );
\BUTTONS_SIG[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEFF00000200"
    )
        port map (
      I0 => BUTTONS_SIG1,
      I1 => CNTR_reg(2),
      I2 => CNTR_reg(3),
      I3 => CNTR_reg(1),
      I4 => CNTR_reg(0),
      I5 => BUTTONS_SIG(2),
      O => \BUTTONS_SIG[2]_i_1_n_0\
    );
\BUTTONS_SIG[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEFFFFFF02000000"
    )
        port map (
      I0 => BUTTONS_SIG1,
      I1 => CNTR_reg(2),
      I2 => CNTR_reg(3),
      I3 => CNTR_reg(0),
      I4 => CNTR_reg(1),
      I5 => BUTTONS_SIG(3),
      O => \BUTTONS_SIG[3]_i_1_n_0\
    );
\BUTTONS_SIG[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFB00000008"
    )
        port map (
      I0 => BUTTONS_SIG1,
      I1 => CNTR_reg(2),
      I2 => CNTR_reg(3),
      I3 => CNTR_reg(0),
      I4 => CNTR_reg(1),
      I5 => BUTTONS_SIG(4),
      O => \BUTTONS_SIG[4]_i_1_n_0\
    );
\BUTTONS_SIG[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFBFF00000800"
    )
        port map (
      I0 => BUTTONS_SIG1,
      I1 => CNTR_reg(2),
      I2 => CNTR_reg(3),
      I3 => CNTR_reg(0),
      I4 => CNTR_reg(1),
      I5 => BUTTONS_SIG(5),
      O => \BUTTONS_SIG[5]_i_1_n_0\
    );
\BUTTONS_SIG[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFBFF00000800"
    )
        port map (
      I0 => BUTTONS_SIG1,
      I1 => CNTR_reg(2),
      I2 => CNTR_reg(3),
      I3 => CNTR_reg(1),
      I4 => CNTR_reg(0),
      I5 => BUTTONS_SIG(6),
      O => \BUTTONS_SIG[6]_i_1_n_0\
    );
\BUTTONS_SIG[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FBFFFFFF08000000"
    )
        port map (
      I0 => BUTTONS_SIG1,
      I1 => CNTR_reg(2),
      I2 => CNTR_reg(3),
      I3 => CNTR_reg(0),
      I4 => CNTR_reg(1),
      I5 => BUTTONS_SIG(7),
      O => \BUTTONS_SIG[7]_i_1_n_0\
    );
\BUTTONS_SIG[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFB00000008"
    )
        port map (
      I0 => BUTTONS_SIG1,
      I1 => CNTR_reg(3),
      I2 => CNTR_reg(2),
      I3 => CNTR_reg(0),
      I4 => CNTR_reg(1),
      I5 => BUTTONS_SIG(8),
      O => \BUTTONS_SIG[8]_i_1_n_0\
    );
\BUTTONS_SIG[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFBFF00000800"
    )
        port map (
      I0 => BUTTONS_SIG1,
      I1 => CNTR_reg(3),
      I2 => CNTR_reg(2),
      I3 => CNTR_reg(0),
      I4 => CNTR_reg(1),
      I5 => BUTTONS_SIG(9),
      O => \BUTTONS_SIG[9]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFB00000002"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      I3 => \S_COLUMNS[0]_i_1_n_0\,
      I4 => \BUTTONS_SIG_FILT[0]_i_2_n_0\,
      I5 => \BUTTONS_SIG_FILT_reg_n_0_[0]\,
      O => \BUTTONS_SIG_FILT[0]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[0]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => CNTR_reg(1),
      I1 => CNTR_reg(0),
      O => \BUTTONS_SIG_FILT[0]_i_2_n_0\
    );
\BUTTONS_SIG_FILT[10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBFF0200"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      I3 => \BUTTONS_SIG_FILT[10]_i_2_n_0\,
      I4 => p_2_in(2),
      O => \BUTTONS_SIG_FILT[10]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[10]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0020"
    )
        port map (
      I0 => CNTR_reg(3),
      I1 => CNTR_reg(2),
      I2 => CNTR_reg(1),
      I3 => CNTR_reg(0),
      O => \BUTTONS_SIG_FILT[10]_i_2_n_0\
    );
\BUTTONS_SIG_FILT[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFB00000002"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      I3 => \BUTTONS_SIG_FILT[11]_i_2_n_0\,
      I4 => \BUTTONS_SIG_FILT[15]_i_2_n_0\,
      I5 => \BUTTONS_SIG_FILT_reg_n_0_[11]\,
      O => \BUTTONS_SIG_FILT[11]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[11]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => CNTR_reg(2),
      I1 => CNTR_reg(3),
      O => \BUTTONS_SIG_FILT[11]_i_2_n_0\
    );
\BUTTONS_SIG_FILT[12]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBFF0200"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      I3 => \BUTTONS_SIG_FILT[12]_i_2_n_0\,
      I4 => p_4_in(0),
      O => \BUTTONS_SIG_FILT[12]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[12]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0008"
    )
        port map (
      I0 => CNTR_reg(2),
      I1 => CNTR_reg(3),
      I2 => CNTR_reg(0),
      I3 => CNTR_reg(1),
      O => \BUTTONS_SIG_FILT[12]_i_2_n_0\
    );
\BUTTONS_SIG_FILT[13]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBFF0200"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      I3 => \BUTTONS_SIG_FILT[13]_i_2_n_0\,
      I4 => p_4_in(1),
      O => \BUTTONS_SIG_FILT[13]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[13]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => CNTR_reg(2),
      I1 => CNTR_reg(3),
      I2 => CNTR_reg(0),
      I3 => CNTR_reg(1),
      O => \BUTTONS_SIG_FILT[13]_i_2_n_0\
    );
\BUTTONS_SIG_FILT[14]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBFF0200"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      I3 => \BUTTONS_SIG_FILT[14]_i_2_n_0\,
      I4 => p_4_in(2),
      O => \BUTTONS_SIG_FILT[14]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[14]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => CNTR_reg(2),
      I1 => CNTR_reg(3),
      I2 => CNTR_reg(1),
      I3 => CNTR_reg(0),
      O => \BUTTONS_SIG_FILT[14]_i_2_n_0\
    );
\BUTTONS_SIG_FILT[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFB00000002"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      I3 => \S_COLUMNS[3]_i_1_n_0\,
      I4 => \BUTTONS_SIG_FILT[15]_i_2_n_0\,
      I5 => \BUTTONS_SIG_FILT_reg_n_0_[15]\,
      O => \BUTTONS_SIG_FILT[15]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[15]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => CNTR_reg(1),
      I1 => CNTR_reg(0),
      O => \BUTTONS_SIG_FILT[15]_i_2_n_0\
    );
\BUTTONS_SIG_FILT[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFB00000002"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      I3 => \S_COLUMNS[0]_i_1_n_0\,
      I4 => \BUTTONS_SIG_FILT[1]_i_2_n_0\,
      I5 => \BUTTONS_SIG_FILT_reg_n_0_[1]\,
      O => \BUTTONS_SIG_FILT[1]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[1]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => CNTR_reg(1),
      I1 => CNTR_reg(0),
      O => \BUTTONS_SIG_FILT[1]_i_2_n_0\
    );
\BUTTONS_SIG_FILT[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFB00000002"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      I3 => \S_COLUMNS[0]_i_1_n_0\,
      I4 => \BUTTONS_SIG_FILT[2]_i_2_n_0\,
      I5 => \BUTTONS_SIG_FILT_reg_n_0_[2]\,
      O => \BUTTONS_SIG_FILT[2]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[2]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => CNTR_reg(0),
      I1 => CNTR_reg(1),
      O => \BUTTONS_SIG_FILT[2]_i_2_n_0\
    );
\BUTTONS_SIG_FILT[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFB00000002"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      I3 => \S_COLUMNS[0]_i_1_n_0\,
      I4 => \BUTTONS_SIG_FILT[15]_i_2_n_0\,
      I5 => p_1_in,
      O => \BUTTONS_SIG_FILT[3]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBFF0200"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      I3 => \BUTTONS_SIG_FILT[4]_i_2_n_0\,
      I4 => p_0_in_0(0),
      O => \BUTTONS_SIG_FILT[4]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[4]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0002"
    )
        port map (
      I0 => CNTR_reg(2),
      I1 => CNTR_reg(3),
      I2 => CNTR_reg(0),
      I3 => CNTR_reg(1),
      O => \BUTTONS_SIG_FILT[4]_i_2_n_0\
    );
\BUTTONS_SIG_FILT[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBFF0200"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      I3 => \BUTTONS_SIG_FILT[5]_i_2_n_0\,
      I4 => p_0_in_0(1),
      O => \BUTTONS_SIG_FILT[5]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[5]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0020"
    )
        port map (
      I0 => CNTR_reg(2),
      I1 => CNTR_reg(3),
      I2 => CNTR_reg(0),
      I3 => CNTR_reg(1),
      O => \BUTTONS_SIG_FILT[5]_i_2_n_0\
    );
\BUTTONS_SIG_FILT[6]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBFF0200"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      I3 => \BUTTONS_SIG_FILT[6]_i_2_n_0\,
      I4 => p_0_in_0(2),
      O => \BUTTONS_SIG_FILT[6]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[6]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0020"
    )
        port map (
      I0 => CNTR_reg(2),
      I1 => CNTR_reg(3),
      I2 => CNTR_reg(1),
      I3 => CNTR_reg(0),
      O => \BUTTONS_SIG_FILT[6]_i_2_n_0\
    );
\BUTTONS_SIG_FILT[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFB00000002"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      I3 => \S_COLUMNS[1]_i_1_n_0\,
      I4 => \BUTTONS_SIG_FILT[15]_i_2_n_0\,
      I5 => p_3_in,
      O => \BUTTONS_SIG_FILT[7]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBFF0200"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      I3 => \BUTTONS_SIG_FILT[8]_i_2_n_0\,
      I4 => p_2_in(0),
      O => \BUTTONS_SIG_FILT[8]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[8]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0002"
    )
        port map (
      I0 => CNTR_reg(3),
      I1 => CNTR_reg(2),
      I2 => CNTR_reg(0),
      I3 => CNTR_reg(1),
      O => \BUTTONS_SIG_FILT[8]_i_2_n_0\
    );
\BUTTONS_SIG_FILT[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBFF0200"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      I3 => \BUTTONS_SIG_FILT[9]_i_2_n_0\,
      I4 => p_2_in(1),
      O => \BUTTONS_SIG_FILT[9]_i_1_n_0\
    );
\BUTTONS_SIG_FILT[9]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0020"
    )
        port map (
      I0 => CNTR_reg(3),
      I1 => CNTR_reg(2),
      I2 => CNTR_reg(0),
      I3 => CNTR_reg(1),
      O => \BUTTONS_SIG_FILT[9]_i_2_n_0\
    );
\BUTTONS_SIG_FILT_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG_FILT[0]_i_1_n_0\,
      Q => \BUTTONS_SIG_FILT_reg_n_0_[0]\,
      R => '0'
    );
\BUTTONS_SIG_FILT_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG_FILT[10]_i_1_n_0\,
      Q => p_2_in(2),
      R => '0'
    );
\BUTTONS_SIG_FILT_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG_FILT[11]_i_1_n_0\,
      Q => \BUTTONS_SIG_FILT_reg_n_0_[11]\,
      R => '0'
    );
\BUTTONS_SIG_FILT_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG_FILT[12]_i_1_n_0\,
      Q => p_4_in(0),
      R => '0'
    );
\BUTTONS_SIG_FILT_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG_FILT[13]_i_1_n_0\,
      Q => p_4_in(1),
      R => '0'
    );
\BUTTONS_SIG_FILT_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG_FILT[14]_i_1_n_0\,
      Q => p_4_in(2),
      R => '0'
    );
\BUTTONS_SIG_FILT_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG_FILT[15]_i_1_n_0\,
      Q => \BUTTONS_SIG_FILT_reg_n_0_[15]\,
      R => '0'
    );
\BUTTONS_SIG_FILT_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG_FILT[1]_i_1_n_0\,
      Q => \BUTTONS_SIG_FILT_reg_n_0_[1]\,
      R => '0'
    );
\BUTTONS_SIG_FILT_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG_FILT[2]_i_1_n_0\,
      Q => \BUTTONS_SIG_FILT_reg_n_0_[2]\,
      R => '0'
    );
\BUTTONS_SIG_FILT_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG_FILT[3]_i_1_n_0\,
      Q => p_1_in,
      R => '0'
    );
\BUTTONS_SIG_FILT_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG_FILT[4]_i_1_n_0\,
      Q => p_0_in_0(0),
      R => '0'
    );
\BUTTONS_SIG_FILT_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG_FILT[5]_i_1_n_0\,
      Q => p_0_in_0(1),
      R => '0'
    );
\BUTTONS_SIG_FILT_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG_FILT[6]_i_1_n_0\,
      Q => p_0_in_0(2),
      R => '0'
    );
\BUTTONS_SIG_FILT_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG_FILT[7]_i_1_n_0\,
      Q => p_3_in,
      R => '0'
    );
\BUTTONS_SIG_FILT_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG_FILT[8]_i_1_n_0\,
      Q => p_2_in(0),
      R => '0'
    );
\BUTTONS_SIG_FILT_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG_FILT[9]_i_1_n_0\,
      Q => p_2_in(1),
      R => '0'
    );
\BUTTONS_SIG_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG[0]_i_1_n_0\,
      Q => BUTTONS_SIG(0),
      R => '0'
    );
\BUTTONS_SIG_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG[10]_i_1_n_0\,
      Q => BUTTONS_SIG(10),
      R => '0'
    );
\BUTTONS_SIG_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG[11]_i_1_n_0\,
      Q => BUTTONS_SIG(11),
      R => '0'
    );
\BUTTONS_SIG_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG[12]_i_1_n_0\,
      Q => BUTTONS_SIG(12),
      R => '0'
    );
\BUTTONS_SIG_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG[13]_i_1_n_0\,
      Q => BUTTONS_SIG(13),
      R => '0'
    );
\BUTTONS_SIG_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG[14]_i_1_n_0\,
      Q => BUTTONS_SIG(14),
      R => '0'
    );
\BUTTONS_SIG_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG[15]_i_1_n_0\,
      Q => BUTTONS_SIG(15),
      R => '0'
    );
\BUTTONS_SIG_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG[1]_i_1_n_0\,
      Q => BUTTONS_SIG(1),
      R => '0'
    );
\BUTTONS_SIG_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG[2]_i_1_n_0\,
      Q => BUTTONS_SIG(2),
      R => '0'
    );
\BUTTONS_SIG_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG[3]_i_1_n_0\,
      Q => BUTTONS_SIG(3),
      R => '0'
    );
\BUTTONS_SIG_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG[4]_i_1_n_0\,
      Q => BUTTONS_SIG(4),
      R => '0'
    );
\BUTTONS_SIG_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG[5]_i_1_n_0\,
      Q => BUTTONS_SIG(5),
      R => '0'
    );
\BUTTONS_SIG_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG[6]_i_1_n_0\,
      Q => BUTTONS_SIG(6),
      R => '0'
    );
\BUTTONS_SIG_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG[7]_i_1_n_0\,
      Q => BUTTONS_SIG(7),
      R => '0'
    );
\BUTTONS_SIG_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG[8]_i_1_n_0\,
      Q => BUTTONS_SIG(8),
      R => '0'
    );
\BUTTONS_SIG_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \BUTTONS_SIG[9]_i_1_n_0\,
      Q => BUTTONS_SIG(9),
      R => '0'
    );
CLK_LOW_F_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \LOW_F_CNT[0]_i_1_n_0\,
      I1 => CLK_LOW_F,
      O => CLK_LOW_F_i_1_n_0
    );
CLK_LOW_F_reg: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => CLK_LOW_F_i_1_n_0,
      Q => CLK_LOW_F,
      R => '0'
    );
\CNTR[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => CNTR_reg(0),
      O => \CNTR[0]_i_1_n_0\
    );
\CNTR[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => CNTR_reg(0),
      I1 => CNTR_reg(1),
      O => p_0_in(1)
    );
\CNTR[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => CNTR_reg(0),
      I1 => CNTR_reg(1),
      I2 => CNTR_reg(2),
      O => \CNTR[2]_i_1_n_0\
    );
\CNTR[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => CNTR_reg(2),
      I1 => CNTR_reg(3),
      I2 => CNTR_reg(1),
      I3 => CNTR_reg(0),
      O => clear
    );
\CNTR[3]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => CNTR_reg(1),
      I1 => CNTR_reg(0),
      I2 => CNTR_reg(2),
      I3 => CNTR_reg(3),
      O => p_0_in(3)
    );
\CNTR_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \CNTR[0]_i_1_n_0\,
      Q => CNTR_reg(0),
      R => clear
    );
\CNTR_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => p_0_in(1),
      Q => CNTR_reg(1),
      R => clear
    );
\CNTR_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \CNTR[2]_i_1_n_0\,
      Q => CNTR_reg(2),
      R => clear
    );
\CNTR_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_LOW_F,
      CE => '1',
      D => p_0_in(3),
      Q => CNTR_reg(3),
      R => clear
    );
DBNC_CNT_reg_0_15_0_0: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => CNTR_reg(0),
      A1 => CNTR_reg(1),
      A2 => CNTR_reg(2),
      A3 => CNTR_reg(3),
      A4 => '0',
      D => DBNC_CNT(0),
      O => p_0_out(0),
      WCLK => CLK_LOW_F,
      WE => '1'
    );
DBNC_CNT_reg_0_15_0_0_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000047B800000000"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_0_0_i_2_n_0,
      I1 => CNTR_reg(3),
      I2 => DBNC_CNT_reg_0_15_0_0_i_3_n_0,
      I3 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I4 => p_0_out(0),
      I5 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      O => DBNC_CNT(0)
    );
DBNC_CNT_reg_0_15_0_0_i_10: unisim.vcomponents.MUXF7
     port map (
      I0 => DBNC_CNT_reg_0_15_0_0_i_12_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_13_n_0,
      O => DBNC_CNT_reg_0_15_0_0_i_10_n_0,
      S => CNTR_reg(2)
    );
DBNC_CNT_reg_0_15_0_0_i_11: unisim.vcomponents.MUXF7
     port map (
      I0 => DBNC_CNT_reg_0_15_0_0_i_14_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_15_n_0,
      O => DBNC_CNT_reg_0_15_0_0_i_11_n_0,
      S => CNTR_reg(2)
    );
DBNC_CNT_reg_0_15_0_0_i_12: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => p_1_in,
      I1 => \BUTTONS_SIG_FILT_reg_n_0_[2]\,
      I2 => CNTR_reg(1),
      I3 => \BUTTONS_SIG_FILT_reg_n_0_[1]\,
      I4 => CNTR_reg(0),
      I5 => \BUTTONS_SIG_FILT_reg_n_0_[0]\,
      O => DBNC_CNT_reg_0_15_0_0_i_12_n_0
    );
DBNC_CNT_reg_0_15_0_0_i_13: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => p_3_in,
      I1 => p_0_in_0(2),
      I2 => CNTR_reg(1),
      I3 => p_0_in_0(1),
      I4 => CNTR_reg(0),
      I5 => p_0_in_0(0),
      O => DBNC_CNT_reg_0_15_0_0_i_13_n_0
    );
DBNC_CNT_reg_0_15_0_0_i_14: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \BUTTONS_SIG_FILT_reg_n_0_[11]\,
      I1 => p_2_in(2),
      I2 => CNTR_reg(1),
      I3 => p_2_in(1),
      I4 => CNTR_reg(0),
      I5 => p_2_in(0),
      O => DBNC_CNT_reg_0_15_0_0_i_14_n_0
    );
DBNC_CNT_reg_0_15_0_0_i_15: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \BUTTONS_SIG_FILT_reg_n_0_[15]\,
      I1 => p_4_in(2),
      I2 => CNTR_reg(1),
      I3 => p_4_in(1),
      I4 => CNTR_reg(0),
      I5 => p_4_in(0),
      O => DBNC_CNT_reg_0_15_0_0_i_15_n_0
    );
DBNC_CNT_reg_0_15_0_0_i_2: unisim.vcomponents.MUXF7
     port map (
      I0 => DBNC_CNT_reg_0_15_0_0_i_6_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_7_n_0,
      O => DBNC_CNT_reg_0_15_0_0_i_2_n_0,
      S => CNTR_reg(2)
    );
DBNC_CNT_reg_0_15_0_0_i_3: unisim.vcomponents.MUXF7
     port map (
      I0 => DBNC_CNT_reg_0_15_0_0_i_8_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_9_n_0,
      O => DBNC_CNT_reg_0_15_0_0_i_3_n_0,
      S => CNTR_reg(2)
    );
DBNC_CNT_reg_0_15_0_0_i_4: unisim.vcomponents.MUXF8
     port map (
      I0 => DBNC_CNT_reg_0_15_0_0_i_10_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_11_n_0,
      O => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      S => CNTR_reg(3)
    );
DBNC_CNT_reg_0_15_0_0_i_5: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00007FFF"
    )
        port map (
      I0 => p_0_out(0),
      I1 => p_0_out(1),
      I2 => p_0_out(3),
      I3 => p_0_out(2),
      I4 => p_0_out(4),
      O => DBNC_CNT_reg_0_15_0_0_i_5_n_0
    );
DBNC_CNT_reg_0_15_0_0_i_6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => BUTTONS_SIG(11),
      I1 => BUTTONS_SIG(10),
      I2 => CNTR_reg(1),
      I3 => BUTTONS_SIG(9),
      I4 => CNTR_reg(0),
      I5 => BUTTONS_SIG(8),
      O => DBNC_CNT_reg_0_15_0_0_i_6_n_0
    );
DBNC_CNT_reg_0_15_0_0_i_7: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => BUTTONS_SIG(15),
      I1 => BUTTONS_SIG(14),
      I2 => CNTR_reg(1),
      I3 => BUTTONS_SIG(13),
      I4 => CNTR_reg(0),
      I5 => BUTTONS_SIG(12),
      O => DBNC_CNT_reg_0_15_0_0_i_7_n_0
    );
DBNC_CNT_reg_0_15_0_0_i_8: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => BUTTONS_SIG(3),
      I1 => BUTTONS_SIG(2),
      I2 => CNTR_reg(1),
      I3 => BUTTONS_SIG(1),
      I4 => CNTR_reg(0),
      I5 => BUTTONS_SIG(0),
      O => DBNC_CNT_reg_0_15_0_0_i_8_n_0
    );
DBNC_CNT_reg_0_15_0_0_i_9: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => BUTTONS_SIG(7),
      I1 => BUTTONS_SIG(6),
      I2 => CNTR_reg(1),
      I3 => BUTTONS_SIG(5),
      I4 => CNTR_reg(0),
      I5 => BUTTONS_SIG(4),
      O => DBNC_CNT_reg_0_15_0_0_i_9_n_0
    );
DBNC_CNT_reg_0_15_1_1: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => CNTR_reg(0),
      A1 => CNTR_reg(1),
      A2 => CNTR_reg(2),
      A3 => CNTR_reg(3),
      A4 => '0',
      D => DBNC_CNT(1),
      O => p_0_out(1),
      WCLK => CLK_LOW_F,
      WE => '1'
    );
DBNC_CNT_reg_0_15_1_1_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"06600000"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => p_0_out(0),
      I3 => p_0_out(1),
      I4 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      O => DBNC_CNT(1)
    );
DBNC_CNT_reg_0_15_1_1_i_2: unisim.vcomponents.MUXF8
     port map (
      I0 => DBNC_CNT_reg_0_15_0_0_i_3_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_2_n_0,
      O => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      S => CNTR_reg(3)
    );
DBNC_CNT_reg_0_15_2_2: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => CNTR_reg(0),
      A1 => CNTR_reg(1),
      A2 => CNTR_reg(2),
      A3 => CNTR_reg(3),
      A4 => '0',
      D => DBNC_CNT(2),
      O => p_0_out(2),
      WCLK => CLK_LOW_F,
      WE => '1'
    );
DBNC_CNT_reg_0_15_2_2_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0666600000000000"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => p_0_out(0),
      I3 => p_0_out(1),
      I4 => p_0_out(2),
      I5 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      O => DBNC_CNT(2)
    );
DBNC_CNT_reg_0_15_3_3: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => CNTR_reg(0),
      A1 => CNTR_reg(1),
      A2 => CNTR_reg(2),
      A3 => CNTR_reg(3),
      A4 => '0',
      D => DBNC_CNT(3),
      O => p_0_out(3),
      WCLK => CLK_LOW_F,
      WE => '1'
    );
DBNC_CNT_reg_0_15_3_3_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"06600000"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_3_3_i_2_n_0,
      I3 => p_0_out(3),
      I4 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      O => DBNC_CNT(3)
    );
DBNC_CNT_reg_0_15_3_3_i_2: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => p_0_out(2),
      I1 => p_0_out(0),
      I2 => p_0_out(1),
      O => DBNC_CNT_reg_0_15_3_3_i_2_n_0
    );
DBNC_CNT_reg_0_15_4_4: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => CNTR_reg(0),
      A1 => CNTR_reg(1),
      A2 => CNTR_reg(2),
      A3 => CNTR_reg(3),
      A4 => '0',
      D => DBNC_CNT(4),
      O => p_0_out(4),
      WCLK => CLK_LOW_F,
      WE => '1'
    );
DBNC_CNT_reg_0_15_4_4_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0666600000000000"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_1_1_i_2_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I2 => DBNC_CNT_reg_0_15_3_3_i_2_n_0,
      I3 => p_0_out(3),
      I4 => p_0_out(4),
      I5 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      O => DBNC_CNT(4)
    );
\LOW_F_CNT[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => \LOW_F_CNT[0]_i_3_n_0\,
      I1 => \LOW_F_CNT[0]_i_4_n_0\,
      I2 => \LOW_F_CNT[0]_i_5_n_0\,
      I3 => \LOW_F_CNT[0]_i_6_n_0\,
      I4 => \LOW_F_CNT[0]_i_7_n_0\,
      I5 => \LOW_F_CNT[0]_i_8_n_0\,
      O => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT[0]_i_10\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(2),
      O => \LOW_F_CNT[0]_i_10_n_0\
    );
\LOW_F_CNT[0]_i_11\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(1),
      O => \LOW_F_CNT[0]_i_11_n_0\
    );
\LOW_F_CNT[0]_i_12\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(0),
      O => \LOW_F_CNT[0]_i_12_n_0\
    );
\LOW_F_CNT[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => LOW_F_CNT_reg(25),
      I1 => LOW_F_CNT_reg(26),
      I2 => LOW_F_CNT_reg(24),
      I3 => LOW_F_CNT_reg(28),
      I4 => LOW_F_CNT_reg(29),
      I5 => LOW_F_CNT_reg(27),
      O => \LOW_F_CNT[0]_i_3_n_0\
    );
\LOW_F_CNT[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => LOW_F_CNT_reg(7),
      I1 => LOW_F_CNT_reg(8),
      I2 => LOW_F_CNT_reg(6),
      I3 => LOW_F_CNT_reg(10),
      I4 => LOW_F_CNT_reg(11),
      I5 => LOW_F_CNT_reg(9),
      O => \LOW_F_CNT[0]_i_4_n_0\
    );
\LOW_F_CNT[0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => LOW_F_CNT_reg(19),
      I1 => LOW_F_CNT_reg(20),
      I2 => LOW_F_CNT_reg(18),
      I3 => LOW_F_CNT_reg(22),
      I4 => LOW_F_CNT_reg(23),
      I5 => LOW_F_CNT_reg(21),
      O => \LOW_F_CNT[0]_i_5_n_0\
    );
\LOW_F_CNT[0]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => LOW_F_CNT_reg(13),
      I1 => LOW_F_CNT_reg(14),
      I2 => LOW_F_CNT_reg(12),
      I3 => LOW_F_CNT_reg(16),
      I4 => LOW_F_CNT_reg(17),
      I5 => LOW_F_CNT_reg(15),
      O => \LOW_F_CNT[0]_i_6_n_0\
    );
\LOW_F_CNT[0]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => LOW_F_CNT_reg(30),
      I1 => LOW_F_CNT_reg(31),
      O => \LOW_F_CNT[0]_i_7_n_0\
    );
\LOW_F_CNT[0]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => LOW_F_CNT_reg(1),
      I1 => LOW_F_CNT_reg(2),
      I2 => LOW_F_CNT_reg(0),
      I3 => LOW_F_CNT_reg(4),
      I4 => LOW_F_CNT_reg(5),
      I5 => LOW_F_CNT_reg(3),
      O => \LOW_F_CNT[0]_i_8_n_0\
    );
\LOW_F_CNT[0]_i_9\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(3),
      O => \LOW_F_CNT[0]_i_9_n_0\
    );
\LOW_F_CNT[12]_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(15),
      O => \LOW_F_CNT[12]_i_2_n_0\
    );
\LOW_F_CNT[12]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(14),
      O => \LOW_F_CNT[12]_i_3_n_0\
    );
\LOW_F_CNT[12]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(13),
      O => \LOW_F_CNT[12]_i_4_n_0\
    );
\LOW_F_CNT[12]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(12),
      O => \LOW_F_CNT[12]_i_5_n_0\
    );
\LOW_F_CNT[16]_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(19),
      O => \LOW_F_CNT[16]_i_2_n_0\
    );
\LOW_F_CNT[16]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(18),
      O => \LOW_F_CNT[16]_i_3_n_0\
    );
\LOW_F_CNT[16]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(17),
      O => \LOW_F_CNT[16]_i_4_n_0\
    );
\LOW_F_CNT[16]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(16),
      O => \LOW_F_CNT[16]_i_5_n_0\
    );
\LOW_F_CNT[20]_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(23),
      O => \LOW_F_CNT[20]_i_2_n_0\
    );
\LOW_F_CNT[20]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(22),
      O => \LOW_F_CNT[20]_i_3_n_0\
    );
\LOW_F_CNT[20]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(21),
      O => \LOW_F_CNT[20]_i_4_n_0\
    );
\LOW_F_CNT[20]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(20),
      O => \LOW_F_CNT[20]_i_5_n_0\
    );
\LOW_F_CNT[24]_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(27),
      O => \LOW_F_CNT[24]_i_2_n_0\
    );
\LOW_F_CNT[24]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(26),
      O => \LOW_F_CNT[24]_i_3_n_0\
    );
\LOW_F_CNT[24]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(25),
      O => \LOW_F_CNT[24]_i_4_n_0\
    );
\LOW_F_CNT[24]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(24),
      O => \LOW_F_CNT[24]_i_5_n_0\
    );
\LOW_F_CNT[28]_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(31),
      O => \LOW_F_CNT[28]_i_2_n_0\
    );
\LOW_F_CNT[28]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(30),
      O => \LOW_F_CNT[28]_i_3_n_0\
    );
\LOW_F_CNT[28]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(29),
      O => \LOW_F_CNT[28]_i_4_n_0\
    );
\LOW_F_CNT[28]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(28),
      O => \LOW_F_CNT[28]_i_5_n_0\
    );
\LOW_F_CNT[4]_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(7),
      O => \LOW_F_CNT[4]_i_2_n_0\
    );
\LOW_F_CNT[4]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(6),
      O => \LOW_F_CNT[4]_i_3_n_0\
    );
\LOW_F_CNT[4]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(5),
      O => \LOW_F_CNT[4]_i_4_n_0\
    );
\LOW_F_CNT[4]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(4),
      O => \LOW_F_CNT[4]_i_5_n_0\
    );
\LOW_F_CNT[8]_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(11),
      O => \LOW_F_CNT[8]_i_2_n_0\
    );
\LOW_F_CNT[8]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(10),
      O => \LOW_F_CNT[8]_i_3_n_0\
    );
\LOW_F_CNT[8]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(9),
      O => \LOW_F_CNT[8]_i_4_n_0\
    );
\LOW_F_CNT[8]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => LOW_F_CNT_reg(8),
      O => \LOW_F_CNT[8]_i_5_n_0\
    );
\LOW_F_CNT_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[0]_i_2_n_7\,
      Q => LOW_F_CNT_reg(0),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[0]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \LOW_F_CNT_reg[0]_i_2_n_0\,
      CO(2) => \LOW_F_CNT_reg[0]_i_2_n_1\,
      CO(1) => \LOW_F_CNT_reg[0]_i_2_n_2\,
      CO(0) => \LOW_F_CNT_reg[0]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"1111",
      O(3) => \LOW_F_CNT_reg[0]_i_2_n_4\,
      O(2) => \LOW_F_CNT_reg[0]_i_2_n_5\,
      O(1) => \LOW_F_CNT_reg[0]_i_2_n_6\,
      O(0) => \LOW_F_CNT_reg[0]_i_2_n_7\,
      S(3) => \LOW_F_CNT[0]_i_9_n_0\,
      S(2) => \LOW_F_CNT[0]_i_10_n_0\,
      S(1) => \LOW_F_CNT[0]_i_11_n_0\,
      S(0) => \LOW_F_CNT[0]_i_12_n_0\
    );
\LOW_F_CNT_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[8]_i_1_n_5\,
      Q => LOW_F_CNT_reg(10),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[8]_i_1_n_4\,
      Q => LOW_F_CNT_reg(11),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[12]_i_1_n_7\,
      Q => LOW_F_CNT_reg(12),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[12]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \LOW_F_CNT_reg[8]_i_1_n_0\,
      CO(3) => \LOW_F_CNT_reg[12]_i_1_n_0\,
      CO(2) => \LOW_F_CNT_reg[12]_i_1_n_1\,
      CO(1) => \LOW_F_CNT_reg[12]_i_1_n_2\,
      CO(0) => \LOW_F_CNT_reg[12]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"1111",
      O(3) => \LOW_F_CNT_reg[12]_i_1_n_4\,
      O(2) => \LOW_F_CNT_reg[12]_i_1_n_5\,
      O(1) => \LOW_F_CNT_reg[12]_i_1_n_6\,
      O(0) => \LOW_F_CNT_reg[12]_i_1_n_7\,
      S(3) => \LOW_F_CNT[12]_i_2_n_0\,
      S(2) => \LOW_F_CNT[12]_i_3_n_0\,
      S(1) => \LOW_F_CNT[12]_i_4_n_0\,
      S(0) => \LOW_F_CNT[12]_i_5_n_0\
    );
\LOW_F_CNT_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[12]_i_1_n_6\,
      Q => LOW_F_CNT_reg(13),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[12]_i_1_n_5\,
      Q => LOW_F_CNT_reg(14),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[12]_i_1_n_4\,
      Q => LOW_F_CNT_reg(15),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[16]_i_1_n_7\,
      Q => LOW_F_CNT_reg(16),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[16]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \LOW_F_CNT_reg[12]_i_1_n_0\,
      CO(3) => \LOW_F_CNT_reg[16]_i_1_n_0\,
      CO(2) => \LOW_F_CNT_reg[16]_i_1_n_1\,
      CO(1) => \LOW_F_CNT_reg[16]_i_1_n_2\,
      CO(0) => \LOW_F_CNT_reg[16]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"1111",
      O(3) => \LOW_F_CNT_reg[16]_i_1_n_4\,
      O(2) => \LOW_F_CNT_reg[16]_i_1_n_5\,
      O(1) => \LOW_F_CNT_reg[16]_i_1_n_6\,
      O(0) => \LOW_F_CNT_reg[16]_i_1_n_7\,
      S(3) => \LOW_F_CNT[16]_i_2_n_0\,
      S(2) => \LOW_F_CNT[16]_i_3_n_0\,
      S(1) => \LOW_F_CNT[16]_i_4_n_0\,
      S(0) => \LOW_F_CNT[16]_i_5_n_0\
    );
\LOW_F_CNT_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[16]_i_1_n_6\,
      Q => LOW_F_CNT_reg(17),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[16]_i_1_n_5\,
      Q => LOW_F_CNT_reg(18),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[16]_i_1_n_4\,
      Q => LOW_F_CNT_reg(19),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[0]_i_2_n_6\,
      Q => LOW_F_CNT_reg(1),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[20]_i_1_n_7\,
      Q => LOW_F_CNT_reg(20),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[20]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \LOW_F_CNT_reg[16]_i_1_n_0\,
      CO(3) => \LOW_F_CNT_reg[20]_i_1_n_0\,
      CO(2) => \LOW_F_CNT_reg[20]_i_1_n_1\,
      CO(1) => \LOW_F_CNT_reg[20]_i_1_n_2\,
      CO(0) => \LOW_F_CNT_reg[20]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"1111",
      O(3) => \LOW_F_CNT_reg[20]_i_1_n_4\,
      O(2) => \LOW_F_CNT_reg[20]_i_1_n_5\,
      O(1) => \LOW_F_CNT_reg[20]_i_1_n_6\,
      O(0) => \LOW_F_CNT_reg[20]_i_1_n_7\,
      S(3) => \LOW_F_CNT[20]_i_2_n_0\,
      S(2) => \LOW_F_CNT[20]_i_3_n_0\,
      S(1) => \LOW_F_CNT[20]_i_4_n_0\,
      S(0) => \LOW_F_CNT[20]_i_5_n_0\
    );
\LOW_F_CNT_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[20]_i_1_n_6\,
      Q => LOW_F_CNT_reg(21),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[20]_i_1_n_5\,
      Q => LOW_F_CNT_reg(22),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[20]_i_1_n_4\,
      Q => LOW_F_CNT_reg(23),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[24]_i_1_n_7\,
      Q => LOW_F_CNT_reg(24),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[24]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \LOW_F_CNT_reg[20]_i_1_n_0\,
      CO(3) => \LOW_F_CNT_reg[24]_i_1_n_0\,
      CO(2) => \LOW_F_CNT_reg[24]_i_1_n_1\,
      CO(1) => \LOW_F_CNT_reg[24]_i_1_n_2\,
      CO(0) => \LOW_F_CNT_reg[24]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"1111",
      O(3) => \LOW_F_CNT_reg[24]_i_1_n_4\,
      O(2) => \LOW_F_CNT_reg[24]_i_1_n_5\,
      O(1) => \LOW_F_CNT_reg[24]_i_1_n_6\,
      O(0) => \LOW_F_CNT_reg[24]_i_1_n_7\,
      S(3) => \LOW_F_CNT[24]_i_2_n_0\,
      S(2) => \LOW_F_CNT[24]_i_3_n_0\,
      S(1) => \LOW_F_CNT[24]_i_4_n_0\,
      S(0) => \LOW_F_CNT[24]_i_5_n_0\
    );
\LOW_F_CNT_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[24]_i_1_n_6\,
      Q => LOW_F_CNT_reg(25),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[24]_i_1_n_5\,
      Q => LOW_F_CNT_reg(26),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[24]_i_1_n_4\,
      Q => LOW_F_CNT_reg(27),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[28]_i_1_n_7\,
      Q => LOW_F_CNT_reg(28),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[28]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \LOW_F_CNT_reg[24]_i_1_n_0\,
      CO(3) => \NLW_LOW_F_CNT_reg[28]_i_1_CO_UNCONNECTED\(3),
      CO(2) => \LOW_F_CNT_reg[28]_i_1_n_1\,
      CO(1) => \LOW_F_CNT_reg[28]_i_1_n_2\,
      CO(0) => \LOW_F_CNT_reg[28]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0111",
      O(3) => \LOW_F_CNT_reg[28]_i_1_n_4\,
      O(2) => \LOW_F_CNT_reg[28]_i_1_n_5\,
      O(1) => \LOW_F_CNT_reg[28]_i_1_n_6\,
      O(0) => \LOW_F_CNT_reg[28]_i_1_n_7\,
      S(3) => \LOW_F_CNT[28]_i_2_n_0\,
      S(2) => \LOW_F_CNT[28]_i_3_n_0\,
      S(1) => \LOW_F_CNT[28]_i_4_n_0\,
      S(0) => \LOW_F_CNT[28]_i_5_n_0\
    );
\LOW_F_CNT_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[28]_i_1_n_6\,
      Q => LOW_F_CNT_reg(29),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[0]_i_2_n_5\,
      Q => LOW_F_CNT_reg(2),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[28]_i_1_n_5\,
      Q => LOW_F_CNT_reg(30),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[28]_i_1_n_4\,
      Q => LOW_F_CNT_reg(31),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[0]_i_2_n_4\,
      Q => LOW_F_CNT_reg(3),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[4]_i_1_n_7\,
      Q => LOW_F_CNT_reg(4),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[4]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \LOW_F_CNT_reg[0]_i_2_n_0\,
      CO(3) => \LOW_F_CNT_reg[4]_i_1_n_0\,
      CO(2) => \LOW_F_CNT_reg[4]_i_1_n_1\,
      CO(1) => \LOW_F_CNT_reg[4]_i_1_n_2\,
      CO(0) => \LOW_F_CNT_reg[4]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"1111",
      O(3) => \LOW_F_CNT_reg[4]_i_1_n_4\,
      O(2) => \LOW_F_CNT_reg[4]_i_1_n_5\,
      O(1) => \LOW_F_CNT_reg[4]_i_1_n_6\,
      O(0) => \LOW_F_CNT_reg[4]_i_1_n_7\,
      S(3) => \LOW_F_CNT[4]_i_2_n_0\,
      S(2) => \LOW_F_CNT[4]_i_3_n_0\,
      S(1) => \LOW_F_CNT[4]_i_4_n_0\,
      S(0) => \LOW_F_CNT[4]_i_5_n_0\
    );
\LOW_F_CNT_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[4]_i_1_n_6\,
      Q => LOW_F_CNT_reg(5),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[6]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[4]_i_1_n_5\,
      Q => LOW_F_CNT_reg(6),
      S => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[4]_i_1_n_4\,
      Q => LOW_F_CNT_reg(7),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[8]_i_1_n_7\,
      Q => LOW_F_CNT_reg(8),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\LOW_F_CNT_reg[8]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \LOW_F_CNT_reg[4]_i_1_n_0\,
      CO(3) => \LOW_F_CNT_reg[8]_i_1_n_0\,
      CO(2) => \LOW_F_CNT_reg[8]_i_1_n_1\,
      CO(1) => \LOW_F_CNT_reg[8]_i_1_n_2\,
      CO(0) => \LOW_F_CNT_reg[8]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"1111",
      O(3) => \LOW_F_CNT_reg[8]_i_1_n_4\,
      O(2) => \LOW_F_CNT_reg[8]_i_1_n_5\,
      O(1) => \LOW_F_CNT_reg[8]_i_1_n_6\,
      O(0) => \LOW_F_CNT_reg[8]_i_1_n_7\,
      S(3) => \LOW_F_CNT[8]_i_2_n_0\,
      S(2) => \LOW_F_CNT[8]_i_3_n_0\,
      S(1) => \LOW_F_CNT[8]_i_4_n_0\,
      S(0) => \LOW_F_CNT[8]_i_5_n_0\
    );
\LOW_F_CNT_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_5M,
      CE => '1',
      D => \LOW_F_CNT_reg[8]_i_1_n_6\,
      Q => LOW_F_CNT_reg(9),
      R => \LOW_F_CNT[0]_i_1_n_0\
    );
\ROWS_FF1_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => ROWS_IN(0),
      Q => ROWS_FF1(0),
      R => '0'
    );
\ROWS_FF1_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => ROWS_IN(1),
      Q => ROWS_FF1(1),
      R => '0'
    );
\ROWS_FF1_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => ROWS_IN(2),
      Q => ROWS_FF1(2),
      R => '0'
    );
\ROWS_FF1_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => ROWS_IN(3),
      Q => ROWS_FF1(3),
      R => '0'
    );
\ROWS_FF2_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => ROWS_FF1(0),
      Q => ROWS_FF2(0),
      R => '0'
    );
\ROWS_FF2_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => ROWS_FF1(1),
      Q => ROWS_FF2(1),
      R => '0'
    );
\ROWS_FF2_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => ROWS_FF1(2),
      Q => ROWS_FF2(2),
      R => '0'
    );
\ROWS_FF2_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => ROWS_FF1(3),
      Q => ROWS_FF2(3),
      R => '0'
    );
\S_COLUMNS[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => CNTR_reg(3),
      I1 => CNTR_reg(2),
      O => \S_COLUMNS[0]_i_1_n_0\
    );
\S_COLUMNS[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => CNTR_reg(3),
      I1 => CNTR_reg(2),
      O => \S_COLUMNS[1]_i_1_n_0\
    );
\S_COLUMNS[2]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"D"
    )
        port map (
      I0 => CNTR_reg(3),
      I1 => CNTR_reg(2),
      O => \S_COLUMNS[2]_i_1_n_0\
    );
\S_COLUMNS[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => CNTR_reg(3),
      I1 => CNTR_reg(2),
      O => \S_COLUMNS[3]_i_1_n_0\
    );
\S_COLUMNS_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \S_COLUMNS[0]_i_1_n_0\,
      Q => COLUMNS_OUT(0),
      R => '0'
    );
\S_COLUMNS_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \S_COLUMNS[1]_i_1_n_0\,
      Q => COLUMNS_OUT(1),
      R => '0'
    );
\S_COLUMNS_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \S_COLUMNS[2]_i_1_n_0\,
      Q => COLUMNS_OUT(2),
      R => '0'
    );
\S_COLUMNS_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => \S_COLUMNS[3]_i_1_n_0\,
      Q => COLUMNS_OUT(3),
      R => '0'
    );
TOP_BTN_0_INST_0: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => p_0_in_0(1),
      O => BUTTONS_OUT(1)
    );
TOP_BTN_1_INST_0: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => p_2_in(0),
      O => BUTTONS_OUT(4)
    );
TOP_BTN_2_INST_0: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \BUTTONS_SIG_FILT_reg_n_0_[11]\,
      O => BUTTONS_OUT(11)
    );
TOP_BTN_3_INST_0: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \BUTTONS_SIG_FILT_reg_n_0_[2]\,
      O => BUTTONS_OUT(14)
    );
VALID_FF_reg: unisim.vcomponents.FDRE
     port map (
      C => CLK_40M,
      CE => '1',
      D => VALID,
      Q => VALID_FF,
      R => '0'
    );
VALID_PRESS_OUT_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => VALID,
      I1 => VALID_FF,
      O => VALID_RELEASE_OUT0
    );
VALID_PRESS_OUT_reg: unisim.vcomponents.FDRE
     port map (
      C => CLK_40M,
      CE => '1',
      D => VALID_RELEASE_OUT0,
      Q => VALID_PRESS_OUT,
      R => '0'
    );
VALID_RELEASE_OUT_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => VALID_FF,
      I1 => VALID,
      O => VALID_RELEASE_OUT_i_1_n_0
    );
VALID_RELEASE_OUT_reg: unisim.vcomponents.FDRE
     port map (
      C => CLK_40M,
      CE => '1',
      D => VALID_RELEASE_OUT_i_1_n_0,
      Q => VALID_RELEASE_OUT,
      R => '0'
    );
VALID_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"000002A2"
    )
        port map (
      I0 => DBNC_CNT_reg_0_15_0_0_i_4_n_0,
      I1 => DBNC_CNT_reg_0_15_0_0_i_3_n_0,
      I2 => CNTR_reg(3),
      I3 => DBNC_CNT_reg_0_15_0_0_i_2_n_0,
      I4 => DBNC_CNT_reg_0_15_0_0_i_5_n_0,
      O => VALID_i_1_n_0
    );
VALID_reg: unisim.vcomponents.FDRE
     port map (
      C => CLK_LOW_F,
      CE => '1',
      D => VALID_i_1_n_0,
      Q => VALID,
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity Uvod2_BUTTON_MATRIX_0_0 is
  port (
    CLK_5M : in STD_LOGIC;
    CLK_40M : in STD_LOGIC;
    ROWS_IN : in STD_LOGIC_VECTOR ( 3 downto 0 );
    COLUMNS_OUT : out STD_LOGIC_VECTOR ( 3 downto 0 );
    BUTTONS_OUT : out STD_LOGIC_VECTOR ( 15 downto 0 );
    VALID_PRESS_OUT : out STD_LOGIC;
    VALID_RELEASE_OUT : out STD_LOGIC;
    TOP_BTN_0 : out STD_LOGIC;
    TOP_BTN_1 : out STD_LOGIC;
    TOP_BTN_2 : out STD_LOGIC;
    TOP_BTN_3 : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of Uvod2_BUTTON_MATRIX_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of Uvod2_BUTTON_MATRIX_0_0 : entity is "Uvod2_BUTTON_MATRIX_0_0,BUTTON_MATRIX,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of Uvod2_BUTTON_MATRIX_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of Uvod2_BUTTON_MATRIX_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of Uvod2_BUTTON_MATRIX_0_0 : entity is "BUTTON_MATRIX,Vivado 2025.1";
end Uvod2_BUTTON_MATRIX_0_0;

architecture STRUCTURE of Uvod2_BUTTON_MATRIX_0_0 is
  signal \^buttons_out\ : STD_LOGIC_VECTOR ( 15 downto 0 );
begin
  BUTTONS_OUT(15 downto 0) <= \^buttons_out\(15 downto 0);
  TOP_BTN_0 <= \^buttons_out\(1);
  TOP_BTN_1 <= \^buttons_out\(4);
  TOP_BTN_2 <= \^buttons_out\(11);
  TOP_BTN_3 <= \^buttons_out\(14);
inst: entity work.Uvod2_BUTTON_MATRIX_0_0_BUTTON_MATRIX
     port map (
      BUTTONS_OUT(15 downto 0) => \^buttons_out\(15 downto 0),
      CLK_40M => CLK_40M,
      CLK_5M => CLK_5M,
      COLUMNS_OUT(3 downto 0) => COLUMNS_OUT(3 downto 0),
      ROWS_IN(3 downto 0) => ROWS_IN(3 downto 0),
      VALID_PRESS_OUT => VALID_PRESS_OUT,
      VALID_RELEASE_OUT => VALID_RELEASE_OUT
    );
end STRUCTURE;
