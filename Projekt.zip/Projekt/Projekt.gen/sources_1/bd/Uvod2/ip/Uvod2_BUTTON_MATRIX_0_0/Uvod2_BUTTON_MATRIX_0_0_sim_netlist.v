// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
// Date        : Mon May 11 15:35:25 2026
// Host        : LRNV-INSTALL running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/vaje/Desktop/Salem/SalemPEV/11.5/PEV/Projekt/Projekt.gen/sources_1/bd/Uvod2/ip/Uvod2_BUTTON_MATRIX_0_0/Uvod2_BUTTON_MATRIX_0_0_sim_netlist.v
// Design      : Uvod2_BUTTON_MATRIX_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7s25csga324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "Uvod2_BUTTON_MATRIX_0_0,BUTTON_MATRIX,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "BUTTON_MATRIX,Vivado 2025.1" *) 
(* NotValidForBitStream *)
module Uvod2_BUTTON_MATRIX_0_0
   (CLK_5M,
    CLK_40M,
    ROWS_IN,
    COLUMNS_OUT,
    BUTTONS_OUT,
    VALID_PRESS_OUT,
    VALID_RELEASE_OUT,
    TOP_BTN_0,
    TOP_BTN_1,
    TOP_BTN_2,
    TOP_BTN_3);
  input CLK_5M;
  input CLK_40M;
  input [3:0]ROWS_IN;
  output [3:0]COLUMNS_OUT;
  output [15:0]BUTTONS_OUT;
  output VALID_PRESS_OUT;
  output VALID_RELEASE_OUT;
  output TOP_BTN_0;
  output TOP_BTN_1;
  output TOP_BTN_2;
  output TOP_BTN_3;

  wire [15:0]BUTTONS_OUT;
  wire CLK_40M;
  wire CLK_5M;
  wire [3:0]COLUMNS_OUT;
  wire [3:0]ROWS_IN;
  wire VALID_PRESS_OUT;
  wire VALID_RELEASE_OUT;

  assign TOP_BTN_0 = BUTTONS_OUT[1];
  assign TOP_BTN_1 = BUTTONS_OUT[4];
  assign TOP_BTN_2 = BUTTONS_OUT[11];
  assign TOP_BTN_3 = BUTTONS_OUT[14];
  Uvod2_BUTTON_MATRIX_0_0_BUTTON_MATRIX inst
       (.BUTTONS_OUT(BUTTONS_OUT),
        .CLK_40M(CLK_40M),
        .CLK_5M(CLK_5M),
        .COLUMNS_OUT(COLUMNS_OUT),
        .ROWS_IN(ROWS_IN),
        .VALID_PRESS_OUT(VALID_PRESS_OUT),
        .VALID_RELEASE_OUT(VALID_RELEASE_OUT));
endmodule

(* ORIG_REF_NAME = "BUTTON_MATRIX" *) 
module Uvod2_BUTTON_MATRIX_0_0_BUTTON_MATRIX
   (COLUMNS_OUT,
    VALID_PRESS_OUT,
    BUTTONS_OUT,
    VALID_RELEASE_OUT,
    ROWS_IN,
    CLK_40M,
    CLK_5M);
  output [3:0]COLUMNS_OUT;
  output VALID_PRESS_OUT;
  output [15:0]BUTTONS_OUT;
  output VALID_RELEASE_OUT;
  input [3:0]ROWS_IN;
  input CLK_40M;
  input CLK_5M;

  wire [15:0]BUTTONS_OUT;
  wire [15:0]BUTTONS_SIG;
  wire BUTTONS_SIG1;
  wire \BUTTONS_SIG[0]_i_1_n_0 ;
  wire \BUTTONS_SIG[10]_i_1_n_0 ;
  wire \BUTTONS_SIG[11]_i_1_n_0 ;
  wire \BUTTONS_SIG[12]_i_1_n_0 ;
  wire \BUTTONS_SIG[13]_i_1_n_0 ;
  wire \BUTTONS_SIG[14]_i_1_n_0 ;
  wire \BUTTONS_SIG[15]_i_1_n_0 ;
  wire \BUTTONS_SIG[1]_i_1_n_0 ;
  wire \BUTTONS_SIG[2]_i_1_n_0 ;
  wire \BUTTONS_SIG[3]_i_1_n_0 ;
  wire \BUTTONS_SIG[4]_i_1_n_0 ;
  wire \BUTTONS_SIG[5]_i_1_n_0 ;
  wire \BUTTONS_SIG[6]_i_1_n_0 ;
  wire \BUTTONS_SIG[7]_i_1_n_0 ;
  wire \BUTTONS_SIG[8]_i_1_n_0 ;
  wire \BUTTONS_SIG[9]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[0]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[0]_i_2_n_0 ;
  wire \BUTTONS_SIG_FILT[10]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[10]_i_2_n_0 ;
  wire \BUTTONS_SIG_FILT[11]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[11]_i_2_n_0 ;
  wire \BUTTONS_SIG_FILT[12]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[12]_i_2_n_0 ;
  wire \BUTTONS_SIG_FILT[13]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[13]_i_2_n_0 ;
  wire \BUTTONS_SIG_FILT[14]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[14]_i_2_n_0 ;
  wire \BUTTONS_SIG_FILT[15]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[15]_i_2_n_0 ;
  wire \BUTTONS_SIG_FILT[1]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[1]_i_2_n_0 ;
  wire \BUTTONS_SIG_FILT[2]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[2]_i_2_n_0 ;
  wire \BUTTONS_SIG_FILT[3]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[4]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[4]_i_2_n_0 ;
  wire \BUTTONS_SIG_FILT[5]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[5]_i_2_n_0 ;
  wire \BUTTONS_SIG_FILT[6]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[6]_i_2_n_0 ;
  wire \BUTTONS_SIG_FILT[7]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[8]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[8]_i_2_n_0 ;
  wire \BUTTONS_SIG_FILT[9]_i_1_n_0 ;
  wire \BUTTONS_SIG_FILT[9]_i_2_n_0 ;
  wire \BUTTONS_SIG_FILT_reg_n_0_[0] ;
  wire \BUTTONS_SIG_FILT_reg_n_0_[11] ;
  wire \BUTTONS_SIG_FILT_reg_n_0_[15] ;
  wire \BUTTONS_SIG_FILT_reg_n_0_[1] ;
  wire \BUTTONS_SIG_FILT_reg_n_0_[2] ;
  wire CLK_40M;
  wire CLK_5M;
  wire CLK_LOW_F;
  wire CLK_LOW_F_i_1_n_0;
  wire \CNTR[0]_i_1_n_0 ;
  wire \CNTR[2]_i_1_n_0 ;
  wire [3:0]CNTR_reg;
  wire [3:0]COLUMNS_OUT;
  wire [4:0]DBNC_CNT;
  wire DBNC_CNT_reg_0_15_0_0_i_10_n_0;
  wire DBNC_CNT_reg_0_15_0_0_i_11_n_0;
  wire DBNC_CNT_reg_0_15_0_0_i_12_n_0;
  wire DBNC_CNT_reg_0_15_0_0_i_13_n_0;
  wire DBNC_CNT_reg_0_15_0_0_i_14_n_0;
  wire DBNC_CNT_reg_0_15_0_0_i_15_n_0;
  wire DBNC_CNT_reg_0_15_0_0_i_2_n_0;
  wire DBNC_CNT_reg_0_15_0_0_i_3_n_0;
  wire DBNC_CNT_reg_0_15_0_0_i_4_n_0;
  wire DBNC_CNT_reg_0_15_0_0_i_5_n_0;
  wire DBNC_CNT_reg_0_15_0_0_i_6_n_0;
  wire DBNC_CNT_reg_0_15_0_0_i_7_n_0;
  wire DBNC_CNT_reg_0_15_0_0_i_8_n_0;
  wire DBNC_CNT_reg_0_15_0_0_i_9_n_0;
  wire DBNC_CNT_reg_0_15_1_1_i_2_n_0;
  wire DBNC_CNT_reg_0_15_3_3_i_2_n_0;
  wire \LOW_F_CNT[0]_i_10_n_0 ;
  wire \LOW_F_CNT[0]_i_11_n_0 ;
  wire \LOW_F_CNT[0]_i_12_n_0 ;
  wire \LOW_F_CNT[0]_i_1_n_0 ;
  wire \LOW_F_CNT[0]_i_3_n_0 ;
  wire \LOW_F_CNT[0]_i_4_n_0 ;
  wire \LOW_F_CNT[0]_i_5_n_0 ;
  wire \LOW_F_CNT[0]_i_6_n_0 ;
  wire \LOW_F_CNT[0]_i_7_n_0 ;
  wire \LOW_F_CNT[0]_i_8_n_0 ;
  wire \LOW_F_CNT[0]_i_9_n_0 ;
  wire \LOW_F_CNT[12]_i_2_n_0 ;
  wire \LOW_F_CNT[12]_i_3_n_0 ;
  wire \LOW_F_CNT[12]_i_4_n_0 ;
  wire \LOW_F_CNT[12]_i_5_n_0 ;
  wire \LOW_F_CNT[16]_i_2_n_0 ;
  wire \LOW_F_CNT[16]_i_3_n_0 ;
  wire \LOW_F_CNT[16]_i_4_n_0 ;
  wire \LOW_F_CNT[16]_i_5_n_0 ;
  wire \LOW_F_CNT[20]_i_2_n_0 ;
  wire \LOW_F_CNT[20]_i_3_n_0 ;
  wire \LOW_F_CNT[20]_i_4_n_0 ;
  wire \LOW_F_CNT[20]_i_5_n_0 ;
  wire \LOW_F_CNT[24]_i_2_n_0 ;
  wire \LOW_F_CNT[24]_i_3_n_0 ;
  wire \LOW_F_CNT[24]_i_4_n_0 ;
  wire \LOW_F_CNT[24]_i_5_n_0 ;
  wire \LOW_F_CNT[28]_i_2_n_0 ;
  wire \LOW_F_CNT[28]_i_3_n_0 ;
  wire \LOW_F_CNT[28]_i_4_n_0 ;
  wire \LOW_F_CNT[28]_i_5_n_0 ;
  wire \LOW_F_CNT[4]_i_2_n_0 ;
  wire \LOW_F_CNT[4]_i_3_n_0 ;
  wire \LOW_F_CNT[4]_i_4_n_0 ;
  wire \LOW_F_CNT[4]_i_5_n_0 ;
  wire \LOW_F_CNT[8]_i_2_n_0 ;
  wire \LOW_F_CNT[8]_i_3_n_0 ;
  wire \LOW_F_CNT[8]_i_4_n_0 ;
  wire \LOW_F_CNT[8]_i_5_n_0 ;
  wire [31:0]LOW_F_CNT_reg;
  wire \LOW_F_CNT_reg[0]_i_2_n_0 ;
  wire \LOW_F_CNT_reg[0]_i_2_n_1 ;
  wire \LOW_F_CNT_reg[0]_i_2_n_2 ;
  wire \LOW_F_CNT_reg[0]_i_2_n_3 ;
  wire \LOW_F_CNT_reg[0]_i_2_n_4 ;
  wire \LOW_F_CNT_reg[0]_i_2_n_5 ;
  wire \LOW_F_CNT_reg[0]_i_2_n_6 ;
  wire \LOW_F_CNT_reg[0]_i_2_n_7 ;
  wire \LOW_F_CNT_reg[12]_i_1_n_0 ;
  wire \LOW_F_CNT_reg[12]_i_1_n_1 ;
  wire \LOW_F_CNT_reg[12]_i_1_n_2 ;
  wire \LOW_F_CNT_reg[12]_i_1_n_3 ;
  wire \LOW_F_CNT_reg[12]_i_1_n_4 ;
  wire \LOW_F_CNT_reg[12]_i_1_n_5 ;
  wire \LOW_F_CNT_reg[12]_i_1_n_6 ;
  wire \LOW_F_CNT_reg[12]_i_1_n_7 ;
  wire \LOW_F_CNT_reg[16]_i_1_n_0 ;
  wire \LOW_F_CNT_reg[16]_i_1_n_1 ;
  wire \LOW_F_CNT_reg[16]_i_1_n_2 ;
  wire \LOW_F_CNT_reg[16]_i_1_n_3 ;
  wire \LOW_F_CNT_reg[16]_i_1_n_4 ;
  wire \LOW_F_CNT_reg[16]_i_1_n_5 ;
  wire \LOW_F_CNT_reg[16]_i_1_n_6 ;
  wire \LOW_F_CNT_reg[16]_i_1_n_7 ;
  wire \LOW_F_CNT_reg[20]_i_1_n_0 ;
  wire \LOW_F_CNT_reg[20]_i_1_n_1 ;
  wire \LOW_F_CNT_reg[20]_i_1_n_2 ;
  wire \LOW_F_CNT_reg[20]_i_1_n_3 ;
  wire \LOW_F_CNT_reg[20]_i_1_n_4 ;
  wire \LOW_F_CNT_reg[20]_i_1_n_5 ;
  wire \LOW_F_CNT_reg[20]_i_1_n_6 ;
  wire \LOW_F_CNT_reg[20]_i_1_n_7 ;
  wire \LOW_F_CNT_reg[24]_i_1_n_0 ;
  wire \LOW_F_CNT_reg[24]_i_1_n_1 ;
  wire \LOW_F_CNT_reg[24]_i_1_n_2 ;
  wire \LOW_F_CNT_reg[24]_i_1_n_3 ;
  wire \LOW_F_CNT_reg[24]_i_1_n_4 ;
  wire \LOW_F_CNT_reg[24]_i_1_n_5 ;
  wire \LOW_F_CNT_reg[24]_i_1_n_6 ;
  wire \LOW_F_CNT_reg[24]_i_1_n_7 ;
  wire \LOW_F_CNT_reg[28]_i_1_n_1 ;
  wire \LOW_F_CNT_reg[28]_i_1_n_2 ;
  wire \LOW_F_CNT_reg[28]_i_1_n_3 ;
  wire \LOW_F_CNT_reg[28]_i_1_n_4 ;
  wire \LOW_F_CNT_reg[28]_i_1_n_5 ;
  wire \LOW_F_CNT_reg[28]_i_1_n_6 ;
  wire \LOW_F_CNT_reg[28]_i_1_n_7 ;
  wire \LOW_F_CNT_reg[4]_i_1_n_0 ;
  wire \LOW_F_CNT_reg[4]_i_1_n_1 ;
  wire \LOW_F_CNT_reg[4]_i_1_n_2 ;
  wire \LOW_F_CNT_reg[4]_i_1_n_3 ;
  wire \LOW_F_CNT_reg[4]_i_1_n_4 ;
  wire \LOW_F_CNT_reg[4]_i_1_n_5 ;
  wire \LOW_F_CNT_reg[4]_i_1_n_6 ;
  wire \LOW_F_CNT_reg[4]_i_1_n_7 ;
  wire \LOW_F_CNT_reg[8]_i_1_n_0 ;
  wire \LOW_F_CNT_reg[8]_i_1_n_1 ;
  wire \LOW_F_CNT_reg[8]_i_1_n_2 ;
  wire \LOW_F_CNT_reg[8]_i_1_n_3 ;
  wire \LOW_F_CNT_reg[8]_i_1_n_4 ;
  wire \LOW_F_CNT_reg[8]_i_1_n_5 ;
  wire \LOW_F_CNT_reg[8]_i_1_n_6 ;
  wire \LOW_F_CNT_reg[8]_i_1_n_7 ;
  wire [3:0]ROWS_FF1;
  wire [3:0]ROWS_FF2;
  wire [3:0]ROWS_IN;
  wire \S_COLUMNS[0]_i_1_n_0 ;
  wire \S_COLUMNS[1]_i_1_n_0 ;
  wire \S_COLUMNS[2]_i_1_n_0 ;
  wire \S_COLUMNS[3]_i_1_n_0 ;
  wire VALID;
  wire VALID_FF;
  wire VALID_PRESS_OUT;
  wire VALID_RELEASE_OUT;
  wire VALID_RELEASE_OUT0;
  wire VALID_RELEASE_OUT_i_1_n_0;
  wire VALID_i_1_n_0;
  wire clear;
  wire [3:1]p_0_in;
  wire [2:0]p_0_in_0;
  wire [4:0]p_0_out;
  wire p_1_in;
  wire [2:0]p_2_in;
  wire p_3_in;
  wire [2:0]p_4_in;
  wire [3:3]\NLW_LOW_F_CNT_reg[28]_i_1_CO_UNCONNECTED ;

  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \BUTTONS_OUT[0]_INST_0 
       (.I0(p_0_in_0[0]),
        .O(BUTTONS_OUT[0]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \BUTTONS_OUT[10]_INST_0 
       (.I0(p_4_in[2]),
        .O(BUTTONS_OUT[10]));
  LUT1 #(
    .INIT(2'h1)) 
    \BUTTONS_OUT[12]_INST_0 
       (.I0(\BUTTONS_SIG_FILT_reg_n_0_[0] ),
        .O(BUTTONS_OUT[12]));
  LUT1 #(
    .INIT(2'h1)) 
    \BUTTONS_OUT[13]_INST_0 
       (.I0(\BUTTONS_SIG_FILT_reg_n_0_[1] ),
        .O(BUTTONS_OUT[13]));
  LUT1 #(
    .INIT(2'h1)) 
    \BUTTONS_OUT[15]_INST_0 
       (.I0(\BUTTONS_SIG_FILT_reg_n_0_[15] ),
        .O(BUTTONS_OUT[15]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \BUTTONS_OUT[2]_INST_0 
       (.I0(p_0_in_0[2]),
        .O(BUTTONS_OUT[2]));
  LUT1 #(
    .INIT(2'h1)) 
    \BUTTONS_OUT[3]_INST_0 
       (.I0(p_1_in),
        .O(BUTTONS_OUT[3]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \BUTTONS_OUT[5]_INST_0 
       (.I0(p_2_in[1]),
        .O(BUTTONS_OUT[5]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \BUTTONS_OUT[6]_INST_0 
       (.I0(p_2_in[2]),
        .O(BUTTONS_OUT[6]));
  LUT1 #(
    .INIT(2'h1)) 
    \BUTTONS_OUT[7]_INST_0 
       (.I0(p_3_in),
        .O(BUTTONS_OUT[7]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \BUTTONS_OUT[8]_INST_0 
       (.I0(p_4_in[0]),
        .O(BUTTONS_OUT[8]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \BUTTONS_OUT[9]_INST_0 
       (.I0(p_4_in[1]),
        .O(BUTTONS_OUT[9]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000002)) 
    \BUTTONS_SIG[0]_i_1 
       (.I0(BUTTONS_SIG1),
        .I1(CNTR_reg[2]),
        .I2(CNTR_reg[3]),
        .I3(CNTR_reg[0]),
        .I4(CNTR_reg[1]),
        .I5(BUTTONS_SIG[0]),
        .O(\BUTTONS_SIG[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFBFF00000800)) 
    \BUTTONS_SIG[10]_i_1 
       (.I0(BUTTONS_SIG1),
        .I1(CNTR_reg[3]),
        .I2(CNTR_reg[2]),
        .I3(CNTR_reg[1]),
        .I4(CNTR_reg[0]),
        .I5(BUTTONS_SIG[10]),
        .O(\BUTTONS_SIG[10]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFBFFFFFF08000000)) 
    \BUTTONS_SIG[11]_i_1 
       (.I0(BUTTONS_SIG1),
        .I1(CNTR_reg[3]),
        .I2(CNTR_reg[2]),
        .I3(CNTR_reg[0]),
        .I4(CNTR_reg[1]),
        .I5(BUTTONS_SIG[11]),
        .O(\BUTTONS_SIG[11]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFBF00000080)) 
    \BUTTONS_SIG[12]_i_1 
       (.I0(BUTTONS_SIG1),
        .I1(CNTR_reg[2]),
        .I2(CNTR_reg[3]),
        .I3(CNTR_reg[0]),
        .I4(CNTR_reg[1]),
        .I5(BUTTONS_SIG[12]),
        .O(\BUTTONS_SIG[12]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFBFFF00008000)) 
    \BUTTONS_SIG[13]_i_1 
       (.I0(BUTTONS_SIG1),
        .I1(CNTR_reg[2]),
        .I2(CNTR_reg[3]),
        .I3(CNTR_reg[0]),
        .I4(CNTR_reg[1]),
        .I5(BUTTONS_SIG[13]),
        .O(\BUTTONS_SIG[13]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFBFFF00008000)) 
    \BUTTONS_SIG[14]_i_1 
       (.I0(BUTTONS_SIG1),
        .I1(CNTR_reg[2]),
        .I2(CNTR_reg[3]),
        .I3(CNTR_reg[1]),
        .I4(CNTR_reg[0]),
        .I5(BUTTONS_SIG[14]),
        .O(\BUTTONS_SIG[14]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hBFFFFFFF80000000)) 
    \BUTTONS_SIG[15]_i_1 
       (.I0(BUTTONS_SIG1),
        .I1(CNTR_reg[2]),
        .I2(CNTR_reg[3]),
        .I3(CNTR_reg[0]),
        .I4(CNTR_reg[1]),
        .I5(BUTTONS_SIG[15]),
        .O(\BUTTONS_SIG[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAACCAACCF0FFF000)) 
    \BUTTONS_SIG[15]_i_2 
       (.I0(ROWS_FF2[3]),
        .I1(ROWS_FF2[2]),
        .I2(ROWS_FF2[1]),
        .I3(CNTR_reg[0]),
        .I4(ROWS_FF2[0]),
        .I5(CNTR_reg[1]),
        .O(BUTTONS_SIG1));
  LUT6 #(
    .INIT(64'hFFFFFEFF00000200)) 
    \BUTTONS_SIG[1]_i_1 
       (.I0(BUTTONS_SIG1),
        .I1(CNTR_reg[2]),
        .I2(CNTR_reg[3]),
        .I3(CNTR_reg[0]),
        .I4(CNTR_reg[1]),
        .I5(BUTTONS_SIG[1]),
        .O(\BUTTONS_SIG[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEFF00000200)) 
    \BUTTONS_SIG[2]_i_1 
       (.I0(BUTTONS_SIG1),
        .I1(CNTR_reg[2]),
        .I2(CNTR_reg[3]),
        .I3(CNTR_reg[1]),
        .I4(CNTR_reg[0]),
        .I5(BUTTONS_SIG[2]),
        .O(\BUTTONS_SIG[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFEFFFFFF02000000)) 
    \BUTTONS_SIG[3]_i_1 
       (.I0(BUTTONS_SIG1),
        .I1(CNTR_reg[2]),
        .I2(CNTR_reg[3]),
        .I3(CNTR_reg[0]),
        .I4(CNTR_reg[1]),
        .I5(BUTTONS_SIG[3]),
        .O(\BUTTONS_SIG[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFB00000008)) 
    \BUTTONS_SIG[4]_i_1 
       (.I0(BUTTONS_SIG1),
        .I1(CNTR_reg[2]),
        .I2(CNTR_reg[3]),
        .I3(CNTR_reg[0]),
        .I4(CNTR_reg[1]),
        .I5(BUTTONS_SIG[4]),
        .O(\BUTTONS_SIG[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFBFF00000800)) 
    \BUTTONS_SIG[5]_i_1 
       (.I0(BUTTONS_SIG1),
        .I1(CNTR_reg[2]),
        .I2(CNTR_reg[3]),
        .I3(CNTR_reg[0]),
        .I4(CNTR_reg[1]),
        .I5(BUTTONS_SIG[5]),
        .O(\BUTTONS_SIG[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFBFF00000800)) 
    \BUTTONS_SIG[6]_i_1 
       (.I0(BUTTONS_SIG1),
        .I1(CNTR_reg[2]),
        .I2(CNTR_reg[3]),
        .I3(CNTR_reg[1]),
        .I4(CNTR_reg[0]),
        .I5(BUTTONS_SIG[6]),
        .O(\BUTTONS_SIG[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFBFFFFFF08000000)) 
    \BUTTONS_SIG[7]_i_1 
       (.I0(BUTTONS_SIG1),
        .I1(CNTR_reg[2]),
        .I2(CNTR_reg[3]),
        .I3(CNTR_reg[0]),
        .I4(CNTR_reg[1]),
        .I5(BUTTONS_SIG[7]),
        .O(\BUTTONS_SIG[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFB00000008)) 
    \BUTTONS_SIG[8]_i_1 
       (.I0(BUTTONS_SIG1),
        .I1(CNTR_reg[3]),
        .I2(CNTR_reg[2]),
        .I3(CNTR_reg[0]),
        .I4(CNTR_reg[1]),
        .I5(BUTTONS_SIG[8]),
        .O(\BUTTONS_SIG[8]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFBFF00000800)) 
    \BUTTONS_SIG[9]_i_1 
       (.I0(BUTTONS_SIG1),
        .I1(CNTR_reg[3]),
        .I2(CNTR_reg[2]),
        .I3(CNTR_reg[0]),
        .I4(CNTR_reg[1]),
        .I5(BUTTONS_SIG[9]),
        .O(\BUTTONS_SIG[9]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFB00000002)) 
    \BUTTONS_SIG_FILT[0]_i_1 
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .I3(\S_COLUMNS[0]_i_1_n_0 ),
        .I4(\BUTTONS_SIG_FILT[0]_i_2_n_0 ),
        .I5(\BUTTONS_SIG_FILT_reg_n_0_[0] ),
        .O(\BUTTONS_SIG_FILT[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \BUTTONS_SIG_FILT[0]_i_2 
       (.I0(CNTR_reg[1]),
        .I1(CNTR_reg[0]),
        .O(\BUTTONS_SIG_FILT[0]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'hFBFF0200)) 
    \BUTTONS_SIG_FILT[10]_i_1 
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .I3(\BUTTONS_SIG_FILT[10]_i_2_n_0 ),
        .I4(p_2_in[2]),
        .O(\BUTTONS_SIG_FILT[10]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT4 #(
    .INIT(16'h0020)) 
    \BUTTONS_SIG_FILT[10]_i_2 
       (.I0(CNTR_reg[3]),
        .I1(CNTR_reg[2]),
        .I2(CNTR_reg[1]),
        .I3(CNTR_reg[0]),
        .O(\BUTTONS_SIG_FILT[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFB00000002)) 
    \BUTTONS_SIG_FILT[11]_i_1 
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .I3(\BUTTONS_SIG_FILT[11]_i_2_n_0 ),
        .I4(\BUTTONS_SIG_FILT[15]_i_2_n_0 ),
        .I5(\BUTTONS_SIG_FILT_reg_n_0_[11] ),
        .O(\BUTTONS_SIG_FILT[11]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \BUTTONS_SIG_FILT[11]_i_2 
       (.I0(CNTR_reg[2]),
        .I1(CNTR_reg[3]),
        .O(\BUTTONS_SIG_FILT[11]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'hFBFF0200)) 
    \BUTTONS_SIG_FILT[12]_i_1 
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .I3(\BUTTONS_SIG_FILT[12]_i_2_n_0 ),
        .I4(p_4_in[0]),
        .O(\BUTTONS_SIG_FILT[12]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT4 #(
    .INIT(16'h0008)) 
    \BUTTONS_SIG_FILT[12]_i_2 
       (.I0(CNTR_reg[2]),
        .I1(CNTR_reg[3]),
        .I2(CNTR_reg[0]),
        .I3(CNTR_reg[1]),
        .O(\BUTTONS_SIG_FILT[12]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hFBFF0200)) 
    \BUTTONS_SIG_FILT[13]_i_1 
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .I3(\BUTTONS_SIG_FILT[13]_i_2_n_0 ),
        .I4(p_4_in[1]),
        .O(\BUTTONS_SIG_FILT[13]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT4 #(
    .INIT(16'h0080)) 
    \BUTTONS_SIG_FILT[13]_i_2 
       (.I0(CNTR_reg[2]),
        .I1(CNTR_reg[3]),
        .I2(CNTR_reg[0]),
        .I3(CNTR_reg[1]),
        .O(\BUTTONS_SIG_FILT[13]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hFBFF0200)) 
    \BUTTONS_SIG_FILT[14]_i_1 
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .I3(\BUTTONS_SIG_FILT[14]_i_2_n_0 ),
        .I4(p_4_in[2]),
        .O(\BUTTONS_SIG_FILT[14]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'h0080)) 
    \BUTTONS_SIG_FILT[14]_i_2 
       (.I0(CNTR_reg[2]),
        .I1(CNTR_reg[3]),
        .I2(CNTR_reg[1]),
        .I3(CNTR_reg[0]),
        .O(\BUTTONS_SIG_FILT[14]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFB00000002)) 
    \BUTTONS_SIG_FILT[15]_i_1 
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .I3(\S_COLUMNS[3]_i_1_n_0 ),
        .I4(\BUTTONS_SIG_FILT[15]_i_2_n_0 ),
        .I5(\BUTTONS_SIG_FILT_reg_n_0_[15] ),
        .O(\BUTTONS_SIG_FILT[15]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \BUTTONS_SIG_FILT[15]_i_2 
       (.I0(CNTR_reg[1]),
        .I1(CNTR_reg[0]),
        .O(\BUTTONS_SIG_FILT[15]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFB00000002)) 
    \BUTTONS_SIG_FILT[1]_i_1 
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .I3(\S_COLUMNS[0]_i_1_n_0 ),
        .I4(\BUTTONS_SIG_FILT[1]_i_2_n_0 ),
        .I5(\BUTTONS_SIG_FILT_reg_n_0_[1] ),
        .O(\BUTTONS_SIG_FILT[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \BUTTONS_SIG_FILT[1]_i_2 
       (.I0(CNTR_reg[1]),
        .I1(CNTR_reg[0]),
        .O(\BUTTONS_SIG_FILT[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFB00000002)) 
    \BUTTONS_SIG_FILT[2]_i_1 
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .I3(\S_COLUMNS[0]_i_1_n_0 ),
        .I4(\BUTTONS_SIG_FILT[2]_i_2_n_0 ),
        .I5(\BUTTONS_SIG_FILT_reg_n_0_[2] ),
        .O(\BUTTONS_SIG_FILT[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \BUTTONS_SIG_FILT[2]_i_2 
       (.I0(CNTR_reg[0]),
        .I1(CNTR_reg[1]),
        .O(\BUTTONS_SIG_FILT[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFB00000002)) 
    \BUTTONS_SIG_FILT[3]_i_1 
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .I3(\S_COLUMNS[0]_i_1_n_0 ),
        .I4(\BUTTONS_SIG_FILT[15]_i_2_n_0 ),
        .I5(p_1_in),
        .O(\BUTTONS_SIG_FILT[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'hFBFF0200)) 
    \BUTTONS_SIG_FILT[4]_i_1 
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .I3(\BUTTONS_SIG_FILT[4]_i_2_n_0 ),
        .I4(p_0_in_0[0]),
        .O(\BUTTONS_SIG_FILT[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT4 #(
    .INIT(16'h0002)) 
    \BUTTONS_SIG_FILT[4]_i_2 
       (.I0(CNTR_reg[2]),
        .I1(CNTR_reg[3]),
        .I2(CNTR_reg[0]),
        .I3(CNTR_reg[1]),
        .O(\BUTTONS_SIG_FILT[4]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'hFBFF0200)) 
    \BUTTONS_SIG_FILT[5]_i_1 
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .I3(\BUTTONS_SIG_FILT[5]_i_2_n_0 ),
        .I4(p_0_in_0[1]),
        .O(\BUTTONS_SIG_FILT[5]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT4 #(
    .INIT(16'h0020)) 
    \BUTTONS_SIG_FILT[5]_i_2 
       (.I0(CNTR_reg[2]),
        .I1(CNTR_reg[3]),
        .I2(CNTR_reg[0]),
        .I3(CNTR_reg[1]),
        .O(\BUTTONS_SIG_FILT[5]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'hFBFF0200)) 
    \BUTTONS_SIG_FILT[6]_i_1 
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .I3(\BUTTONS_SIG_FILT[6]_i_2_n_0 ),
        .I4(p_0_in_0[2]),
        .O(\BUTTONS_SIG_FILT[6]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT4 #(
    .INIT(16'h0020)) 
    \BUTTONS_SIG_FILT[6]_i_2 
       (.I0(CNTR_reg[2]),
        .I1(CNTR_reg[3]),
        .I2(CNTR_reg[1]),
        .I3(CNTR_reg[0]),
        .O(\BUTTONS_SIG_FILT[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFB00000002)) 
    \BUTTONS_SIG_FILT[7]_i_1 
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .I3(\S_COLUMNS[1]_i_1_n_0 ),
        .I4(\BUTTONS_SIG_FILT[15]_i_2_n_0 ),
        .I5(p_3_in),
        .O(\BUTTONS_SIG_FILT[7]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'hFBFF0200)) 
    \BUTTONS_SIG_FILT[8]_i_1 
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .I3(\BUTTONS_SIG_FILT[8]_i_2_n_0 ),
        .I4(p_2_in[0]),
        .O(\BUTTONS_SIG_FILT[8]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT4 #(
    .INIT(16'h0002)) 
    \BUTTONS_SIG_FILT[8]_i_2 
       (.I0(CNTR_reg[3]),
        .I1(CNTR_reg[2]),
        .I2(CNTR_reg[0]),
        .I3(CNTR_reg[1]),
        .O(\BUTTONS_SIG_FILT[8]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'hFBFF0200)) 
    \BUTTONS_SIG_FILT[9]_i_1 
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .I3(\BUTTONS_SIG_FILT[9]_i_2_n_0 ),
        .I4(p_2_in[1]),
        .O(\BUTTONS_SIG_FILT[9]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT4 #(
    .INIT(16'h0020)) 
    \BUTTONS_SIG_FILT[9]_i_2 
       (.I0(CNTR_reg[3]),
        .I1(CNTR_reg[2]),
        .I2(CNTR_reg[0]),
        .I3(CNTR_reg[1]),
        .O(\BUTTONS_SIG_FILT[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b1)) 
    \BUTTONS_SIG_FILT_reg[0] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG_FILT[0]_i_1_n_0 ),
        .Q(\BUTTONS_SIG_FILT_reg_n_0_[0] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \BUTTONS_SIG_FILT_reg[10] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG_FILT[10]_i_1_n_0 ),
        .Q(p_2_in[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \BUTTONS_SIG_FILT_reg[11] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG_FILT[11]_i_1_n_0 ),
        .Q(\BUTTONS_SIG_FILT_reg_n_0_[11] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \BUTTONS_SIG_FILT_reg[12] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG_FILT[12]_i_1_n_0 ),
        .Q(p_4_in[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \BUTTONS_SIG_FILT_reg[13] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG_FILT[13]_i_1_n_0 ),
        .Q(p_4_in[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \BUTTONS_SIG_FILT_reg[14] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG_FILT[14]_i_1_n_0 ),
        .Q(p_4_in[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \BUTTONS_SIG_FILT_reg[15] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG_FILT[15]_i_1_n_0 ),
        .Q(\BUTTONS_SIG_FILT_reg_n_0_[15] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \BUTTONS_SIG_FILT_reg[1] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG_FILT[1]_i_1_n_0 ),
        .Q(\BUTTONS_SIG_FILT_reg_n_0_[1] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \BUTTONS_SIG_FILT_reg[2] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG_FILT[2]_i_1_n_0 ),
        .Q(\BUTTONS_SIG_FILT_reg_n_0_[2] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \BUTTONS_SIG_FILT_reg[3] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG_FILT[3]_i_1_n_0 ),
        .Q(p_1_in),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \BUTTONS_SIG_FILT_reg[4] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG_FILT[4]_i_1_n_0 ),
        .Q(p_0_in_0[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \BUTTONS_SIG_FILT_reg[5] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG_FILT[5]_i_1_n_0 ),
        .Q(p_0_in_0[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \BUTTONS_SIG_FILT_reg[6] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG_FILT[6]_i_1_n_0 ),
        .Q(p_0_in_0[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \BUTTONS_SIG_FILT_reg[7] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG_FILT[7]_i_1_n_0 ),
        .Q(p_3_in),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \BUTTONS_SIG_FILT_reg[8] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG_FILT[8]_i_1_n_0 ),
        .Q(p_2_in[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \BUTTONS_SIG_FILT_reg[9] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG_FILT[9]_i_1_n_0 ),
        .Q(p_2_in[1]),
        .R(1'b0));
  FDRE \BUTTONS_SIG_reg[0] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG[0]_i_1_n_0 ),
        .Q(BUTTONS_SIG[0]),
        .R(1'b0));
  FDRE \BUTTONS_SIG_reg[10] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG[10]_i_1_n_0 ),
        .Q(BUTTONS_SIG[10]),
        .R(1'b0));
  FDRE \BUTTONS_SIG_reg[11] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG[11]_i_1_n_0 ),
        .Q(BUTTONS_SIG[11]),
        .R(1'b0));
  FDRE \BUTTONS_SIG_reg[12] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG[12]_i_1_n_0 ),
        .Q(BUTTONS_SIG[12]),
        .R(1'b0));
  FDRE \BUTTONS_SIG_reg[13] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG[13]_i_1_n_0 ),
        .Q(BUTTONS_SIG[13]),
        .R(1'b0));
  FDRE \BUTTONS_SIG_reg[14] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG[14]_i_1_n_0 ),
        .Q(BUTTONS_SIG[14]),
        .R(1'b0));
  FDRE \BUTTONS_SIG_reg[15] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG[15]_i_1_n_0 ),
        .Q(BUTTONS_SIG[15]),
        .R(1'b0));
  FDRE \BUTTONS_SIG_reg[1] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG[1]_i_1_n_0 ),
        .Q(BUTTONS_SIG[1]),
        .R(1'b0));
  FDRE \BUTTONS_SIG_reg[2] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG[2]_i_1_n_0 ),
        .Q(BUTTONS_SIG[2]),
        .R(1'b0));
  FDRE \BUTTONS_SIG_reg[3] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG[3]_i_1_n_0 ),
        .Q(BUTTONS_SIG[3]),
        .R(1'b0));
  FDRE \BUTTONS_SIG_reg[4] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG[4]_i_1_n_0 ),
        .Q(BUTTONS_SIG[4]),
        .R(1'b0));
  FDRE \BUTTONS_SIG_reg[5] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG[5]_i_1_n_0 ),
        .Q(BUTTONS_SIG[5]),
        .R(1'b0));
  FDRE \BUTTONS_SIG_reg[6] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG[6]_i_1_n_0 ),
        .Q(BUTTONS_SIG[6]),
        .R(1'b0));
  FDRE \BUTTONS_SIG_reg[7] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG[7]_i_1_n_0 ),
        .Q(BUTTONS_SIG[7]),
        .R(1'b0));
  FDRE \BUTTONS_SIG_reg[8] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG[8]_i_1_n_0 ),
        .Q(BUTTONS_SIG[8]),
        .R(1'b0));
  FDRE \BUTTONS_SIG_reg[9] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\BUTTONS_SIG[9]_i_1_n_0 ),
        .Q(BUTTONS_SIG[9]),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h6)) 
    CLK_LOW_F_i_1
       (.I0(\LOW_F_CNT[0]_i_1_n_0 ),
        .I1(CLK_LOW_F),
        .O(CLK_LOW_F_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    CLK_LOW_F_reg
       (.C(CLK_5M),
        .CE(1'b1),
        .D(CLK_LOW_F_i_1_n_0),
        .Q(CLK_LOW_F),
        .R(1'b0));
  LUT1 #(
    .INIT(2'h1)) 
    \CNTR[0]_i_1 
       (.I0(CNTR_reg[0]),
        .O(\CNTR[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \CNTR[1]_i_1 
       (.I0(CNTR_reg[0]),
        .I1(CNTR_reg[1]),
        .O(p_0_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \CNTR[2]_i_1 
       (.I0(CNTR_reg[0]),
        .I1(CNTR_reg[1]),
        .I2(CNTR_reg[2]),
        .O(\CNTR[2]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h8000)) 
    \CNTR[3]_i_1 
       (.I0(CNTR_reg[2]),
        .I1(CNTR_reg[3]),
        .I2(CNTR_reg[1]),
        .I3(CNTR_reg[0]),
        .O(clear));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \CNTR[3]_i_2 
       (.I0(CNTR_reg[1]),
        .I1(CNTR_reg[0]),
        .I2(CNTR_reg[2]),
        .I3(CNTR_reg[3]),
        .O(p_0_in[3]));
  FDRE #(
    .INIT(1'b0)) 
    \CNTR_reg[0] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\CNTR[0]_i_1_n_0 ),
        .Q(CNTR_reg[0]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \CNTR_reg[1] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(p_0_in[1]),
        .Q(CNTR_reg[1]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \CNTR_reg[2] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\CNTR[2]_i_1_n_0 ),
        .Q(CNTR_reg[2]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \CNTR_reg[3] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(p_0_in[3]),
        .Q(CNTR_reg[3]),
        .R(clear));
  (* RTL_RAM_BITS = "80" *) 
  (* RTL_RAM_NAME = "Uvod2_BUTTON_MATRIX_0_0/inst/DBNC_CNT_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* XILINX_LEGACY_PRIM = "RAM16X1S" *) 
  (* XILINX_TRANSFORM_PINMAP = "GND:A4" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "0" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    DBNC_CNT_reg_0_15_0_0
       (.A0(CNTR_reg[0]),
        .A1(CNTR_reg[1]),
        .A2(CNTR_reg[2]),
        .A3(CNTR_reg[3]),
        .A4(1'b0),
        .D(DBNC_CNT[0]),
        .O(p_0_out[0]),
        .WCLK(CLK_LOW_F),
        .WE(1'b1));
  LUT6 #(
    .INIT(64'h000047B800000000)) 
    DBNC_CNT_reg_0_15_0_0_i_1
       (.I0(DBNC_CNT_reg_0_15_0_0_i_2_n_0),
        .I1(CNTR_reg[3]),
        .I2(DBNC_CNT_reg_0_15_0_0_i_3_n_0),
        .I3(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I4(p_0_out[0]),
        .I5(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .O(DBNC_CNT[0]));
  MUXF7 DBNC_CNT_reg_0_15_0_0_i_10
       (.I0(DBNC_CNT_reg_0_15_0_0_i_12_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_13_n_0),
        .O(DBNC_CNT_reg_0_15_0_0_i_10_n_0),
        .S(CNTR_reg[2]));
  MUXF7 DBNC_CNT_reg_0_15_0_0_i_11
       (.I0(DBNC_CNT_reg_0_15_0_0_i_14_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_15_n_0),
        .O(DBNC_CNT_reg_0_15_0_0_i_11_n_0),
        .S(CNTR_reg[2]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    DBNC_CNT_reg_0_15_0_0_i_12
       (.I0(p_1_in),
        .I1(\BUTTONS_SIG_FILT_reg_n_0_[2] ),
        .I2(CNTR_reg[1]),
        .I3(\BUTTONS_SIG_FILT_reg_n_0_[1] ),
        .I4(CNTR_reg[0]),
        .I5(\BUTTONS_SIG_FILT_reg_n_0_[0] ),
        .O(DBNC_CNT_reg_0_15_0_0_i_12_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    DBNC_CNT_reg_0_15_0_0_i_13
       (.I0(p_3_in),
        .I1(p_0_in_0[2]),
        .I2(CNTR_reg[1]),
        .I3(p_0_in_0[1]),
        .I4(CNTR_reg[0]),
        .I5(p_0_in_0[0]),
        .O(DBNC_CNT_reg_0_15_0_0_i_13_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    DBNC_CNT_reg_0_15_0_0_i_14
       (.I0(\BUTTONS_SIG_FILT_reg_n_0_[11] ),
        .I1(p_2_in[2]),
        .I2(CNTR_reg[1]),
        .I3(p_2_in[1]),
        .I4(CNTR_reg[0]),
        .I5(p_2_in[0]),
        .O(DBNC_CNT_reg_0_15_0_0_i_14_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    DBNC_CNT_reg_0_15_0_0_i_15
       (.I0(\BUTTONS_SIG_FILT_reg_n_0_[15] ),
        .I1(p_4_in[2]),
        .I2(CNTR_reg[1]),
        .I3(p_4_in[1]),
        .I4(CNTR_reg[0]),
        .I5(p_4_in[0]),
        .O(DBNC_CNT_reg_0_15_0_0_i_15_n_0));
  MUXF7 DBNC_CNT_reg_0_15_0_0_i_2
       (.I0(DBNC_CNT_reg_0_15_0_0_i_6_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_7_n_0),
        .O(DBNC_CNT_reg_0_15_0_0_i_2_n_0),
        .S(CNTR_reg[2]));
  MUXF7 DBNC_CNT_reg_0_15_0_0_i_3
       (.I0(DBNC_CNT_reg_0_15_0_0_i_8_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_9_n_0),
        .O(DBNC_CNT_reg_0_15_0_0_i_3_n_0),
        .S(CNTR_reg[2]));
  MUXF8 DBNC_CNT_reg_0_15_0_0_i_4
       (.I0(DBNC_CNT_reg_0_15_0_0_i_10_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_11_n_0),
        .O(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .S(CNTR_reg[3]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'h00007FFF)) 
    DBNC_CNT_reg_0_15_0_0_i_5
       (.I0(p_0_out[0]),
        .I1(p_0_out[1]),
        .I2(p_0_out[3]),
        .I3(p_0_out[2]),
        .I4(p_0_out[4]),
        .O(DBNC_CNT_reg_0_15_0_0_i_5_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    DBNC_CNT_reg_0_15_0_0_i_6
       (.I0(BUTTONS_SIG[11]),
        .I1(BUTTONS_SIG[10]),
        .I2(CNTR_reg[1]),
        .I3(BUTTONS_SIG[9]),
        .I4(CNTR_reg[0]),
        .I5(BUTTONS_SIG[8]),
        .O(DBNC_CNT_reg_0_15_0_0_i_6_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    DBNC_CNT_reg_0_15_0_0_i_7
       (.I0(BUTTONS_SIG[15]),
        .I1(BUTTONS_SIG[14]),
        .I2(CNTR_reg[1]),
        .I3(BUTTONS_SIG[13]),
        .I4(CNTR_reg[0]),
        .I5(BUTTONS_SIG[12]),
        .O(DBNC_CNT_reg_0_15_0_0_i_7_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    DBNC_CNT_reg_0_15_0_0_i_8
       (.I0(BUTTONS_SIG[3]),
        .I1(BUTTONS_SIG[2]),
        .I2(CNTR_reg[1]),
        .I3(BUTTONS_SIG[1]),
        .I4(CNTR_reg[0]),
        .I5(BUTTONS_SIG[0]),
        .O(DBNC_CNT_reg_0_15_0_0_i_8_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    DBNC_CNT_reg_0_15_0_0_i_9
       (.I0(BUTTONS_SIG[7]),
        .I1(BUTTONS_SIG[6]),
        .I2(CNTR_reg[1]),
        .I3(BUTTONS_SIG[5]),
        .I4(CNTR_reg[0]),
        .I5(BUTTONS_SIG[4]),
        .O(DBNC_CNT_reg_0_15_0_0_i_9_n_0));
  (* RTL_RAM_BITS = "80" *) 
  (* RTL_RAM_NAME = "Uvod2_BUTTON_MATRIX_0_0/inst/DBNC_CNT_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* XILINX_LEGACY_PRIM = "RAM16X1S" *) 
  (* XILINX_TRANSFORM_PINMAP = "GND:A4" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "1" *) 
  (* ram_slice_end = "1" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    DBNC_CNT_reg_0_15_1_1
       (.A0(CNTR_reg[0]),
        .A1(CNTR_reg[1]),
        .A2(CNTR_reg[2]),
        .A3(CNTR_reg[3]),
        .A4(1'b0),
        .D(DBNC_CNT[1]),
        .O(p_0_out[1]),
        .WCLK(CLK_LOW_F),
        .WE(1'b1));
  LUT5 #(
    .INIT(32'h06600000)) 
    DBNC_CNT_reg_0_15_1_1_i_1
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(p_0_out[0]),
        .I3(p_0_out[1]),
        .I4(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .O(DBNC_CNT[1]));
  MUXF8 DBNC_CNT_reg_0_15_1_1_i_2
       (.I0(DBNC_CNT_reg_0_15_0_0_i_3_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_2_n_0),
        .O(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .S(CNTR_reg[3]));
  (* RTL_RAM_BITS = "80" *) 
  (* RTL_RAM_NAME = "Uvod2_BUTTON_MATRIX_0_0/inst/DBNC_CNT_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* XILINX_LEGACY_PRIM = "RAM16X1S" *) 
  (* XILINX_TRANSFORM_PINMAP = "GND:A4" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "2" *) 
  (* ram_slice_end = "2" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    DBNC_CNT_reg_0_15_2_2
       (.A0(CNTR_reg[0]),
        .A1(CNTR_reg[1]),
        .A2(CNTR_reg[2]),
        .A3(CNTR_reg[3]),
        .A4(1'b0),
        .D(DBNC_CNT[2]),
        .O(p_0_out[2]),
        .WCLK(CLK_LOW_F),
        .WE(1'b1));
  LUT6 #(
    .INIT(64'h0666600000000000)) 
    DBNC_CNT_reg_0_15_2_2_i_1
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(p_0_out[0]),
        .I3(p_0_out[1]),
        .I4(p_0_out[2]),
        .I5(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .O(DBNC_CNT[2]));
  (* RTL_RAM_BITS = "80" *) 
  (* RTL_RAM_NAME = "Uvod2_BUTTON_MATRIX_0_0/inst/DBNC_CNT_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* XILINX_LEGACY_PRIM = "RAM16X1S" *) 
  (* XILINX_TRANSFORM_PINMAP = "GND:A4" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "3" *) 
  (* ram_slice_end = "3" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    DBNC_CNT_reg_0_15_3_3
       (.A0(CNTR_reg[0]),
        .A1(CNTR_reg[1]),
        .A2(CNTR_reg[2]),
        .A3(CNTR_reg[3]),
        .A4(1'b0),
        .D(DBNC_CNT[3]),
        .O(p_0_out[3]),
        .WCLK(CLK_LOW_F),
        .WE(1'b1));
  LUT5 #(
    .INIT(32'h06600000)) 
    DBNC_CNT_reg_0_15_3_3_i_1
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_3_3_i_2_n_0),
        .I3(p_0_out[3]),
        .I4(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .O(DBNC_CNT[3]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'h80)) 
    DBNC_CNT_reg_0_15_3_3_i_2
       (.I0(p_0_out[2]),
        .I1(p_0_out[0]),
        .I2(p_0_out[1]),
        .O(DBNC_CNT_reg_0_15_3_3_i_2_n_0));
  (* RTL_RAM_BITS = "80" *) 
  (* RTL_RAM_NAME = "Uvod2_BUTTON_MATRIX_0_0/inst/DBNC_CNT_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* XILINX_LEGACY_PRIM = "RAM16X1S" *) 
  (* XILINX_TRANSFORM_PINMAP = "GND:A4" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "4" *) 
  (* ram_slice_end = "4" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    DBNC_CNT_reg_0_15_4_4
       (.A0(CNTR_reg[0]),
        .A1(CNTR_reg[1]),
        .A2(CNTR_reg[2]),
        .A3(CNTR_reg[3]),
        .A4(1'b0),
        .D(DBNC_CNT[4]),
        .O(p_0_out[4]),
        .WCLK(CLK_LOW_F),
        .WE(1'b1));
  LUT6 #(
    .INIT(64'h0666600000000000)) 
    DBNC_CNT_reg_0_15_4_4_i_1
       (.I0(DBNC_CNT_reg_0_15_1_1_i_2_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I2(DBNC_CNT_reg_0_15_3_3_i_2_n_0),
        .I3(p_0_out[3]),
        .I4(p_0_out[4]),
        .I5(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .O(DBNC_CNT[4]));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \LOW_F_CNT[0]_i_1 
       (.I0(\LOW_F_CNT[0]_i_3_n_0 ),
        .I1(\LOW_F_CNT[0]_i_4_n_0 ),
        .I2(\LOW_F_CNT[0]_i_5_n_0 ),
        .I3(\LOW_F_CNT[0]_i_6_n_0 ),
        .I4(\LOW_F_CNT[0]_i_7_n_0 ),
        .I5(\LOW_F_CNT[0]_i_8_n_0 ),
        .O(\LOW_F_CNT[0]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[0]_i_10 
       (.I0(LOW_F_CNT_reg[2]),
        .O(\LOW_F_CNT[0]_i_10_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[0]_i_11 
       (.I0(LOW_F_CNT_reg[1]),
        .O(\LOW_F_CNT[0]_i_11_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[0]_i_12 
       (.I0(LOW_F_CNT_reg[0]),
        .O(\LOW_F_CNT[0]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \LOW_F_CNT[0]_i_3 
       (.I0(LOW_F_CNT_reg[25]),
        .I1(LOW_F_CNT_reg[26]),
        .I2(LOW_F_CNT_reg[24]),
        .I3(LOW_F_CNT_reg[28]),
        .I4(LOW_F_CNT_reg[29]),
        .I5(LOW_F_CNT_reg[27]),
        .O(\LOW_F_CNT[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \LOW_F_CNT[0]_i_4 
       (.I0(LOW_F_CNT_reg[7]),
        .I1(LOW_F_CNT_reg[8]),
        .I2(LOW_F_CNT_reg[6]),
        .I3(LOW_F_CNT_reg[10]),
        .I4(LOW_F_CNT_reg[11]),
        .I5(LOW_F_CNT_reg[9]),
        .O(\LOW_F_CNT[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \LOW_F_CNT[0]_i_5 
       (.I0(LOW_F_CNT_reg[19]),
        .I1(LOW_F_CNT_reg[20]),
        .I2(LOW_F_CNT_reg[18]),
        .I3(LOW_F_CNT_reg[22]),
        .I4(LOW_F_CNT_reg[23]),
        .I5(LOW_F_CNT_reg[21]),
        .O(\LOW_F_CNT[0]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \LOW_F_CNT[0]_i_6 
       (.I0(LOW_F_CNT_reg[13]),
        .I1(LOW_F_CNT_reg[14]),
        .I2(LOW_F_CNT_reg[12]),
        .I3(LOW_F_CNT_reg[16]),
        .I4(LOW_F_CNT_reg[17]),
        .I5(LOW_F_CNT_reg[15]),
        .O(\LOW_F_CNT[0]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \LOW_F_CNT[0]_i_7 
       (.I0(LOW_F_CNT_reg[30]),
        .I1(LOW_F_CNT_reg[31]),
        .O(\LOW_F_CNT[0]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \LOW_F_CNT[0]_i_8 
       (.I0(LOW_F_CNT_reg[1]),
        .I1(LOW_F_CNT_reg[2]),
        .I2(LOW_F_CNT_reg[0]),
        .I3(LOW_F_CNT_reg[4]),
        .I4(LOW_F_CNT_reg[5]),
        .I5(LOW_F_CNT_reg[3]),
        .O(\LOW_F_CNT[0]_i_8_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[0]_i_9 
       (.I0(LOW_F_CNT_reg[3]),
        .O(\LOW_F_CNT[0]_i_9_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[12]_i_2 
       (.I0(LOW_F_CNT_reg[15]),
        .O(\LOW_F_CNT[12]_i_2_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[12]_i_3 
       (.I0(LOW_F_CNT_reg[14]),
        .O(\LOW_F_CNT[12]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[12]_i_4 
       (.I0(LOW_F_CNT_reg[13]),
        .O(\LOW_F_CNT[12]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[12]_i_5 
       (.I0(LOW_F_CNT_reg[12]),
        .O(\LOW_F_CNT[12]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[16]_i_2 
       (.I0(LOW_F_CNT_reg[19]),
        .O(\LOW_F_CNT[16]_i_2_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[16]_i_3 
       (.I0(LOW_F_CNT_reg[18]),
        .O(\LOW_F_CNT[16]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[16]_i_4 
       (.I0(LOW_F_CNT_reg[17]),
        .O(\LOW_F_CNT[16]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[16]_i_5 
       (.I0(LOW_F_CNT_reg[16]),
        .O(\LOW_F_CNT[16]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[20]_i_2 
       (.I0(LOW_F_CNT_reg[23]),
        .O(\LOW_F_CNT[20]_i_2_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[20]_i_3 
       (.I0(LOW_F_CNT_reg[22]),
        .O(\LOW_F_CNT[20]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[20]_i_4 
       (.I0(LOW_F_CNT_reg[21]),
        .O(\LOW_F_CNT[20]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[20]_i_5 
       (.I0(LOW_F_CNT_reg[20]),
        .O(\LOW_F_CNT[20]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[24]_i_2 
       (.I0(LOW_F_CNT_reg[27]),
        .O(\LOW_F_CNT[24]_i_2_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[24]_i_3 
       (.I0(LOW_F_CNT_reg[26]),
        .O(\LOW_F_CNT[24]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[24]_i_4 
       (.I0(LOW_F_CNT_reg[25]),
        .O(\LOW_F_CNT[24]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[24]_i_5 
       (.I0(LOW_F_CNT_reg[24]),
        .O(\LOW_F_CNT[24]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[28]_i_2 
       (.I0(LOW_F_CNT_reg[31]),
        .O(\LOW_F_CNT[28]_i_2_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[28]_i_3 
       (.I0(LOW_F_CNT_reg[30]),
        .O(\LOW_F_CNT[28]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[28]_i_4 
       (.I0(LOW_F_CNT_reg[29]),
        .O(\LOW_F_CNT[28]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[28]_i_5 
       (.I0(LOW_F_CNT_reg[28]),
        .O(\LOW_F_CNT[28]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[4]_i_2 
       (.I0(LOW_F_CNT_reg[7]),
        .O(\LOW_F_CNT[4]_i_2_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[4]_i_3 
       (.I0(LOW_F_CNT_reg[6]),
        .O(\LOW_F_CNT[4]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[4]_i_4 
       (.I0(LOW_F_CNT_reg[5]),
        .O(\LOW_F_CNT[4]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[4]_i_5 
       (.I0(LOW_F_CNT_reg[4]),
        .O(\LOW_F_CNT[4]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[8]_i_2 
       (.I0(LOW_F_CNT_reg[11]),
        .O(\LOW_F_CNT[8]_i_2_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[8]_i_3 
       (.I0(LOW_F_CNT_reg[10]),
        .O(\LOW_F_CNT[8]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[8]_i_4 
       (.I0(LOW_F_CNT_reg[9]),
        .O(\LOW_F_CNT[8]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \LOW_F_CNT[8]_i_5 
       (.I0(LOW_F_CNT_reg[8]),
        .O(\LOW_F_CNT[8]_i_5_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[0] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[0]_i_2_n_7 ),
        .Q(LOW_F_CNT_reg[0]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \LOW_F_CNT_reg[0]_i_2 
       (.CI(1'b0),
        .CO({\LOW_F_CNT_reg[0]_i_2_n_0 ,\LOW_F_CNT_reg[0]_i_2_n_1 ,\LOW_F_CNT_reg[0]_i_2_n_2 ,\LOW_F_CNT_reg[0]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b1,1'b1,1'b1,1'b1}),
        .O({\LOW_F_CNT_reg[0]_i_2_n_4 ,\LOW_F_CNT_reg[0]_i_2_n_5 ,\LOW_F_CNT_reg[0]_i_2_n_6 ,\LOW_F_CNT_reg[0]_i_2_n_7 }),
        .S({\LOW_F_CNT[0]_i_9_n_0 ,\LOW_F_CNT[0]_i_10_n_0 ,\LOW_F_CNT[0]_i_11_n_0 ,\LOW_F_CNT[0]_i_12_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[10] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[8]_i_1_n_5 ),
        .Q(LOW_F_CNT_reg[10]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[11] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[8]_i_1_n_4 ),
        .Q(LOW_F_CNT_reg[11]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[12] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[12]_i_1_n_7 ),
        .Q(LOW_F_CNT_reg[12]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \LOW_F_CNT_reg[12]_i_1 
       (.CI(\LOW_F_CNT_reg[8]_i_1_n_0 ),
        .CO({\LOW_F_CNT_reg[12]_i_1_n_0 ,\LOW_F_CNT_reg[12]_i_1_n_1 ,\LOW_F_CNT_reg[12]_i_1_n_2 ,\LOW_F_CNT_reg[12]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b1,1'b1,1'b1,1'b1}),
        .O({\LOW_F_CNT_reg[12]_i_1_n_4 ,\LOW_F_CNT_reg[12]_i_1_n_5 ,\LOW_F_CNT_reg[12]_i_1_n_6 ,\LOW_F_CNT_reg[12]_i_1_n_7 }),
        .S({\LOW_F_CNT[12]_i_2_n_0 ,\LOW_F_CNT[12]_i_3_n_0 ,\LOW_F_CNT[12]_i_4_n_0 ,\LOW_F_CNT[12]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[13] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[12]_i_1_n_6 ),
        .Q(LOW_F_CNT_reg[13]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[14] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[12]_i_1_n_5 ),
        .Q(LOW_F_CNT_reg[14]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[15] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[12]_i_1_n_4 ),
        .Q(LOW_F_CNT_reg[15]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[16] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[16]_i_1_n_7 ),
        .Q(LOW_F_CNT_reg[16]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \LOW_F_CNT_reg[16]_i_1 
       (.CI(\LOW_F_CNT_reg[12]_i_1_n_0 ),
        .CO({\LOW_F_CNT_reg[16]_i_1_n_0 ,\LOW_F_CNT_reg[16]_i_1_n_1 ,\LOW_F_CNT_reg[16]_i_1_n_2 ,\LOW_F_CNT_reg[16]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b1,1'b1,1'b1,1'b1}),
        .O({\LOW_F_CNT_reg[16]_i_1_n_4 ,\LOW_F_CNT_reg[16]_i_1_n_5 ,\LOW_F_CNT_reg[16]_i_1_n_6 ,\LOW_F_CNT_reg[16]_i_1_n_7 }),
        .S({\LOW_F_CNT[16]_i_2_n_0 ,\LOW_F_CNT[16]_i_3_n_0 ,\LOW_F_CNT[16]_i_4_n_0 ,\LOW_F_CNT[16]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[17] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[16]_i_1_n_6 ),
        .Q(LOW_F_CNT_reg[17]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[18] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[16]_i_1_n_5 ),
        .Q(LOW_F_CNT_reg[18]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[19] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[16]_i_1_n_4 ),
        .Q(LOW_F_CNT_reg[19]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[1] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[0]_i_2_n_6 ),
        .Q(LOW_F_CNT_reg[1]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[20] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[20]_i_1_n_7 ),
        .Q(LOW_F_CNT_reg[20]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \LOW_F_CNT_reg[20]_i_1 
       (.CI(\LOW_F_CNT_reg[16]_i_1_n_0 ),
        .CO({\LOW_F_CNT_reg[20]_i_1_n_0 ,\LOW_F_CNT_reg[20]_i_1_n_1 ,\LOW_F_CNT_reg[20]_i_1_n_2 ,\LOW_F_CNT_reg[20]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b1,1'b1,1'b1,1'b1}),
        .O({\LOW_F_CNT_reg[20]_i_1_n_4 ,\LOW_F_CNT_reg[20]_i_1_n_5 ,\LOW_F_CNT_reg[20]_i_1_n_6 ,\LOW_F_CNT_reg[20]_i_1_n_7 }),
        .S({\LOW_F_CNT[20]_i_2_n_0 ,\LOW_F_CNT[20]_i_3_n_0 ,\LOW_F_CNT[20]_i_4_n_0 ,\LOW_F_CNT[20]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[21] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[20]_i_1_n_6 ),
        .Q(LOW_F_CNT_reg[21]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[22] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[20]_i_1_n_5 ),
        .Q(LOW_F_CNT_reg[22]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[23] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[20]_i_1_n_4 ),
        .Q(LOW_F_CNT_reg[23]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[24] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[24]_i_1_n_7 ),
        .Q(LOW_F_CNT_reg[24]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \LOW_F_CNT_reg[24]_i_1 
       (.CI(\LOW_F_CNT_reg[20]_i_1_n_0 ),
        .CO({\LOW_F_CNT_reg[24]_i_1_n_0 ,\LOW_F_CNT_reg[24]_i_1_n_1 ,\LOW_F_CNT_reg[24]_i_1_n_2 ,\LOW_F_CNT_reg[24]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b1,1'b1,1'b1,1'b1}),
        .O({\LOW_F_CNT_reg[24]_i_1_n_4 ,\LOW_F_CNT_reg[24]_i_1_n_5 ,\LOW_F_CNT_reg[24]_i_1_n_6 ,\LOW_F_CNT_reg[24]_i_1_n_7 }),
        .S({\LOW_F_CNT[24]_i_2_n_0 ,\LOW_F_CNT[24]_i_3_n_0 ,\LOW_F_CNT[24]_i_4_n_0 ,\LOW_F_CNT[24]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[25] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[24]_i_1_n_6 ),
        .Q(LOW_F_CNT_reg[25]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[26] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[24]_i_1_n_5 ),
        .Q(LOW_F_CNT_reg[26]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[27] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[24]_i_1_n_4 ),
        .Q(LOW_F_CNT_reg[27]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[28] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[28]_i_1_n_7 ),
        .Q(LOW_F_CNT_reg[28]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \LOW_F_CNT_reg[28]_i_1 
       (.CI(\LOW_F_CNT_reg[24]_i_1_n_0 ),
        .CO({\NLW_LOW_F_CNT_reg[28]_i_1_CO_UNCONNECTED [3],\LOW_F_CNT_reg[28]_i_1_n_1 ,\LOW_F_CNT_reg[28]_i_1_n_2 ,\LOW_F_CNT_reg[28]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b1,1'b1,1'b1}),
        .O({\LOW_F_CNT_reg[28]_i_1_n_4 ,\LOW_F_CNT_reg[28]_i_1_n_5 ,\LOW_F_CNT_reg[28]_i_1_n_6 ,\LOW_F_CNT_reg[28]_i_1_n_7 }),
        .S({\LOW_F_CNT[28]_i_2_n_0 ,\LOW_F_CNT[28]_i_3_n_0 ,\LOW_F_CNT[28]_i_4_n_0 ,\LOW_F_CNT[28]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[29] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[28]_i_1_n_6 ),
        .Q(LOW_F_CNT_reg[29]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[2] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[0]_i_2_n_5 ),
        .Q(LOW_F_CNT_reg[2]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[30] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[28]_i_1_n_5 ),
        .Q(LOW_F_CNT_reg[30]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[31] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[28]_i_1_n_4 ),
        .Q(LOW_F_CNT_reg[31]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[3] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[0]_i_2_n_4 ),
        .Q(LOW_F_CNT_reg[3]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[4] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[4]_i_1_n_7 ),
        .Q(LOW_F_CNT_reg[4]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \LOW_F_CNT_reg[4]_i_1 
       (.CI(\LOW_F_CNT_reg[0]_i_2_n_0 ),
        .CO({\LOW_F_CNT_reg[4]_i_1_n_0 ,\LOW_F_CNT_reg[4]_i_1_n_1 ,\LOW_F_CNT_reg[4]_i_1_n_2 ,\LOW_F_CNT_reg[4]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b1,1'b1,1'b1,1'b1}),
        .O({\LOW_F_CNT_reg[4]_i_1_n_4 ,\LOW_F_CNT_reg[4]_i_1_n_5 ,\LOW_F_CNT_reg[4]_i_1_n_6 ,\LOW_F_CNT_reg[4]_i_1_n_7 }),
        .S({\LOW_F_CNT[4]_i_2_n_0 ,\LOW_F_CNT[4]_i_3_n_0 ,\LOW_F_CNT[4]_i_4_n_0 ,\LOW_F_CNT[4]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[5] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[4]_i_1_n_6 ),
        .Q(LOW_F_CNT_reg[5]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \LOW_F_CNT_reg[6] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[4]_i_1_n_5 ),
        .Q(LOW_F_CNT_reg[6]),
        .S(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[7] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[4]_i_1_n_4 ),
        .Q(LOW_F_CNT_reg[7]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[8] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[8]_i_1_n_7 ),
        .Q(LOW_F_CNT_reg[8]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \LOW_F_CNT_reg[8]_i_1 
       (.CI(\LOW_F_CNT_reg[4]_i_1_n_0 ),
        .CO({\LOW_F_CNT_reg[8]_i_1_n_0 ,\LOW_F_CNT_reg[8]_i_1_n_1 ,\LOW_F_CNT_reg[8]_i_1_n_2 ,\LOW_F_CNT_reg[8]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b1,1'b1,1'b1,1'b1}),
        .O({\LOW_F_CNT_reg[8]_i_1_n_4 ,\LOW_F_CNT_reg[8]_i_1_n_5 ,\LOW_F_CNT_reg[8]_i_1_n_6 ,\LOW_F_CNT_reg[8]_i_1_n_7 }),
        .S({\LOW_F_CNT[8]_i_2_n_0 ,\LOW_F_CNT[8]_i_3_n_0 ,\LOW_F_CNT[8]_i_4_n_0 ,\LOW_F_CNT[8]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \LOW_F_CNT_reg[9] 
       (.C(CLK_5M),
        .CE(1'b1),
        .D(\LOW_F_CNT_reg[8]_i_1_n_6 ),
        .Q(LOW_F_CNT_reg[9]),
        .R(\LOW_F_CNT[0]_i_1_n_0 ));
  FDRE \ROWS_FF1_reg[0] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(ROWS_IN[0]),
        .Q(ROWS_FF1[0]),
        .R(1'b0));
  FDRE \ROWS_FF1_reg[1] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(ROWS_IN[1]),
        .Q(ROWS_FF1[1]),
        .R(1'b0));
  FDRE \ROWS_FF1_reg[2] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(ROWS_IN[2]),
        .Q(ROWS_FF1[2]),
        .R(1'b0));
  FDRE \ROWS_FF1_reg[3] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(ROWS_IN[3]),
        .Q(ROWS_FF1[3]),
        .R(1'b0));
  FDRE \ROWS_FF2_reg[0] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(ROWS_FF1[0]),
        .Q(ROWS_FF2[0]),
        .R(1'b0));
  FDRE \ROWS_FF2_reg[1] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(ROWS_FF1[1]),
        .Q(ROWS_FF2[1]),
        .R(1'b0));
  FDRE \ROWS_FF2_reg[2] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(ROWS_FF1[2]),
        .Q(ROWS_FF2[2]),
        .R(1'b0));
  FDRE \ROWS_FF2_reg[3] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(ROWS_FF1[3]),
        .Q(ROWS_FF2[3]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \S_COLUMNS[0]_i_1 
       (.I0(CNTR_reg[3]),
        .I1(CNTR_reg[2]),
        .O(\S_COLUMNS[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \S_COLUMNS[1]_i_1 
       (.I0(CNTR_reg[3]),
        .I1(CNTR_reg[2]),
        .O(\S_COLUMNS[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'hD)) 
    \S_COLUMNS[2]_i_1 
       (.I0(CNTR_reg[3]),
        .I1(CNTR_reg[2]),
        .O(\S_COLUMNS[2]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \S_COLUMNS[3]_i_1 
       (.I0(CNTR_reg[3]),
        .I1(CNTR_reg[2]),
        .O(\S_COLUMNS[3]_i_1_n_0 ));
  FDRE \S_COLUMNS_reg[0] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\S_COLUMNS[0]_i_1_n_0 ),
        .Q(COLUMNS_OUT[0]),
        .R(1'b0));
  FDRE \S_COLUMNS_reg[1] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\S_COLUMNS[1]_i_1_n_0 ),
        .Q(COLUMNS_OUT[1]),
        .R(1'b0));
  FDRE \S_COLUMNS_reg[2] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\S_COLUMNS[2]_i_1_n_0 ),
        .Q(COLUMNS_OUT[2]),
        .R(1'b0));
  FDRE \S_COLUMNS_reg[3] 
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(\S_COLUMNS[3]_i_1_n_0 ),
        .Q(COLUMNS_OUT[3]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT1 #(
    .INIT(2'h1)) 
    TOP_BTN_0_INST_0
       (.I0(p_0_in_0[1]),
        .O(BUTTONS_OUT[1]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT1 #(
    .INIT(2'h1)) 
    TOP_BTN_1_INST_0
       (.I0(p_2_in[0]),
        .O(BUTTONS_OUT[4]));
  LUT1 #(
    .INIT(2'h1)) 
    TOP_BTN_2_INST_0
       (.I0(\BUTTONS_SIG_FILT_reg_n_0_[11] ),
        .O(BUTTONS_OUT[11]));
  LUT1 #(
    .INIT(2'h1)) 
    TOP_BTN_3_INST_0
       (.I0(\BUTTONS_SIG_FILT_reg_n_0_[2] ),
        .O(BUTTONS_OUT[14]));
  FDRE VALID_FF_reg
       (.C(CLK_40M),
        .CE(1'b1),
        .D(VALID),
        .Q(VALID_FF),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT2 #(
    .INIT(4'h2)) 
    VALID_PRESS_OUT_i_1
       (.I0(VALID),
        .I1(VALID_FF),
        .O(VALID_RELEASE_OUT0));
  FDRE VALID_PRESS_OUT_reg
       (.C(CLK_40M),
        .CE(1'b1),
        .D(VALID_RELEASE_OUT0),
        .Q(VALID_PRESS_OUT),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT2 #(
    .INIT(4'h2)) 
    VALID_RELEASE_OUT_i_1
       (.I0(VALID_FF),
        .I1(VALID),
        .O(VALID_RELEASE_OUT_i_1_n_0));
  FDRE VALID_RELEASE_OUT_reg
       (.C(CLK_40M),
        .CE(1'b1),
        .D(VALID_RELEASE_OUT_i_1_n_0),
        .Q(VALID_RELEASE_OUT),
        .R(1'b0));
  LUT5 #(
    .INIT(32'h000002A2)) 
    VALID_i_1
       (.I0(DBNC_CNT_reg_0_15_0_0_i_4_n_0),
        .I1(DBNC_CNT_reg_0_15_0_0_i_3_n_0),
        .I2(CNTR_reg[3]),
        .I3(DBNC_CNT_reg_0_15_0_0_i_2_n_0),
        .I4(DBNC_CNT_reg_0_15_0_0_i_5_n_0),
        .O(VALID_i_1_n_0));
  FDRE VALID_reg
       (.C(CLK_LOW_F),
        .CE(1'b1),
        .D(VALID_i_1_n_0),
        .Q(VALID),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
