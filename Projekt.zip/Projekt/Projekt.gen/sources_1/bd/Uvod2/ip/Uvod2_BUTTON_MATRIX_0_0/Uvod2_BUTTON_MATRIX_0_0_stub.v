// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
// Date        : Mon May 11 15:35:25 2026
// Host        : LRNV-INSTALL running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Users/vaje/Desktop/Salem/SalemPEV/11.5/PEV/Projekt/Projekt.gen/sources_1/bd/Uvod2/ip/Uvod2_BUTTON_MATRIX_0_0/Uvod2_BUTTON_MATRIX_0_0_stub.v
// Design      : Uvod2_BUTTON_MATRIX_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7s25csga324-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "Uvod2_BUTTON_MATRIX_0_0,BUTTON_MATRIX,{}" *) (* CORE_GENERATION_INFO = "Uvod2_BUTTON_MATRIX_0_0,BUTTON_MATRIX,{x_ipProduct=Vivado 2025.1,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=BUTTON_MATRIX,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED,G_ROW=4,G_CLK_DIV=64,G_DEBOUNCE_COUNTER_SIZE=16}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "BUTTON_MATRIX,Vivado 2025.1" *) 
module Uvod2_BUTTON_MATRIX_0_0(CLK_5M, CLK_40M, ROWS_IN, COLUMNS_OUT, 
  BUTTONS_OUT, VALID_PRESS_OUT, VALID_RELEASE_OUT, TOP_BTN_0, TOP_BTN_1, TOP_BTN_2, TOP_BTN_3)
/* synthesis syn_black_box black_box_pad_pin="ROWS_IN[3:0],COLUMNS_OUT[3:0],BUTTONS_OUT[15:0],VALID_PRESS_OUT,VALID_RELEASE_OUT,TOP_BTN_0,TOP_BTN_1,TOP_BTN_2,TOP_BTN_3" */
/* synthesis syn_force_seq_prim="CLK_5M" */
/* synthesis syn_force_seq_prim="CLK_40M" */;
  input CLK_5M /* synthesis syn_isclock = 1 */;
  input CLK_40M /* synthesis syn_isclock = 1 */;
  input [3:0]ROWS_IN;
  output [3:0]COLUMNS_OUT;
  output [15:0]BUTTONS_OUT;
  output VALID_PRESS_OUT;
  output VALID_RELEASE_OUT;
  output TOP_BTN_0;
  output TOP_BTN_1;
  output TOP_BTN_2;
  output TOP_BTN_3;
endmodule
