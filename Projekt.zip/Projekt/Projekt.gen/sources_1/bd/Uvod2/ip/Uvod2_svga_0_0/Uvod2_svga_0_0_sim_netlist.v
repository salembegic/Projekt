// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
// Date        : Mon May 11 17:36:07 2026
// Host        : LRNV-INSTALL running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/vaje/Desktop/Salem/SalemPEV/11.5/PEV/Projekt/Projekt.gen/sources_1/bd/Uvod2/ip/Uvod2_svga_0_0/Uvod2_svga_0_0_sim_netlist.v
// Design      : Uvod2_svga_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7s25csga324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "Uvod2_svga_0_0,svga,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "svga,Vivado 2025.1" *) 
(* NotValidForBitStream *)
module Uvod2_svga_0_0
   (iw_pix_clk,
    iw4_red,
    iw4_green,
    iw4_blue,
    iw2_State,
    iw4_result_left,
    iw4_result_right,
    iw11_x_pos,
    iw11_y_pos,
    iw11_block_left_pos,
    iw11_block_right_pos,
    ow4_red,
    ow4_green,
    ow4_blue,
    ow_hsync,
    ow_vsync);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 iw_pix_clk CLK" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME iw_pix_clk, FREQ_HZ 40000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0" *) input iw_pix_clk;
  input [3:0]iw4_red;
  input [3:0]iw4_green;
  input [3:0]iw4_blue;
  input [1:0]iw2_State;
  input [3:0]iw4_result_left;
  input [3:0]iw4_result_right;
  input [10:0]iw11_x_pos;
  input [10:0]iw11_y_pos;
  input [10:0]iw11_block_left_pos;
  input [10:0]iw11_block_right_pos;
  output [3:0]ow4_red;
  output [3:0]ow4_green;
  output [3:0]ow4_blue;
  output ow_hsync;
  output ow_vsync;

  wire [10:0]iw11_block_left_pos;
  wire [10:0]iw11_block_right_pos;
  wire [10:0]iw11_x_pos;
  wire [10:0]iw11_y_pos;
  wire [1:0]iw2_State;
  wire [3:0]iw4_blue;
  wire [3:0]iw4_green;
  wire [3:0]iw4_red;
  wire [3:0]iw4_result_left;
  wire [3:0]iw4_result_right;
  wire iw_pix_clk;
  wire [3:0]ow4_blue;
  wire [3:0]ow4_green;
  wire [3:0]ow4_red;
  wire ow_hsync;
  wire ow_vsync;

  Uvod2_svga_0_0_svga inst
       (.iw11_block_left_pos(iw11_block_left_pos),
        .iw11_block_right_pos(iw11_block_right_pos),
        .iw11_x_pos(iw11_x_pos),
        .iw11_y_pos(iw11_y_pos),
        .iw2_State(iw2_State),
        .iw4_blue(iw4_blue),
        .iw4_green(iw4_green),
        .iw4_red(iw4_red),
        .iw4_result_left(iw4_result_left),
        .iw4_result_right(iw4_result_right),
        .iw_pix_clk(iw_pix_clk),
        .ow4_blue(ow4_blue),
        .ow4_green(ow4_green),
        .ow4_red(ow4_red),
        .ow_hsync(ow_hsync),
        .ow_vsync(ow_vsync));
endmodule

(* ORIG_REF_NAME = "svga" *) 
module Uvod2_svga_0_0_svga
   (ow4_red,
    ow4_green,
    ow4_blue,
    ow_hsync,
    ow_vsync,
    iw11_block_right_pos,
    iw11_block_left_pos,
    iw11_y_pos,
    iw11_x_pos,
    iw_pix_clk,
    iw2_State,
    iw4_blue,
    iw4_result_right,
    iw4_green,
    iw4_red,
    iw4_result_left);
  output [3:0]ow4_red;
  output [3:0]ow4_green;
  output [3:0]ow4_blue;
  output ow_hsync;
  output ow_vsync;
  input [10:0]iw11_block_right_pos;
  input [10:0]iw11_block_left_pos;
  input [10:0]iw11_y_pos;
  input [10:0]iw11_x_pos;
  input iw_pix_clk;
  input [1:0]iw2_State;
  input [3:0]iw4_blue;
  input [3:0]iw4_result_right;
  input [3:0]iw4_green;
  input [3:0]iw4_red;
  input [3:0]iw4_result_left;

  wire [1:0]State;
  wire g0_b0__0_n_0;
  wire g0_b0__1_n_0;
  wire g0_b0__2_n_0;
  wire g0_b0__3_n_0;
  wire g0_b0__4_n_0;
  wire g0_b0_i_1_n_0;
  wire g0_b0_i_2_n_0;
  wire g0_b0_i_3_n_0;
  wire g0_b0_i_4_n_0;
  wire g0_b1__0_n_0;
  wire g0_b1__1_n_0;
  wire g0_b1__2_n_0;
  wire g0_b1__4_n_0;
  wire g0_b1_n_0;
  wire g0_b2__0_n_0;
  wire g0_b2__1_n_0;
  wire g0_b2__2_n_0;
  wire g0_b2__4_n_0;
  wire g0_b2_n_0;
  wire g0_b3__0_n_0;
  wire g0_b3__2_n_0;
  wire g0_b3_n_0;
  wire g0_b4__0_n_0;
  wire g0_b4__1_n_0;
  wire g0_b4__2_n_0;
  wire g0_b4_n_0;
  wire g0_b5__0_n_0;
  wire g0_b5__1_n_0;
  wire g0_b5__2_n_0;
  wire g0_b5_n_0;
  wire g0_b6__0_n_0;
  wire g0_b6__1_n_0;
  wire g0_b6__2_n_0;
  wire g0_b6__3_n_0;
  wire g0_b6_n_0;
  wire g0_b7__0_n_0;
  wire g0_b7_n_0;
  wire g0_b8_n_0;
  wire g0_b9_n_0;
  wire i___0_carry__0_i_1__0_n_0;
  wire i___0_carry__0_i_1_n_0;
  wire i___0_carry__0_i_2__0_n_0;
  wire i___0_carry__0_i_2_n_0;
  wire i___0_carry__0_i_3__0_n_0;
  wire i___0_carry__0_i_3_n_0;
  wire i___0_carry__0_i_4__0_n_0;
  wire i___0_carry__0_i_4_n_0;
  wire i___0_carry__0_i_5__0_n_0;
  wire i___0_carry__0_i_5_n_0;
  wire i___0_carry__0_i_6__0_n_0;
  wire i___0_carry__0_i_6_n_0;
  wire i___0_carry__0_i_7__0_n_0;
  wire i___0_carry__0_i_7_n_0;
  wire i___0_carry__0_i_8__0_n_0;
  wire i___0_carry__0_i_8_n_0;
  wire i___0_carry__1_i_1__0_n_0;
  wire i___0_carry__1_i_1_n_0;
  wire i___0_carry__1_i_2__0_n_0;
  wire i___0_carry__1_i_2_n_0;
  wire i___0_carry__1_i_3__0_n_0;
  wire i___0_carry__1_i_3_n_0;
  wire i___0_carry__1_i_4__0_n_0;
  wire i___0_carry__1_i_4_n_0;
  wire i___0_carry__1_i_5__0_n_0;
  wire i___0_carry__1_i_5_n_0;
  wire i___0_carry__1_i_6__0_n_0;
  wire i___0_carry__1_i_6_n_0;
  wire i___0_carry__1_i_7__0_n_0;
  wire i___0_carry__1_i_7_n_0;
  wire i___0_carry_i_1__0_n_0;
  wire i___0_carry_i_1_n_0;
  wire i___0_carry_i_2__0_n_0;
  wire i___0_carry_i_2_n_0;
  wire i___0_carry_i_3__0_n_0;
  wire i___0_carry_i_3_n_0;
  wire i___0_carry_i_4__0_n_0;
  wire i___0_carry_i_4_n_0;
  wire i___0_carry_i_5__0_n_0;
  wire i___0_carry_i_5_n_0;
  wire i___0_carry_i_6__0_n_0;
  wire i___0_carry_i_6_n_0;
  wire i___0_carry_i_7__0_n_0;
  wire i___0_carry_i_7_n_0;
  wire i___0_carry_i_8__0_n_0;
  wire i___0_carry_i_8_n_0;
  wire i__carry__0_i_1__0_n_0;
  wire i__carry__0_i_1__1_n_0;
  wire i__carry__0_i_1__2_n_0;
  wire i__carry__0_i_1_n_0;
  wire i__carry__0_i_2__0_n_0;
  wire i__carry__0_i_2__1_n_0;
  wire i__carry__0_i_2__2_n_0;
  wire i__carry__0_i_2_n_0;
  wire i__carry__0_i_3__0_n_0;
  wire i__carry__0_i_3__1_n_0;
  wire i__carry__0_i_3__2_n_0;
  wire i__carry__0_i_3_n_0;
  wire i__carry__0_i_4__0_n_0;
  wire i__carry__0_i_4__1_n_0;
  wire i__carry__0_i_4__2_n_0;
  wire i__carry__0_i_4_n_0;
  wire i__carry__0_i_5_n_0;
  wire i__carry__0_i_6_n_0;
  wire i__carry__0_i_7_n_0;
  wire i__carry__0_i_8_n_0;
  wire i__carry__1_i_1_n_0;
  wire i__carry__1_i_2_n_0;
  wire i__carry__1_i_3_n_0;
  wire i__carry__1_i_4_n_0;
  wire i__carry__1_i_5_n_0;
  wire i__carry__1_i_6_n_0;
  wire i__carry__1_i_7_n_0;
  wire i__carry_i_1__0_n_0;
  wire i__carry_i_1__1_n_0;
  wire i__carry_i_1__2_n_0;
  wire i__carry_i_1_n_0;
  wire i__carry_i_2__0_n_0;
  wire i__carry_i_2__1_n_0;
  wire i__carry_i_2__2_n_0;
  wire i__carry_i_2_n_0;
  wire i__carry_i_3__0_n_0;
  wire i__carry_i_3__1_n_0;
  wire i__carry_i_3__2_n_0;
  wire i__carry_i_3_n_0;
  wire i__carry_i_4__0_n_0;
  wire i__carry_i_4__1_n_0;
  wire i__carry_i_4__2_n_0;
  wire i__carry_i_4_n_0;
  wire i__carry_i_5__0_n_0;
  wire i__carry_i_5__1_n_0;
  wire i__carry_i_5__2_n_0;
  wire i__carry_i_5_n_0;
  wire i__carry_i_6__0_n_0;
  wire i__carry_i_6__1_n_0;
  wire i__carry_i_6_n_0;
  wire i__carry_i_7__0_n_0;
  wire i__carry_i_7__1_n_0;
  wire i__carry_i_7_n_0;
  wire i__carry_i_8__0_n_0;
  wire i__carry_i_8__1_n_0;
  wire i__carry_i_8_n_0;
  wire [10:0]iw11_block_left_pos;
  wire [10:0]iw11_block_right_pos;
  wire [10:0]iw11_x_pos;
  wire [10:0]iw11_y_pos;
  wire [1:0]iw2_State;
  wire [3:0]iw4_blue;
  wire [3:0]iw4_green;
  wire [3:0]iw4_red;
  wire [3:0]iw4_result_left;
  wire [3:0]iw4_result_right;
  wire iw_pix_clk;
  wire [3:0]ow4_blue;
  wire [3:0]ow4_green;
  wire [3:0]ow4_red;
  wire \ow4_red[3]_INST_0_i_10_n_0 ;
  wire \ow4_red[3]_INST_0_i_2_n_0 ;
  wire \ow4_red[3]_INST_0_i_4_n_0 ;
  wire \ow4_red[3]_INST_0_i_5_n_0 ;
  wire \ow4_red[3]_INST_0_i_6_n_0 ;
  wire \ow4_red[3]_INST_0_i_7_n_0 ;
  wire \ow4_red[3]_INST_0_i_8_n_0 ;
  wire \ow4_red[3]_INST_0_i_9_n_0 ;
  wire ow_hsync;
  wire ow_hsync_INST_0_i_1_n_0;
  wire ow_hsync_INST_0_i_2_n_0;
  wire ow_vsync;
  wire ow_vsync_INST_0_i_1_n_0;
  wire [10:0]p_0_in;
  wire [10:1]p_0_in__0;
  wire [10:0]p_0_in__1;
  wire \p_0_out_inferred__4/r4_red[3]_i_204_n_0 ;
  wire \p_0_out_inferred__4/r4_red[3]_i_206_n_0 ;
  wire \p_0_out_inferred__4/r4_red[3]_i_210_n_0 ;
  wire \p_0_out_inferred__4/r4_red[3]_i_211_n_0 ;
  wire \p_0_out_inferred__4/r4_red[3]_i_222_n_0 ;
  wire \p_0_out_inferred__4/r4_red[3]_i_223_n_0 ;
  wire \p_0_out_inferred__4/r4_red[3]_i_269_n_0 ;
  wire \p_0_out_inferred__4/r4_red[3]_i_270_n_0 ;
  wire \p_0_out_inferred__4/r4_red[3]_i_271_n_0 ;
  wire \p_0_out_inferred__4/r4_red[3]_i_272_n_0 ;
  wire \p_0_out_inferred__4/r4_red[3]_i_273_n_0 ;
  wire \p_0_out_inferred__4/r4_red[3]_i_274_n_0 ;
  wire \p_0_out_inferred__4/r4_red[3]_i_275_n_0 ;
  wire \p_0_out_inferred__4/r4_red[3]_i_276_n_0 ;
  wire [9:0]p_1_in;
  wire p_1_out_carry__0_i_1_n_0;
  wire p_1_out_carry__0_i_2_n_0;
  wire p_1_out_carry__0_i_3_n_0;
  wire p_1_out_carry__0_i_4_n_0;
  wire p_1_out_carry__0_i_5_n_0;
  wire p_1_out_carry__0_i_6_n_0;
  wire p_1_out_carry__0_i_7_n_0;
  wire p_1_out_carry__0_i_8_n_0;
  wire p_1_out_carry__0_n_0;
  wire p_1_out_carry__0_n_1;
  wire p_1_out_carry__0_n_2;
  wire p_1_out_carry__0_n_3;
  wire p_1_out_carry__1_i_1_n_0;
  wire p_1_out_carry__1_i_2_n_0;
  wire p_1_out_carry__1_i_3_n_0;
  wire p_1_out_carry__1_i_4_n_0;
  wire p_1_out_carry__1_i_5_n_0;
  wire p_1_out_carry__1_i_6_n_0;
  wire p_1_out_carry__1_i_7_n_0;
  wire p_1_out_carry__1_n_0;
  wire p_1_out_carry__1_n_1;
  wire p_1_out_carry__1_n_2;
  wire p_1_out_carry__1_n_3;
  wire p_1_out_carry_i_1_n_0;
  wire p_1_out_carry_i_2_n_0;
  wire p_1_out_carry_i_3_n_0;
  wire p_1_out_carry_i_4_n_0;
  wire p_1_out_carry_i_5_n_0;
  wire p_1_out_carry_n_0;
  wire p_1_out_carry_n_1;
  wire p_1_out_carry_n_2;
  wire p_1_out_carry_n_3;
  wire \p_1_out_inferred__0/i__carry__0_n_0 ;
  wire \p_1_out_inferred__0/i__carry__0_n_1 ;
  wire \p_1_out_inferred__0/i__carry__0_n_2 ;
  wire \p_1_out_inferred__0/i__carry__0_n_3 ;
  wire \p_1_out_inferred__0/i__carry__1_n_0 ;
  wire \p_1_out_inferred__0/i__carry__1_n_1 ;
  wire \p_1_out_inferred__0/i__carry__1_n_2 ;
  wire \p_1_out_inferred__0/i__carry__1_n_3 ;
  wire \p_1_out_inferred__0/i__carry_n_0 ;
  wire \p_1_out_inferred__0/i__carry_n_1 ;
  wire \p_1_out_inferred__0/i__carry_n_2 ;
  wire \p_1_out_inferred__0/i__carry_n_3 ;
  wire \p_1_out_inferred__1/i___0_carry__0_n_0 ;
  wire \p_1_out_inferred__1/i___0_carry__0_n_1 ;
  wire \p_1_out_inferred__1/i___0_carry__0_n_2 ;
  wire \p_1_out_inferred__1/i___0_carry__0_n_3 ;
  wire \p_1_out_inferred__1/i___0_carry__1_n_0 ;
  wire \p_1_out_inferred__1/i___0_carry__1_n_1 ;
  wire \p_1_out_inferred__1/i___0_carry__1_n_2 ;
  wire \p_1_out_inferred__1/i___0_carry__1_n_3 ;
  wire \p_1_out_inferred__1/i___0_carry_n_0 ;
  wire \p_1_out_inferred__1/i___0_carry_n_1 ;
  wire \p_1_out_inferred__1/i___0_carry_n_2 ;
  wire \p_1_out_inferred__1/i___0_carry_n_3 ;
  wire \p_1_out_inferred__2/i___0_carry__0_n_0 ;
  wire \p_1_out_inferred__2/i___0_carry__0_n_1 ;
  wire \p_1_out_inferred__2/i___0_carry__0_n_2 ;
  wire \p_1_out_inferred__2/i___0_carry__0_n_3 ;
  wire \p_1_out_inferred__2/i___0_carry__1_n_0 ;
  wire \p_1_out_inferred__2/i___0_carry__1_n_1 ;
  wire \p_1_out_inferred__2/i___0_carry__1_n_2 ;
  wire \p_1_out_inferred__2/i___0_carry__1_n_3 ;
  wire \p_1_out_inferred__2/i___0_carry_n_0 ;
  wire \p_1_out_inferred__2/i___0_carry_n_1 ;
  wire \p_1_out_inferred__2/i___0_carry_n_2 ;
  wire \p_1_out_inferred__2/i___0_carry_n_3 ;
  wire p_43_in;
  wire \r11_active_x[0]_i_1_n_0 ;
  wire \r11_active_x[10]_i_3_n_0 ;
  wire \r11_active_x[8]_i_2_n_0 ;
  wire \r11_active_x[8]_i_3_n_0 ;
  wire [10:0]r11_active_x_reg;
  wire r11_active_y;
  wire \r11_active_y[10]_i_3_n_0 ;
  wire \r11_active_y[7]_i_2_n_0 ;
  wire \r11_active_y[7]_i_3_n_0 ;
  wire [10:0]r11_active_y_reg;
  wire \r11_h_count[10]_i_2_n_0 ;
  wire [10:0]r11_h_count_reg;
  wire r11_v_count;
  wire \r11_v_count[9]_i_2_n_0 ;
  wire \r11_v_count[9]_i_4_n_0 ;
  wire \r11_v_count[9]_i_5_n_0 ;
  wire \r11_v_count[9]_i_6_n_0 ;
  wire \r11_v_count_reg_n_0_[0] ;
  wire \r11_v_count_reg_n_0_[1] ;
  wire \r11_v_count_reg_n_0_[2] ;
  wire \r11_v_count_reg_n_0_[3] ;
  wire \r11_v_count_reg_n_0_[4] ;
  wire \r11_v_count_reg_n_0_[5] ;
  wire \r11_v_count_reg_n_0_[6] ;
  wire \r11_v_count_reg_n_0_[7] ;
  wire \r11_v_count_reg_n_0_[8] ;
  wire \r11_v_count_reg_n_0_[9] ;
  wire [3:2]r4_blue;
  wire \r4_blue[0]_i_1_n_0 ;
  wire \r4_blue[0]_i_2_n_0 ;
  wire \r4_blue[0]_i_3_n_0 ;
  wire \r4_blue[1]_i_1_n_0 ;
  wire \r4_blue[1]_i_2_n_0 ;
  wire \r4_blue[1]_i_3_n_0 ;
  wire \r4_blue[2]_i_1_n_0 ;
  wire \r4_blue[2]_i_2_n_0 ;
  wire \r4_blue[2]_i_3_n_0 ;
  wire \r4_blue[3]_i_1_n_0 ;
  wire \r4_blue[3]_i_2_n_0 ;
  wire \r4_blue[3]_i_3_n_0 ;
  wire \r4_blue_reg_n_0_[0] ;
  wire \r4_blue_reg_n_0_[1] ;
  wire \r4_blue_reg_n_0_[2] ;
  wire \r4_blue_reg_n_0_[3] ;
  wire [3:0]r4_green;
  wire \r4_green[0]_i_2_n_0 ;
  wire \r4_green[0]_i_3_n_0 ;
  wire \r4_green[1]_i_2_n_0 ;
  wire \r4_green[1]_i_3_n_0 ;
  wire \r4_green[2]_i_2_n_0 ;
  wire \r4_green[2]_i_3_n_0 ;
  wire \r4_green[3]_i_2_n_0 ;
  wire \r4_green[3]_i_3_n_0 ;
  wire \r4_green_reg_n_0_[0] ;
  wire \r4_green_reg_n_0_[1] ;
  wire \r4_green_reg_n_0_[2] ;
  wire \r4_green_reg_n_0_[3] ;
  wire [3:0]r4_red;
  wire r4_red115_out;
  wire r4_red120_out;
  wire r4_red125_out;
  wire r4_red128_out;
  wire [3:0]r4_red2;
  wire r4_red310_in;
  wire r4_red311_in;
  wire r4_red313_in;
  wire r4_red318_in;
  wire r4_red31_in;
  wire r4_red35_in;
  wire r4_red3_carry__0_i_1_n_0;
  wire r4_red3_carry__0_i_2_n_0;
  wire r4_red3_carry__0_i_3_n_0;
  wire r4_red3_carry__0_i_4_n_0;
  wire r4_red3_carry__0_n_3;
  wire r4_red3_carry_i_1_n_0;
  wire r4_red3_carry_i_2_n_0;
  wire r4_red3_carry_i_3_n_0;
  wire r4_red3_carry_i_4_n_0;
  wire r4_red3_carry_i_5_n_0;
  wire r4_red3_carry_i_6_n_0;
  wire r4_red3_carry_i_7_n_0;
  wire r4_red3_carry_i_8_n_0;
  wire r4_red3_carry_n_0;
  wire r4_red3_carry_n_1;
  wire r4_red3_carry_n_2;
  wire r4_red3_carry_n_3;
  wire \r4_red3_inferred__0/i__carry__0_n_3 ;
  wire \r4_red3_inferred__0/i__carry_n_0 ;
  wire \r4_red3_inferred__0/i__carry_n_1 ;
  wire \r4_red3_inferred__0/i__carry_n_2 ;
  wire \r4_red3_inferred__0/i__carry_n_3 ;
  wire \r4_red3_inferred__1/i__carry__0_n_3 ;
  wire \r4_red3_inferred__1/i__carry_n_0 ;
  wire \r4_red3_inferred__1/i__carry_n_1 ;
  wire \r4_red3_inferred__1/i__carry_n_2 ;
  wire \r4_red3_inferred__1/i__carry_n_3 ;
  wire \r4_red3_inferred__2/i__carry__0_n_3 ;
  wire \r4_red3_inferred__2/i__carry_n_0 ;
  wire \r4_red3_inferred__2/i__carry_n_1 ;
  wire \r4_red3_inferred__2/i__carry_n_2 ;
  wire \r4_red3_inferred__2/i__carry_n_3 ;
  wire r4_red434_in;
  wire \r4_red[0]_i_2_n_0 ;
  wire \r4_red[0]_i_3_n_0 ;
  wire \r4_red[1]_i_2_n_0 ;
  wire \r4_red[1]_i_3_n_0 ;
  wire \r4_red[2]_i_10_n_0 ;
  wire \r4_red[2]_i_11_n_0 ;
  wire \r4_red[2]_i_12_n_0 ;
  wire \r4_red[2]_i_13_n_0 ;
  wire \r4_red[2]_i_14_n_0 ;
  wire \r4_red[2]_i_15_n_0 ;
  wire \r4_red[2]_i_16_n_0 ;
  wire \r4_red[2]_i_17_n_0 ;
  wire \r4_red[2]_i_18_n_0 ;
  wire \r4_red[2]_i_19_n_0 ;
  wire \r4_red[2]_i_20_n_0 ;
  wire \r4_red[2]_i_21_n_0 ;
  wire \r4_red[2]_i_2_n_0 ;
  wire \r4_red[2]_i_4_n_0 ;
  wire \r4_red[2]_i_5_n_0 ;
  wire \r4_red[2]_i_6_n_0 ;
  wire \r4_red[2]_i_7_n_0 ;
  wire \r4_red[2]_i_8_n_0 ;
  wire \r4_red[2]_i_9_n_0 ;
  wire \r4_red[3]_i_100_n_0 ;
  wire \r4_red[3]_i_101_n_0 ;
  wire \r4_red[3]_i_102_n_0 ;
  wire \r4_red[3]_i_103_n_0 ;
  wire \r4_red[3]_i_104_n_0 ;
  wire \r4_red[3]_i_105_n_0 ;
  wire \r4_red[3]_i_106_n_0 ;
  wire \r4_red[3]_i_107_n_0 ;
  wire \r4_red[3]_i_108_n_0 ;
  wire \r4_red[3]_i_109_n_0 ;
  wire \r4_red[3]_i_10_n_0 ;
  wire \r4_red[3]_i_110_n_0 ;
  wire \r4_red[3]_i_111_n_0 ;
  wire \r4_red[3]_i_112_n_0 ;
  wire \r4_red[3]_i_113_n_0 ;
  wire \r4_red[3]_i_114_n_0 ;
  wire \r4_red[3]_i_115_n_0 ;
  wire \r4_red[3]_i_116_n_0 ;
  wire \r4_red[3]_i_117_n_0 ;
  wire \r4_red[3]_i_118_n_0 ;
  wire \r4_red[3]_i_119_n_0 ;
  wire \r4_red[3]_i_11_n_0 ;
  wire \r4_red[3]_i_120_n_0 ;
  wire \r4_red[3]_i_121_n_0 ;
  wire \r4_red[3]_i_122_n_0 ;
  wire \r4_red[3]_i_123_n_0 ;
  wire \r4_red[3]_i_124_n_0 ;
  wire \r4_red[3]_i_125_n_0 ;
  wire \r4_red[3]_i_126_n_0 ;
  wire \r4_red[3]_i_127_n_0 ;
  wire \r4_red[3]_i_128_n_0 ;
  wire \r4_red[3]_i_129_n_0 ;
  wire \r4_red[3]_i_12_n_0 ;
  wire \r4_red[3]_i_130_n_0 ;
  wire \r4_red[3]_i_131_n_0 ;
  wire \r4_red[3]_i_132_n_0 ;
  wire \r4_red[3]_i_133_n_0 ;
  wire \r4_red[3]_i_134_n_0 ;
  wire \r4_red[3]_i_135_n_0 ;
  wire \r4_red[3]_i_136_n_0 ;
  wire \r4_red[3]_i_137_n_0 ;
  wire \r4_red[3]_i_138_n_0 ;
  wire \r4_red[3]_i_139_n_0 ;
  wire \r4_red[3]_i_13_n_0 ;
  wire \r4_red[3]_i_140_n_0 ;
  wire \r4_red[3]_i_141_n_0 ;
  wire \r4_red[3]_i_142_n_0 ;
  wire \r4_red[3]_i_143_n_0 ;
  wire \r4_red[3]_i_144_n_0 ;
  wire \r4_red[3]_i_145_n_0 ;
  wire \r4_red[3]_i_146_n_0 ;
  wire \r4_red[3]_i_147_n_0 ;
  wire \r4_red[3]_i_148_n_0 ;
  wire \r4_red[3]_i_149_n_0 ;
  wire \r4_red[3]_i_14_n_0 ;
  wire \r4_red[3]_i_150_n_0 ;
  wire \r4_red[3]_i_151_n_0 ;
  wire \r4_red[3]_i_152_n_0 ;
  wire \r4_red[3]_i_153_n_0 ;
  wire \r4_red[3]_i_154_n_0 ;
  wire \r4_red[3]_i_155_n_0 ;
  wire \r4_red[3]_i_156_n_0 ;
  wire \r4_red[3]_i_157_n_0 ;
  wire \r4_red[3]_i_158_n_0 ;
  wire \r4_red[3]_i_159_n_0 ;
  wire \r4_red[3]_i_15_n_0 ;
  wire \r4_red[3]_i_160_n_0 ;
  wire \r4_red[3]_i_161_n_0 ;
  wire \r4_red[3]_i_162_n_0 ;
  wire \r4_red[3]_i_163_n_0 ;
  wire \r4_red[3]_i_164_n_0 ;
  wire \r4_red[3]_i_165_n_0 ;
  wire \r4_red[3]_i_166_n_0 ;
  wire \r4_red[3]_i_167_n_0 ;
  wire \r4_red[3]_i_168_n_0 ;
  wire \r4_red[3]_i_169_n_0 ;
  wire \r4_red[3]_i_16_n_0 ;
  wire \r4_red[3]_i_170_n_0 ;
  wire \r4_red[3]_i_171_n_0 ;
  wire \r4_red[3]_i_172_n_0 ;
  wire \r4_red[3]_i_173_n_0 ;
  wire \r4_red[3]_i_174_n_0 ;
  wire \r4_red[3]_i_175_n_0 ;
  wire \r4_red[3]_i_176_n_0 ;
  wire \r4_red[3]_i_177_n_0 ;
  wire \r4_red[3]_i_178_n_0 ;
  wire \r4_red[3]_i_179_n_0 ;
  wire \r4_red[3]_i_17_n_0 ;
  wire \r4_red[3]_i_180_n_0 ;
  wire \r4_red[3]_i_181_n_0 ;
  wire \r4_red[3]_i_182_n_0 ;
  wire \r4_red[3]_i_183_n_0 ;
  wire \r4_red[3]_i_184_n_0 ;
  wire \r4_red[3]_i_185_n_0 ;
  wire \r4_red[3]_i_186_n_0 ;
  wire \r4_red[3]_i_187_n_0 ;
  wire \r4_red[3]_i_188_n_0 ;
  wire \r4_red[3]_i_189_n_0 ;
  wire \r4_red[3]_i_18_n_0 ;
  wire \r4_red[3]_i_190_n_0 ;
  wire \r4_red[3]_i_191_n_0 ;
  wire \r4_red[3]_i_192_n_0 ;
  wire \r4_red[3]_i_193_n_0 ;
  wire \r4_red[3]_i_194_n_0 ;
  wire \r4_red[3]_i_195_n_0 ;
  wire \r4_red[3]_i_196_n_0 ;
  wire \r4_red[3]_i_197_n_0 ;
  wire \r4_red[3]_i_198_n_0 ;
  wire \r4_red[3]_i_199_n_0 ;
  wire \r4_red[3]_i_19_n_0 ;
  wire \r4_red[3]_i_200_n_0 ;
  wire \r4_red[3]_i_201_n_0 ;
  wire \r4_red[3]_i_202_n_0 ;
  wire \r4_red[3]_i_203_n_0 ;
  wire \r4_red[3]_i_205_n_0 ;
  wire \r4_red[3]_i_207_n_0 ;
  wire \r4_red[3]_i_208_n_0 ;
  wire \r4_red[3]_i_209_n_0 ;
  wire \r4_red[3]_i_20_n_0 ;
  wire \r4_red[3]_i_212_n_0 ;
  wire \r4_red[3]_i_213_n_0 ;
  wire \r4_red[3]_i_214_n_0 ;
  wire \r4_red[3]_i_215_n_0 ;
  wire \r4_red[3]_i_216_n_0 ;
  wire \r4_red[3]_i_217_n_0 ;
  wire \r4_red[3]_i_218_n_0 ;
  wire \r4_red[3]_i_219_n_0 ;
  wire \r4_red[3]_i_220_n_0 ;
  wire \r4_red[3]_i_221_n_0 ;
  wire \r4_red[3]_i_224_n_0 ;
  wire \r4_red[3]_i_225_n_0 ;
  wire \r4_red[3]_i_226_n_0 ;
  wire \r4_red[3]_i_227_n_0 ;
  wire \r4_red[3]_i_228_n_0 ;
  wire \r4_red[3]_i_229_n_0 ;
  wire \r4_red[3]_i_22_n_0 ;
  wire \r4_red[3]_i_230_n_0 ;
  wire \r4_red[3]_i_231_n_0 ;
  wire \r4_red[3]_i_232_n_0 ;
  wire \r4_red[3]_i_233_n_0 ;
  wire \r4_red[3]_i_234_n_0 ;
  wire \r4_red[3]_i_235_n_0 ;
  wire \r4_red[3]_i_236_n_0 ;
  wire \r4_red[3]_i_237_n_0 ;
  wire \r4_red[3]_i_238_n_0 ;
  wire \r4_red[3]_i_239_n_0 ;
  wire \r4_red[3]_i_23_n_0 ;
  wire \r4_red[3]_i_240_n_0 ;
  wire \r4_red[3]_i_241_n_0 ;
  wire \r4_red[3]_i_242_n_0 ;
  wire \r4_red[3]_i_243_n_0 ;
  wire \r4_red[3]_i_244_n_0 ;
  wire \r4_red[3]_i_245_n_0 ;
  wire \r4_red[3]_i_246_n_0 ;
  wire \r4_red[3]_i_247_n_0 ;
  wire \r4_red[3]_i_248_n_0 ;
  wire \r4_red[3]_i_249_n_0 ;
  wire \r4_red[3]_i_250_n_0 ;
  wire \r4_red[3]_i_251_n_0 ;
  wire \r4_red[3]_i_252_n_0 ;
  wire \r4_red[3]_i_253_n_0 ;
  wire \r4_red[3]_i_254_n_0 ;
  wire \r4_red[3]_i_255_n_0 ;
  wire \r4_red[3]_i_256_n_0 ;
  wire \r4_red[3]_i_257_n_0 ;
  wire \r4_red[3]_i_258_n_0 ;
  wire \r4_red[3]_i_259_n_0 ;
  wire \r4_red[3]_i_25_n_0 ;
  wire \r4_red[3]_i_260_n_0 ;
  wire \r4_red[3]_i_261_n_0 ;
  wire \r4_red[3]_i_262_n_0 ;
  wire \r4_red[3]_i_263_n_0 ;
  wire \r4_red[3]_i_264_n_0 ;
  wire \r4_red[3]_i_265_n_0 ;
  wire \r4_red[3]_i_266_n_0 ;
  wire \r4_red[3]_i_267_n_0 ;
  wire \r4_red[3]_i_268_n_0 ;
  wire \r4_red[3]_i_27_n_0 ;
  wire \r4_red[3]_i_28_n_0 ;
  wire \r4_red[3]_i_29_n_0 ;
  wire \r4_red[3]_i_2_n_0 ;
  wire \r4_red[3]_i_30_n_0 ;
  wire \r4_red[3]_i_31_n_0 ;
  wire \r4_red[3]_i_32_n_0 ;
  wire \r4_red[3]_i_33_n_0 ;
  wire \r4_red[3]_i_34_n_0 ;
  wire \r4_red[3]_i_35_n_0 ;
  wire \r4_red[3]_i_36_n_0 ;
  wire \r4_red[3]_i_38_n_0 ;
  wire \r4_red[3]_i_39_n_0 ;
  wire \r4_red[3]_i_40_n_0 ;
  wire \r4_red[3]_i_41_n_0 ;
  wire \r4_red[3]_i_42_n_0 ;
  wire \r4_red[3]_i_43_n_0 ;
  wire \r4_red[3]_i_44_n_0 ;
  wire \r4_red[3]_i_45_n_0 ;
  wire \r4_red[3]_i_46_n_0 ;
  wire \r4_red[3]_i_47_n_0 ;
  wire \r4_red[3]_i_48_n_0 ;
  wire \r4_red[3]_i_49_n_0 ;
  wire \r4_red[3]_i_4_n_0 ;
  wire \r4_red[3]_i_50_n_0 ;
  wire \r4_red[3]_i_51_n_0 ;
  wire \r4_red[3]_i_53_n_0 ;
  wire \r4_red[3]_i_54_n_0 ;
  wire \r4_red[3]_i_55_n_0 ;
  wire \r4_red[3]_i_56_n_0 ;
  wire \r4_red[3]_i_57_n_0 ;
  wire \r4_red[3]_i_59_n_0 ;
  wire \r4_red[3]_i_5_n_0 ;
  wire \r4_red[3]_i_60_n_0 ;
  wire \r4_red[3]_i_61_n_0 ;
  wire \r4_red[3]_i_62_n_0 ;
  wire \r4_red[3]_i_63_n_0 ;
  wire \r4_red[3]_i_64_n_0 ;
  wire \r4_red[3]_i_65_n_0 ;
  wire \r4_red[3]_i_66_n_0 ;
  wire \r4_red[3]_i_67_n_0 ;
  wire \r4_red[3]_i_68_n_0 ;
  wire \r4_red[3]_i_69_n_0 ;
  wire \r4_red[3]_i_6_n_0 ;
  wire \r4_red[3]_i_70_n_0 ;
  wire \r4_red[3]_i_71_n_0 ;
  wire \r4_red[3]_i_72_n_0 ;
  wire \r4_red[3]_i_73_n_0 ;
  wire \r4_red[3]_i_74_n_0 ;
  wire \r4_red[3]_i_75_n_0 ;
  wire \r4_red[3]_i_76_n_0 ;
  wire \r4_red[3]_i_77_n_0 ;
  wire \r4_red[3]_i_78_n_0 ;
  wire \r4_red[3]_i_79_n_0 ;
  wire \r4_red[3]_i_7_n_0 ;
  wire \r4_red[3]_i_80_n_0 ;
  wire \r4_red[3]_i_81_n_0 ;
  wire \r4_red[3]_i_82_n_0 ;
  wire \r4_red[3]_i_83_n_0 ;
  wire \r4_red[3]_i_84_n_0 ;
  wire \r4_red[3]_i_85_n_0 ;
  wire \r4_red[3]_i_86_n_0 ;
  wire \r4_red[3]_i_87_n_0 ;
  wire \r4_red[3]_i_88_n_0 ;
  wire \r4_red[3]_i_89_n_0 ;
  wire \r4_red[3]_i_8_n_0 ;
  wire \r4_red[3]_i_90_n_0 ;
  wire \r4_red[3]_i_91_n_0 ;
  wire \r4_red[3]_i_92_n_0 ;
  wire \r4_red[3]_i_94_n_0 ;
  wire \r4_red[3]_i_95_n_0 ;
  wire \r4_red[3]_i_96_n_0 ;
  wire \r4_red[3]_i_97_n_0 ;
  wire \r4_red[3]_i_98_n_0 ;
  wire \r4_red[3]_i_99_n_0 ;
  wire \r4_red[3]_i_9_n_0 ;
  wire \r4_red_reg_n_0_[0] ;
  wire \r4_red_reg_n_0_[1] ;
  wire \r4_red_reg_n_0_[2] ;
  wire \r4_red_reg_n_0_[3] ;
  wire w_hactive041_in;
  wire w_vactive040_in;
  wire [3:0]NLW_p_1_out_carry_O_UNCONNECTED;
  wire [3:0]NLW_p_1_out_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_p_1_out_carry__1_O_UNCONNECTED;
  wire [3:0]\NLW_p_1_out_inferred__0/i__carry_O_UNCONNECTED ;
  wire [3:0]\NLW_p_1_out_inferred__0/i__carry__0_O_UNCONNECTED ;
  wire [3:0]\NLW_p_1_out_inferred__0/i__carry__1_O_UNCONNECTED ;
  wire [3:0]\NLW_p_1_out_inferred__1/i___0_carry_O_UNCONNECTED ;
  wire [3:0]\NLW_p_1_out_inferred__1/i___0_carry__0_O_UNCONNECTED ;
  wire [3:0]\NLW_p_1_out_inferred__1/i___0_carry__1_O_UNCONNECTED ;
  wire [3:0]\NLW_p_1_out_inferred__2/i___0_carry_O_UNCONNECTED ;
  wire [3:0]\NLW_p_1_out_inferred__2/i___0_carry__0_O_UNCONNECTED ;
  wire [3:0]\NLW_p_1_out_inferred__2/i___0_carry__1_O_UNCONNECTED ;
  wire [3:0]NLW_r4_red3_carry_O_UNCONNECTED;
  wire [3:2]NLW_r4_red3_carry__0_CO_UNCONNECTED;
  wire [3:0]NLW_r4_red3_carry__0_O_UNCONNECTED;
  wire [3:0]\NLW_r4_red3_inferred__0/i__carry_O_UNCONNECTED ;
  wire [3:2]\NLW_r4_red3_inferred__0/i__carry__0_CO_UNCONNECTED ;
  wire [3:0]\NLW_r4_red3_inferred__0/i__carry__0_O_UNCONNECTED ;
  wire [3:0]\NLW_r4_red3_inferred__1/i__carry_O_UNCONNECTED ;
  wire [3:2]\NLW_r4_red3_inferred__1/i__carry__0_CO_UNCONNECTED ;
  wire [3:0]\NLW_r4_red3_inferred__1/i__carry__0_O_UNCONNECTED ;
  wire [3:0]\NLW_r4_red3_inferred__2/i__carry_O_UNCONNECTED ;
  wire [3:2]\NLW_r4_red3_inferred__2/i__carry__0_CO_UNCONNECTED ;
  wire [3:0]\NLW_r4_red3_inferred__2/i__carry__0_O_UNCONNECTED ;

  FDRE \State_reg[0] 
       (.C(iw_pix_clk),
        .CE(1'b1),
        .D(iw2_State[0]),
        .Q(State[0]),
        .R(1'b0));
  FDRE \State_reg[1] 
       (.C(iw_pix_clk),
        .CE(1'b1),
        .D(iw2_State[1]),
        .Q(State[1]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT4 #(
    .INIT(16'h6003)) 
    g0_b0
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(r4_red2[0]));
  (* SOFT_HLUTNM = "soft_lutpair47" *) 
  LUT4 #(
    .INIT(16'h607C)) 
    g0_b0__0
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b0__0_n_0));
  (* SOFT_HLUTNM = "soft_lutpair52" *) 
  LUT4 #(
    .INIT(16'h1F03)) 
    g0_b0__1
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b0__1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair55" *) 
  LUT4 #(
    .INIT(16'h1F0C)) 
    g0_b0__2
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b0__2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair57" *) 
  LUT4 #(
    .INIT(16'h001F)) 
    g0_b0__3
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b0__3_n_0));
  (* SOFT_HLUTNM = "soft_lutpair74" *) 
  LUT4 #(
    .INIT(16'h60C3)) 
    g0_b0__4
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b0__4_n_0));
  LUT3 #(
    .INIT(8'hA9)) 
    g0_b0_i_1
       (.I0(r11_active_y_reg[2]),
        .I1(r11_active_y_reg[1]),
        .I2(r11_active_y_reg[0]),
        .O(g0_b0_i_1_n_0));
  LUT4 #(
    .INIT(16'h01FE)) 
    g0_b0_i_2
       (.I0(r11_active_y_reg[2]),
        .I1(r11_active_y_reg[1]),
        .I2(r11_active_y_reg[0]),
        .I3(r11_active_y_reg[3]),
        .O(g0_b0_i_2_n_0));
  LUT5 #(
    .INIT(32'hF0E00F1F)) 
    g0_b0_i_3
       (.I0(r11_active_y_reg[0]),
        .I1(r11_active_y_reg[1]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[4]),
        .O(g0_b0_i_3_n_0));
  LUT6 #(
    .INIT(64'h5555555666666666)) 
    g0_b0_i_4
       (.I0(r11_active_y_reg[5]),
        .I1(r11_active_y_reg[4]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[0]),
        .I5(r11_active_y_reg[3]),
        .O(g0_b0_i_4_n_0));
  (* SOFT_HLUTNM = "soft_lutpair47" *) 
  LUT4 #(
    .INIT(16'h60FE)) 
    g0_b1
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair53" *) 
  LUT4 #(
    .INIT(16'h3F83)) 
    g0_b1__0
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b1__0_n_0));
  (* SOFT_HLUTNM = "soft_lutpair56" *) 
  LUT4 #(
    .INIT(16'h3F8E)) 
    g0_b1__1
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b1__1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair57" *) 
  LUT4 #(
    .INIT(16'h007F)) 
    g0_b1__2
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b1__2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair72" *) 
  LUT4 #(
    .INIT(16'h7007)) 
    g0_b1__3
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(r4_red2[1]));
  (* SOFT_HLUTNM = "soft_lutpair73" *) 
  LUT4 #(
    .INIT(16'h71E7)) 
    g0_b1__4
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b1__4_n_0));
  (* SOFT_HLUTNM = "soft_lutpair48" *) 
  LUT4 #(
    .INIT(16'h61C7)) 
    g0_b2
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair53" *) 
  LUT4 #(
    .INIT(16'h71C3)) 
    g0_b2__0
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b2__0_n_0));
  (* SOFT_HLUTNM = "soft_lutpair56" *) 
  LUT4 #(
    .INIT(16'h71C7)) 
    g0_b2__1
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b2__1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair58" *) 
  LUT4 #(
    .INIT(16'h01F3)) 
    g0_b2__2
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b2__2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair61" *) 
  LUT4 #(
    .INIT(16'h3FFE)) 
    g0_b2__3
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(r4_red2[2]));
  (* SOFT_HLUTNM = "soft_lutpair74" *) 
  LUT4 #(
    .INIT(16'h70C7)) 
    g0_b2__4
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b2__4_n_0));
  (* SOFT_HLUTNM = "soft_lutpair48" *) 
  LUT4 #(
    .INIT(16'h6383)) 
    g0_b3
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b3_n_0));
  (* SOFT_HLUTNM = "soft_lutpair58" *) 
  LUT4 #(
    .INIT(16'h07C3)) 
    g0_b3__0
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b3__0_n_0));
  (* SOFT_HLUTNM = "soft_lutpair72" *) 
  LUT4 #(
    .INIT(16'h1FFC)) 
    g0_b3__1
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(r4_red2[3]));
  (* SOFT_HLUTNM = "soft_lutpair73" *) 
  LUT4 #(
    .INIT(16'h1F3C)) 
    g0_b3__2
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b3__2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair49" *) 
  LUT4 #(
    .INIT(16'h6703)) 
    g0_b4
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b4_n_0));
  (* SOFT_HLUTNM = "soft_lutpair54" *) 
  LUT4 #(
    .INIT(16'h70C3)) 
    g0_b4__0
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b4__0_n_0));
  (* SOFT_HLUTNM = "soft_lutpair59" *) 
  LUT4 #(
    .INIT(16'h7F03)) 
    g0_b4__1
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b4__1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair60" *) 
  LUT4 #(
    .INIT(16'h70E7)) 
    g0_b4__2
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b4__2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair49" *) 
  LUT4 #(
    .INIT(16'h6E03)) 
    g0_b5
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b5_n_0));
  (* SOFT_HLUTNM = "soft_lutpair51" *) 
  LUT4 #(
    .INIT(16'h380E)) 
    g0_b5__0
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b5__0_n_0));
  (* SOFT_HLUTNM = "soft_lutpair54" *) 
  LUT4 #(
    .INIT(16'h38FF)) 
    g0_b5__1
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b5__1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair60" *) 
  LUT4 #(
    .INIT(16'h387E)) 
    g0_b5__2
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b5__2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair52" *) 
  LUT4 #(
    .INIT(16'h180C)) 
    g0_b6
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b6_n_0));
  (* SOFT_HLUTNM = "soft_lutpair55" *) 
  LUT4 #(
    .INIT(16'h18FF)) 
    g0_b6__0
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b6__0_n_0));
  (* SOFT_HLUTNM = "soft_lutpair75" *) 
  LUT3 #(
    .INIT(8'h01)) 
    g0_b6__1
       (.I0(g0_b0_i_2_n_0),
        .I1(g0_b0_i_3_n_0),
        .I2(g0_b0_i_4_n_0),
        .O(g0_b6__1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair61" *) 
  LUT4 #(
    .INIT(16'h183C)) 
    g0_b6__2
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b6__2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair75" *) 
  LUT4 #(
    .INIT(16'h7C03)) 
    g0_b6__3
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b6__3_n_0));
  (* SOFT_HLUTNM = "soft_lutpair50" *) 
  LUT4 #(
    .INIT(16'h7807)) 
    g0_b7
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b7_n_0));
  (* SOFT_HLUTNM = "soft_lutpair59" *) 
  LUT4 #(
    .INIT(16'h0007)) 
    g0_b7__0
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b7__0_n_0));
  (* SOFT_HLUTNM = "soft_lutpair50" *) 
  LUT4 #(
    .INIT(16'h700E)) 
    g0_b8
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b8_n_0));
  (* SOFT_HLUTNM = "soft_lutpair51" *) 
  LUT4 #(
    .INIT(16'h600C)) 
    g0_b9
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_4_n_0),
        .O(g0_b9_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i___0_carry__0_i_1
       (.I0(r11_active_y_reg[6]),
        .I1(iw11_y_pos[6]),
        .O(i___0_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i___0_carry__0_i_1__0
       (.I0(r11_active_x_reg[6]),
        .I1(iw11_x_pos[6]),
        .O(i___0_carry__0_i_1__0_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i___0_carry__0_i_2
       (.I0(r11_active_y_reg[5]),
        .I1(iw11_y_pos[5]),
        .O(i___0_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i___0_carry__0_i_2__0
       (.I0(r11_active_x_reg[5]),
        .I1(iw11_x_pos[5]),
        .O(i___0_carry__0_i_2__0_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i___0_carry__0_i_3
       (.I0(r11_active_y_reg[4]),
        .I1(iw11_y_pos[4]),
        .O(i___0_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i___0_carry__0_i_3__0
       (.I0(r11_active_x_reg[4]),
        .I1(iw11_x_pos[4]),
        .O(i___0_carry__0_i_3__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i___0_carry__0_i_4
       (.I0(r11_active_y_reg[4]),
        .I1(iw11_y_pos[4]),
        .O(i___0_carry__0_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i___0_carry__0_i_4__0
       (.I0(iw11_x_pos[4]),
        .I1(r11_active_x_reg[4]),
        .O(i___0_carry__0_i_4__0_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    i___0_carry__0_i_5
       (.I0(iw11_y_pos[6]),
        .I1(r11_active_y_reg[6]),
        .I2(iw11_y_pos[7]),
        .I3(r11_active_y_reg[7]),
        .O(i___0_carry__0_i_5_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    i___0_carry__0_i_5__0
       (.I0(iw11_x_pos[6]),
        .I1(r11_active_x_reg[6]),
        .I2(r11_active_x_reg[7]),
        .I3(iw11_x_pos[7]),
        .O(i___0_carry__0_i_5__0_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    i___0_carry__0_i_6
       (.I0(iw11_y_pos[5]),
        .I1(r11_active_y_reg[5]),
        .I2(iw11_y_pos[6]),
        .I3(r11_active_y_reg[6]),
        .O(i___0_carry__0_i_6_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    i___0_carry__0_i_6__0
       (.I0(iw11_x_pos[5]),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[6]),
        .I3(iw11_x_pos[6]),
        .O(i___0_carry__0_i_6__0_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    i___0_carry__0_i_7
       (.I0(iw11_y_pos[4]),
        .I1(r11_active_y_reg[4]),
        .I2(iw11_y_pos[5]),
        .I3(r11_active_y_reg[5]),
        .O(i___0_carry__0_i_7_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    i___0_carry__0_i_7__0
       (.I0(iw11_x_pos[4]),
        .I1(r11_active_x_reg[4]),
        .I2(r11_active_x_reg[5]),
        .I3(iw11_x_pos[5]),
        .O(i___0_carry__0_i_7__0_n_0));
  LUT4 #(
    .INIT(16'h6966)) 
    i___0_carry__0_i_8
       (.I0(iw11_y_pos[4]),
        .I1(r11_active_y_reg[4]),
        .I2(iw11_y_pos[3]),
        .I3(r11_active_y_reg[3]),
        .O(i___0_carry__0_i_8_n_0));
  LUT4 #(
    .INIT(16'h6966)) 
    i___0_carry__0_i_8__0
       (.I0(r11_active_x_reg[4]),
        .I1(iw11_x_pos[4]),
        .I2(iw11_x_pos[3]),
        .I3(r11_active_x_reg[3]),
        .O(i___0_carry__0_i_8__0_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i___0_carry__1_i_1
       (.I0(r11_active_y_reg[9]),
        .I1(iw11_y_pos[9]),
        .O(i___0_carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i___0_carry__1_i_1__0
       (.I0(r11_active_x_reg[9]),
        .I1(iw11_x_pos[9]),
        .O(i___0_carry__1_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i___0_carry__1_i_2
       (.I0(iw11_y_pos[9]),
        .I1(r11_active_y_reg[9]),
        .O(i___0_carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i___0_carry__1_i_2__0
       (.I0(r11_active_x_reg[8]),
        .I1(iw11_x_pos[8]),
        .O(i___0_carry__1_i_2__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i___0_carry__1_i_3
       (.I0(iw11_y_pos[8]),
        .I1(r11_active_y_reg[8]),
        .O(i___0_carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i___0_carry__1_i_3__0
       (.I0(r11_active_x_reg[7]),
        .I1(iw11_x_pos[7]),
        .O(i___0_carry__1_i_3__0_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i___0_carry__1_i_4
       (.I0(r11_active_y_reg[10]),
        .I1(iw11_y_pos[10]),
        .O(i___0_carry__1_i_4_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i___0_carry__1_i_4__0
       (.I0(r11_active_x_reg[10]),
        .I1(iw11_x_pos[10]),
        .O(i___0_carry__1_i_4__0_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    i___0_carry__1_i_5
       (.I0(iw11_y_pos[9]),
        .I1(r11_active_y_reg[9]),
        .I2(iw11_y_pos[10]),
        .I3(r11_active_y_reg[10]),
        .O(i___0_carry__1_i_5_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    i___0_carry__1_i_5__0
       (.I0(iw11_x_pos[9]),
        .I1(r11_active_x_reg[9]),
        .I2(iw11_x_pos[10]),
        .I3(r11_active_x_reg[10]),
        .O(i___0_carry__1_i_5__0_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    i___0_carry__1_i_6
       (.I0(iw11_y_pos[8]),
        .I1(r11_active_y_reg[8]),
        .I2(r11_active_y_reg[9]),
        .I3(iw11_y_pos[9]),
        .O(i___0_carry__1_i_6_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    i___0_carry__1_i_6__0
       (.I0(iw11_x_pos[8]),
        .I1(r11_active_x_reg[8]),
        .I2(r11_active_x_reg[9]),
        .I3(iw11_x_pos[9]),
        .O(i___0_carry__1_i_6__0_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    i___0_carry__1_i_7
       (.I0(iw11_y_pos[7]),
        .I1(r11_active_y_reg[7]),
        .I2(r11_active_y_reg[8]),
        .I3(iw11_y_pos[8]),
        .O(i___0_carry__1_i_7_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    i___0_carry__1_i_7__0
       (.I0(iw11_x_pos[7]),
        .I1(r11_active_x_reg[7]),
        .I2(r11_active_x_reg[8]),
        .I3(iw11_x_pos[8]),
        .O(i___0_carry__1_i_7__0_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i___0_carry_i_1
       (.I0(r11_active_y_reg[2]),
        .I1(iw11_y_pos[2]),
        .O(i___0_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i___0_carry_i_1__0
       (.I0(r11_active_x_reg[2]),
        .I1(iw11_x_pos[2]),
        .O(i___0_carry_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i___0_carry_i_2
       (.I0(r11_active_y_reg[2]),
        .I1(iw11_y_pos[2]),
        .O(i___0_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i___0_carry_i_2__0
       (.I0(r11_active_x_reg[2]),
        .I1(iw11_x_pos[2]),
        .O(i___0_carry_i_2__0_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i___0_carry_i_3
       (.I0(r11_active_y_reg[0]),
        .I1(iw11_y_pos[0]),
        .O(i___0_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i___0_carry_i_3__0
       (.I0(r11_active_x_reg[0]),
        .I1(iw11_x_pos[0]),
        .O(i___0_carry_i_3__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i___0_carry_i_4
       (.I0(iw11_y_pos[0]),
        .I1(r11_active_y_reg[0]),
        .O(i___0_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i___0_carry_i_4__0
       (.I0(iw11_x_pos[0]),
        .I1(r11_active_x_reg[0]),
        .O(i___0_carry_i_4__0_n_0));
  LUT4 #(
    .INIT(16'h2DD2)) 
    i___0_carry_i_5
       (.I0(iw11_y_pos[2]),
        .I1(r11_active_y_reg[2]),
        .I2(iw11_y_pos[3]),
        .I3(r11_active_y_reg[3]),
        .O(i___0_carry_i_5_n_0));
  LUT4 #(
    .INIT(16'h2DD2)) 
    i___0_carry_i_5__0
       (.I0(iw11_x_pos[2]),
        .I1(r11_active_x_reg[2]),
        .I2(iw11_x_pos[3]),
        .I3(r11_active_x_reg[3]),
        .O(i___0_carry_i_5__0_n_0));
  LUT4 #(
    .INIT(16'h6966)) 
    i___0_carry_i_6
       (.I0(iw11_y_pos[2]),
        .I1(r11_active_y_reg[2]),
        .I2(iw11_y_pos[1]),
        .I3(r11_active_y_reg[1]),
        .O(i___0_carry_i_6_n_0));
  LUT4 #(
    .INIT(16'h6966)) 
    i___0_carry_i_6__0
       (.I0(iw11_x_pos[2]),
        .I1(r11_active_x_reg[2]),
        .I2(iw11_x_pos[1]),
        .I3(r11_active_x_reg[1]),
        .O(i___0_carry_i_6__0_n_0));
  LUT4 #(
    .INIT(16'h2DD2)) 
    i___0_carry_i_7
       (.I0(iw11_y_pos[0]),
        .I1(r11_active_y_reg[0]),
        .I2(iw11_y_pos[1]),
        .I3(r11_active_y_reg[1]),
        .O(i___0_carry_i_7_n_0));
  LUT4 #(
    .INIT(16'h2DD2)) 
    i___0_carry_i_7__0
       (.I0(iw11_x_pos[0]),
        .I1(r11_active_x_reg[0]),
        .I2(iw11_x_pos[1]),
        .I3(r11_active_x_reg[1]),
        .O(i___0_carry_i_7__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i___0_carry_i_8
       (.I0(r11_active_y_reg[0]),
        .I1(iw11_y_pos[0]),
        .O(i___0_carry_i_8_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i___0_carry_i_8__0
       (.I0(r11_active_x_reg[0]),
        .I1(iw11_x_pos[0]),
        .O(i___0_carry_i_8__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry__0_i_1
       (.I0(r11_active_y_reg[7]),
        .I1(iw11_block_left_pos[7]),
        .O(i__carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    i__carry__0_i_1__0
       (.I0(r11_active_y_reg[10]),
        .I1(iw11_block_left_pos[10]),
        .O(i__carry__0_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    i__carry__0_i_1__1
       (.I0(r11_active_y_reg[10]),
        .I1(iw11_y_pos[10]),
        .O(i__carry__0_i_1__1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    i__carry__0_i_1__2
       (.I0(r11_active_x_reg[10]),
        .I1(iw11_x_pos[10]),
        .O(i__carry__0_i_1__2_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    i__carry__0_i_2
       (.I0(iw11_y_pos[9]),
        .I1(iw11_y_pos[8]),
        .I2(r11_active_y_reg[9]),
        .I3(r11_active_y_reg[8]),
        .O(i__carry__0_i_2_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    i__carry__0_i_2__0
       (.I0(iw11_block_left_pos[9]),
        .I1(iw11_block_left_pos[8]),
        .I2(r11_active_y_reg[9]),
        .I3(r11_active_y_reg[8]),
        .O(i__carry__0_i_2__0_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    i__carry__0_i_2__1
       (.I0(r11_active_y_reg[5]),
        .I1(iw11_block_left_pos[5]),
        .O(i__carry__0_i_2__1_n_0));
  LUT4 #(
    .INIT(16'h22B2)) 
    i__carry__0_i_2__2
       (.I0(r11_active_x_reg[9]),
        .I1(iw11_x_pos[9]),
        .I2(r11_active_x_reg[8]),
        .I3(iw11_x_pos[8]),
        .O(i__carry__0_i_2__2_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i__carry__0_i_3
       (.I0(r11_active_y_reg[4]),
        .I1(iw11_block_left_pos[4]),
        .O(i__carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__0_i_3__0
       (.I0(iw11_block_left_pos[10]),
        .I1(r11_active_y_reg[10]),
        .O(i__carry__0_i_3__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__0_i_3__1
       (.I0(iw11_y_pos[10]),
        .I1(r11_active_y_reg[10]),
        .O(i__carry__0_i_3__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__0_i_3__2
       (.I0(iw11_x_pos[10]),
        .I1(r11_active_x_reg[10]),
        .O(i__carry__0_i_3__2_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i__carry__0_i_4
       (.I0(r11_active_y_reg[3]),
        .I1(iw11_block_left_pos[3]),
        .O(i__carry__0_i_4_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry__0_i_4__0
       (.I0(r11_active_y_reg[9]),
        .I1(iw11_block_left_pos[9]),
        .I2(r11_active_y_reg[8]),
        .I3(iw11_block_left_pos[8]),
        .O(i__carry__0_i_4__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry__0_i_4__1
       (.I0(r11_active_y_reg[9]),
        .I1(iw11_y_pos[9]),
        .I2(r11_active_y_reg[8]),
        .I3(iw11_y_pos[8]),
        .O(i__carry__0_i_4__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry__0_i_4__2
       (.I0(iw11_x_pos[8]),
        .I1(r11_active_x_reg[8]),
        .I2(iw11_x_pos[9]),
        .I3(r11_active_x_reg[9]),
        .O(i__carry__0_i_4__2_n_0));
  LUT4 #(
    .INIT(16'h6966)) 
    i__carry__0_i_5
       (.I0(iw11_block_left_pos[7]),
        .I1(r11_active_y_reg[7]),
        .I2(iw11_block_left_pos[6]),
        .I3(r11_active_y_reg[6]),
        .O(i__carry__0_i_5_n_0));
  LUT4 #(
    .INIT(16'hB44B)) 
    i__carry__0_i_6
       (.I0(iw11_block_left_pos[5]),
        .I1(r11_active_y_reg[5]),
        .I2(iw11_block_left_pos[6]),
        .I3(r11_active_y_reg[6]),
        .O(i__carry__0_i_6_n_0));
  LUT4 #(
    .INIT(16'h2DD2)) 
    i__carry__0_i_7
       (.I0(iw11_block_left_pos[4]),
        .I1(r11_active_y_reg[4]),
        .I2(iw11_block_left_pos[5]),
        .I3(r11_active_y_reg[5]),
        .O(i__carry__0_i_7_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    i__carry__0_i_8
       (.I0(iw11_block_left_pos[3]),
        .I1(r11_active_y_reg[3]),
        .I2(iw11_block_left_pos[4]),
        .I3(r11_active_y_reg[4]),
        .O(i__carry__0_i_8_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i__carry__1_i_1
       (.I0(r11_active_y_reg[9]),
        .I1(iw11_block_left_pos[9]),
        .O(i__carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry__1_i_2
       (.I0(iw11_block_left_pos[9]),
        .I1(r11_active_y_reg[9]),
        .O(i__carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry__1_i_3
       (.I0(iw11_block_left_pos[8]),
        .I1(r11_active_y_reg[8]),
        .O(i__carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    i__carry__1_i_4
       (.I0(r11_active_y_reg[10]),
        .I1(iw11_block_left_pos[10]),
        .O(i__carry__1_i_4_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    i__carry__1_i_5
       (.I0(iw11_block_left_pos[9]),
        .I1(r11_active_y_reg[9]),
        .I2(iw11_block_left_pos[10]),
        .I3(r11_active_y_reg[10]),
        .O(i__carry__1_i_5_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    i__carry__1_i_6
       (.I0(iw11_block_left_pos[8]),
        .I1(r11_active_y_reg[8]),
        .I2(r11_active_y_reg[9]),
        .I3(iw11_block_left_pos[9]),
        .O(i__carry__1_i_6_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    i__carry__1_i_7
       (.I0(iw11_block_left_pos[7]),
        .I1(r11_active_y_reg[7]),
        .I2(r11_active_y_reg[8]),
        .I3(iw11_block_left_pos[8]),
        .O(i__carry__1_i_7_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    i__carry_i_1
       (.I0(iw11_y_pos[7]),
        .I1(iw11_y_pos[6]),
        .I2(r11_active_y_reg[7]),
        .I3(r11_active_y_reg[6]),
        .O(i__carry_i_1_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    i__carry_i_1__0
       (.I0(iw11_block_left_pos[7]),
        .I1(iw11_block_left_pos[6]),
        .I2(r11_active_y_reg[7]),
        .I3(r11_active_y_reg[6]),
        .O(i__carry_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_1__1
       (.I0(iw11_block_left_pos[3]),
        .I1(r11_active_y_reg[3]),
        .O(i__carry_i_1__1_n_0));
  LUT4 #(
    .INIT(16'h22B2)) 
    i__carry_i_1__2
       (.I0(r11_active_x_reg[7]),
        .I1(iw11_x_pos[7]),
        .I2(r11_active_x_reg[6]),
        .I3(iw11_x_pos[6]),
        .O(i__carry_i_1__2_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    i__carry_i_2
       (.I0(iw11_y_pos[5]),
        .I1(iw11_y_pos[4]),
        .I2(r11_active_y_reg[5]),
        .I3(r11_active_y_reg[4]),
        .O(i__carry_i_2_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    i__carry_i_2__0
       (.I0(iw11_block_left_pos[5]),
        .I1(iw11_block_left_pos[4]),
        .I2(r11_active_y_reg[5]),
        .I3(r11_active_y_reg[4]),
        .O(i__carry_i_2__0_n_0));
  LUT4 #(
    .INIT(16'h22B2)) 
    i__carry_i_2__1
       (.I0(r11_active_x_reg[5]),
        .I1(iw11_x_pos[5]),
        .I2(r11_active_x_reg[4]),
        .I3(iw11_x_pos[4]),
        .O(i__carry_i_2__1_n_0));
  LUT3 #(
    .INIT(8'h69)) 
    i__carry_i_2__2
       (.I0(r11_active_y_reg[3]),
        .I1(iw11_block_left_pos[3]),
        .I2(iw11_block_left_pos[2]),
        .O(i__carry_i_2__2_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    i__carry_i_3
       (.I0(iw11_x_pos[3]),
        .I1(iw11_x_pos[2]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[2]),
        .O(i__carry_i_3_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    i__carry_i_3__0
       (.I0(iw11_y_pos[3]),
        .I1(iw11_y_pos[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[2]),
        .O(i__carry_i_3__0_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    i__carry_i_3__1
       (.I0(iw11_block_left_pos[3]),
        .I1(iw11_block_left_pos[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[2]),
        .O(i__carry_i_3__1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_3__2
       (.I0(iw11_block_left_pos[2]),
        .I1(r11_active_y_reg[2]),
        .O(i__carry_i_3__2_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    i__carry_i_4
       (.I0(iw11_x_pos[1]),
        .I1(iw11_x_pos[0]),
        .I2(r11_active_x_reg[1]),
        .I3(r11_active_x_reg[0]),
        .O(i__carry_i_4_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    i__carry_i_4__0
       (.I0(iw11_y_pos[1]),
        .I1(iw11_y_pos[0]),
        .I2(r11_active_y_reg[1]),
        .I3(r11_active_y_reg[0]),
        .O(i__carry_i_4__0_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    i__carry_i_4__1
       (.I0(iw11_block_left_pos[1]),
        .I1(iw11_block_left_pos[0]),
        .I2(r11_active_y_reg[1]),
        .I3(r11_active_y_reg[0]),
        .O(i__carry_i_4__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_4__2
       (.I0(r11_active_y_reg[1]),
        .I1(iw11_block_left_pos[1]),
        .O(i__carry_i_4__2_n_0));
  LUT4 #(
    .INIT(16'h8241)) 
    i__carry_i_5
       (.I0(iw11_y_pos[7]),
        .I1(iw11_y_pos[6]),
        .I2(r11_active_y_reg[6]),
        .I3(r11_active_y_reg[7]),
        .O(i__carry_i_5_n_0));
  LUT4 #(
    .INIT(16'h8241)) 
    i__carry_i_5__0
       (.I0(iw11_block_left_pos[7]),
        .I1(iw11_block_left_pos[6]),
        .I2(r11_active_y_reg[6]),
        .I3(r11_active_y_reg[7]),
        .O(i__carry_i_5__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry_i_5__1
       (.I0(iw11_x_pos[6]),
        .I1(r11_active_x_reg[6]),
        .I2(iw11_x_pos[7]),
        .I3(r11_active_x_reg[7]),
        .O(i__carry_i_5__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_5__2
       (.I0(r11_active_y_reg[0]),
        .I1(iw11_block_left_pos[0]),
        .O(i__carry_i_5__2_n_0));
  LUT4 #(
    .INIT(16'h8241)) 
    i__carry_i_6
       (.I0(iw11_y_pos[5]),
        .I1(iw11_y_pos[4]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[5]),
        .O(i__carry_i_6_n_0));
  LUT4 #(
    .INIT(16'h8241)) 
    i__carry_i_6__0
       (.I0(iw11_block_left_pos[5]),
        .I1(iw11_block_left_pos[4]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[5]),
        .O(i__carry_i_6__0_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry_i_6__1
       (.I0(iw11_x_pos[4]),
        .I1(r11_active_x_reg[4]),
        .I2(iw11_x_pos[5]),
        .I3(r11_active_x_reg[5]),
        .O(i__carry_i_6__1_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    i__carry_i_7
       (.I0(r11_active_y_reg[3]),
        .I1(iw11_block_left_pos[3]),
        .I2(r11_active_y_reg[2]),
        .I3(iw11_block_left_pos[2]),
        .O(i__carry_i_7_n_0));
  LUT4 #(
    .INIT(16'h8241)) 
    i__carry_i_7__0
       (.I0(iw11_x_pos[3]),
        .I1(iw11_x_pos[2]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[3]),
        .O(i__carry_i_7__0_n_0));
  LUT4 #(
    .INIT(16'h8241)) 
    i__carry_i_7__1
       (.I0(iw11_y_pos[3]),
        .I1(iw11_y_pos[2]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[3]),
        .O(i__carry_i_7__1_n_0));
  LUT4 #(
    .INIT(16'h8241)) 
    i__carry_i_8
       (.I0(iw11_x_pos[1]),
        .I1(iw11_x_pos[0]),
        .I2(r11_active_x_reg[0]),
        .I3(r11_active_x_reg[1]),
        .O(i__carry_i_8_n_0));
  LUT4 #(
    .INIT(16'h8241)) 
    i__carry_i_8__0
       (.I0(iw11_y_pos[1]),
        .I1(iw11_y_pos[0]),
        .I2(r11_active_y_reg[0]),
        .I3(r11_active_y_reg[1]),
        .O(i__carry_i_8__0_n_0));
  LUT4 #(
    .INIT(16'h8241)) 
    i__carry_i_8__1
       (.I0(iw11_block_left_pos[1]),
        .I1(iw11_block_left_pos[0]),
        .I2(r11_active_y_reg[0]),
        .I3(r11_active_y_reg[1]),
        .O(i__carry_i_8__1_n_0));
  LUT5 #(
    .INIT(32'h80000000)) 
    \ow4_blue[0]_INST_0 
       (.I0(w_vactive040_in),
        .I1(\ow4_red[3]_INST_0_i_2_n_0 ),
        .I2(w_hactive041_in),
        .I3(\ow4_red[3]_INST_0_i_4_n_0 ),
        .I4(\r4_blue_reg_n_0_[0] ),
        .O(ow4_blue[0]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \ow4_blue[1]_INST_0 
       (.I0(w_vactive040_in),
        .I1(\ow4_red[3]_INST_0_i_2_n_0 ),
        .I2(w_hactive041_in),
        .I3(\ow4_red[3]_INST_0_i_4_n_0 ),
        .I4(\r4_blue_reg_n_0_[1] ),
        .O(ow4_blue[1]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \ow4_blue[2]_INST_0 
       (.I0(w_vactive040_in),
        .I1(\ow4_red[3]_INST_0_i_2_n_0 ),
        .I2(w_hactive041_in),
        .I3(\ow4_red[3]_INST_0_i_4_n_0 ),
        .I4(\r4_blue_reg_n_0_[2] ),
        .O(ow4_blue[2]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \ow4_blue[3]_INST_0 
       (.I0(w_vactive040_in),
        .I1(\ow4_red[3]_INST_0_i_2_n_0 ),
        .I2(w_hactive041_in),
        .I3(\ow4_red[3]_INST_0_i_4_n_0 ),
        .I4(\r4_blue_reg_n_0_[3] ),
        .O(ow4_blue[3]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \ow4_green[0]_INST_0 
       (.I0(w_vactive040_in),
        .I1(\ow4_red[3]_INST_0_i_2_n_0 ),
        .I2(w_hactive041_in),
        .I3(\ow4_red[3]_INST_0_i_4_n_0 ),
        .I4(\r4_green_reg_n_0_[0] ),
        .O(ow4_green[0]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \ow4_green[1]_INST_0 
       (.I0(w_vactive040_in),
        .I1(\ow4_red[3]_INST_0_i_2_n_0 ),
        .I2(w_hactive041_in),
        .I3(\ow4_red[3]_INST_0_i_4_n_0 ),
        .I4(\r4_green_reg_n_0_[1] ),
        .O(ow4_green[1]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \ow4_green[2]_INST_0 
       (.I0(w_vactive040_in),
        .I1(\ow4_red[3]_INST_0_i_2_n_0 ),
        .I2(w_hactive041_in),
        .I3(\ow4_red[3]_INST_0_i_4_n_0 ),
        .I4(\r4_green_reg_n_0_[2] ),
        .O(ow4_green[2]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \ow4_green[3]_INST_0 
       (.I0(w_vactive040_in),
        .I1(\ow4_red[3]_INST_0_i_2_n_0 ),
        .I2(w_hactive041_in),
        .I3(\ow4_red[3]_INST_0_i_4_n_0 ),
        .I4(\r4_green_reg_n_0_[3] ),
        .O(ow4_green[3]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \ow4_red[0]_INST_0 
       (.I0(w_vactive040_in),
        .I1(\ow4_red[3]_INST_0_i_2_n_0 ),
        .I2(w_hactive041_in),
        .I3(\ow4_red[3]_INST_0_i_4_n_0 ),
        .I4(\r4_red_reg_n_0_[0] ),
        .O(ow4_red[0]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \ow4_red[1]_INST_0 
       (.I0(w_vactive040_in),
        .I1(\ow4_red[3]_INST_0_i_2_n_0 ),
        .I2(w_hactive041_in),
        .I3(\ow4_red[3]_INST_0_i_4_n_0 ),
        .I4(\r4_red_reg_n_0_[1] ),
        .O(ow4_red[1]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \ow4_red[2]_INST_0 
       (.I0(w_vactive040_in),
        .I1(\ow4_red[3]_INST_0_i_2_n_0 ),
        .I2(w_hactive041_in),
        .I3(\ow4_red[3]_INST_0_i_4_n_0 ),
        .I4(\r4_red_reg_n_0_[2] ),
        .O(ow4_red[2]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \ow4_red[3]_INST_0 
       (.I0(w_vactive040_in),
        .I1(\ow4_red[3]_INST_0_i_2_n_0 ),
        .I2(w_hactive041_in),
        .I3(\ow4_red[3]_INST_0_i_4_n_0 ),
        .I4(\r4_red_reg_n_0_[3] ),
        .O(ow4_red[3]));
  (* SOFT_HLUTNM = "soft_lutpair76" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \ow4_red[3]_INST_0_i_1 
       (.I0(\ow4_red[3]_INST_0_i_5_n_0 ),
        .I1(\r11_v_count_reg_n_0_[5] ),
        .I2(\r11_v_count_reg_n_0_[9] ),
        .O(w_vactive040_in));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT5 #(
    .INIT(32'h7777777F)) 
    \ow4_red[3]_INST_0_i_10 
       (.I0(r11_h_count_reg[5]),
        .I1(r11_h_count_reg[4]),
        .I2(r11_h_count_reg[0]),
        .I3(r11_h_count_reg[1]),
        .I4(r11_h_count_reg[2]),
        .O(\ow4_red[3]_INST_0_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h00FF00FFFFFF57FF)) 
    \ow4_red[3]_INST_0_i_2 
       (.I0(\r11_v_count_reg_n_0_[4] ),
        .I1(\r11_v_count_reg_n_0_[3] ),
        .I2(\r11_v_count_reg_n_0_[2] ),
        .I3(\r11_v_count_reg_n_0_[9] ),
        .I4(\ow4_red[3]_INST_0_i_6_n_0 ),
        .I5(\ow4_red[3]_INST_0_i_7_n_0 ),
        .O(\ow4_red[3]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAFEEEEEEE)) 
    \ow4_red[3]_INST_0_i_3 
       (.I0(ow_hsync_INST_0_i_2_n_0),
        .I1(r11_h_count_reg[5]),
        .I2(\ow4_red[3]_INST_0_i_8_n_0 ),
        .I3(r11_h_count_reg[4]),
        .I4(r11_h_count_reg[3]),
        .I5(\ow4_red[3]_INST_0_i_9_n_0 ),
        .O(w_hactive041_in));
  LUT6 #(
    .INIT(64'h00000000FBFFFFFF)) 
    \ow4_red[3]_INST_0_i_4 
       (.I0(\ow4_red[3]_INST_0_i_10_n_0 ),
        .I1(r11_h_count_reg[8]),
        .I2(\ow4_red[3]_INST_0_i_9_n_0 ),
        .I3(r11_h_count_reg[3]),
        .I4(r11_h_count_reg[9]),
        .I5(r11_h_count_reg[10]),
        .O(\ow4_red[3]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFEFEFEFEFEFEFE)) 
    \ow4_red[3]_INST_0_i_5 
       (.I0(\r11_v_count_reg_n_0_[7] ),
        .I1(\r11_v_count_reg_n_0_[8] ),
        .I2(\r11_v_count_reg_n_0_[6] ),
        .I3(\r11_v_count_reg_n_0_[2] ),
        .I4(\r11_v_count_reg_n_0_[3] ),
        .I5(\r11_v_count_reg_n_0_[4] ),
        .O(\ow4_red[3]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \ow4_red[3]_INST_0_i_6 
       (.I0(\r11_v_count_reg_n_0_[5] ),
        .I1(\r11_v_count_reg_n_0_[6] ),
        .O(\ow4_red[3]_INST_0_i_6_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \ow4_red[3]_INST_0_i_7 
       (.I0(\r11_v_count_reg_n_0_[7] ),
        .I1(\r11_v_count_reg_n_0_[8] ),
        .O(\ow4_red[3]_INST_0_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \ow4_red[3]_INST_0_i_8 
       (.I0(r11_h_count_reg[2]),
        .I1(r11_h_count_reg[1]),
        .I2(r11_h_count_reg[0]),
        .O(\ow4_red[3]_INST_0_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \ow4_red[3]_INST_0_i_9 
       (.I0(r11_h_count_reg[6]),
        .I1(r11_h_count_reg[7]),
        .O(\ow4_red[3]_INST_0_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h000000000002FFFF)) 
    ow_hsync_INST_0
       (.I0(ow_hsync_INST_0_i_1_n_0),
        .I1(r11_h_count_reg[0]),
        .I2(r11_h_count_reg[1]),
        .I3(r11_h_count_reg[2]),
        .I4(r11_h_count_reg[7]),
        .I5(ow_hsync_INST_0_i_2_n_0),
        .O(ow_hsync));
  (* SOFT_HLUTNM = "soft_lutpair71" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    ow_hsync_INST_0_i_1
       (.I0(r11_h_count_reg[4]),
        .I1(r11_h_count_reg[3]),
        .I2(r11_h_count_reg[6]),
        .I3(r11_h_count_reg[5]),
        .O(ow_hsync_INST_0_i_1_n_0));
  LUT3 #(
    .INIT(8'hFE)) 
    ow_hsync_INST_0_i_2
       (.I0(r11_h_count_reg[9]),
        .I1(r11_h_count_reg[8]),
        .I2(r11_h_count_reg[10]),
        .O(ow_hsync_INST_0_i_2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT5 #(
    .INIT(32'h0202020A)) 
    ow_vsync_INST_0
       (.I0(ow_vsync_INST_0_i_1_n_0),
        .I1(\r11_v_count_reg_n_0_[2] ),
        .I2(\r11_v_count_reg_n_0_[3] ),
        .I3(\r11_v_count_reg_n_0_[1] ),
        .I4(\r11_v_count_reg_n_0_[0] ),
        .O(ow_vsync));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    ow_vsync_INST_0_i_1
       (.I0(\r11_v_count_reg_n_0_[6] ),
        .I1(\r11_v_count_reg_n_0_[9] ),
        .I2(\r11_v_count_reg_n_0_[4] ),
        .I3(\r11_v_count_reg_n_0_[5] ),
        .I4(\r11_v_count_reg_n_0_[8] ),
        .I5(\r11_v_count_reg_n_0_[7] ),
        .O(ow_vsync_INST_0_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT5 #(
    .INIT(32'h99280089)) 
    \p_0_out_inferred__4/r4_red[3]_i_204 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[4]),
        .I4(r11_active_y_reg[5]),
        .O(\p_0_out_inferred__4/r4_red[3]_i_204_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT4 #(
    .INIT(16'h80BF)) 
    \p_0_out_inferred__4/r4_red[3]_i_206 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[5]),
        .O(\p_0_out_inferred__4/r4_red[3]_i_206_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair44" *) 
  LUT4 #(
    .INIT(16'hFBFF)) 
    \p_0_out_inferred__4/r4_red[3]_i_210 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[5]),
        .O(\p_0_out_inferred__4/r4_red[3]_i_210_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT5 #(
    .INIT(32'hFF3BFFFF)) 
    \p_0_out_inferred__4/r4_red[3]_i_211 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[4]),
        .I4(r11_active_y_reg[5]),
        .O(\p_0_out_inferred__4/r4_red[3]_i_211_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT5 #(
    .INIT(32'h17BB00A8)) 
    \p_0_out_inferred__4/r4_red[3]_i_222 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[4]),
        .I4(r11_active_y_reg[5]),
        .O(\p_0_out_inferred__4/r4_red[3]_i_222_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT5 #(
    .INIT(32'hB9280000)) 
    \p_0_out_inferred__4/r4_red[3]_i_223 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[4]),
        .I4(r11_active_y_reg[5]),
        .O(\p_0_out_inferred__4/r4_red[3]_i_223_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT5 #(
    .INIT(32'h55115402)) 
    \p_0_out_inferred__4/r4_red[3]_i_269 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[4]),
        .I4(r11_active_y_reg[5]),
        .O(\p_0_out_inferred__4/r4_red[3]_i_269_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT5 #(
    .INIT(32'h91280011)) 
    \p_0_out_inferred__4/r4_red[3]_i_270 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[4]),
        .I4(r11_active_y_reg[5]),
        .O(\p_0_out_inferred__4/r4_red[3]_i_270_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT5 #(
    .INIT(32'h551157FE)) 
    \p_0_out_inferred__4/r4_red[3]_i_271 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[4]),
        .I4(r11_active_y_reg[5]),
        .O(\p_0_out_inferred__4/r4_red[3]_i_271_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT5 #(
    .INIT(32'h91280099)) 
    \p_0_out_inferred__4/r4_red[3]_i_272 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[4]),
        .I4(r11_active_y_reg[5]),
        .O(\p_0_out_inferred__4/r4_red[3]_i_272_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT5 #(
    .INIT(32'hB9280088)) 
    \p_0_out_inferred__4/r4_red[3]_i_273 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[4]),
        .I4(r11_active_y_reg[5]),
        .O(\p_0_out_inferred__4/r4_red[3]_i_273_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair46" *) 
  LUT4 #(
    .INIT(16'hA2B1)) 
    \p_0_out_inferred__4/r4_red[3]_i_274 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[5]),
        .O(\p_0_out_inferred__4/r4_red[3]_i_274_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT5 #(
    .INIT(32'h7E23FFEE)) 
    \p_0_out_inferred__4/r4_red[3]_i_275 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[4]),
        .I4(r11_active_y_reg[5]),
        .O(\p_0_out_inferred__4/r4_red[3]_i_275_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT5 #(
    .INIT(32'h37BB4044)) 
    \p_0_out_inferred__4/r4_red[3]_i_276 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[4]),
        .I4(r11_active_y_reg[5]),
        .O(\p_0_out_inferred__4/r4_red[3]_i_276_n_0 ));
  CARRY4 p_1_out_carry
       (.CI(1'b0),
        .CO({p_1_out_carry_n_0,p_1_out_carry_n_1,p_1_out_carry_n_2,p_1_out_carry_n_3}),
        .CYINIT(1'b1),
        .DI({p_1_out_carry_i_1_n_0,iw11_block_right_pos[2],r11_active_y_reg[1:0]}),
        .O(NLW_p_1_out_carry_O_UNCONNECTED[3:0]),
        .S({p_1_out_carry_i_2_n_0,p_1_out_carry_i_3_n_0,p_1_out_carry_i_4_n_0,p_1_out_carry_i_5_n_0}));
  CARRY4 p_1_out_carry__0
       (.CI(p_1_out_carry_n_0),
        .CO({p_1_out_carry__0_n_0,p_1_out_carry__0_n_1,p_1_out_carry__0_n_2,p_1_out_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({p_1_out_carry__0_i_1_n_0,p_1_out_carry__0_i_2_n_0,p_1_out_carry__0_i_3_n_0,p_1_out_carry__0_i_4_n_0}),
        .O(NLW_p_1_out_carry__0_O_UNCONNECTED[3:0]),
        .S({p_1_out_carry__0_i_5_n_0,p_1_out_carry__0_i_6_n_0,p_1_out_carry__0_i_7_n_0,p_1_out_carry__0_i_8_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    p_1_out_carry__0_i_1
       (.I0(r11_active_y_reg[7]),
        .I1(iw11_block_right_pos[7]),
        .O(p_1_out_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    p_1_out_carry__0_i_2
       (.I0(r11_active_y_reg[5]),
        .I1(iw11_block_right_pos[5]),
        .O(p_1_out_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    p_1_out_carry__0_i_3
       (.I0(r11_active_y_reg[4]),
        .I1(iw11_block_right_pos[4]),
        .O(p_1_out_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    p_1_out_carry__0_i_4
       (.I0(r11_active_y_reg[3]),
        .I1(iw11_block_right_pos[3]),
        .O(p_1_out_carry__0_i_4_n_0));
  LUT4 #(
    .INIT(16'h6966)) 
    p_1_out_carry__0_i_5
       (.I0(iw11_block_right_pos[7]),
        .I1(r11_active_y_reg[7]),
        .I2(iw11_block_right_pos[6]),
        .I3(r11_active_y_reg[6]),
        .O(p_1_out_carry__0_i_5_n_0));
  LUT4 #(
    .INIT(16'hB44B)) 
    p_1_out_carry__0_i_6
       (.I0(iw11_block_right_pos[5]),
        .I1(r11_active_y_reg[5]),
        .I2(iw11_block_right_pos[6]),
        .I3(r11_active_y_reg[6]),
        .O(p_1_out_carry__0_i_6_n_0));
  LUT4 #(
    .INIT(16'h2DD2)) 
    p_1_out_carry__0_i_7
       (.I0(iw11_block_right_pos[4]),
        .I1(r11_active_y_reg[4]),
        .I2(iw11_block_right_pos[5]),
        .I3(r11_active_y_reg[5]),
        .O(p_1_out_carry__0_i_7_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    p_1_out_carry__0_i_8
       (.I0(iw11_block_right_pos[3]),
        .I1(r11_active_y_reg[3]),
        .I2(iw11_block_right_pos[4]),
        .I3(r11_active_y_reg[4]),
        .O(p_1_out_carry__0_i_8_n_0));
  CARRY4 p_1_out_carry__1
       (.CI(p_1_out_carry__0_n_0),
        .CO({p_1_out_carry__1_n_0,p_1_out_carry__1_n_1,p_1_out_carry__1_n_2,p_1_out_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,p_1_out_carry__1_i_1_n_0,p_1_out_carry__1_i_2_n_0,p_1_out_carry__1_i_3_n_0}),
        .O(NLW_p_1_out_carry__1_O_UNCONNECTED[3:0]),
        .S({p_1_out_carry__1_i_4_n_0,p_1_out_carry__1_i_5_n_0,p_1_out_carry__1_i_6_n_0,p_1_out_carry__1_i_7_n_0}));
  LUT2 #(
    .INIT(4'hB)) 
    p_1_out_carry__1_i_1
       (.I0(r11_active_y_reg[9]),
        .I1(iw11_block_right_pos[9]),
        .O(p_1_out_carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    p_1_out_carry__1_i_2
       (.I0(iw11_block_right_pos[9]),
        .I1(r11_active_y_reg[9]),
        .O(p_1_out_carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    p_1_out_carry__1_i_3
       (.I0(iw11_block_right_pos[8]),
        .I1(r11_active_y_reg[8]),
        .O(p_1_out_carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    p_1_out_carry__1_i_4
       (.I0(r11_active_y_reg[10]),
        .I1(iw11_block_right_pos[10]),
        .O(p_1_out_carry__1_i_4_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    p_1_out_carry__1_i_5
       (.I0(iw11_block_right_pos[9]),
        .I1(r11_active_y_reg[9]),
        .I2(iw11_block_right_pos[10]),
        .I3(r11_active_y_reg[10]),
        .O(p_1_out_carry__1_i_5_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    p_1_out_carry__1_i_6
       (.I0(iw11_block_right_pos[8]),
        .I1(r11_active_y_reg[8]),
        .I2(r11_active_y_reg[9]),
        .I3(iw11_block_right_pos[9]),
        .O(p_1_out_carry__1_i_6_n_0));
  LUT4 #(
    .INIT(16'hD22D)) 
    p_1_out_carry__1_i_7
       (.I0(iw11_block_right_pos[7]),
        .I1(r11_active_y_reg[7]),
        .I2(r11_active_y_reg[8]),
        .I3(iw11_block_right_pos[8]),
        .O(p_1_out_carry__1_i_7_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    p_1_out_carry_i_1
       (.I0(iw11_block_right_pos[3]),
        .I1(r11_active_y_reg[3]),
        .O(p_1_out_carry_i_1_n_0));
  LUT3 #(
    .INIT(8'h69)) 
    p_1_out_carry_i_2
       (.I0(r11_active_y_reg[3]),
        .I1(iw11_block_right_pos[3]),
        .I2(iw11_block_right_pos[2]),
        .O(p_1_out_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    p_1_out_carry_i_3
       (.I0(iw11_block_right_pos[2]),
        .I1(r11_active_y_reg[2]),
        .O(p_1_out_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    p_1_out_carry_i_4
       (.I0(r11_active_y_reg[1]),
        .I1(iw11_block_right_pos[1]),
        .O(p_1_out_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    p_1_out_carry_i_5
       (.I0(r11_active_y_reg[0]),
        .I1(iw11_block_right_pos[0]),
        .O(p_1_out_carry_i_5_n_0));
  CARRY4 \p_1_out_inferred__0/i__carry 
       (.CI(1'b0),
        .CO({\p_1_out_inferred__0/i__carry_n_0 ,\p_1_out_inferred__0/i__carry_n_1 ,\p_1_out_inferred__0/i__carry_n_2 ,\p_1_out_inferred__0/i__carry_n_3 }),
        .CYINIT(1'b1),
        .DI({i__carry_i_1__1_n_0,iw11_block_left_pos[2],r11_active_y_reg[1:0]}),
        .O(\NLW_p_1_out_inferred__0/i__carry_O_UNCONNECTED [3:0]),
        .S({i__carry_i_2__2_n_0,i__carry_i_3__2_n_0,i__carry_i_4__2_n_0,i__carry_i_5__2_n_0}));
  CARRY4 \p_1_out_inferred__0/i__carry__0 
       (.CI(\p_1_out_inferred__0/i__carry_n_0 ),
        .CO({\p_1_out_inferred__0/i__carry__0_n_0 ,\p_1_out_inferred__0/i__carry__0_n_1 ,\p_1_out_inferred__0/i__carry__0_n_2 ,\p_1_out_inferred__0/i__carry__0_n_3 }),
        .CYINIT(1'b0),
        .DI({i__carry__0_i_1_n_0,i__carry__0_i_2__1_n_0,i__carry__0_i_3_n_0,i__carry__0_i_4_n_0}),
        .O(\NLW_p_1_out_inferred__0/i__carry__0_O_UNCONNECTED [3:0]),
        .S({i__carry__0_i_5_n_0,i__carry__0_i_6_n_0,i__carry__0_i_7_n_0,i__carry__0_i_8_n_0}));
  CARRY4 \p_1_out_inferred__0/i__carry__1 
       (.CI(\p_1_out_inferred__0/i__carry__0_n_0 ),
        .CO({\p_1_out_inferred__0/i__carry__1_n_0 ,\p_1_out_inferred__0/i__carry__1_n_1 ,\p_1_out_inferred__0/i__carry__1_n_2 ,\p_1_out_inferred__0/i__carry__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,i__carry__1_i_1_n_0,i__carry__1_i_2_n_0,i__carry__1_i_3_n_0}),
        .O(\NLW_p_1_out_inferred__0/i__carry__1_O_UNCONNECTED [3:0]),
        .S({i__carry__1_i_4_n_0,i__carry__1_i_5_n_0,i__carry__1_i_6_n_0,i__carry__1_i_7_n_0}));
  CARRY4 \p_1_out_inferred__1/i___0_carry 
       (.CI(1'b0),
        .CO({\p_1_out_inferred__1/i___0_carry_n_0 ,\p_1_out_inferred__1/i___0_carry_n_1 ,\p_1_out_inferred__1/i___0_carry_n_2 ,\p_1_out_inferred__1/i___0_carry_n_3 }),
        .CYINIT(1'b1),
        .DI({i___0_carry_i_1_n_0,i___0_carry_i_2_n_0,i___0_carry_i_3_n_0,i___0_carry_i_4_n_0}),
        .O(\NLW_p_1_out_inferred__1/i___0_carry_O_UNCONNECTED [3:0]),
        .S({i___0_carry_i_5_n_0,i___0_carry_i_6_n_0,i___0_carry_i_7_n_0,i___0_carry_i_8_n_0}));
  CARRY4 \p_1_out_inferred__1/i___0_carry__0 
       (.CI(\p_1_out_inferred__1/i___0_carry_n_0 ),
        .CO({\p_1_out_inferred__1/i___0_carry__0_n_0 ,\p_1_out_inferred__1/i___0_carry__0_n_1 ,\p_1_out_inferred__1/i___0_carry__0_n_2 ,\p_1_out_inferred__1/i___0_carry__0_n_3 }),
        .CYINIT(1'b0),
        .DI({i___0_carry__0_i_1_n_0,i___0_carry__0_i_2_n_0,i___0_carry__0_i_3_n_0,i___0_carry__0_i_4_n_0}),
        .O(\NLW_p_1_out_inferred__1/i___0_carry__0_O_UNCONNECTED [3:0]),
        .S({i___0_carry__0_i_5_n_0,i___0_carry__0_i_6_n_0,i___0_carry__0_i_7_n_0,i___0_carry__0_i_8_n_0}));
  CARRY4 \p_1_out_inferred__1/i___0_carry__1 
       (.CI(\p_1_out_inferred__1/i___0_carry__0_n_0 ),
        .CO({\p_1_out_inferred__1/i___0_carry__1_n_0 ,\p_1_out_inferred__1/i___0_carry__1_n_1 ,\p_1_out_inferred__1/i___0_carry__1_n_2 ,\p_1_out_inferred__1/i___0_carry__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,i___0_carry__1_i_1_n_0,i___0_carry__1_i_2_n_0,i___0_carry__1_i_3_n_0}),
        .O(\NLW_p_1_out_inferred__1/i___0_carry__1_O_UNCONNECTED [3:0]),
        .S({i___0_carry__1_i_4_n_0,i___0_carry__1_i_5_n_0,i___0_carry__1_i_6_n_0,i___0_carry__1_i_7_n_0}));
  CARRY4 \p_1_out_inferred__2/i___0_carry 
       (.CI(1'b0),
        .CO({\p_1_out_inferred__2/i___0_carry_n_0 ,\p_1_out_inferred__2/i___0_carry_n_1 ,\p_1_out_inferred__2/i___0_carry_n_2 ,\p_1_out_inferred__2/i___0_carry_n_3 }),
        .CYINIT(1'b1),
        .DI({i___0_carry_i_1__0_n_0,i___0_carry_i_2__0_n_0,i___0_carry_i_3__0_n_0,i___0_carry_i_4__0_n_0}),
        .O(\NLW_p_1_out_inferred__2/i___0_carry_O_UNCONNECTED [3:0]),
        .S({i___0_carry_i_5__0_n_0,i___0_carry_i_6__0_n_0,i___0_carry_i_7__0_n_0,i___0_carry_i_8__0_n_0}));
  CARRY4 \p_1_out_inferred__2/i___0_carry__0 
       (.CI(\p_1_out_inferred__2/i___0_carry_n_0 ),
        .CO({\p_1_out_inferred__2/i___0_carry__0_n_0 ,\p_1_out_inferred__2/i___0_carry__0_n_1 ,\p_1_out_inferred__2/i___0_carry__0_n_2 ,\p_1_out_inferred__2/i___0_carry__0_n_3 }),
        .CYINIT(1'b0),
        .DI({i___0_carry__0_i_1__0_n_0,i___0_carry__0_i_2__0_n_0,i___0_carry__0_i_3__0_n_0,i___0_carry__0_i_4__0_n_0}),
        .O(\NLW_p_1_out_inferred__2/i___0_carry__0_O_UNCONNECTED [3:0]),
        .S({i___0_carry__0_i_5__0_n_0,i___0_carry__0_i_6__0_n_0,i___0_carry__0_i_7__0_n_0,i___0_carry__0_i_8__0_n_0}));
  CARRY4 \p_1_out_inferred__2/i___0_carry__1 
       (.CI(\p_1_out_inferred__2/i___0_carry__0_n_0 ),
        .CO({\p_1_out_inferred__2/i___0_carry__1_n_0 ,\p_1_out_inferred__2/i___0_carry__1_n_1 ,\p_1_out_inferred__2/i___0_carry__1_n_2 ,\p_1_out_inferred__2/i___0_carry__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,i___0_carry__1_i_1__0_n_0,i___0_carry__1_i_2__0_n_0,i___0_carry__1_i_3__0_n_0}),
        .O(\NLW_p_1_out_inferred__2/i___0_carry__1_O_UNCONNECTED [3:0]),
        .S({i___0_carry__1_i_4__0_n_0,i___0_carry__1_i_5__0_n_0,i___0_carry__1_i_6__0_n_0,i___0_carry__1_i_7__0_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    \r11_active_x[0]_i_1 
       (.I0(r11_active_x_reg[0]),
        .O(\r11_active_x[0]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \r11_active_x[10]_i_1 
       (.I0(\ow4_red[3]_INST_0_i_4_n_0 ),
        .I1(w_hactive041_in),
        .O(p_43_in));
  LUT6 #(
    .INIT(64'hFFFF7FFF00008000)) 
    \r11_active_x[10]_i_2 
       (.I0(r11_active_x_reg[9]),
        .I1(r11_active_x_reg[6]),
        .I2(r11_active_x_reg[8]),
        .I3(r11_active_x_reg[7]),
        .I4(\r11_active_x[10]_i_3_n_0 ),
        .I5(r11_active_x_reg[10]),
        .O(p_0_in__0[10]));
  LUT6 #(
    .INIT(64'h7FFFFFFFFFFFFFFF)) 
    \r11_active_x[10]_i_3 
       (.I0(r11_active_x_reg[5]),
        .I1(r11_active_x_reg[2]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[4]),
        .I4(r11_active_x_reg[1]),
        .I5(r11_active_x_reg[0]),
        .O(\r11_active_x[10]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair83" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \r11_active_x[1]_i_1 
       (.I0(r11_active_x_reg[0]),
        .I1(r11_active_x_reg[1]),
        .O(p_0_in__0[1]));
  (* SOFT_HLUTNM = "soft_lutpair78" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \r11_active_x[2]_i_1 
       (.I0(r11_active_x_reg[0]),
        .I1(r11_active_x_reg[1]),
        .I2(r11_active_x_reg[2]),
        .O(p_0_in__0[2]));
  (* SOFT_HLUTNM = "soft_lutpair63" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \r11_active_x[3]_i_1 
       (.I0(r11_active_x_reg[2]),
        .I1(r11_active_x_reg[1]),
        .I2(r11_active_x_reg[0]),
        .I3(r11_active_x_reg[3]),
        .O(p_0_in__0[3]));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \r11_active_x[4]_i_1 
       (.I0(r11_active_x_reg[3]),
        .I1(r11_active_x_reg[2]),
        .I2(r11_active_x_reg[1]),
        .I3(r11_active_x_reg[0]),
        .I4(r11_active_x_reg[4]),
        .O(p_0_in__0[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \r11_active_x[5]_i_1 
       (.I0(r11_active_x_reg[2]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[1]),
        .I4(r11_active_x_reg[0]),
        .I5(r11_active_x_reg[5]),
        .O(p_0_in__0[5]));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT5 #(
    .INIT(32'hF7FF0800)) 
    \r11_active_x[6]_i_1 
       (.I0(r11_active_x_reg[0]),
        .I1(r11_active_x_reg[1]),
        .I2(\r11_active_x[8]_i_3_n_0 ),
        .I3(r11_active_x_reg[5]),
        .I4(r11_active_x_reg[6]),
        .O(p_0_in__0[6]));
  LUT6 #(
    .INIT(64'hF7FFFFFF08000000)) 
    \r11_active_x[7]_i_1 
       (.I0(r11_active_x_reg[6]),
        .I1(r11_active_x_reg[5]),
        .I2(\r11_active_x[8]_i_3_n_0 ),
        .I3(r11_active_x_reg[1]),
        .I4(r11_active_x_reg[0]),
        .I5(r11_active_x_reg[7]),
        .O(p_0_in__0[7]));
  LUT6 #(
    .INIT(64'hFDFFFFFF02000000)) 
    \r11_active_x[8]_i_1 
       (.I0(r11_active_x_reg[7]),
        .I1(\r11_active_x[8]_i_2_n_0 ),
        .I2(\r11_active_x[8]_i_3_n_0 ),
        .I3(r11_active_x_reg[5]),
        .I4(r11_active_x_reg[6]),
        .I5(r11_active_x_reg[8]),
        .O(p_0_in__0[8]));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \r11_active_x[8]_i_2 
       (.I0(r11_active_x_reg[1]),
        .I1(r11_active_x_reg[0]),
        .O(\r11_active_x[8]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair70" *) 
  LUT3 #(
    .INIT(8'h7F)) 
    \r11_active_x[8]_i_3 
       (.I0(r11_active_x_reg[2]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[4]),
        .O(\r11_active_x[8]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT5 #(
    .INIT(32'hBFFF4000)) 
    \r11_active_x[9]_i_1 
       (.I0(\r11_active_x[10]_i_3_n_0 ),
        .I1(r11_active_x_reg[7]),
        .I2(r11_active_x_reg[8]),
        .I3(r11_active_x_reg[6]),
        .I4(r11_active_x_reg[9]),
        .O(p_0_in__0[9]));
  FDSE #(
    .INIT(1'b1)) 
    \r11_active_x_reg[0] 
       (.C(iw_pix_clk),
        .CE(p_43_in),
        .D(\r11_active_x[0]_i_1_n_0 ),
        .Q(r11_active_x_reg[0]),
        .S(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_x_reg[10] 
       (.C(iw_pix_clk),
        .CE(p_43_in),
        .D(p_0_in__0[10]),
        .Q(r11_active_x_reg[10]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_x_reg[1] 
       (.C(iw_pix_clk),
        .CE(p_43_in),
        .D(p_0_in__0[1]),
        .Q(r11_active_x_reg[1]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_x_reg[2] 
       (.C(iw_pix_clk),
        .CE(p_43_in),
        .D(p_0_in__0[2]),
        .Q(r11_active_x_reg[2]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_x_reg[3] 
       (.C(iw_pix_clk),
        .CE(p_43_in),
        .D(p_0_in__0[3]),
        .Q(r11_active_x_reg[3]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_x_reg[4] 
       (.C(iw_pix_clk),
        .CE(p_43_in),
        .D(p_0_in__0[4]),
        .Q(r11_active_x_reg[4]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_x_reg[5] 
       (.C(iw_pix_clk),
        .CE(p_43_in),
        .D(p_0_in__0[5]),
        .Q(r11_active_x_reg[5]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_x_reg[6] 
       (.C(iw_pix_clk),
        .CE(p_43_in),
        .D(p_0_in__0[6]),
        .Q(r11_active_x_reg[6]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_x_reg[7] 
       (.C(iw_pix_clk),
        .CE(p_43_in),
        .D(p_0_in__0[7]),
        .Q(r11_active_x_reg[7]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_x_reg[8] 
       (.C(iw_pix_clk),
        .CE(p_43_in),
        .D(p_0_in__0[8]),
        .Q(r11_active_x_reg[8]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_x_reg[9] 
       (.C(iw_pix_clk),
        .CE(p_43_in),
        .D(p_0_in__0[9]),
        .Q(r11_active_x_reg[9]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \r11_active_y[0]_i_1 
       (.I0(r11_active_y_reg[0]),
        .O(p_0_in__1[0]));
  LUT3 #(
    .INIT(8'h80)) 
    \r11_active_y[10]_i_1 
       (.I0(\ow4_red[3]_INST_0_i_2_n_0 ),
        .I1(\r11_v_count[9]_i_2_n_0 ),
        .I2(w_vactive040_in),
        .O(r11_active_y));
  LUT6 #(
    .INIT(64'hBFFFFFFF40000000)) 
    \r11_active_y[10]_i_2 
       (.I0(\r11_active_y[10]_i_3_n_0 ),
        .I1(r11_active_y_reg[6]),
        .I2(r11_active_y_reg[7]),
        .I3(r11_active_y_reg[9]),
        .I4(r11_active_y_reg[8]),
        .I5(r11_active_y_reg[10]),
        .O(p_0_in__1[10]));
  LUT6 #(
    .INIT(64'h7FFFFFFFFFFFFFFF)) 
    \r11_active_y[10]_i_3 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[5]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[1]),
        .I5(r11_active_y_reg[0]),
        .O(\r11_active_y[10]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair84" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \r11_active_y[1]_i_1 
       (.I0(r11_active_y_reg[1]),
        .I1(r11_active_y_reg[0]),
        .O(p_0_in__1[1]));
  (* SOFT_HLUTNM = "soft_lutpair66" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \r11_active_y[2]_i_1 
       (.I0(r11_active_y_reg[0]),
        .I1(r11_active_y_reg[1]),
        .I2(r11_active_y_reg[2]),
        .O(p_0_in__1[2]));
  (* SOFT_HLUTNM = "soft_lutpair66" *) 
  LUT4 #(
    .INIT(16'h6CCC)) 
    \r11_active_y[3]_i_1 
       (.I0(r11_active_y_reg[2]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[1]),
        .I3(r11_active_y_reg[0]),
        .O(p_0_in__1[3]));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \r11_active_y[4]_i_1 
       (.I0(r11_active_y_reg[3]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[1]),
        .I3(r11_active_y_reg[0]),
        .I4(r11_active_y_reg[4]),
        .O(p_0_in__1[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \r11_active_y[5]_i_1 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[0]),
        .I2(r11_active_y_reg[1]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[3]),
        .I5(r11_active_y_reg[5]),
        .O(p_0_in__1[5]));
  LUT6 #(
    .INIT(64'hBFFFFFFF40000000)) 
    \r11_active_y[6]_i_1 
       (.I0(\r11_active_y[7]_i_3_n_0 ),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[5]),
        .I4(r11_active_y_reg[4]),
        .I5(r11_active_y_reg[6]),
        .O(p_0_in__1[6]));
  LUT6 #(
    .INIT(64'hCCCCCCCCCCCC6CCC)) 
    \r11_active_y[7]_i_1 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[7]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[5]),
        .I4(\r11_active_y[7]_i_2_n_0 ),
        .I5(\r11_active_y[7]_i_3_n_0 ),
        .O(p_0_in__1[7]));
  (* SOFT_HLUTNM = "soft_lutpair65" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \r11_active_y[7]_i_2 
       (.I0(r11_active_y_reg[3]),
        .I1(r11_active_y_reg[2]),
        .O(\r11_active_y[7]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair84" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \r11_active_y[7]_i_3 
       (.I0(r11_active_y_reg[1]),
        .I1(r11_active_y_reg[0]),
        .O(\r11_active_y[7]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT4 #(
    .INIT(16'hF708)) 
    \r11_active_y[8]_i_1 
       (.I0(r11_active_y_reg[7]),
        .I1(r11_active_y_reg[6]),
        .I2(\r11_active_y[10]_i_3_n_0 ),
        .I3(r11_active_y_reg[8]),
        .O(p_0_in__1[8]));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT5 #(
    .INIT(32'hDFFF2000)) 
    \r11_active_y[9]_i_1 
       (.I0(r11_active_y_reg[8]),
        .I1(\r11_active_y[10]_i_3_n_0 ),
        .I2(r11_active_y_reg[6]),
        .I3(r11_active_y_reg[7]),
        .I4(r11_active_y_reg[9]),
        .O(p_0_in__1[9]));
  FDSE #(
    .INIT(1'b1)) 
    \r11_active_y_reg[0] 
       (.C(iw_pix_clk),
        .CE(r11_active_y),
        .D(p_0_in__1[0]),
        .Q(r11_active_y_reg[0]),
        .S(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_y_reg[10] 
       (.C(iw_pix_clk),
        .CE(r11_active_y),
        .D(p_0_in__1[10]),
        .Q(r11_active_y_reg[10]),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_y_reg[1] 
       (.C(iw_pix_clk),
        .CE(r11_active_y),
        .D(p_0_in__1[1]),
        .Q(r11_active_y_reg[1]),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_y_reg[2] 
       (.C(iw_pix_clk),
        .CE(r11_active_y),
        .D(p_0_in__1[2]),
        .Q(r11_active_y_reg[2]),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_y_reg[3] 
       (.C(iw_pix_clk),
        .CE(r11_active_y),
        .D(p_0_in__1[3]),
        .Q(r11_active_y_reg[3]),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_y_reg[4] 
       (.C(iw_pix_clk),
        .CE(r11_active_y),
        .D(p_0_in__1[4]),
        .Q(r11_active_y_reg[4]),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_y_reg[5] 
       (.C(iw_pix_clk),
        .CE(r11_active_y),
        .D(p_0_in__1[5]),
        .Q(r11_active_y_reg[5]),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_y_reg[6] 
       (.C(iw_pix_clk),
        .CE(r11_active_y),
        .D(p_0_in__1[6]),
        .Q(r11_active_y_reg[6]),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_y_reg[7] 
       (.C(iw_pix_clk),
        .CE(r11_active_y),
        .D(p_0_in__1[7]),
        .Q(r11_active_y_reg[7]),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_y_reg[8] 
       (.C(iw_pix_clk),
        .CE(r11_active_y),
        .D(p_0_in__1[8]),
        .Q(r11_active_y_reg[8]),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_active_y_reg[9] 
       (.C(iw_pix_clk),
        .CE(r11_active_y),
        .D(p_0_in__1[9]),
        .Q(r11_active_y_reg[9]),
        .R(r11_v_count));
  LUT1 #(
    .INIT(2'h1)) 
    \r11_h_count[0]_i_1 
       (.I0(r11_h_count_reg[0]),
        .O(p_0_in[0]));
  LUT6 #(
    .INIT(64'hDFFFFFFF20000000)) 
    \r11_h_count[10]_i_1 
       (.I0(r11_h_count_reg[9]),
        .I1(\r11_h_count[10]_i_2_n_0 ),
        .I2(r11_h_count_reg[6]),
        .I3(r11_h_count_reg[7]),
        .I4(r11_h_count_reg[8]),
        .I5(r11_h_count_reg[10]),
        .O(p_0_in[10]));
  LUT6 #(
    .INIT(64'h7FFFFFFFFFFFFFFF)) 
    \r11_h_count[10]_i_2 
       (.I0(r11_h_count_reg[2]),
        .I1(r11_h_count_reg[0]),
        .I2(r11_h_count_reg[1]),
        .I3(r11_h_count_reg[3]),
        .I4(r11_h_count_reg[4]),
        .I5(r11_h_count_reg[5]),
        .O(\r11_h_count[10]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair77" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \r11_h_count[1]_i_1 
       (.I0(r11_h_count_reg[0]),
        .I1(r11_h_count_reg[1]),
        .O(p_0_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair77" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \r11_h_count[2]_i_1 
       (.I0(r11_h_count_reg[1]),
        .I1(r11_h_count_reg[0]),
        .I2(r11_h_count_reg[2]),
        .O(p_0_in[2]));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \r11_h_count[3]_i_1 
       (.I0(r11_h_count_reg[2]),
        .I1(r11_h_count_reg[0]),
        .I2(r11_h_count_reg[1]),
        .I3(r11_h_count_reg[3]),
        .O(p_0_in[3]));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \r11_h_count[4]_i_1 
       (.I0(r11_h_count_reg[3]),
        .I1(r11_h_count_reg[1]),
        .I2(r11_h_count_reg[0]),
        .I3(r11_h_count_reg[2]),
        .I4(r11_h_count_reg[4]),
        .O(p_0_in[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \r11_h_count[5]_i_1 
       (.I0(r11_h_count_reg[2]),
        .I1(r11_h_count_reg[0]),
        .I2(r11_h_count_reg[1]),
        .I3(r11_h_count_reg[3]),
        .I4(r11_h_count_reg[4]),
        .I5(r11_h_count_reg[5]),
        .O(p_0_in[5]));
  (* SOFT_HLUTNM = "soft_lutpair71" *) 
  LUT2 #(
    .INIT(4'h9)) 
    \r11_h_count[6]_i_1 
       (.I0(\r11_h_count[10]_i_2_n_0 ),
        .I1(r11_h_count_reg[6]),
        .O(p_0_in[6]));
  LUT3 #(
    .INIT(8'hD2)) 
    \r11_h_count[7]_i_1 
       (.I0(r11_h_count_reg[6]),
        .I1(\r11_h_count[10]_i_2_n_0 ),
        .I2(r11_h_count_reg[7]),
        .O(p_0_in[7]));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT4 #(
    .INIT(16'hBF40)) 
    \r11_h_count[8]_i_1 
       (.I0(\r11_h_count[10]_i_2_n_0 ),
        .I1(r11_h_count_reg[6]),
        .I2(r11_h_count_reg[7]),
        .I3(r11_h_count_reg[8]),
        .O(p_0_in[8]));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT5 #(
    .INIT(32'hFF7F0080)) 
    \r11_h_count[9]_i_1 
       (.I0(r11_h_count_reg[8]),
        .I1(r11_h_count_reg[7]),
        .I2(r11_h_count_reg[6]),
        .I3(\r11_h_count[10]_i_2_n_0 ),
        .I4(r11_h_count_reg[9]),
        .O(p_0_in[9]));
  FDSE #(
    .INIT(1'b1)) 
    \r11_h_count_reg[0] 
       (.C(iw_pix_clk),
        .CE(1'b1),
        .D(p_0_in[0]),
        .Q(r11_h_count_reg[0]),
        .S(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_h_count_reg[10] 
       (.C(iw_pix_clk),
        .CE(1'b1),
        .D(p_0_in[10]),
        .Q(r11_h_count_reg[10]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_h_count_reg[1] 
       (.C(iw_pix_clk),
        .CE(1'b1),
        .D(p_0_in[1]),
        .Q(r11_h_count_reg[1]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_h_count_reg[2] 
       (.C(iw_pix_clk),
        .CE(1'b1),
        .D(p_0_in[2]),
        .Q(r11_h_count_reg[2]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_h_count_reg[3] 
       (.C(iw_pix_clk),
        .CE(1'b1),
        .D(p_0_in[3]),
        .Q(r11_h_count_reg[3]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_h_count_reg[4] 
       (.C(iw_pix_clk),
        .CE(1'b1),
        .D(p_0_in[4]),
        .Q(r11_h_count_reg[4]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_h_count_reg[5] 
       (.C(iw_pix_clk),
        .CE(1'b1),
        .D(p_0_in[5]),
        .Q(r11_h_count_reg[5]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_h_count_reg[6] 
       (.C(iw_pix_clk),
        .CE(1'b1),
        .D(p_0_in[6]),
        .Q(r11_h_count_reg[6]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_h_count_reg[7] 
       (.C(iw_pix_clk),
        .CE(1'b1),
        .D(p_0_in[7]),
        .Q(r11_h_count_reg[7]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_h_count_reg[8] 
       (.C(iw_pix_clk),
        .CE(1'b1),
        .D(p_0_in[8]),
        .Q(r11_h_count_reg[8]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \r11_h_count_reg[9] 
       (.C(iw_pix_clk),
        .CE(1'b1),
        .D(p_0_in[9]),
        .Q(r11_h_count_reg[9]),
        .R(\r11_v_count[9]_i_2_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \r11_v_count[0]_i_1 
       (.I0(\r11_v_count_reg_n_0_[0] ),
        .O(p_1_in[0]));
  (* SOFT_HLUTNM = "soft_lutpair82" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \r11_v_count[1]_i_1 
       (.I0(\r11_v_count_reg_n_0_[0] ),
        .I1(\r11_v_count_reg_n_0_[1] ),
        .O(p_1_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair82" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \r11_v_count[2]_i_1 
       (.I0(\r11_v_count_reg_n_0_[0] ),
        .I1(\r11_v_count_reg_n_0_[1] ),
        .I2(\r11_v_count_reg_n_0_[2] ),
        .O(p_1_in[2]));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \r11_v_count[3]_i_1 
       (.I0(\r11_v_count_reg_n_0_[2] ),
        .I1(\r11_v_count_reg_n_0_[1] ),
        .I2(\r11_v_count_reg_n_0_[0] ),
        .I3(\r11_v_count_reg_n_0_[3] ),
        .O(p_1_in[3]));
  (* SOFT_HLUTNM = "soft_lutpair42" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \r11_v_count[4]_i_1 
       (.I0(\r11_v_count_reg_n_0_[3] ),
        .I1(\r11_v_count_reg_n_0_[0] ),
        .I2(\r11_v_count_reg_n_0_[1] ),
        .I3(\r11_v_count_reg_n_0_[2] ),
        .I4(\r11_v_count_reg_n_0_[4] ),
        .O(p_1_in[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \r11_v_count[5]_i_1 
       (.I0(\r11_v_count_reg_n_0_[2] ),
        .I1(\r11_v_count_reg_n_0_[1] ),
        .I2(\r11_v_count_reg_n_0_[0] ),
        .I3(\r11_v_count_reg_n_0_[3] ),
        .I4(\r11_v_count_reg_n_0_[4] ),
        .I5(\r11_v_count_reg_n_0_[5] ),
        .O(p_1_in[5]));
  (* SOFT_HLUTNM = "soft_lutpair76" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \r11_v_count[6]_i_1 
       (.I0(\r11_v_count_reg_n_0_[5] ),
        .I1(\r11_v_count[9]_i_6_n_0 ),
        .I2(\r11_v_count_reg_n_0_[6] ),
        .O(p_1_in[6]));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \r11_v_count[7]_i_1 
       (.I0(\r11_v_count[9]_i_6_n_0 ),
        .I1(\r11_v_count_reg_n_0_[5] ),
        .I2(\r11_v_count_reg_n_0_[6] ),
        .I3(\r11_v_count_reg_n_0_[7] ),
        .O(p_1_in[7]));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \r11_v_count[8]_i_1 
       (.I0(\r11_v_count_reg_n_0_[7] ),
        .I1(\r11_v_count_reg_n_0_[6] ),
        .I2(\r11_v_count_reg_n_0_[5] ),
        .I3(\r11_v_count[9]_i_6_n_0 ),
        .I4(\r11_v_count_reg_n_0_[8] ),
        .O(p_1_in[8]));
  LUT6 #(
    .INIT(64'h4040404040404000)) 
    \r11_v_count[9]_i_1 
       (.I0(\r11_v_count[9]_i_4_n_0 ),
        .I1(\r11_v_count_reg_n_0_[9] ),
        .I2(r11_h_count_reg[10]),
        .I3(\r11_v_count_reg_n_0_[7] ),
        .I4(\r11_v_count_reg_n_0_[8] ),
        .I5(\r11_v_count[9]_i_5_n_0 ),
        .O(r11_v_count));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \r11_v_count[9]_i_2 
       (.I0(r11_h_count_reg[10]),
        .I1(r11_h_count_reg[8]),
        .I2(r11_h_count_reg[9]),
        .I3(r11_h_count_reg[7]),
        .I4(r11_h_count_reg[6]),
        .I5(r11_h_count_reg[5]),
        .O(\r11_v_count[9]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \r11_v_count[9]_i_3 
       (.I0(\r11_v_count_reg_n_0_[8] ),
        .I1(\r11_v_count[9]_i_6_n_0 ),
        .I2(\r11_v_count_reg_n_0_[5] ),
        .I3(\r11_v_count_reg_n_0_[6] ),
        .I4(\r11_v_count_reg_n_0_[7] ),
        .I5(\r11_v_count_reg_n_0_[9] ),
        .O(p_1_in[9]));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT5 #(
    .INIT(32'h00000001)) 
    \r11_v_count[9]_i_4 
       (.I0(r11_h_count_reg[5]),
        .I1(r11_h_count_reg[6]),
        .I2(r11_h_count_reg[7]),
        .I3(r11_h_count_reg[9]),
        .I4(r11_h_count_reg[8]),
        .O(\r11_v_count[9]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT5 #(
    .INIT(32'h80808000)) 
    \r11_v_count[9]_i_5 
       (.I0(\r11_v_count_reg_n_0_[5] ),
        .I1(\r11_v_count_reg_n_0_[6] ),
        .I2(\r11_v_count_reg_n_0_[4] ),
        .I3(\r11_v_count_reg_n_0_[3] ),
        .I4(\r11_v_count_reg_n_0_[2] ),
        .O(\r11_v_count[9]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair42" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \r11_v_count[9]_i_6 
       (.I0(\r11_v_count_reg_n_0_[4] ),
        .I1(\r11_v_count_reg_n_0_[3] ),
        .I2(\r11_v_count_reg_n_0_[0] ),
        .I3(\r11_v_count_reg_n_0_[1] ),
        .I4(\r11_v_count_reg_n_0_[2] ),
        .O(\r11_v_count[9]_i_6_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \r11_v_count_reg[0] 
       (.C(iw_pix_clk),
        .CE(\r11_v_count[9]_i_2_n_0 ),
        .D(p_1_in[0]),
        .Q(\r11_v_count_reg_n_0_[0] ),
        .S(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_v_count_reg[1] 
       (.C(iw_pix_clk),
        .CE(\r11_v_count[9]_i_2_n_0 ),
        .D(p_1_in[1]),
        .Q(\r11_v_count_reg_n_0_[1] ),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_v_count_reg[2] 
       (.C(iw_pix_clk),
        .CE(\r11_v_count[9]_i_2_n_0 ),
        .D(p_1_in[2]),
        .Q(\r11_v_count_reg_n_0_[2] ),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_v_count_reg[3] 
       (.C(iw_pix_clk),
        .CE(\r11_v_count[9]_i_2_n_0 ),
        .D(p_1_in[3]),
        .Q(\r11_v_count_reg_n_0_[3] ),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_v_count_reg[4] 
       (.C(iw_pix_clk),
        .CE(\r11_v_count[9]_i_2_n_0 ),
        .D(p_1_in[4]),
        .Q(\r11_v_count_reg_n_0_[4] ),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_v_count_reg[5] 
       (.C(iw_pix_clk),
        .CE(\r11_v_count[9]_i_2_n_0 ),
        .D(p_1_in[5]),
        .Q(\r11_v_count_reg_n_0_[5] ),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_v_count_reg[6] 
       (.C(iw_pix_clk),
        .CE(\r11_v_count[9]_i_2_n_0 ),
        .D(p_1_in[6]),
        .Q(\r11_v_count_reg_n_0_[6] ),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_v_count_reg[7] 
       (.C(iw_pix_clk),
        .CE(\r11_v_count[9]_i_2_n_0 ),
        .D(p_1_in[7]),
        .Q(\r11_v_count_reg_n_0_[7] ),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_v_count_reg[8] 
       (.C(iw_pix_clk),
        .CE(\r11_v_count[9]_i_2_n_0 ),
        .D(p_1_in[8]),
        .Q(\r11_v_count_reg_n_0_[8] ),
        .R(r11_v_count));
  FDRE #(
    .INIT(1'b0)) 
    \r11_v_count_reg[9] 
       (.C(iw_pix_clk),
        .CE(\r11_v_count[9]_i_2_n_0 ),
        .D(p_1_in[9]),
        .Q(\r11_v_count_reg_n_0_[9] ),
        .R(r11_v_count));
  LUT5 #(
    .INIT(32'hFFFEFEFE)) 
    \r4_blue[0]_i_1 
       (.I0(\r4_blue[0]_i_2_n_0 ),
        .I1(\r4_blue[0]_i_3_n_0 ),
        .I2(\r4_red[2]_i_10_n_0 ),
        .I3(\r4_red[3]_i_8_n_0 ),
        .I4(iw4_blue[0]),
        .O(\r4_blue[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_blue[0]_i_2 
       (.I0(\r4_red[3]_i_29_n_0 ),
        .I1(\r4_red[3]_i_30_n_0 ),
        .I2(iw4_blue[0]),
        .I3(iw4_result_right[3]),
        .I4(iw4_result_right[2]),
        .I5(\r4_red[3]_i_31_n_0 ),
        .O(\r4_blue[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_blue[0]_i_3 
       (.I0(\r4_red[3]_i_32_n_0 ),
        .I1(\r4_red[2]_i_15_n_0 ),
        .I2(iw4_blue[0]),
        .I3(iw4_result_left[3]),
        .I4(iw4_result_left[2]),
        .I5(\r4_red[3]_i_34_n_0 ),
        .O(\r4_blue[0]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'hFFF8)) 
    \r4_blue[1]_i_1 
       (.I0(\r4_red[3]_i_8_n_0 ),
        .I1(iw4_blue[1]),
        .I2(\r4_blue[1]_i_2_n_0 ),
        .I3(\r4_blue[1]_i_3_n_0 ),
        .O(\r4_blue[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_blue[1]_i_2 
       (.I0(\r4_red[3]_i_29_n_0 ),
        .I1(\r4_red[3]_i_30_n_0 ),
        .I2(iw4_blue[1]),
        .I3(iw4_result_right[3]),
        .I4(iw4_result_right[2]),
        .I5(\r4_red[3]_i_31_n_0 ),
        .O(\r4_blue[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_blue[1]_i_3 
       (.I0(\r4_red[3]_i_32_n_0 ),
        .I1(\r4_red[3]_i_33_n_0 ),
        .I2(iw4_blue[1]),
        .I3(iw4_result_left[3]),
        .I4(iw4_result_left[2]),
        .I5(\r4_red[3]_i_34_n_0 ),
        .O(\r4_blue[1]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hFFFEFEFE)) 
    \r4_blue[2]_i_1 
       (.I0(\r4_blue[2]_i_2_n_0 ),
        .I1(\r4_blue[2]_i_3_n_0 ),
        .I2(\r4_red[2]_i_10_n_0 ),
        .I3(\r4_red[3]_i_8_n_0 ),
        .I4(iw4_blue[2]),
        .O(\r4_blue[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_blue[2]_i_2 
       (.I0(\r4_red[3]_i_29_n_0 ),
        .I1(\r4_red[3]_i_30_n_0 ),
        .I2(iw4_blue[2]),
        .I3(iw4_result_right[3]),
        .I4(iw4_result_right[2]),
        .I5(\r4_red[3]_i_31_n_0 ),
        .O(\r4_blue[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_blue[2]_i_3 
       (.I0(\r4_red[3]_i_32_n_0 ),
        .I1(\r4_red[2]_i_15_n_0 ),
        .I2(iw4_blue[2]),
        .I3(iw4_result_left[3]),
        .I4(iw4_result_left[2]),
        .I5(\r4_red[3]_i_34_n_0 ),
        .O(\r4_blue[2]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'hFFF8)) 
    \r4_blue[3]_i_1 
       (.I0(\r4_red[3]_i_8_n_0 ),
        .I1(iw4_blue[3]),
        .I2(\r4_blue[3]_i_2_n_0 ),
        .I3(\r4_blue[3]_i_3_n_0 ),
        .O(\r4_blue[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_blue[3]_i_2 
       (.I0(\r4_red[3]_i_29_n_0 ),
        .I1(\r4_red[3]_i_30_n_0 ),
        .I2(iw4_blue[3]),
        .I3(iw4_result_right[3]),
        .I4(iw4_result_right[2]),
        .I5(\r4_red[3]_i_31_n_0 ),
        .O(\r4_blue[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_blue[3]_i_3 
       (.I0(\r4_red[3]_i_32_n_0 ),
        .I1(\r4_red[3]_i_33_n_0 ),
        .I2(iw4_blue[3]),
        .I3(iw4_result_left[3]),
        .I4(iw4_result_left[2]),
        .I5(\r4_red[3]_i_34_n_0 ),
        .O(\r4_blue[3]_i_3_n_0 ));
  FDRE #(
    .INIT(1'b1)) 
    \r4_blue_reg[0] 
       (.C(iw_pix_clk),
        .CE(\r4_red[2]_i_2_n_0 ),
        .D(\r4_blue[0]_i_1_n_0 ),
        .Q(\r4_blue_reg_n_0_[0] ),
        .R(r4_blue[2]));
  FDRE #(
    .INIT(1'b1)) 
    \r4_blue_reg[1] 
       (.C(iw_pix_clk),
        .CE(\r4_red[3]_i_2_n_0 ),
        .D(\r4_blue[1]_i_1_n_0 ),
        .Q(\r4_blue_reg_n_0_[1] ),
        .R(r4_blue[3]));
  FDRE #(
    .INIT(1'b1)) 
    \r4_blue_reg[2] 
       (.C(iw_pix_clk),
        .CE(\r4_red[2]_i_2_n_0 ),
        .D(\r4_blue[2]_i_1_n_0 ),
        .Q(\r4_blue_reg_n_0_[2] ),
        .R(r4_blue[2]));
  FDRE #(
    .INIT(1'b0)) 
    \r4_blue_reg[3] 
       (.C(iw_pix_clk),
        .CE(\r4_red[3]_i_2_n_0 ),
        .D(\r4_blue[3]_i_1_n_0 ),
        .Q(\r4_blue_reg_n_0_[3] ),
        .R(r4_blue[3]));
  LUT5 #(
    .INIT(32'hFFFEFEFE)) 
    \r4_green[0]_i_1 
       (.I0(\r4_green[0]_i_2_n_0 ),
        .I1(\r4_green[0]_i_3_n_0 ),
        .I2(\r4_red[2]_i_10_n_0 ),
        .I3(\r4_red[3]_i_8_n_0 ),
        .I4(iw4_green[0]),
        .O(r4_green[0]));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_green[0]_i_2 
       (.I0(\r4_red[3]_i_29_n_0 ),
        .I1(\r4_red[3]_i_30_n_0 ),
        .I2(iw4_green[0]),
        .I3(iw4_result_right[3]),
        .I4(iw4_result_right[2]),
        .I5(\r4_red[3]_i_31_n_0 ),
        .O(\r4_green[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_green[0]_i_3 
       (.I0(\r4_red[3]_i_32_n_0 ),
        .I1(\r4_red[2]_i_15_n_0 ),
        .I2(iw4_green[0]),
        .I3(iw4_result_left[3]),
        .I4(iw4_result_left[2]),
        .I5(\r4_red[3]_i_34_n_0 ),
        .O(\r4_green[0]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'hFFF8)) 
    \r4_green[1]_i_1 
       (.I0(\r4_red[3]_i_8_n_0 ),
        .I1(iw4_green[1]),
        .I2(\r4_green[1]_i_2_n_0 ),
        .I3(\r4_green[1]_i_3_n_0 ),
        .O(r4_green[1]));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_green[1]_i_2 
       (.I0(\r4_red[3]_i_29_n_0 ),
        .I1(\r4_red[3]_i_30_n_0 ),
        .I2(iw4_green[1]),
        .I3(iw4_result_right[3]),
        .I4(iw4_result_right[2]),
        .I5(\r4_red[3]_i_31_n_0 ),
        .O(\r4_green[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_green[1]_i_3 
       (.I0(\r4_red[3]_i_32_n_0 ),
        .I1(\r4_red[3]_i_33_n_0 ),
        .I2(iw4_green[1]),
        .I3(iw4_result_left[3]),
        .I4(iw4_result_left[2]),
        .I5(\r4_red[3]_i_34_n_0 ),
        .O(\r4_green[1]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hFFFEFEFE)) 
    \r4_green[2]_i_1 
       (.I0(\r4_green[2]_i_2_n_0 ),
        .I1(\r4_green[2]_i_3_n_0 ),
        .I2(\r4_red[2]_i_10_n_0 ),
        .I3(\r4_red[3]_i_8_n_0 ),
        .I4(iw4_green[2]),
        .O(r4_green[2]));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_green[2]_i_2 
       (.I0(\r4_red[3]_i_29_n_0 ),
        .I1(\r4_red[3]_i_30_n_0 ),
        .I2(iw4_green[2]),
        .I3(iw4_result_right[3]),
        .I4(iw4_result_right[2]),
        .I5(\r4_red[3]_i_31_n_0 ),
        .O(\r4_green[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_green[2]_i_3 
       (.I0(\r4_red[3]_i_32_n_0 ),
        .I1(\r4_red[2]_i_15_n_0 ),
        .I2(iw4_green[2]),
        .I3(iw4_result_left[3]),
        .I4(iw4_result_left[2]),
        .I5(\r4_red[3]_i_34_n_0 ),
        .O(\r4_green[2]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'hFFF8)) 
    \r4_green[3]_i_1 
       (.I0(\r4_red[3]_i_8_n_0 ),
        .I1(iw4_green[3]),
        .I2(\r4_green[3]_i_2_n_0 ),
        .I3(\r4_green[3]_i_3_n_0 ),
        .O(r4_green[3]));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_green[3]_i_2 
       (.I0(\r4_red[3]_i_29_n_0 ),
        .I1(\r4_red[3]_i_30_n_0 ),
        .I2(iw4_green[3]),
        .I3(iw4_result_right[3]),
        .I4(iw4_result_right[2]),
        .I5(\r4_red[3]_i_31_n_0 ),
        .O(\r4_green[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_green[3]_i_3 
       (.I0(\r4_red[3]_i_32_n_0 ),
        .I1(\r4_red[3]_i_33_n_0 ),
        .I2(iw4_green[3]),
        .I3(iw4_result_left[3]),
        .I4(iw4_result_left[2]),
        .I5(\r4_red[3]_i_34_n_0 ),
        .O(\r4_green[3]_i_3_n_0 ));
  FDRE #(
    .INIT(1'b1)) 
    \r4_green_reg[0] 
       (.C(iw_pix_clk),
        .CE(\r4_red[2]_i_2_n_0 ),
        .D(r4_green[0]),
        .Q(\r4_green_reg_n_0_[0] ),
        .R(r4_blue[2]));
  FDRE #(
    .INIT(1'b1)) 
    \r4_green_reg[1] 
       (.C(iw_pix_clk),
        .CE(\r4_red[3]_i_2_n_0 ),
        .D(r4_green[1]),
        .Q(\r4_green_reg_n_0_[1] ),
        .R(r4_blue[3]));
  FDRE #(
    .INIT(1'b1)) 
    \r4_green_reg[2] 
       (.C(iw_pix_clk),
        .CE(\r4_red[2]_i_2_n_0 ),
        .D(r4_green[2]),
        .Q(\r4_green_reg_n_0_[2] ),
        .R(r4_blue[2]));
  FDRE #(
    .INIT(1'b0)) 
    \r4_green_reg[3] 
       (.C(iw_pix_clk),
        .CE(\r4_red[3]_i_2_n_0 ),
        .D(r4_green[3]),
        .Q(\r4_green_reg_n_0_[3] ),
        .R(r4_blue[3]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 r4_red3_carry
       (.CI(1'b0),
        .CO({r4_red3_carry_n_0,r4_red3_carry_n_1,r4_red3_carry_n_2,r4_red3_carry_n_3}),
        .CYINIT(1'b1),
        .DI({r4_red3_carry_i_1_n_0,r4_red3_carry_i_2_n_0,r4_red3_carry_i_3_n_0,r4_red3_carry_i_4_n_0}),
        .O(NLW_r4_red3_carry_O_UNCONNECTED[3:0]),
        .S({r4_red3_carry_i_5_n_0,r4_red3_carry_i_6_n_0,r4_red3_carry_i_7_n_0,r4_red3_carry_i_8_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 r4_red3_carry__0
       (.CI(r4_red3_carry_n_0),
        .CO({NLW_r4_red3_carry__0_CO_UNCONNECTED[3:2],r4_red31_in,r4_red3_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,r4_red3_carry__0_i_1_n_0,r4_red3_carry__0_i_2_n_0}),
        .O(NLW_r4_red3_carry__0_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,r4_red3_carry__0_i_3_n_0,r4_red3_carry__0_i_4_n_0}));
  LUT2 #(
    .INIT(4'h2)) 
    r4_red3_carry__0_i_1
       (.I0(r11_active_y_reg[10]),
        .I1(iw11_block_right_pos[10]),
        .O(r4_red3_carry__0_i_1_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    r4_red3_carry__0_i_2
       (.I0(iw11_block_right_pos[9]),
        .I1(iw11_block_right_pos[8]),
        .I2(r11_active_y_reg[9]),
        .I3(r11_active_y_reg[8]),
        .O(r4_red3_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    r4_red3_carry__0_i_3
       (.I0(iw11_block_right_pos[10]),
        .I1(r11_active_y_reg[10]),
        .O(r4_red3_carry__0_i_3_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    r4_red3_carry__0_i_4
       (.I0(r11_active_y_reg[9]),
        .I1(iw11_block_right_pos[9]),
        .I2(r11_active_y_reg[8]),
        .I3(iw11_block_right_pos[8]),
        .O(r4_red3_carry__0_i_4_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    r4_red3_carry_i_1
       (.I0(iw11_block_right_pos[7]),
        .I1(iw11_block_right_pos[6]),
        .I2(r11_active_y_reg[7]),
        .I3(r11_active_y_reg[6]),
        .O(r4_red3_carry_i_1_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    r4_red3_carry_i_2
       (.I0(iw11_block_right_pos[5]),
        .I1(iw11_block_right_pos[4]),
        .I2(r11_active_y_reg[5]),
        .I3(r11_active_y_reg[4]),
        .O(r4_red3_carry_i_2_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    r4_red3_carry_i_3
       (.I0(iw11_block_right_pos[3]),
        .I1(iw11_block_right_pos[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[2]),
        .O(r4_red3_carry_i_3_n_0));
  LUT4 #(
    .INIT(16'h7150)) 
    r4_red3_carry_i_4
       (.I0(iw11_block_right_pos[1]),
        .I1(iw11_block_right_pos[0]),
        .I2(r11_active_y_reg[1]),
        .I3(r11_active_y_reg[0]),
        .O(r4_red3_carry_i_4_n_0));
  LUT4 #(
    .INIT(16'h8241)) 
    r4_red3_carry_i_5
       (.I0(iw11_block_right_pos[7]),
        .I1(iw11_block_right_pos[6]),
        .I2(r11_active_y_reg[6]),
        .I3(r11_active_y_reg[7]),
        .O(r4_red3_carry_i_5_n_0));
  LUT4 #(
    .INIT(16'h8241)) 
    r4_red3_carry_i_6
       (.I0(iw11_block_right_pos[5]),
        .I1(iw11_block_right_pos[4]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[5]),
        .O(r4_red3_carry_i_6_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    r4_red3_carry_i_7
       (.I0(r11_active_y_reg[3]),
        .I1(iw11_block_right_pos[3]),
        .I2(r11_active_y_reg[2]),
        .I3(iw11_block_right_pos[2]),
        .O(r4_red3_carry_i_7_n_0));
  LUT4 #(
    .INIT(16'h8241)) 
    r4_red3_carry_i_8
       (.I0(iw11_block_right_pos[1]),
        .I1(iw11_block_right_pos[0]),
        .I2(r11_active_y_reg[0]),
        .I3(r11_active_y_reg[1]),
        .O(r4_red3_carry_i_8_n_0));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \r4_red3_inferred__0/i__carry 
       (.CI(1'b0),
        .CO({\r4_red3_inferred__0/i__carry_n_0 ,\r4_red3_inferred__0/i__carry_n_1 ,\r4_red3_inferred__0/i__carry_n_2 ,\r4_red3_inferred__0/i__carry_n_3 }),
        .CYINIT(1'b1),
        .DI({i__carry_i_1__0_n_0,i__carry_i_2__0_n_0,i__carry_i_3__1_n_0,i__carry_i_4__1_n_0}),
        .O(\NLW_r4_red3_inferred__0/i__carry_O_UNCONNECTED [3:0]),
        .S({i__carry_i_5__0_n_0,i__carry_i_6__0_n_0,i__carry_i_7_n_0,i__carry_i_8__1_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \r4_red3_inferred__0/i__carry__0 
       (.CI(\r4_red3_inferred__0/i__carry_n_0 ),
        .CO({\NLW_r4_red3_inferred__0/i__carry__0_CO_UNCONNECTED [3:2],r4_red35_in,\r4_red3_inferred__0/i__carry__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,i__carry__0_i_1__0_n_0,i__carry__0_i_2__0_n_0}),
        .O(\NLW_r4_red3_inferred__0/i__carry__0_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,i__carry__0_i_3__0_n_0,i__carry__0_i_4__0_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \r4_red3_inferred__1/i__carry 
       (.CI(1'b0),
        .CO({\r4_red3_inferred__1/i__carry_n_0 ,\r4_red3_inferred__1/i__carry_n_1 ,\r4_red3_inferred__1/i__carry_n_2 ,\r4_red3_inferred__1/i__carry_n_3 }),
        .CYINIT(1'b1),
        .DI({i__carry_i_1_n_0,i__carry_i_2_n_0,i__carry_i_3__0_n_0,i__carry_i_4__0_n_0}),
        .O(\NLW_r4_red3_inferred__1/i__carry_O_UNCONNECTED [3:0]),
        .S({i__carry_i_5_n_0,i__carry_i_6_n_0,i__carry_i_7__1_n_0,i__carry_i_8__0_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \r4_red3_inferred__1/i__carry__0 
       (.CI(\r4_red3_inferred__1/i__carry_n_0 ),
        .CO({\NLW_r4_red3_inferred__1/i__carry__0_CO_UNCONNECTED [3:2],r4_red310_in,\r4_red3_inferred__1/i__carry__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,i__carry__0_i_1__1_n_0,i__carry__0_i_2_n_0}),
        .O(\NLW_r4_red3_inferred__1/i__carry__0_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,i__carry__0_i_3__1_n_0,i__carry__0_i_4__1_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \r4_red3_inferred__2/i__carry 
       (.CI(1'b0),
        .CO({\r4_red3_inferred__2/i__carry_n_0 ,\r4_red3_inferred__2/i__carry_n_1 ,\r4_red3_inferred__2/i__carry_n_2 ,\r4_red3_inferred__2/i__carry_n_3 }),
        .CYINIT(1'b1),
        .DI({i__carry_i_1__2_n_0,i__carry_i_2__1_n_0,i__carry_i_3_n_0,i__carry_i_4_n_0}),
        .O(\NLW_r4_red3_inferred__2/i__carry_O_UNCONNECTED [3:0]),
        .S({i__carry_i_5__1_n_0,i__carry_i_6__1_n_0,i__carry_i_7__0_n_0,i__carry_i_8_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \r4_red3_inferred__2/i__carry__0 
       (.CI(\r4_red3_inferred__2/i__carry_n_0 ),
        .CO({\NLW_r4_red3_inferred__2/i__carry__0_CO_UNCONNECTED [3:2],r4_red311_in,\r4_red3_inferred__2/i__carry__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,i__carry__0_i_1__2_n_0,i__carry__0_i_2__2_n_0}),
        .O(\NLW_r4_red3_inferred__2/i__carry__0_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,i__carry__0_i_3__2_n_0,i__carry__0_i_4__2_n_0}));
  LUT5 #(
    .INIT(32'hFFFEFEFE)) 
    \r4_red[0]_i_1 
       (.I0(\r4_red[0]_i_2_n_0 ),
        .I1(\r4_red[0]_i_3_n_0 ),
        .I2(\r4_red[2]_i_10_n_0 ),
        .I3(\r4_red[3]_i_8_n_0 ),
        .I4(iw4_red[0]),
        .O(r4_red[0]));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_red[0]_i_2 
       (.I0(\r4_red[3]_i_29_n_0 ),
        .I1(\r4_red[3]_i_30_n_0 ),
        .I2(iw4_red[0]),
        .I3(iw4_result_right[3]),
        .I4(iw4_result_right[2]),
        .I5(\r4_red[3]_i_31_n_0 ),
        .O(\r4_red[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_red[0]_i_3 
       (.I0(\r4_red[3]_i_32_n_0 ),
        .I1(\r4_red[2]_i_15_n_0 ),
        .I2(iw4_red[0]),
        .I3(iw4_result_left[3]),
        .I4(iw4_result_left[2]),
        .I5(\r4_red[3]_i_34_n_0 ),
        .O(\r4_red[0]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'hFFF8)) 
    \r4_red[1]_i_1 
       (.I0(\r4_red[3]_i_8_n_0 ),
        .I1(iw4_red[1]),
        .I2(\r4_red[1]_i_2_n_0 ),
        .I3(\r4_red[1]_i_3_n_0 ),
        .O(r4_red[1]));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_red[1]_i_2 
       (.I0(\r4_red[3]_i_29_n_0 ),
        .I1(\r4_red[3]_i_30_n_0 ),
        .I2(iw4_red[1]),
        .I3(iw4_result_right[3]),
        .I4(iw4_result_right[2]),
        .I5(\r4_red[3]_i_31_n_0 ),
        .O(\r4_red[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_red[1]_i_3 
       (.I0(\r4_red[3]_i_32_n_0 ),
        .I1(\r4_red[3]_i_33_n_0 ),
        .I2(iw4_red[1]),
        .I3(iw4_result_left[3]),
        .I4(iw4_result_left[2]),
        .I5(\r4_red[3]_i_34_n_0 ),
        .O(\r4_red[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF8AAA00000000)) 
    \r4_red[2]_i_1 
       (.I0(\r4_red[2]_i_4_n_0 ),
        .I1(\r4_red[2]_i_5_n_0 ),
        .I2(r11_active_x_reg[8]),
        .I3(r11_active_x_reg[9]),
        .I4(\r4_red[2]_i_6_n_0 ),
        .I5(\r4_red[2]_i_7_n_0 ),
        .O(r4_blue[2]));
  (* SOFT_HLUTNM = "soft_lutpair62" *) 
  LUT4 #(
    .INIT(16'h0800)) 
    \r4_red[2]_i_10 
       (.I0(\r4_red[3]_i_4_n_0 ),
        .I1(State[0]),
        .I2(State[1]),
        .I3(\r4_red[3]_i_11_n_0 ),
        .O(\r4_red[2]_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT5 #(
    .INIT(32'hCCCCCCC8)) 
    \r4_red[2]_i_11 
       (.I0(\r4_red[2]_i_16_n_0 ),
        .I1(r11_active_x_reg[8]),
        .I2(r11_active_x_reg[7]),
        .I3(r11_active_x_reg[5]),
        .I4(r11_active_x_reg[6]),
        .O(\r4_red[2]_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair40" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \r4_red[2]_i_12 
       (.I0(r11_active_x_reg[6]),
        .I1(r11_active_x_reg[5]),
        .O(\r4_red[2]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFD)) 
    \r4_red[2]_i_13 
       (.I0(\r4_red[3]_i_66_n_0 ),
        .I1(r11_active_x_reg[7]),
        .I2(\r4_red[2]_i_12_n_0 ),
        .I3(r11_active_x_reg[8]),
        .I4(\r4_red[3]_i_38_n_0 ),
        .I5(\p_1_out_inferred__0/i__carry__1_n_0 ),
        .O(\r4_red[2]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEEE00000000)) 
    \r4_red[2]_i_14 
       (.I0(\r4_red[3]_i_38_n_0 ),
        .I1(\r4_red[2]_i_16_n_0 ),
        .I2(r11_active_x_reg[1]),
        .I3(r11_active_x_reg[3]),
        .I4(\r4_red[2]_i_17_n_0 ),
        .I5(r4_red35_in),
        .O(\r4_red[2]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFEAAAAA)) 
    \r4_red[2]_i_15 
       (.I0(\r4_red[2]_i_18_n_0 ),
        .I1(\r4_red[3]_i_25_n_0 ),
        .I2(\r4_red[3]_i_22_n_0 ),
        .I3(\r4_red[3]_i_83_n_0 ),
        .I4(iw4_result_left[3]),
        .I5(\r4_red[2]_i_19_n_0 ),
        .O(\r4_red[2]_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    \r4_red[2]_i_16 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[2]),
        .I2(r11_active_x_reg[3]),
        .O(\r4_red[2]_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \r4_red[2]_i_17 
       (.I0(r11_active_x_reg[7]),
        .I1(r11_active_x_reg[6]),
        .I2(r11_active_x_reg[5]),
        .I3(r11_active_x_reg[8]),
        .O(\r4_red[2]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFEA00)) 
    \r4_red[2]_i_18 
       (.I0(\r4_red[2]_i_20_n_0 ),
        .I1(\r4_red[3]_i_160_n_0 ),
        .I2(\r4_red[2]_i_21_n_0 ),
        .I3(\r4_red[3]_i_161_n_0 ),
        .I4(\r4_red[3]_i_162_n_0 ),
        .I5(\r4_red[3]_i_163_n_0 ),
        .O(\r4_red[2]_i_18_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair41" *) 
  LUT5 #(
    .INIT(32'h00010000)) 
    \r4_red[2]_i_19 
       (.I0(iw4_result_left[1]),
        .I1(iw4_result_left[2]),
        .I2(iw4_result_left[3]),
        .I3(iw4_result_left[0]),
        .I4(\r4_red[3]_i_5_n_0 ),
        .O(\r4_red[2]_i_19_n_0 ));
  LUT4 #(
    .INIT(16'h5F5D)) 
    \r4_red[2]_i_2 
       (.I0(State[0]),
        .I1(\r4_red[3]_i_4_n_0 ),
        .I2(State[1]),
        .I3(\r4_red[3]_i_7_n_0 ),
        .O(\r4_red[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h4044400044444444)) 
    \r4_red[2]_i_20 
       (.I0(iw4_result_left[1]),
        .I1(iw4_result_left[0]),
        .I2(\r4_red[3]_i_237_n_0 ),
        .I3(\r4_red[3]_i_47_n_0 ),
        .I4(\r4_red[3]_i_238_n_0 ),
        .I5(\r4_red[3]_i_50_n_0 ),
        .O(\r4_red[2]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \r4_red[2]_i_21 
       (.I0(iw4_result_left[1]),
        .I1(iw4_result_left[0]),
        .O(\r4_red[2]_i_21_n_0 ));
  LUT5 #(
    .INIT(32'hFFFEFEFE)) 
    \r4_red[2]_i_3 
       (.I0(\r4_red[2]_i_8_n_0 ),
        .I1(\r4_red[2]_i_9_n_0 ),
        .I2(\r4_red[2]_i_10_n_0 ),
        .I3(\r4_red[3]_i_8_n_0 ),
        .I4(iw4_red[2]),
        .O(r4_red[2]));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT5 #(
    .INIT(32'h00200000)) 
    \r4_red[2]_i_4 
       (.I0(r11_active_x_reg[9]),
        .I1(r11_active_x_reg[10]),
        .I2(r4_red31_in),
        .I3(p_1_out_carry__1_n_0),
        .I4(\r4_red[2]_i_11_n_0 ),
        .O(\r4_red[2]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000001F3F)) 
    \r4_red[2]_i_5 
       (.I0(r11_active_x_reg[2]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[1]),
        .I4(r11_active_x_reg[7]),
        .I5(\r4_red[2]_i_12_n_0 ),
        .O(\r4_red[2]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h1000FFFF10001000)) 
    \r4_red[2]_i_6 
       (.I0(\p_1_out_inferred__2/i___0_carry__1_n_0 ),
        .I1(\p_1_out_inferred__1/i___0_carry__1_n_0 ),
        .I2(r4_red311_in),
        .I3(r4_red310_in),
        .I4(\r4_red[2]_i_13_n_0 ),
        .I5(\r4_red[2]_i_14_n_0 ),
        .O(\r4_red[2]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \r4_red[2]_i_7 
       (.I0(State[0]),
        .I1(State[1]),
        .O(\r4_red[2]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_red[2]_i_8 
       (.I0(\r4_red[3]_i_29_n_0 ),
        .I1(\r4_red[3]_i_30_n_0 ),
        .I2(iw4_red[2]),
        .I3(iw4_result_right[3]),
        .I4(iw4_result_right[2]),
        .I5(\r4_red[3]_i_31_n_0 ),
        .O(\r4_red[2]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_red[2]_i_9 
       (.I0(\r4_red[3]_i_32_n_0 ),
        .I1(\r4_red[2]_i_15_n_0 ),
        .I2(iw4_red[2]),
        .I3(iw4_result_left[3]),
        .I4(iw4_result_left[2]),
        .I5(\r4_red[3]_i_34_n_0 ),
        .O(\r4_red[2]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hAEAAFFFFAEAAAEAA)) 
    \r4_red[3]_i_1 
       (.I0(r4_blue[2]),
        .I1(\r4_red[3]_i_4_n_0 ),
        .I2(State[1]),
        .I3(State[0]),
        .I4(\r4_red[3]_i_5_n_0 ),
        .I5(\r4_red[3]_i_6_n_0 ),
        .O(r4_blue[3]));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_red[3]_i_10 
       (.I0(\r4_red[3]_i_32_n_0 ),
        .I1(\r4_red[3]_i_33_n_0 ),
        .I2(iw4_red[3]),
        .I3(iw4_result_left[3]),
        .I4(iw4_result_left[2]),
        .I5(\r4_red[3]_i_34_n_0 ),
        .O(\r4_red[3]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h8000000380000000)) 
    \r4_red[3]_i_100 
       (.I0(\r4_red[3]_i_187_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[4]),
        .I5(\r4_red[3]_i_188_n_0 ),
        .O(\r4_red[3]_i_100_n_0 ));
  LUT6 #(
    .INIT(64'h222E222822222228)) 
    \r4_red[3]_i_101 
       (.I0(\r4_red[3]_i_189_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[2]),
        .I5(\r4_red[3]_i_190_n_0 ),
        .O(\r4_red[3]_i_101_n_0 ));
  LUT6 #(
    .INIT(64'h2000000C20000000)) 
    \r4_red[3]_i_102 
       (.I0(\r4_red[3]_i_191_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[4]),
        .I5(\r4_red[3]_i_192_n_0 ),
        .O(\r4_red[3]_i_102_n_0 ));
  LUT6 #(
    .INIT(64'h8380000380800000)) 
    \r4_red[3]_i_103 
       (.I0(\r4_red[3]_i_193_n_0 ),
        .I1(r11_active_x_reg[2]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[4]),
        .I4(r11_active_x_reg[5]),
        .I5(\r4_red[3]_i_194_n_0 ),
        .O(\r4_red[3]_i_103_n_0 ));
  LUT6 #(
    .INIT(64'h0E00000002000000)) 
    \r4_red[3]_i_104 
       (.I0(\r4_red[3]_i_195_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[4]),
        .I5(\r4_red[3]_i_196_n_0 ),
        .O(\r4_red[3]_i_104_n_0 ));
  LUT6 #(
    .INIT(64'h00000000CC4C444C)) 
    \r4_red[3]_i_105 
       (.I0(\r4_red[3]_i_108_n_0 ),
        .I1(\r4_red[3]_i_113_n_0 ),
        .I2(\r4_red[3]_i_186_n_0 ),
        .I3(\r4_red[3]_i_184_n_0 ),
        .I4(\r4_red[3]_i_197_n_0 ),
        .I5(\r4_red[3]_i_109_n_0 ),
        .O(\r4_red[3]_i_105_n_0 ));
  LUT6 #(
    .INIT(64'h0080030000800000)) 
    \r4_red[3]_i_106 
       (.I0(\r4_red[3]_i_198_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[4]),
        .I5(\r4_red[3]_i_199_n_0 ),
        .O(\r4_red[3]_i_106_n_0 ));
  LUT6 #(
    .INIT(64'h0030002000000020)) 
    \r4_red[3]_i_107 
       (.I0(\r4_red[3]_i_195_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[4]),
        .I5(\r4_red[3]_i_199_n_0 ),
        .O(\r4_red[3]_i_107_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT4 #(
    .INIT(16'h01FE)) 
    \r4_red[3]_i_108 
       (.I0(r11_active_x_reg[2]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[5]),
        .O(\r4_red[3]_i_108_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \r4_red[3]_i_109 
       (.I0(r11_active_x_reg[2]),
        .I1(r11_active_x_reg[3]),
        .O(\r4_red[3]_i_109_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFF0FF02)) 
    \r4_red[3]_i_11 
       (.I0(\r4_red[3]_i_35_n_0 ),
        .I1(r11_active_y_reg[7]),
        .I2(r11_active_y_reg[9]),
        .I3(r11_active_y_reg[10]),
        .I4(r11_active_y_reg[8]),
        .I5(\r4_red[3]_i_36_n_0 ),
        .O(\r4_red[3]_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h01054000)) 
    \r4_red[3]_i_110 
       (.I0(r11_active_y_reg[5]),
        .I1(r11_active_y_reg[1]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[4]),
        .O(\r4_red[3]_i_110_n_0 ));
  LUT6 #(
    .INIT(64'h4444444444444442)) 
    \r4_red[3]_i_111 
       (.I0(r11_active_x_reg[7]),
        .I1(r11_active_x_reg[6]),
        .I2(r11_active_x_reg[5]),
        .I3(r11_active_x_reg[4]),
        .I4(r11_active_x_reg[3]),
        .I5(r11_active_x_reg[2]),
        .O(\r4_red[3]_i_111_n_0 ));
  LUT6 #(
    .INIT(64'h9190901091909090)) 
    \r4_red[3]_i_112 
       (.I0(r11_active_x_reg[3]),
        .I1(r11_active_x_reg[2]),
        .I2(\r4_red[3]_i_184_n_0 ),
        .I3(\r4_red[3]_i_185_n_0 ),
        .I4(\r4_red[3]_i_186_n_0 ),
        .I5(\r4_red[3]_i_200_n_0 ),
        .O(\r4_red[3]_i_112_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT3 #(
    .INIT(8'h56)) 
    \r4_red[3]_i_113 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[2]),
        .O(\r4_red[3]_i_113_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT5 #(
    .INIT(32'h22242004)) 
    \r4_red[3]_i_114 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[3]),
        .I4(\r4_red[3]_i_110_n_0 ),
        .O(\r4_red[3]_i_114_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT5 #(
    .INIT(32'h0302C000)) 
    \r4_red[3]_i_115 
       (.I0(\r4_red[3]_i_201_n_0 ),
        .I1(r11_active_x_reg[2]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[5]),
        .I4(r11_active_x_reg[4]),
        .O(\r4_red[3]_i_115_n_0 ));
  LUT6 #(
    .INIT(64'h0F00040000000400)) 
    \r4_red[3]_i_116 
       (.I0(r11_active_x_reg[5]),
        .I1(\r4_red[3]_i_190_n_0 ),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[2]),
        .I5(\r4_red[3]_i_202_n_0 ),
        .O(\r4_red[3]_i_116_n_0 ));
  LUT6 #(
    .INIT(64'hA88888BAA888888A)) 
    \r4_red[3]_i_117 
       (.I0(\r4_red[3]_i_110_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[4]),
        .I5(\r4_red[3]_i_203_n_0 ),
        .O(\r4_red[3]_i_117_n_0 ));
  LUT6 #(
    .INIT(64'h5555555555555556)) 
    \r4_red[3]_i_118 
       (.I0(r11_active_x_reg[7]),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[6]),
        .I3(r11_active_x_reg[4]),
        .I4(r11_active_x_reg[3]),
        .I5(r11_active_x_reg[2]),
        .O(\r4_red[3]_i_118_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT5 #(
    .INIT(32'h0001FFFE)) 
    \r4_red[3]_i_119 
       (.I0(r11_active_x_reg[2]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[5]),
        .I4(r11_active_x_reg[6]),
        .O(\r4_red[3]_i_119_n_0 ));
  LUT6 #(
    .INIT(64'h00FF4FFF00FFFFFF)) 
    \r4_red[3]_i_12 
       (.I0(r11_active_y_reg[2]),
        .I1(\r11_active_y[7]_i_3_n_0 ),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[6]),
        .I4(r11_active_y_reg[5]),
        .I5(r11_active_y_reg[4]),
        .O(\r4_red[3]_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair46" *) 
  LUT4 #(
    .INIT(16'h07FF)) 
    \r4_red[3]_i_120 
       (.I0(r11_active_y_reg[3]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_120_n_0 ));
  LUT6 #(
    .INIT(64'h0101000101010101)) 
    \r4_red[3]_i_121 
       (.I0(r11_active_y_reg[10]),
        .I1(r11_active_y_reg[9]),
        .I2(\r4_red[3]_i_38_n_0 ),
        .I3(\r4_red[2]_i_16_n_0 ),
        .I4(\r4_red[3]_i_57_n_0 ),
        .I5(r11_active_x_reg[5]),
        .O(\r4_red[3]_i_121_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair65" *) 
  LUT4 #(
    .INIT(16'hF800)) 
    \r4_red[3]_i_122 
       (.I0(r11_active_y_reg[3]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_122_n_0 ));
  LUT6 #(
    .INIT(64'h4444400022222AAA)) 
    \r4_red[3]_i_123 
       (.I0(r11_active_x_reg[7]),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[4]),
        .I5(r11_active_x_reg[6]),
        .O(\r4_red[3]_i_123_n_0 ));
  LUT6 #(
    .INIT(64'hFF00C0880000C088)) 
    \r4_red[3]_i_124 
       (.I0(\p_0_out_inferred__4/r4_red[3]_i_204_n_0 ),
        .I1(\r4_red[3]_i_205_n_0 ),
        .I2(\p_0_out_inferred__4/r4_red[3]_i_206_n_0 ),
        .I3(\r4_red[3]_i_207_n_0 ),
        .I4(\r4_red[3]_i_208_n_0 ),
        .I5(\r4_red[3]_i_209_n_0 ),
        .O(\r4_red[3]_i_124_n_0 ));
  LUT6 #(
    .INIT(64'h0320000000200000)) 
    \r4_red[3]_i_125 
       (.I0(\p_0_out_inferred__4/r4_red[3]_i_210_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[4]),
        .I5(\p_0_out_inferred__4/r4_red[3]_i_211_n_0 ),
        .O(\r4_red[3]_i_125_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \r4_red[3]_i_126 
       (.I0(\r4_red[3]_i_212_n_0 ),
        .I1(\r4_red[3]_i_213_n_0 ),
        .I2(\r4_red[3]_i_214_n_0 ),
        .I3(\r4_red[3]_i_215_n_0 ),
        .O(\r4_red[3]_i_126_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAA88A888)) 
    \r4_red[3]_i_127 
       (.I0(\r4_red[3]_i_216_n_0 ),
        .I1(\r4_red[3]_i_217_n_0 ),
        .I2(\r4_red[3]_i_218_n_0 ),
        .I3(\r4_red[3]_i_208_n_0 ),
        .I4(\r4_red[3]_i_219_n_0 ),
        .I5(\r4_red[3]_i_220_n_0 ),
        .O(\r4_red[3]_i_127_n_0 ));
  LUT6 #(
    .INIT(64'h0880808000000000)) 
    \r4_red[3]_i_128 
       (.I0(\r4_red[3]_i_221_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[2]),
        .I5(\r4_red[3]_i_68_n_0 ),
        .O(\r4_red[3]_i_128_n_0 ));
  LUT6 #(
    .INIT(64'hC000FF88C0000088)) 
    \r4_red[3]_i_129 
       (.I0(\p_0_out_inferred__4/r4_red[3]_i_222_n_0 ),
        .I1(\r4_red[3]_i_205_n_0 ),
        .I2(\p_0_out_inferred__4/r4_red[3]_i_223_n_0 ),
        .I3(\r4_red[3]_i_208_n_0 ),
        .I4(\r4_red[3]_i_207_n_0 ),
        .I5(\r4_red[3]_i_224_n_0 ),
        .O(\r4_red[3]_i_129_n_0 ));
  LUT6 #(
    .INIT(64'h0000000002020200)) 
    \r4_red[3]_i_13 
       (.I0(r4_red434_in),
        .I1(r11_active_y_reg[7]),
        .I2(\r4_red[3]_i_38_n_0 ),
        .I3(\r4_red[3]_i_39_n_0 ),
        .I4(\r4_red[3]_i_40_n_0 ),
        .I5(\r4_red[3]_i_41_n_0 ),
        .O(\r4_red[3]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFE00FE00FE00)) 
    \r4_red[3]_i_130 
       (.I0(\r4_red[3]_i_225_n_0 ),
        .I1(\r4_red[3]_i_226_n_0 ),
        .I2(\r4_red[3]_i_227_n_0 ),
        .I3(\r4_red[3]_i_228_n_0 ),
        .I4(\r4_red[3]_i_229_n_0 ),
        .I5(\r4_red[3]_i_230_n_0 ),
        .O(\r4_red[3]_i_130_n_0 ));
  LUT6 #(
    .INIT(64'hFFAACC00F0AACC00)) 
    \r4_red[3]_i_131 
       (.I0(\r4_red[3]_i_231_n_0 ),
        .I1(\r4_red[3]_i_232_n_0 ),
        .I2(\r4_red[3]_i_233_n_0 ),
        .I3(\r4_red[3]_i_208_n_0 ),
        .I4(\r4_red[3]_i_207_n_0 ),
        .I5(\r4_red[3]_i_234_n_0 ),
        .O(\r4_red[3]_i_131_n_0 ));
  LUT6 #(
    .INIT(64'h2A22008800008888)) 
    \r4_red[3]_i_132 
       (.I0(\r4_red[3]_i_235_n_0 ),
        .I1(r11_active_y_reg[5]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[3]),
        .I5(r11_active_y_reg[6]),
        .O(\r4_red[3]_i_132_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair69" *) 
  LUT4 #(
    .INIT(16'h1540)) 
    \r4_red[3]_i_133 
       (.I0(r11_active_x_reg[5]),
        .I1(r11_active_x_reg[2]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[4]),
        .O(\r4_red[3]_i_133_n_0 ));
  LUT6 #(
    .INIT(64'h2A22208000028A88)) 
    \r4_red[3]_i_134 
       (.I0(\r4_red[3]_i_236_n_0 ),
        .I1(r11_active_y_reg[5]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[3]),
        .I5(r11_active_y_reg[6]),
        .O(\r4_red[3]_i_134_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair87" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \r4_red[3]_i_135 
       (.I0(r11_active_x_reg[3]),
        .I1(r11_active_x_reg[2]),
        .O(\r4_red[3]_i_135_n_0 ));
  LUT4 #(
    .INIT(16'hFD5D)) 
    \r4_red[3]_i_136 
       (.I0(\r4_red[3]_i_157_n_0 ),
        .I1(\r4_red[3]_i_237_n_0 ),
        .I2(\r4_red[3]_i_47_n_0 ),
        .I3(\r4_red[3]_i_238_n_0 ),
        .O(\r4_red[3]_i_136_n_0 ));
  LUT6 #(
    .INIT(64'hFFAEFFAEFFFFFFAE)) 
    \r4_red[3]_i_137 
       (.I0(\r4_red[3]_i_145_n_0 ),
        .I1(\r4_red[3]_i_239_n_0 ),
        .I2(g0_b1__4_n_0),
        .I3(\r4_red[3]_i_240_n_0 ),
        .I4(\r4_red[3]_i_241_n_0 ),
        .I5(g0_b3__2_n_0),
        .O(\r4_red[3]_i_137_n_0 ));
  LUT5 #(
    .INIT(32'hFFFF22F2)) 
    \r4_red[3]_i_138 
       (.I0(\r4_red[3]_i_242_n_0 ),
        .I1(g0_b2_n_0),
        .I2(\r4_red[3]_i_243_n_0 ),
        .I3(g0_b0__0_n_0),
        .I4(\r4_red[3]_i_244_n_0 ),
        .O(\r4_red[3]_i_138_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF2020FF20)) 
    \r4_red[3]_i_139 
       (.I0(\r4_red[3]_i_245_n_0 ),
        .I1(\r4_red[3]_i_47_n_0 ),
        .I2(\r4_red[3]_i_157_n_0 ),
        .I3(\r4_red[3]_i_158_n_0 ),
        .I4(g0_b1_n_0),
        .I5(\r4_red[3]_i_246_n_0 ),
        .O(\r4_red[3]_i_139_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF05150555)) 
    \r4_red[3]_i_14 
       (.I0(\r4_red[2]_i_12_n_0 ),
        .I1(r11_active_x_reg[1]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[2]),
        .I5(\r4_red[3]_i_42_n_0 ),
        .O(\r4_red[3]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF2222FFF2)) 
    \r4_red[3]_i_140 
       (.I0(\r4_red[3]_i_247_n_0 ),
        .I1(r4_red2[0]),
        .I2(\r4_red[3]_i_242_n_0 ),
        .I3(\r4_red[3]_i_144_n_0 ),
        .I4(r4_red2[1]),
        .I5(\r4_red[3]_i_248_n_0 ),
        .O(\r4_red[3]_i_140_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFF4)) 
    \r4_red[3]_i_141 
       (.I0(g0_b4__2_n_0),
        .I1(\r4_red[3]_i_144_n_0 ),
        .I2(\r4_red[3]_i_145_n_0 ),
        .I3(\r4_red[3]_i_249_n_0 ),
        .I4(\r4_red[3]_i_250_n_0 ),
        .O(\r4_red[3]_i_141_n_0 ));
  LUT6 #(
    .INIT(64'h0123FFFF01230123)) 
    \r4_red[3]_i_142 
       (.I0(\r4_red[3]_i_49_n_0 ),
        .I1(\r4_red[3]_i_157_n_0 ),
        .I2(g0_b5__0_n_0),
        .I3(g0_b6_n_0),
        .I4(r4_red2[2]),
        .I5(\r4_red[3]_i_158_n_0 ),
        .O(\r4_red[3]_i_142_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFF22F2)) 
    \r4_red[3]_i_143 
       (.I0(\r4_red[3]_i_242_n_0 ),
        .I1(g0_b1__4_n_0),
        .I2(\r4_red[3]_i_243_n_0 ),
        .I3(g0_b3__2_n_0),
        .I4(\r4_red[3]_i_145_n_0 ),
        .I5(\r4_red[3]_i_251_n_0 ),
        .O(\r4_red[3]_i_143_n_0 ));
  LUT6 #(
    .INIT(64'h4440000000000008)) 
    \r4_red[3]_i_144 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[0]),
        .I3(r11_active_x_reg[1]),
        .I4(r11_active_x_reg[2]),
        .I5(r11_active_x_reg[3]),
        .O(\r4_red[3]_i_144_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FE000001)) 
    \r4_red[3]_i_145 
       (.I0(\r4_red[3]_i_91_n_0 ),
        .I1(r11_active_x_reg[2]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[4]),
        .I4(r11_active_x_reg[5]),
        .I5(g0_b0__4_n_0),
        .O(\r4_red[3]_i_145_n_0 ));
  LUT6 #(
    .INIT(64'h0550033000000000)) 
    \r4_red[3]_i_146 
       (.I0(g0_b0__1_n_0),
        .I1(g0_b2__0_n_0),
        .I2(\r4_red[3]_i_91_n_0 ),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(\r4_red[3]_i_252_n_0 ),
        .O(\r4_red[3]_i_146_n_0 ));
  LUT6 #(
    .INIT(64'h0123FFFF01230123)) 
    \r4_red[3]_i_147 
       (.I0(\r4_red[3]_i_49_n_0 ),
        .I1(\r4_red[3]_i_157_n_0 ),
        .I2(g0_b5__1_n_0),
        .I3(g0_b6__0_n_0),
        .I4(g0_b1__0_n_0),
        .I5(\r4_red[3]_i_158_n_0 ),
        .O(\r4_red[3]_i_147_n_0 ));
  LUT6 #(
    .INIT(64'h0550033000000000)) 
    \r4_red[3]_i_148 
       (.I0(g0_b0__2_n_0),
        .I1(g0_b2__1_n_0),
        .I2(\r4_red[3]_i_91_n_0 ),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(\r4_red[3]_i_252_n_0 ),
        .O(\r4_red[3]_i_148_n_0 ));
  LUT6 #(
    .INIT(64'h0123FFFF01230123)) 
    \r4_red[3]_i_149 
       (.I0(\r4_red[3]_i_49_n_0 ),
        .I1(\r4_red[3]_i_157_n_0 ),
        .I2(r4_red2[2]),
        .I3(r4_red2[3]),
        .I4(g0_b1__1_n_0),
        .I5(\r4_red[3]_i_158_n_0 ),
        .O(\r4_red[3]_i_149_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF00FD00000000)) 
    \r4_red[3]_i_15 
       (.I0(\r11_active_y[7]_i_3_n_0 ),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[2]),
        .I3(\r4_red[3]_i_43_n_0 ),
        .I4(\r4_red[3]_i_44_n_0 ),
        .I5(r4_red434_in),
        .O(\r4_red[3]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h00000000AA8AF3C3)) 
    \r4_red[3]_i_150 
       (.I0(\r4_red[3]_i_48_n_0 ),
        .I1(g0_b0_i_3_n_0),
        .I2(g0_b0_i_4_n_0),
        .I3(g0_b0_i_2_n_0),
        .I4(\r4_red[3]_i_157_n_0 ),
        .I5(\r4_red[3]_i_49_n_0 ),
        .O(\r4_red[3]_i_150_n_0 ));
  LUT6 #(
    .INIT(64'hFF2FF0FF22222022)) 
    \r4_red[3]_i_151 
       (.I0(\r4_red[3]_i_252_n_0 ),
        .I1(\r4_red[3]_i_253_n_0 ),
        .I2(g0_b0_i_2_n_0),
        .I3(g0_b0_i_4_n_0),
        .I4(g0_b0_i_3_n_0),
        .I5(\r4_red[3]_i_254_n_0 ),
        .O(\r4_red[3]_i_151_n_0 ));
  LUT6 #(
    .INIT(64'h9989998999899895)) 
    \r4_red[3]_i_152 
       (.I0(r11_active_y_reg[5]),
        .I1(r11_active_y_reg[4]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[3]),
        .I4(r11_active_y_reg[1]),
        .I5(r11_active_y_reg[0]),
        .O(\r4_red[3]_i_152_n_0 ));
  LUT6 #(
    .INIT(64'hFEAA00000000FAA8)) 
    \r4_red[3]_i_153 
       (.I0(g0_b0_i_3_n_0),
        .I1(g0_b0_i_1_n_0),
        .I2(g0_b0_i_4_n_0),
        .I3(g0_b0_i_2_n_0),
        .I4(\r4_red[3]_i_48_n_0 ),
        .I5(\r4_red[3]_i_49_n_0 ),
        .O(\r4_red[3]_i_153_n_0 ));
  LUT6 #(
    .INIT(64'h02AAAAAAA8000000)) 
    \r4_red[3]_i_154 
       (.I0(r11_active_x_reg[5]),
        .I1(r11_active_x_reg[0]),
        .I2(r11_active_x_reg[1]),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(r11_active_x_reg[4]),
        .O(\r4_red[3]_i_154_n_0 ));
  LUT6 #(
    .INIT(64'hABABABFBABABABAB)) 
    \r4_red[3]_i_155 
       (.I0(\r4_red[3]_i_255_n_0 ),
        .I1(g0_b7__0_n_0),
        .I2(\r4_red[3]_i_157_n_0 ),
        .I3(g0_b3__0_n_0),
        .I4(\r4_red[3]_i_253_n_0 ),
        .I5(\r4_red[3]_i_47_n_0 ),
        .O(\r4_red[3]_i_155_n_0 ));
  LUT6 #(
    .INIT(64'h305305333F53F533)) 
    \r4_red[3]_i_156 
       (.I0(g0_b6__3_n_0),
        .I1(g0_b6__1_n_0),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[3]),
        .I4(\r4_red[3]_i_91_n_0 ),
        .I5(g0_b4__1_n_0),
        .O(\r4_red[3]_i_156_n_0 ));
  LUT6 #(
    .INIT(64'hAA95AA95AA95AA55)) 
    \r4_red[3]_i_157 
       (.I0(r11_active_x_reg[5]),
        .I1(r11_active_x_reg[2]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[4]),
        .I4(r11_active_x_reg[0]),
        .I5(r11_active_x_reg[1]),
        .O(\r4_red[3]_i_157_n_0 ));
  LUT6 #(
    .INIT(64'h0000000010101004)) 
    \r4_red[3]_i_158 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[1]),
        .I4(r11_active_x_reg[0]),
        .I5(r11_active_x_reg[5]),
        .O(\r4_red[3]_i_158_n_0 ));
  LUT5 #(
    .INIT(32'h0000B8FF)) 
    \r4_red[3]_i_159 
       (.I0(\r4_red[3]_i_237_n_0 ),
        .I1(\r4_red[3]_i_47_n_0 ),
        .I2(\r4_red[3]_i_238_n_0 ),
        .I3(\r4_red[3]_i_50_n_0 ),
        .I4(iw4_result_left[1]),
        .O(\r4_red[3]_i_159_n_0 ));
  LUT6 #(
    .INIT(64'h0101010101010001)) 
    \r4_red[3]_i_16 
       (.I0(\r4_red[3]_i_45_n_0 ),
        .I1(\r4_red[3]_i_38_n_0 ),
        .I2(r11_active_y_reg[6]),
        .I3(\r4_red[3]_i_46_n_0 ),
        .I4(\r4_red[3]_i_43_n_0 ),
        .I5(\r11_active_y[7]_i_2_n_0 ),
        .O(\r4_red[3]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFEEEEEEE)) 
    \r4_red[3]_i_160 
       (.I0(\r4_red[3]_i_256_n_0 ),
        .I1(\r4_red[3]_i_257_n_0 ),
        .I2(\r4_red[3]_i_245_n_0 ),
        .I3(\r4_red[3]_i_47_n_0 ),
        .I4(\r4_red[3]_i_50_n_0 ),
        .I5(\r4_red[3]_i_258_n_0 ),
        .O(\r4_red[3]_i_160_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair88" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \r4_red[3]_i_161 
       (.I0(iw4_result_left[2]),
        .I1(iw4_result_left[3]),
        .O(\r4_red[3]_i_161_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAA88A8)) 
    \r4_red[3]_i_162 
       (.I0(\r4_red[3]_i_259_n_0 ),
        .I1(\r4_red[3]_i_260_n_0 ),
        .I2(\r4_red[3]_i_167_n_0 ),
        .I3(r4_red2[2]),
        .I4(\r4_red[3]_i_166_n_0 ),
        .I5(\r4_red[3]_i_261_n_0 ),
        .O(\r4_red[3]_i_162_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAA88A8)) 
    \r4_red[3]_i_163 
       (.I0(\r4_red[3]_i_262_n_0 ),
        .I1(\r4_red[3]_i_263_n_0 ),
        .I2(\r4_red[3]_i_167_n_0 ),
        .I3(r4_red2[2]),
        .I4(\r4_red[3]_i_166_n_0 ),
        .I5(\r4_red[3]_i_264_n_0 ),
        .O(\r4_red[3]_i_163_n_0 ));
  LUT6 #(
    .INIT(64'hFFF2FFF2FFFFFFF2)) 
    \r4_red[3]_i_164 
       (.I0(\r4_red[3]_i_265_n_0 ),
        .I1(g0_b1__4_n_0),
        .I2(\r4_red[3]_i_166_n_0 ),
        .I3(\r4_red[3]_i_266_n_0 ),
        .I4(\r4_red[3]_i_267_n_0 ),
        .I5(g0_b3__2_n_0),
        .O(\r4_red[3]_i_164_n_0 ));
  LUT6 #(
    .INIT(64'h0550033000000000)) 
    \r4_red[3]_i_165 
       (.I0(g0_b0__2_n_0),
        .I1(g0_b2__1_n_0),
        .I2(\r4_red[3]_i_91_n_0 ),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(\r4_red[3]_i_154_n_0 ),
        .O(\r4_red[3]_i_165_n_0 ));
  LUT6 #(
    .INIT(64'h0000000055005600)) 
    \r4_red[3]_i_166 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[5]),
        .I4(\r4_red[3]_i_91_n_0 ),
        .I5(g0_b0__4_n_0),
        .O(\r4_red[3]_i_166_n_0 ));
  LUT6 #(
    .INIT(64'h2020200800000000)) 
    \r4_red[3]_i_167 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[1]),
        .I4(r11_active_x_reg[0]),
        .I5(r11_active_x_reg[5]),
        .O(\r4_red[3]_i_167_n_0 ));
  LUT6 #(
    .INIT(64'h0123FFFF01230123)) 
    \r4_red[3]_i_168 
       (.I0(\r4_red[3]_i_49_n_0 ),
        .I1(\r4_red[3]_i_50_n_0 ),
        .I2(r4_red2[2]),
        .I3(r4_red2[3]),
        .I4(g0_b2__4_n_0),
        .I5(\r4_red[3]_i_18_n_0 ),
        .O(\r4_red[3]_i_168_n_0 ));
  LUT6 #(
    .INIT(64'h0550033000000000)) 
    \r4_red[3]_i_169 
       (.I0(g0_b0__1_n_0),
        .I1(g0_b2__0_n_0),
        .I2(\r4_red[3]_i_91_n_0 ),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(\r4_red[3]_i_154_n_0 ),
        .O(\r4_red[3]_i_169_n_0 ));
  LUT6 #(
    .INIT(64'h0202022000000000)) 
    \r4_red[3]_i_17 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[1]),
        .I4(r11_active_x_reg[0]),
        .I5(r11_active_x_reg[5]),
        .O(\r4_red[3]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'h0123FFFF01230123)) 
    \r4_red[3]_i_170 
       (.I0(\r4_red[3]_i_49_n_0 ),
        .I1(\r4_red[3]_i_50_n_0 ),
        .I2(g0_b5__1_n_0),
        .I3(g0_b6__0_n_0),
        .I4(g0_b4__0_n_0),
        .I5(\r4_red[3]_i_18_n_0 ),
        .O(\r4_red[3]_i_170_n_0 ));
  LUT6 #(
    .INIT(64'h00DB00D900D900DB)) 
    \r4_red[3]_i_171 
       (.I0(g0_b0_i_3_n_0),
        .I1(g0_b0_i_4_n_0),
        .I2(g0_b0_i_2_n_0),
        .I3(\r4_red[3]_i_50_n_0 ),
        .I4(r11_active_x_reg[2]),
        .I5(\r4_red[3]_i_91_n_0 ),
        .O(\r4_red[3]_i_171_n_0 ));
  LUT6 #(
    .INIT(64'h5400000002AAAAAA)) 
    \r4_red[3]_i_172 
       (.I0(r11_active_x_reg[5]),
        .I1(r11_active_x_reg[0]),
        .I2(r11_active_x_reg[1]),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(r11_active_x_reg[4]),
        .O(\r4_red[3]_i_172_n_0 ));
  LUT6 #(
    .INIT(64'h000000004C00C200)) 
    \r4_red[3]_i_173 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[5]),
        .I4(\r4_red[3]_i_91_n_0 ),
        .I5(\r4_red[3]_i_268_n_0 ),
        .O(\r4_red[3]_i_173_n_0 ));
  LUT6 #(
    .INIT(64'h04400000C440000C)) 
    \r4_red[3]_i_174 
       (.I0(g0_b0__3_n_0),
        .I1(\r4_red[3]_i_154_n_0 ),
        .I2(\r4_red[3]_i_91_n_0 ),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(g0_b3__0_n_0),
        .O(\r4_red[3]_i_174_n_0 ));
  LUT5 #(
    .INIT(32'h80FF8080)) 
    \r4_red[3]_i_175 
       (.I0(\r4_red[3]_i_50_n_0 ),
        .I1(\r4_red[3]_i_47_n_0 ),
        .I2(\r4_red[3]_i_156_n_0 ),
        .I3(g0_b1__2_n_0),
        .I4(\r4_red[3]_i_167_n_0 ),
        .O(\r4_red[3]_i_175_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT5 #(
    .INIT(32'hFEEEEEEE)) 
    \r4_red[3]_i_176 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[5]),
        .I2(r11_active_y_reg[1]),
        .I3(r11_active_y_reg[3]),
        .I4(r11_active_y_reg[2]),
        .O(\r4_red[3]_i_176_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT5 #(
    .INIT(32'h80808000)) 
    \r4_red[3]_i_177 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[8]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[1]),
        .O(\r4_red[3]_i_177_n_0 ));
  LUT6 #(
    .INIT(64'hF8F8F8F8F8F8F888)) 
    \r4_red[3]_i_178 
       (.I0(r11_active_y_reg[7]),
        .I1(r11_active_y_reg[8]),
        .I2(r11_active_x_reg[9]),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(r11_active_x_reg[4]),
        .O(\r4_red[3]_i_178_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h5042575E)) 
    \r4_red[3]_i_179 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_179_n_0 ));
  LUT6 #(
    .INIT(64'h2220000000000004)) 
    \r4_red[3]_i_18 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[0]),
        .I3(r11_active_x_reg[1]),
        .I4(r11_active_x_reg[2]),
        .I5(r11_active_x_reg[3]),
        .O(\r4_red[3]_i_18_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'h1450575E)) 
    \r4_red[3]_i_180 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_180_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'hD24A5F7F)) 
    \r4_red[3]_i_181 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_181_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h5452575E)) 
    \r4_red[3]_i_182 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_182_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair85" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \r4_red[3]_i_183 
       (.I0(r11_active_y_reg[1]),
        .I1(r11_active_y_reg[2]),
        .O(\r4_red[3]_i_183_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'hEAAA1555)) 
    \r4_red[3]_i_184 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_184_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \r4_red[3]_i_185 
       (.I0(r11_active_y_reg[1]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .O(\r4_red[3]_i_185_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair45" *) 
  LUT4 #(
    .INIT(16'h807F)) 
    \r4_red[3]_i_186 
       (.I0(r11_active_y_reg[2]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[1]),
        .I3(r11_active_y_reg[4]),
        .O(\r4_red[3]_i_186_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hEAAA2BAD)) 
    \r4_red[3]_i_187 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_187_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'hAAA828A1)) 
    \r4_red[3]_i_188 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_188_n_0 ));
  LUT6 #(
    .INIT(64'h00000000F5D40B2F)) 
    \r4_red[3]_i_189 
       (.I0(r11_active_y_reg[5]),
        .I1(r11_active_y_reg[1]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[4]),
        .I5(r11_active_x_reg[2]),
        .O(\r4_red[3]_i_189_n_0 ));
  LUT6 #(
    .INIT(64'h00000010F0F0F0E0)) 
    \r4_red[3]_i_19 
       (.I0(r11_active_x_reg[0]),
        .I1(r11_active_x_reg[1]),
        .I2(r11_active_x_reg[5]),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(r11_active_x_reg[4]),
        .O(\r4_red[3]_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h95545F7F)) 
    \r4_red[3]_i_190 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_190_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'hAAAABFD5)) 
    \r4_red[3]_i_191 
       (.I0(r11_active_y_reg[5]),
        .I1(r11_active_y_reg[1]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[3]),
        .I4(r11_active_y_reg[4]),
        .O(\r4_red[3]_i_191_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h89919911)) 
    \r4_red[3]_i_192 
       (.I0(r11_active_y_reg[5]),
        .I1(r11_active_y_reg[4]),
        .I2(r11_active_y_reg[1]),
        .I3(r11_active_y_reg[3]),
        .I4(r11_active_y_reg[2]),
        .O(\r4_red[3]_i_192_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'h3EF8420A)) 
    \r4_red[3]_i_193 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_193_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'hBCF0420B)) 
    \r4_red[3]_i_194 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_194_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'h5F7FA080)) 
    \r4_red[3]_i_195 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_195_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'h5E7A420A)) 
    \r4_red[3]_i_196 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_196_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT4 #(
    .INIT(16'h5600)) 
    \r4_red[3]_i_197 
       (.I0(r11_active_y_reg[3]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[1]),
        .I3(r11_active_y_reg[4]),
        .O(\r4_red[3]_i_197_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h565A420A)) 
    \r4_red[3]_i_198 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_198_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'h0F3DAAA8)) 
    \r4_red[3]_i_199 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_199_n_0 ));
  LUT4 #(
    .INIT(16'h02FF)) 
    \r4_red[3]_i_2 
       (.I0(\r4_red[3]_i_7_n_0 ),
        .I1(\r4_red[3]_i_4_n_0 ),
        .I2(State[1]),
        .I3(State[0]),
        .O(\r4_red[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0300050055553333)) 
    \r4_red[3]_i_20 
       (.I0(r4_red2[3]),
        .I1(r4_red2[2]),
        .I2(\r4_red[3]_i_47_n_0 ),
        .I3(\r4_red[3]_i_48_n_0 ),
        .I4(\r4_red[3]_i_49_n_0 ),
        .I5(\r4_red[3]_i_50_n_0 ),
        .O(\r4_red[3]_i_20_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair45" *) 
  LUT4 #(
    .INIT(16'h6ABE)) 
    \r4_red[3]_i_200 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[1]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[3]),
        .O(\r4_red[3]_i_200_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h0105BCF0)) 
    \r4_red[3]_i_201 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_201_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'h0515BFFC)) 
    \r4_red[3]_i_202 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_202_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'hB4D0430F)) 
    \r4_red[3]_i_203 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[1]),
        .I4(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_203_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair87" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \r4_red[3]_i_205 
       (.I0(r11_active_x_reg[3]),
        .I1(r11_active_x_reg[2]),
        .O(\r4_red[3]_i_205_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair70" *) 
  LUT4 #(
    .INIT(16'hEA15)) 
    \r4_red[3]_i_207 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[5]),
        .O(\r4_red[3]_i_207_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair79" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \r4_red[3]_i_208 
       (.I0(r11_active_x_reg[2]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[4]),
        .O(\r4_red[3]_i_208_n_0 ));
  LUT6 #(
    .INIT(64'h2888888800002020)) 
    \r4_red[3]_i_209 
       (.I0(\r4_red[3]_i_109_n_0 ),
        .I1(r11_active_y_reg[5]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[3]),
        .I5(r11_active_y_reg[6]),
        .O(\r4_red[3]_i_209_n_0 ));
  LUT6 #(
    .INIT(64'h0040000000000000)) 
    \r4_red[3]_i_21 
       (.I0(\r4_red[3]_i_51_n_0 ),
        .I1(r4_red313_in),
        .I2(\r4_red[3]_i_53_n_0 ),
        .I3(\r4_red[3]_i_38_n_0 ),
        .I4(\r4_red[3]_i_42_n_0 ),
        .I5(\r4_red[3]_i_54_n_0 ),
        .O(r4_red128_out));
  LUT6 #(
    .INIT(64'h00000E0000000200)) 
    \r4_red[3]_i_212 
       (.I0(\p_0_out_inferred__4/r4_red[3]_i_269_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[2]),
        .I5(\p_0_out_inferred__4/r4_red[3]_i_270_n_0 ),
        .O(\r4_red[3]_i_212_n_0 ));
  LUT6 #(
    .INIT(64'h000E000000020000)) 
    \r4_red[3]_i_213 
       (.I0(\p_0_out_inferred__4/r4_red[3]_i_271_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[2]),
        .I5(\p_0_out_inferred__4/r4_red[3]_i_272_n_0 ),
        .O(\r4_red[3]_i_213_n_0 ));
  LUT6 #(
    .INIT(64'h200000C020000000)) 
    \r4_red[3]_i_214 
       (.I0(\p_0_out_inferred__4/r4_red[3]_i_273_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[2]),
        .I5(\p_0_out_inferred__4/r4_red[3]_i_274_n_0 ),
        .O(\r4_red[3]_i_214_n_0 ));
  LUT6 #(
    .INIT(64'hC800000008000000)) 
    \r4_red[3]_i_215 
       (.I0(\p_0_out_inferred__4/r4_red[3]_i_206_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[2]),
        .I5(\p_0_out_inferred__4/r4_red[3]_i_274_n_0 ),
        .O(\r4_red[3]_i_215_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair43" *) 
  LUT5 #(
    .INIT(32'h11111444)) 
    \r4_red[3]_i_216 
       (.I0(r11_active_x_reg[7]),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[4]),
        .O(\r4_red[3]_i_216_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT5 #(
    .INIT(32'h080C0800)) 
    \r4_red[3]_i_217 
       (.I0(\p_0_out_inferred__4/r4_red[3]_i_275_n_0 ),
        .I1(r11_active_x_reg[2]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[4]),
        .I4(\p_0_out_inferred__4/r4_red[3]_i_269_n_0 ),
        .O(\r4_red[3]_i_217_n_0 ));
  LUT6 #(
    .INIT(64'h22A2A22AA2A22020)) 
    \r4_red[3]_i_218 
       (.I0(\r4_red[3]_i_235_n_0 ),
        .I1(r11_active_y_reg[5]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[3]),
        .I5(r11_active_y_reg[6]),
        .O(\r4_red[3]_i_218_n_0 ));
  LUT6 #(
    .INIT(64'h00000000222811AA)) 
    \r4_red[3]_i_219 
       (.I0(r11_active_y_reg[5]),
        .I1(r11_active_y_reg[4]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[3]),
        .I4(r11_active_y_reg[6]),
        .I5(\r4_red[3]_i_135_n_0 ),
        .O(\r4_red[3]_i_219_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair88" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \r4_red[3]_i_22 
       (.I0(iw4_result_left[1]),
        .I1(iw4_result_left[2]),
        .O(\r4_red[3]_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT5 #(
    .INIT(32'h03200020)) 
    \r4_red[3]_i_220 
       (.I0(\p_0_out_inferred__4/r4_red[3]_i_271_n_0 ),
        .I1(r11_active_x_reg[2]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[4]),
        .I4(\p_0_out_inferred__4/r4_red[3]_i_276_n_0 ),
        .O(\r4_red[3]_i_220_n_0 ));
  LUT6 #(
    .INIT(64'hFDF4040DFFFFFFFF)) 
    \r4_red[3]_i_221 
       (.I0(r11_active_x_reg[2]),
        .I1(r11_active_y_reg[6]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[4]),
        .I5(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_221_n_0 ));
  LUT6 #(
    .INIT(64'h00000000314C01BA)) 
    \r4_red[3]_i_224 
       (.I0(r11_active_y_reg[5]),
        .I1(r11_active_y_reg[4]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[3]),
        .I4(r11_active_y_reg[6]),
        .I5(\r4_red[3]_i_135_n_0 ),
        .O(\r4_red[3]_i_224_n_0 ));
  LUT6 #(
    .INIT(64'h0808028280800808)) 
    \r4_red[3]_i_225 
       (.I0(\r4_red[3]_i_235_n_0 ),
        .I1(r11_active_y_reg[5]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[3]),
        .I5(r11_active_y_reg[6]),
        .O(\r4_red[3]_i_225_n_0 ));
  LUT6 #(
    .INIT(64'h080A0A8280808808)) 
    \r4_red[3]_i_226 
       (.I0(\r4_red[3]_i_236_n_0 ),
        .I1(r11_active_y_reg[5]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[3]),
        .I5(r11_active_y_reg[6]),
        .O(\r4_red[3]_i_226_n_0 ));
  LUT6 #(
    .INIT(64'h00000000712A00AA)) 
    \r4_red[3]_i_227 
       (.I0(r11_active_y_reg[5]),
        .I1(r11_active_y_reg[4]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[3]),
        .I4(r11_active_y_reg[6]),
        .I5(\r4_red[3]_i_135_n_0 ),
        .O(\r4_red[3]_i_227_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT4 #(
    .INIT(16'h4222)) 
    \r4_red[3]_i_228 
       (.I0(r11_active_x_reg[5]),
        .I1(r11_active_x_reg[4]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[2]),
        .O(\r4_red[3]_i_228_n_0 ));
  LUT6 #(
    .INIT(64'h000000008A200089)) 
    \r4_red[3]_i_229 
       (.I0(r11_active_y_reg[5]),
        .I1(r11_active_y_reg[4]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[3]),
        .I4(r11_active_y_reg[6]),
        .I5(\r4_red[3]_i_135_n_0 ),
        .O(\r4_red[3]_i_229_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair81" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \r4_red[3]_i_23 
       (.I0(iw4_result_right[1]),
        .I1(iw4_result_right[2]),
        .O(\r4_red[3]_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair69" *) 
  LUT4 #(
    .INIT(16'h2888)) 
    \r4_red[3]_i_230 
       (.I0(r11_active_x_reg[5]),
        .I1(r11_active_x_reg[4]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[2]),
        .O(\r4_red[3]_i_230_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair44" *) 
  LUT5 #(
    .INIT(32'hAAAAA2AA)) 
    \r4_red[3]_i_231 
       (.I0(\r4_red[3]_i_109_n_0 ),
        .I1(r11_active_y_reg[5]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[3]),
        .I4(r11_active_y_reg[6]),
        .O(\r4_red[3]_i_231_n_0 ));
  LUT6 #(
    .INIT(64'h0A2220A000028A88)) 
    \r4_red[3]_i_232 
       (.I0(\r4_red[3]_i_205_n_0 ),
        .I1(r11_active_y_reg[5]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[3]),
        .I5(r11_active_y_reg[6]),
        .O(\r4_red[3]_i_232_n_0 ));
  LUT6 #(
    .INIT(64'h888888802222AAAA)) 
    \r4_red[3]_i_233 
       (.I0(\r4_red[3]_i_235_n_0 ),
        .I1(r11_active_y_reg[5]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[3]),
        .I5(r11_active_y_reg[6]),
        .O(\r4_red[3]_i_233_n_0 ));
  LUT6 #(
    .INIT(64'h808888802222AAAA)) 
    \r4_red[3]_i_234 
       (.I0(\r4_red[3]_i_236_n_0 ),
        .I1(r11_active_y_reg[5]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[3]),
        .I5(r11_active_y_reg[6]),
        .O(\r4_red[3]_i_234_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair86" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \r4_red[3]_i_235 
       (.I0(r11_active_x_reg[3]),
        .I1(r11_active_x_reg[2]),
        .O(\r4_red[3]_i_235_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair86" *) 
  LUT2 #(
    .INIT(4'h4)) 
    \r4_red[3]_i_236 
       (.I0(r11_active_x_reg[3]),
        .I1(r11_active_x_reg[2]),
        .O(\r4_red[3]_i_236_n_0 ));
  LUT6 #(
    .INIT(64'h00001FF300001FF1)) 
    \r4_red[3]_i_237 
       (.I0(g0_b0_i_1_n_0),
        .I1(g0_b0_i_2_n_0),
        .I2(g0_b0_i_4_n_0),
        .I3(g0_b0_i_3_n_0),
        .I4(\r4_red[3]_i_48_n_0 ),
        .I5(\r4_red[3]_i_49_n_0 ),
        .O(\r4_red[3]_i_237_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT5 #(
    .INIT(32'hBFBFBFFF)) 
    \r4_red[3]_i_238 
       (.I0(\r4_red[3]_i_48_n_0 ),
        .I1(g0_b0_i_4_n_0),
        .I2(g0_b0_i_3_n_0),
        .I3(g0_b0_i_2_n_0),
        .I4(g0_b0_i_1_n_0),
        .O(\r4_red[3]_i_238_n_0 ));
  LUT6 #(
    .INIT(64'h00000002A8000154)) 
    \r4_red[3]_i_239 
       (.I0(r11_active_x_reg[5]),
        .I1(r11_active_x_reg[0]),
        .I2(r11_active_x_reg[1]),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(r11_active_x_reg[4]),
        .O(\r4_red[3]_i_239_n_0 ));
  LUT6 #(
    .INIT(64'h2200202000000000)) 
    \r4_red[3]_i_24 
       (.I0(r4_red313_in),
        .I1(\r4_red[3]_i_38_n_0 ),
        .I2(\r4_red[3]_i_55_n_0 ),
        .I3(\r4_red[3]_i_56_n_0 ),
        .I4(\r4_red[3]_i_57_n_0 ),
        .I5(\r4_red[3]_i_53_n_0 ),
        .O(r4_red115_out));
  LUT6 #(
    .INIT(64'h00000000015A5A04)) 
    \r4_red[3]_i_240 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[5]),
        .I3(r11_active_x_reg[2]),
        .I4(\r4_red[3]_i_91_n_0 ),
        .I5(r4_red2[2]),
        .O(\r4_red[3]_i_240_n_0 ));
  LUT6 #(
    .INIT(64'h4458445844581162)) 
    \r4_red[3]_i_241 
       (.I0(r11_active_x_reg[5]),
        .I1(r11_active_x_reg[2]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[4]),
        .I4(r11_active_x_reg[0]),
        .I5(r11_active_x_reg[1]),
        .O(\r4_red[3]_i_241_n_0 ));
  LUT6 #(
    .INIT(64'h0000000001010110)) 
    \r4_red[3]_i_242 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[1]),
        .I4(r11_active_x_reg[0]),
        .I5(r11_active_x_reg[5]),
        .O(\r4_red[3]_i_242_n_0 ));
  LUT6 #(
    .INIT(64'h0000000004040440)) 
    \r4_red[3]_i_243 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[1]),
        .I4(r11_active_x_reg[0]),
        .I5(r11_active_x_reg[5]),
        .O(\r4_red[3]_i_243_n_0 ));
  LUT6 #(
    .INIT(64'h0503050305030305)) 
    \r4_red[3]_i_244 
       (.I0(g0_b9_n_0),
        .I1(g0_b8_n_0),
        .I2(\r4_red[3]_i_157_n_0 ),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[1]),
        .I5(r11_active_x_reg[0]),
        .O(\r4_red[3]_i_244_n_0 ));
  LUT6 #(
    .INIT(64'h0140017C3D403D7C)) 
    \r4_red[3]_i_245 
       (.I0(g0_b5_n_0),
        .I1(\r4_red[3]_i_91_n_0 ),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[3]),
        .I4(g0_b6__3_n_0),
        .I5(g0_b4_n_0),
        .O(\r4_red[3]_i_245_n_0 ));
  LUT5 #(
    .INIT(32'h00005300)) 
    \r4_red[3]_i_246 
       (.I0(g0_b3_n_0),
        .I1(g0_b7_n_0),
        .I2(\r4_red[3]_i_47_n_0 ),
        .I3(\r4_red[3]_i_157_n_0 ),
        .I4(\r4_red[3]_i_253_n_0 ),
        .O(\r4_red[3]_i_246_n_0 ));
  LUT6 #(
    .INIT(64'h8888888888888881)) 
    \r4_red[3]_i_247 
       (.I0(r11_active_x_reg[5]),
        .I1(r11_active_x_reg[4]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[1]),
        .I5(r11_active_x_reg[0]),
        .O(\r4_red[3]_i_247_n_0 ));
  LUT6 #(
    .INIT(64'h3000500055553333)) 
    \r4_red[3]_i_248 
       (.I0(r4_red2[3]),
        .I1(r4_red2[2]),
        .I2(\r4_red[3]_i_47_n_0 ),
        .I3(\r4_red[3]_i_48_n_0 ),
        .I4(\r4_red[3]_i_49_n_0 ),
        .I5(\r4_red[3]_i_157_n_0 ),
        .O(\r4_red[3]_i_248_n_0 ));
  LUT6 #(
    .INIT(64'h0550033000000000)) 
    \r4_red[3]_i_249 
       (.I0(r4_red2[3]),
        .I1(g0_b2__4_n_0),
        .I2(\r4_red[3]_i_91_n_0 ),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(\r4_red[3]_i_252_n_0 ),
        .O(\r4_red[3]_i_249_n_0 ));
  LUT6 #(
    .INIT(64'h5555555555555777)) 
    \r4_red[3]_i_25 
       (.I0(r4_red120_out),
        .I1(\r4_red[3]_i_59_n_0 ),
        .I2(\r4_red[3]_i_60_n_0 ),
        .I3(\r4_red[3]_i_61_n_0 ),
        .I4(\r4_red[3]_i_62_n_0 ),
        .I5(\r4_red[3]_i_63_n_0 ),
        .O(\r4_red[3]_i_25_n_0 ));
  LUT6 #(
    .INIT(64'h0123FFFF01230123)) 
    \r4_red[3]_i_250 
       (.I0(\r4_red[3]_i_49_n_0 ),
        .I1(\r4_red[3]_i_157_n_0 ),
        .I2(g0_b5__2_n_0),
        .I3(g0_b6__2_n_0),
        .I4(r4_red2[2]),
        .I5(\r4_red[3]_i_158_n_0 ),
        .O(\r4_red[3]_i_250_n_0 ));
  LUT6 #(
    .INIT(64'h0000000001008000)) 
    \r4_red[3]_i_251 
       (.I0(r11_active_x_reg[3]),
        .I1(r11_active_x_reg[2]),
        .I2(\r4_red[3]_i_91_n_0 ),
        .I3(r11_active_x_reg[5]),
        .I4(r11_active_x_reg[4]),
        .I5(r4_red2[1]),
        .O(\r4_red[3]_i_251_n_0 ));
  LUT6 #(
    .INIT(64'hA800000001555555)) 
    \r4_red[3]_i_252 
       (.I0(r11_active_x_reg[5]),
        .I1(r11_active_x_reg[0]),
        .I2(r11_active_x_reg[1]),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(r11_active_x_reg[4]),
        .O(\r4_red[3]_i_252_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair68" *) 
  LUT4 #(
    .INIT(16'h777E)) 
    \r4_red[3]_i_253 
       (.I0(r11_active_x_reg[3]),
        .I1(r11_active_x_reg[2]),
        .I2(r11_active_x_reg[1]),
        .I3(r11_active_x_reg[0]),
        .O(\r4_red[3]_i_253_n_0 ));
  LUT6 #(
    .INIT(64'h000E0101EEE01010)) 
    \r4_red[3]_i_254 
       (.I0(r11_active_x_reg[1]),
        .I1(r11_active_x_reg[0]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[2]),
        .I5(r11_active_x_reg[5]),
        .O(\r4_red[3]_i_254_n_0 ));
  LUT6 #(
    .INIT(64'h0550033000000000)) 
    \r4_red[3]_i_255 
       (.I0(g0_b0__3_n_0),
        .I1(g0_b2__2_n_0),
        .I2(\r4_red[3]_i_91_n_0 ),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(\r4_red[3]_i_252_n_0 ),
        .O(\r4_red[3]_i_255_n_0 ));
  LUT5 #(
    .INIT(32'h0040004C)) 
    \r4_red[3]_i_256 
       (.I0(g0_b7_n_0),
        .I1(\r4_red[3]_i_50_n_0 ),
        .I2(\r4_red[3]_i_47_n_0 ),
        .I3(\r4_red[3]_i_253_n_0 ),
        .I4(g0_b3_n_0),
        .O(\r4_red[3]_i_256_n_0 ));
  LUT6 #(
    .INIT(64'h0123FFFF01230123)) 
    \r4_red[3]_i_257 
       (.I0(\r4_red[3]_i_49_n_0 ),
        .I1(\r4_red[3]_i_50_n_0 ),
        .I2(g0_b8_n_0),
        .I3(g0_b9_n_0),
        .I4(g0_b1_n_0),
        .I5(\r4_red[3]_i_167_n_0 ),
        .O(\r4_red[3]_i_257_n_0 ));
  LUT6 #(
    .INIT(64'h0550033000000000)) 
    \r4_red[3]_i_258 
       (.I0(g0_b0__0_n_0),
        .I1(g0_b2_n_0),
        .I2(\r4_red[3]_i_91_n_0 ),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(\r4_red[3]_i_154_n_0 ),
        .O(\r4_red[3]_i_258_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair41" *) 
  LUT4 #(
    .INIT(16'h0020)) 
    \r4_red[3]_i_259 
       (.I0(iw4_result_left[3]),
        .I1(iw4_result_left[2]),
        .I2(iw4_result_left[0]),
        .I3(iw4_result_left[1]),
        .O(\r4_red[3]_i_259_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA8A8888888888)) 
    \r4_red[3]_i_26 
       (.I0(\r4_red[3]_i_64_n_0 ),
        .I1(\r4_red[3]_i_65_n_0 ),
        .I2(\r4_red[3]_i_66_n_0 ),
        .I3(r11_active_x_reg[5]),
        .I4(r11_active_x_reg[6]),
        .I5(r11_active_x_reg[8]),
        .O(r4_red125_out));
  LUT6 #(
    .INIT(64'h0123FFFF01230123)) 
    \r4_red[3]_i_260 
       (.I0(\r4_red[3]_i_49_n_0 ),
        .I1(\r4_red[3]_i_50_n_0 ),
        .I2(g0_b5__2_n_0),
        .I3(g0_b6__2_n_0),
        .I4(g0_b4__2_n_0),
        .I5(\r4_red[3]_i_18_n_0 ),
        .O(\r4_red[3]_i_260_n_0 ));
  LUT6 #(
    .INIT(64'h0550033000000000)) 
    \r4_red[3]_i_261 
       (.I0(r4_red2[3]),
        .I1(g0_b2__4_n_0),
        .I2(\r4_red[3]_i_91_n_0 ),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(\r4_red[3]_i_154_n_0 ),
        .O(\r4_red[3]_i_261_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair67" *) 
  LUT4 #(
    .INIT(16'h0400)) 
    \r4_red[3]_i_262 
       (.I0(iw4_result_left[3]),
        .I1(iw4_result_left[0]),
        .I2(iw4_result_left[2]),
        .I3(iw4_result_left[1]),
        .O(\r4_red[3]_i_262_n_0 ));
  LUT6 #(
    .INIT(64'h0123FFFF01230123)) 
    \r4_red[3]_i_263 
       (.I0(\r4_red[3]_i_49_n_0 ),
        .I1(\r4_red[3]_i_50_n_0 ),
        .I2(g0_b5__0_n_0),
        .I3(g0_b6_n_0),
        .I4(r4_red2[1]),
        .I5(\r4_red[3]_i_18_n_0 ),
        .O(\r4_red[3]_i_263_n_0 ));
  LUT6 #(
    .INIT(64'h0550033000000000)) 
    \r4_red[3]_i_264 
       (.I0(g0_b3__2_n_0),
        .I1(g0_b1__4_n_0),
        .I2(\r4_red[3]_i_91_n_0 ),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(\r4_red[3]_i_154_n_0 ),
        .O(\r4_red[3]_i_264_n_0 ));
  LUT6 #(
    .INIT(64'h540002A800000002)) 
    \r4_red[3]_i_265 
       (.I0(r11_active_x_reg[5]),
        .I1(r11_active_x_reg[0]),
        .I2(r11_active_x_reg[1]),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(r11_active_x_reg[4]),
        .O(\r4_red[3]_i_265_n_0 ));
  LUT6 #(
    .INIT(64'h0000000020555580)) 
    \r4_red[3]_i_266 
       (.I0(r11_active_x_reg[5]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[2]),
        .I4(\r4_red[3]_i_91_n_0 ),
        .I5(r4_red2[2]),
        .O(\r4_red[3]_i_266_n_0 ));
  LUT6 #(
    .INIT(64'h887088708870800F)) 
    \r4_red[3]_i_267 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[5]),
        .I4(r11_active_x_reg[1]),
        .I5(r11_active_x_reg[0]),
        .O(\r4_red[3]_i_267_n_0 ));
  LUT6 #(
    .INIT(64'h1100110011001004)) 
    \r4_red[3]_i_268 
       (.I0(r11_active_y_reg[5]),
        .I1(r11_active_y_reg[4]),
        .I2(r11_active_y_reg[2]),
        .I3(r11_active_y_reg[3]),
        .I4(r11_active_y_reg[1]),
        .I5(r11_active_y_reg[0]),
        .O(\r4_red[3]_i_268_n_0 ));
  LUT6 #(
    .INIT(64'hFEEEBAAABAAABAAA)) 
    \r4_red[3]_i_27 
       (.I0(\r4_red[3]_i_67_n_0 ),
        .I1(\r4_red[3]_i_68_n_0 ),
        .I2(\r4_red[3]_i_69_n_0 ),
        .I3(\r4_red[3]_i_70_n_0 ),
        .I4(\r4_red[3]_i_71_n_0 ),
        .I5(\r4_red[3]_i_72_n_0 ),
        .O(\r4_red[3]_i_27_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT5 #(
    .INIT(32'h00000100)) 
    \r4_red[3]_i_28 
       (.I0(r4_red115_out),
        .I1(\r4_red[3]_i_4_n_0 ),
        .I2(r4_red128_out),
        .I3(State[0]),
        .I4(State[1]),
        .O(\r4_red[3]_i_28_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT5 #(
    .INIT(32'h00000400)) 
    \r4_red[3]_i_29 
       (.I0(r4_red128_out),
        .I1(r4_red115_out),
        .I2(\r4_red[3]_i_4_n_0 ),
        .I3(State[0]),
        .I4(State[1]),
        .O(\r4_red[3]_i_29_n_0 ));
  LUT4 #(
    .INIT(16'hFFF8)) 
    \r4_red[3]_i_3 
       (.I0(\r4_red[3]_i_8_n_0 ),
        .I1(iw4_red[3]),
        .I2(\r4_red[3]_i_9_n_0 ),
        .I3(\r4_red[3]_i_10_n_0 ),
        .O(r4_red[3]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFEFEE)) 
    \r4_red[3]_i_30 
       (.I0(\r4_red[3]_i_73_n_0 ),
        .I1(\r4_red[3]_i_74_n_0 ),
        .I2(\r4_red[3]_i_75_n_0 ),
        .I3(\r4_red[3]_i_25_n_0 ),
        .I4(\r4_red[3]_i_76_n_0 ),
        .I5(\r4_red[3]_i_77_n_0 ),
        .O(\r4_red[3]_i_30_n_0 ));
  LUT6 #(
    .INIT(64'hFACFFAC00ACF0AC0)) 
    \r4_red[3]_i_31 
       (.I0(\r4_red[3]_i_78_n_0 ),
        .I1(\r4_red[3]_i_79_n_0 ),
        .I2(iw4_result_right[1]),
        .I3(iw4_result_right[0]),
        .I4(\r4_red[3]_i_80_n_0 ),
        .I5(\r4_red[3]_i_81_n_0 ),
        .O(\r4_red[3]_i_31_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair62" *) 
  LUT4 #(
    .INIT(16'h0400)) 
    \r4_red[3]_i_32 
       (.I0(\r4_red[3]_i_4_n_0 ),
        .I1(State[0]),
        .I2(State[1]),
        .I3(r4_red128_out),
        .O(\r4_red[3]_i_32_n_0 ));
  LUT6 #(
    .INIT(64'hFFEAAAAAFFEAAFAF)) 
    \r4_red[3]_i_33 
       (.I0(\r4_red[3]_i_82_n_0 ),
        .I1(\r4_red[3]_i_25_n_0 ),
        .I2(\r4_red[3]_i_22_n_0 ),
        .I3(\r4_red[3]_i_83_n_0 ),
        .I4(iw4_result_left[3]),
        .I5(iw4_result_left[0]),
        .O(\r4_red[3]_i_33_n_0 ));
  LUT6 #(
    .INIT(64'hFCAFFCA00CAF0CA0)) 
    \r4_red[3]_i_34 
       (.I0(\r4_red[3]_i_84_n_0 ),
        .I1(\r4_red[3]_i_85_n_0 ),
        .I2(iw4_result_left[1]),
        .I3(iw4_result_left[0]),
        .I4(\r4_red[3]_i_86_n_0 ),
        .I5(\r4_red[3]_i_87_n_0 ),
        .O(\r4_red[3]_i_34_n_0 ));
  LUT6 #(
    .INIT(64'h0000000100010001)) 
    \r4_red[3]_i_35 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[5]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[3]),
        .I4(r11_active_y_reg[2]),
        .I5(r11_active_y_reg[1]),
        .O(\r4_red[3]_i_35_n_0 ));
  LUT6 #(
    .INIT(64'hF0F0F080F000F000)) 
    \r4_red[3]_i_36 
       (.I0(\r4_red[3]_i_88_n_0 ),
        .I1(r11_active_y_reg[4]),
        .I2(r11_active_y_reg[9]),
        .I3(r11_active_y_reg[7]),
        .I4(r11_active_y_reg[5]),
        .I5(r11_active_y_reg[6]),
        .O(\r4_red[3]_i_36_n_0 ));
  LUT6 #(
    .INIT(64'hFFAAAAAAFEAAAAAA)) 
    \r4_red[3]_i_37 
       (.I0(\r4_red[3]_i_38_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[6]),
        .I3(r11_active_x_reg[8]),
        .I4(r11_active_x_reg[7]),
        .I5(\r4_red[2]_i_16_n_0 ),
        .O(r4_red434_in));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \r4_red[3]_i_38 
       (.I0(r11_active_x_reg[10]),
        .I1(r11_active_x_reg[9]),
        .O(\r4_red[3]_i_38_n_0 ));
  LUT6 #(
    .INIT(64'h8888888888888880)) 
    \r4_red[3]_i_39 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[4]),
        .I2(r11_active_y_reg[1]),
        .I3(r11_active_y_reg[0]),
        .I4(r11_active_y_reg[3]),
        .I5(r11_active_y_reg[2]),
        .O(\r4_red[3]_i_39_n_0 ));
  LUT6 #(
    .INIT(64'hFFAAEAAAEAAAEAAA)) 
    \r4_red[3]_i_4 
       (.I0(\r4_red[3]_i_11_n_0 ),
        .I1(\r4_red[3]_i_12_n_0 ),
        .I2(\r4_red[3]_i_13_n_0 ),
        .I3(\r4_red[3]_i_14_n_0 ),
        .I4(\r4_red[3]_i_15_n_0 ),
        .I5(\r4_red[3]_i_16_n_0 ),
        .O(\r4_red[3]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair80" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    \r4_red[3]_i_40 
       (.I0(r11_active_y_reg[7]),
        .I1(r11_active_y_reg[5]),
        .I2(r11_active_y_reg[6]),
        .O(\r4_red[3]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'hFE)) 
    \r4_red[3]_i_41 
       (.I0(r11_active_y_reg[9]),
        .I1(r11_active_y_reg[10]),
        .I2(r11_active_y_reg[8]),
        .O(\r4_red[3]_i_41_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair64" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \r4_red[3]_i_42 
       (.I0(r11_active_x_reg[8]),
        .I1(r11_active_x_reg[7]),
        .O(\r4_red[3]_i_42_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \r4_red[3]_i_43 
       (.I0(r11_active_y_reg[5]),
        .I1(r11_active_y_reg[4]),
        .O(\r4_red[3]_i_43_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair39" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \r4_red[3]_i_44 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[7]),
        .I2(r11_active_y_reg[8]),
        .I3(r11_active_y_reg[10]),
        .I4(r11_active_y_reg[9]),
        .O(\r4_red[3]_i_44_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair39" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \r4_red[3]_i_45 
       (.I0(r11_active_y_reg[8]),
        .I1(r11_active_y_reg[10]),
        .I2(r11_active_y_reg[9]),
        .I3(r11_active_y_reg[7]),
        .O(\r4_red[3]_i_45_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair85" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \r4_red[3]_i_46 
       (.I0(r11_active_y_reg[1]),
        .I1(r11_active_y_reg[0]),
        .O(\r4_red[3]_i_46_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT5 #(
    .INIT(32'h95959555)) 
    \r4_red[3]_i_47 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[1]),
        .I4(r11_active_x_reg[0]),
        .O(\r4_red[3]_i_47_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair68" *) 
  LUT4 #(
    .INIT(16'h1EF0)) 
    \r4_red[3]_i_48 
       (.I0(r11_active_x_reg[1]),
        .I1(r11_active_x_reg[0]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[2]),
        .O(\r4_red[3]_i_48_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair78" *) 
  LUT3 #(
    .INIT(8'hE1)) 
    \r4_red[3]_i_49 
       (.I0(r11_active_x_reg[0]),
        .I1(r11_active_x_reg[1]),
        .I2(r11_active_x_reg[2]),
        .O(\r4_red[3]_i_49_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF0E0EFF0E)) 
    \r4_red[3]_i_5 
       (.I0(\r4_red[3]_i_17_n_0 ),
        .I1(\r4_red[3]_i_18_n_0 ),
        .I2(r4_red2[1]),
        .I3(\r4_red[3]_i_19_n_0 ),
        .I4(r4_red2[0]),
        .I5(\r4_red[3]_i_20_n_0 ),
        .O(\r4_red[3]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h7F807F807F80FF00)) 
    \r4_red[3]_i_50 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[2]),
        .I3(r11_active_x_reg[5]),
        .I4(r11_active_x_reg[1]),
        .I5(r11_active_x_reg[0]),
        .O(\r4_red[3]_i_50_n_0 ));
  LUT6 #(
    .INIT(64'h00000000E0000000)) 
    \r4_red[3]_i_51 
       (.I0(r11_active_x_reg[1]),
        .I1(r11_active_x_reg[0]),
        .I2(r11_active_x_reg[8]),
        .I3(r11_active_x_reg[6]),
        .I4(r11_active_x_reg[5]),
        .I5(\r11_active_x[8]_i_3_n_0 ),
        .O(\r4_red[3]_i_51_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFA00F800)) 
    \r4_red[3]_i_52 
       (.I0(r11_active_y_reg[3]),
        .I1(r11_active_y_reg[2]),
        .I2(r11_active_y_reg[4]),
        .I3(r11_active_y_reg[5]),
        .I4(\r4_red[3]_i_46_n_0 ),
        .I5(\r4_red[3]_i_44_n_0 ),
        .O(r4_red313_in));
  LUT6 #(
    .INIT(64'h0000FFFF00000015)) 
    \r4_red[3]_i_53 
       (.I0(r11_active_y_reg[3]),
        .I1(r11_active_y_reg[2]),
        .I2(\r4_red[3]_i_46_n_0 ),
        .I3(r11_active_y_reg[4]),
        .I4(\r4_red[3]_i_45_n_0 ),
        .I5(\r4_red[3]_i_89_n_0 ),
        .O(\r4_red[3]_i_53_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair40" *) 
  LUT5 #(
    .INIT(32'h88808080)) 
    \r4_red[3]_i_54 
       (.I0(r11_active_x_reg[8]),
        .I1(r11_active_x_reg[6]),
        .I2(r11_active_x_reg[5]),
        .I3(\r4_red[3]_i_90_n_0 ),
        .I4(r11_active_x_reg[4]),
        .O(\r4_red[3]_i_54_n_0 ));
  LUT6 #(
    .INIT(64'h0000000015151555)) 
    \r4_red[3]_i_55 
       (.I0(r11_active_x_reg[4]),
        .I1(r11_active_x_reg[2]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[0]),
        .I4(r11_active_x_reg[1]),
        .I5(r11_active_x_reg[5]),
        .O(\r4_red[3]_i_55_n_0 ));
  LUT6 #(
    .INIT(64'h4444444444404040)) 
    \r4_red[3]_i_56 
       (.I0(\r4_red[3]_i_42_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[2]),
        .I4(\r4_red[3]_i_91_n_0 ),
        .I5(r11_active_x_reg[3]),
        .O(\r4_red[3]_i_56_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT3 #(
    .INIT(8'h7F)) 
    \r4_red[3]_i_57 
       (.I0(r11_active_x_reg[7]),
        .I1(r11_active_x_reg[8]),
        .I2(r11_active_x_reg[6]),
        .O(\r4_red[3]_i_57_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000F400)) 
    \r4_red[3]_i_58 
       (.I0(\r11_active_x[8]_i_3_n_0 ),
        .I1(r11_active_x_reg[8]),
        .I2(\r4_red[3]_i_92_n_0 ),
        .I3(r4_red318_in),
        .I4(\r4_red[3]_i_94_n_0 ),
        .I5(\r4_red[3]_i_95_n_0 ),
        .O(r4_red120_out));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \r4_red[3]_i_59 
       (.I0(\r4_red[3]_i_96_n_0 ),
        .I1(\r4_red[3]_i_97_n_0 ),
        .I2(\r4_red[3]_i_98_n_0 ),
        .I3(\r4_red[3]_i_99_n_0 ),
        .I4(\r4_red[3]_i_100_n_0 ),
        .I5(\r4_red[3]_i_101_n_0 ),
        .O(\r4_red[3]_i_59_n_0 ));
  LUT6 #(
    .INIT(64'h0000000200000000)) 
    \r4_red[3]_i_6 
       (.I0(\r4_red[2]_i_7_n_0 ),
        .I1(iw4_result_left[1]),
        .I2(iw4_result_left[0]),
        .I3(iw4_result_left[3]),
        .I4(iw4_result_left[2]),
        .I5(r4_red128_out),
        .O(\r4_red[3]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \r4_red[3]_i_60 
       (.I0(\r4_red[3]_i_102_n_0 ),
        .I1(\r4_red[3]_i_103_n_0 ),
        .I2(\r4_red[3]_i_104_n_0 ),
        .I3(\r4_red[3]_i_105_n_0 ),
        .I4(\r4_red[3]_i_106_n_0 ),
        .I5(\r4_red[3]_i_107_n_0 ),
        .O(\r4_red[3]_i_60_n_0 ));
  LUT6 #(
    .INIT(64'h00FF01FE00000000)) 
    \r4_red[3]_i_61 
       (.I0(r11_active_x_reg[2]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[6]),
        .I4(r11_active_x_reg[5]),
        .I5(r11_active_x_reg[7]),
        .O(\r4_red[3]_i_61_n_0 ));
  LUT6 #(
    .INIT(64'h70007000FF000000)) 
    \r4_red[3]_i_62 
       (.I0(\r4_red[3]_i_108_n_0 ),
        .I1(\r4_red[3]_i_109_n_0 ),
        .I2(\r4_red[3]_i_110_n_0 ),
        .I3(\r4_red[3]_i_111_n_0 ),
        .I4(\r4_red[3]_i_112_n_0 ),
        .I5(\r4_red[3]_i_113_n_0 ),
        .O(\r4_red[3]_i_62_n_0 ));
  LUT6 #(
    .INIT(64'h00000000AAAAFFFC)) 
    \r4_red[3]_i_63 
       (.I0(\r4_red[3]_i_114_n_0 ),
        .I1(\r4_red[3]_i_115_n_0 ),
        .I2(\r4_red[3]_i_116_n_0 ),
        .I3(\r4_red[3]_i_117_n_0 ),
        .I4(\r4_red[3]_i_118_n_0 ),
        .I5(\r4_red[3]_i_119_n_0 ),
        .O(\r4_red[3]_i_63_n_0 ));
  LUT6 #(
    .INIT(64'h0C0000008080C0C0)) 
    \r4_red[3]_i_64 
       (.I0(\r4_red[3]_i_120_n_0 ),
        .I1(\r4_red[3]_i_121_n_0 ),
        .I2(r11_active_y_reg[8]),
        .I3(\r4_red[3]_i_122_n_0 ),
        .I4(r11_active_y_reg[6]),
        .I5(r11_active_y_reg[7]),
        .O(\r4_red[3]_i_64_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair64" *) 
  LUT4 #(
    .INIT(16'hFEEE)) 
    \r4_red[3]_i_65 
       (.I0(r11_active_x_reg[9]),
        .I1(r11_active_x_reg[10]),
        .I2(r11_active_x_reg[7]),
        .I3(r11_active_x_reg[8]),
        .O(\r4_red[3]_i_65_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair79" *) 
  LUT3 #(
    .INIT(8'h1F)) 
    \r4_red[3]_i_66 
       (.I0(r11_active_x_reg[2]),
        .I1(r11_active_x_reg[3]),
        .I2(r11_active_x_reg[4]),
        .O(\r4_red[3]_i_66_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFAAA8)) 
    \r4_red[3]_i_67 
       (.I0(\r4_red[3]_i_123_n_0 ),
        .I1(\r4_red[3]_i_124_n_0 ),
        .I2(\r4_red[3]_i_125_n_0 ),
        .I3(\r4_red[3]_i_126_n_0 ),
        .I4(\r4_red[3]_i_127_n_0 ),
        .I5(\r4_red[3]_i_128_n_0 ),
        .O(\r4_red[3]_i_67_n_0 ));
  LUT6 #(
    .INIT(64'h9595959595555555)) 
    \r4_red[3]_i_68 
       (.I0(r11_active_x_reg[7]),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[6]),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[3]),
        .I5(r11_active_x_reg[4]),
        .O(\r4_red[3]_i_68_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT5 #(
    .INIT(32'h5666AAAA)) 
    \r4_red[3]_i_69 
       (.I0(r11_active_x_reg[6]),
        .I1(r11_active_x_reg[4]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[2]),
        .I4(r11_active_x_reg[5]),
        .O(\r4_red[3]_i_69_n_0 ));
  LUT6 #(
    .INIT(64'h707F7F7F7F7F7F7F)) 
    \r4_red[3]_i_7 
       (.I0(\r4_red[3]_i_22_n_0 ),
        .I1(iw4_result_left[3]),
        .I2(r4_red128_out),
        .I3(\r4_red[3]_i_23_n_0 ),
        .I4(iw4_result_right[3]),
        .I5(r4_red115_out),
        .O(\r4_red[3]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEFEFFFEFEFE)) 
    \r4_red[3]_i_70 
       (.I0(\r4_red[3]_i_129_n_0 ),
        .I1(\r4_red[3]_i_130_n_0 ),
        .I2(\r4_red[3]_i_131_n_0 ),
        .I3(\r4_red[3]_i_132_n_0 ),
        .I4(\r4_red[3]_i_133_n_0 ),
        .I5(\r4_red[3]_i_134_n_0 ),
        .O(\r4_red[3]_i_70_n_0 ));
  LUT6 #(
    .INIT(64'h071FCFC710000000)) 
    \r4_red[3]_i_71 
       (.I0(\r4_red[3]_i_135_n_0 ),
        .I1(r11_active_y_reg[6]),
        .I2(r11_active_y_reg[3]),
        .I3(r11_active_y_reg[2]),
        .I4(r11_active_y_reg[4]),
        .I5(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_71_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair43" *) 
  LUT4 #(
    .INIT(16'h8111)) 
    \r4_red[3]_i_72 
       (.I0(r11_active_x_reg[5]),
        .I1(r11_active_x_reg[4]),
        .I2(r11_active_x_reg[3]),
        .I3(r11_active_x_reg[2]),
        .O(\r4_red[3]_i_72_n_0 ));
  LUT6 #(
    .INIT(64'h00000000000A00C0)) 
    \r4_red[3]_i_73 
       (.I0(\r4_red[3]_i_136_n_0 ),
        .I1(\r4_red[3]_i_137_n_0 ),
        .I2(iw4_result_right[3]),
        .I3(iw4_result_right[2]),
        .I4(iw4_result_right[0]),
        .I5(iw4_result_right[1]),
        .O(\r4_red[3]_i_73_n_0 ));
  LUT6 #(
    .INIT(64'h0002000200020000)) 
    \r4_red[3]_i_74 
       (.I0(iw4_result_right[1]),
        .I1(iw4_result_right[2]),
        .I2(iw4_result_right[3]),
        .I3(iw4_result_right[0]),
        .I4(\r4_red[3]_i_138_n_0 ),
        .I5(\r4_red[3]_i_139_n_0 ),
        .O(\r4_red[3]_i_74_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair81" *) 
  LUT3 #(
    .INIT(8'h57)) 
    \r4_red[3]_i_75 
       (.I0(iw4_result_right[3]),
        .I1(iw4_result_right[2]),
        .I2(iw4_result_right[1]),
        .O(\r4_red[3]_i_75_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000C0000A)) 
    \r4_red[3]_i_76 
       (.I0(\r4_red[3]_i_140_n_0 ),
        .I1(\r4_red[3]_i_141_n_0 ),
        .I2(iw4_result_right[3]),
        .I3(iw4_result_right[2]),
        .I4(iw4_result_right[0]),
        .I5(iw4_result_right[1]),
        .O(\r4_red[3]_i_76_n_0 ));
  LUT6 #(
    .INIT(64'h1000100010000000)) 
    \r4_red[3]_i_77 
       (.I0(iw4_result_right[2]),
        .I1(iw4_result_right[3]),
        .I2(iw4_result_right[0]),
        .I3(iw4_result_right[1]),
        .I4(\r4_red[3]_i_142_n_0 ),
        .I5(\r4_red[3]_i_143_n_0 ),
        .O(\r4_red[3]_i_77_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFF4)) 
    \r4_red[3]_i_78 
       (.I0(g0_b4__0_n_0),
        .I1(\r4_red[3]_i_144_n_0 ),
        .I2(\r4_red[3]_i_145_n_0 ),
        .I3(\r4_red[3]_i_146_n_0 ),
        .I4(\r4_red[3]_i_147_n_0 ),
        .O(\r4_red[3]_i_78_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFF4)) 
    \r4_red[3]_i_79 
       (.I0(g0_b2__4_n_0),
        .I1(\r4_red[3]_i_144_n_0 ),
        .I2(\r4_red[3]_i_145_n_0 ),
        .I3(\r4_red[3]_i_148_n_0 ),
        .I4(\r4_red[3]_i_149_n_0 ),
        .O(\r4_red[3]_i_79_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFA30AAF0A)) 
    \r4_red[3]_i_8 
       (.I0(\r4_red[3]_i_25_n_0 ),
        .I1(r4_red125_out),
        .I2(State[0]),
        .I3(State[1]),
        .I4(\r4_red[3]_i_27_n_0 ),
        .I5(\r4_red[3]_i_28_n_0 ),
        .O(\r4_red[3]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFEEFEEEFEEEFE)) 
    \r4_red[3]_i_80 
       (.I0(\r4_red[3]_i_150_n_0 ),
        .I1(\r4_red[3]_i_151_n_0 ),
        .I2(\r4_red[3]_i_144_n_0 ),
        .I3(\r4_red[3]_i_152_n_0 ),
        .I4(\r4_red[3]_i_153_n_0 ),
        .I5(\r4_red[3]_i_154_n_0 ),
        .O(\r4_red[3]_i_80_n_0 ));
  LUT6 #(
    .INIT(64'hAEAAAEAAFFFFAEAA)) 
    \r4_red[3]_i_81 
       (.I0(\r4_red[3]_i_155_n_0 ),
        .I1(\r4_red[3]_i_156_n_0 ),
        .I2(\r4_red[3]_i_47_n_0 ),
        .I3(\r4_red[3]_i_157_n_0 ),
        .I4(\r4_red[3]_i_158_n_0 ),
        .I5(g0_b1__2_n_0),
        .O(\r4_red[3]_i_81_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFBA00)) 
    \r4_red[3]_i_82 
       (.I0(\r4_red[3]_i_159_n_0 ),
        .I1(iw4_result_left[0]),
        .I2(\r4_red[3]_i_160_n_0 ),
        .I3(\r4_red[3]_i_161_n_0 ),
        .I4(\r4_red[3]_i_162_n_0 ),
        .I5(\r4_red[3]_i_163_n_0 ),
        .O(\r4_red[3]_i_82_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair67" *) 
  LUT4 #(
    .INIT(16'h0100)) 
    \r4_red[3]_i_83 
       (.I0(iw4_result_left[1]),
        .I1(iw4_result_left[2]),
        .I2(iw4_result_left[0]),
        .I3(\r4_red[3]_i_164_n_0 ),
        .O(\r4_red[3]_i_83_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFEFEE)) 
    \r4_red[3]_i_84 
       (.I0(\r4_red[3]_i_165_n_0 ),
        .I1(\r4_red[3]_i_166_n_0 ),
        .I2(g0_b1__1_n_0),
        .I3(\r4_red[3]_i_167_n_0 ),
        .I4(\r4_red[3]_i_168_n_0 ),
        .O(\r4_red[3]_i_84_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFEFEE)) 
    \r4_red[3]_i_85 
       (.I0(\r4_red[3]_i_169_n_0 ),
        .I1(\r4_red[3]_i_166_n_0 ),
        .I2(g0_b1__0_n_0),
        .I3(\r4_red[3]_i_167_n_0 ),
        .I4(\r4_red[3]_i_170_n_0 ),
        .O(\r4_red[3]_i_85_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFEAFFEAEA)) 
    \r4_red[3]_i_86 
       (.I0(\r4_red[3]_i_171_n_0 ),
        .I1(\r4_red[3]_i_172_n_0 ),
        .I2(\r4_red[3]_i_153_n_0 ),
        .I3(\r4_red[3]_i_152_n_0 ),
        .I4(\r4_red[3]_i_18_n_0 ),
        .I5(\r4_red[3]_i_173_n_0 ),
        .O(\r4_red[3]_i_86_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFF444F)) 
    \r4_red[3]_i_87 
       (.I0(g0_b2__2_n_0),
        .I1(\r4_red[3]_i_17_n_0 ),
        .I2(\r4_red[3]_i_50_n_0 ),
        .I3(g0_b7__0_n_0),
        .I4(\r4_red[3]_i_174_n_0 ),
        .I5(\r4_red[3]_i_175_n_0 ),
        .O(\r4_red[3]_i_87_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT4 #(
    .INIT(16'hFEEE)) 
    \r4_red[3]_i_88 
       (.I0(r11_active_y_reg[2]),
        .I1(r11_active_y_reg[3]),
        .I2(r11_active_y_reg[0]),
        .I3(r11_active_y_reg[1]),
        .O(\r4_red[3]_i_88_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair80" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \r4_red[3]_i_89 
       (.I0(r11_active_y_reg[6]),
        .I1(r11_active_y_reg[5]),
        .O(\r4_red[3]_i_89_n_0 ));
  LUT6 #(
    .INIT(64'h80A0808080808080)) 
    \r4_red[3]_i_9 
       (.I0(\r4_red[3]_i_29_n_0 ),
        .I1(\r4_red[3]_i_30_n_0 ),
        .I2(iw4_red[3]),
        .I3(iw4_result_right[3]),
        .I4(iw4_result_right[2]),
        .I5(\r4_red[3]_i_31_n_0 ),
        .O(\r4_red[3]_i_9_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair63" *) 
  LUT4 #(
    .INIT(16'hFFA8)) 
    \r4_red[3]_i_90 
       (.I0(r11_active_x_reg[2]),
        .I1(r11_active_x_reg[1]),
        .I2(r11_active_x_reg[0]),
        .I3(r11_active_x_reg[3]),
        .O(\r4_red[3]_i_90_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair83" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \r4_red[3]_i_91 
       (.I0(r11_active_x_reg[1]),
        .I1(r11_active_x_reg[0]),
        .O(\r4_red[3]_i_91_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFAAA8)) 
    \r4_red[3]_i_92 
       (.I0(r11_active_x_reg[8]),
        .I1(r11_active_x_reg[7]),
        .I2(r11_active_x_reg[5]),
        .I3(r11_active_x_reg[6]),
        .I4(r11_active_x_reg[9]),
        .I5(r11_active_x_reg[10]),
        .O(\r4_red[3]_i_92_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFEEEEFFFEEEEE)) 
    \r4_red[3]_i_93 
       (.I0(r11_active_y_reg[10]),
        .I1(r11_active_y_reg[9]),
        .I2(r11_active_y_reg[6]),
        .I3(r11_active_y_reg[7]),
        .I4(r11_active_y_reg[8]),
        .I5(\r4_red[3]_i_176_n_0 ),
        .O(r4_red318_in));
  LUT6 #(
    .INIT(64'hFFFFE000E000E000)) 
    \r4_red[3]_i_94 
       (.I0(r11_active_y_reg[4]),
        .I1(r11_active_y_reg[5]),
        .I2(r11_active_y_reg[6]),
        .I3(r11_active_y_reg[8]),
        .I4(r11_active_x_reg[9]),
        .I5(\r4_red[2]_i_17_n_0 ),
        .O(\r4_red[3]_i_94_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \r4_red[3]_i_95 
       (.I0(\r4_red[3]_i_177_n_0 ),
        .I1(r11_active_y_reg[9]),
        .I2(r11_active_y_reg[10]),
        .I3(r11_active_x_reg[10]),
        .I4(\r4_red[3]_i_178_n_0 ),
        .O(\r4_red[3]_i_95_n_0 ));
  LUT6 #(
    .INIT(64'h1111111111111114)) 
    \r4_red[3]_i_96 
       (.I0(r11_active_x_reg[7]),
        .I1(r11_active_x_reg[6]),
        .I2(r11_active_x_reg[5]),
        .I3(r11_active_x_reg[4]),
        .I4(r11_active_x_reg[3]),
        .I5(r11_active_x_reg[2]),
        .O(\r4_red[3]_i_96_n_0 ));
  LUT6 #(
    .INIT(64'h00800C0000800000)) 
    \r4_red[3]_i_97 
       (.I0(\r4_red[3]_i_179_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[2]),
        .I5(\r4_red[3]_i_180_n_0 ),
        .O(\r4_red[3]_i_97_n_0 ));
  LUT6 #(
    .INIT(64'h0C0080C000008000)) 
    \r4_red[3]_i_98 
       (.I0(\r4_red[3]_i_181_n_0 ),
        .I1(r11_active_x_reg[5]),
        .I2(r11_active_x_reg[4]),
        .I3(r11_active_x_reg[3]),
        .I4(r11_active_x_reg[2]),
        .I5(\r4_red[3]_i_182_n_0 ),
        .O(\r4_red[3]_i_98_n_0 ));
  LUT6 #(
    .INIT(64'h07B0000000000000)) 
    \r4_red[3]_i_99 
       (.I0(\r4_red[3]_i_183_n_0 ),
        .I1(\r4_red[3]_i_184_n_0 ),
        .I2(\r4_red[3]_i_185_n_0 ),
        .I3(\r4_red[3]_i_186_n_0 ),
        .I4(r11_active_x_reg[2]),
        .I5(\r4_red[3]_i_108_n_0 ),
        .O(\r4_red[3]_i_99_n_0 ));
  FDRE #(
    .INIT(1'b1)) 
    \r4_red_reg[0] 
       (.C(iw_pix_clk),
        .CE(\r4_red[2]_i_2_n_0 ),
        .D(r4_red[0]),
        .Q(\r4_red_reg_n_0_[0] ),
        .R(r4_blue[2]));
  FDRE #(
    .INIT(1'b1)) 
    \r4_red_reg[1] 
       (.C(iw_pix_clk),
        .CE(\r4_red[3]_i_2_n_0 ),
        .D(r4_red[1]),
        .Q(\r4_red_reg_n_0_[1] ),
        .R(r4_blue[3]));
  FDRE #(
    .INIT(1'b1)) 
    \r4_red_reg[2] 
       (.C(iw_pix_clk),
        .CE(\r4_red[2]_i_2_n_0 ),
        .D(r4_red[2]),
        .Q(\r4_red_reg_n_0_[2] ),
        .R(r4_blue[2]));
  FDRE #(
    .INIT(1'b0)) 
    \r4_red_reg[3] 
       (.C(iw_pix_clk),
        .CE(\r4_red[3]_i_2_n_0 ),
        .D(r4_red[3]),
        .Q(\r4_red_reg_n_0_[3] ),
        .R(r4_blue[3]));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
