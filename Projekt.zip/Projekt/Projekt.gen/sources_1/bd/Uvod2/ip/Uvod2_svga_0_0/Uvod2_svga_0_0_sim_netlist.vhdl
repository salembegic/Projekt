-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
-- Date        : Mon May 11 17:36:07 2026
-- Host        : LRNV-INSTALL running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/vaje/Desktop/Salem/SalemPEV/11.5/PEV/Projekt/Projekt.gen/sources_1/bd/Uvod2/ip/Uvod2_svga_0_0/Uvod2_svga_0_0_sim_netlist.vhdl
-- Design      : Uvod2_svga_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7s25csga324-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity Uvod2_svga_0_0_svga is
  port (
    ow4_red : out STD_LOGIC_VECTOR ( 3 downto 0 );
    ow4_green : out STD_LOGIC_VECTOR ( 3 downto 0 );
    ow4_blue : out STD_LOGIC_VECTOR ( 3 downto 0 );
    ow_hsync : out STD_LOGIC;
    ow_vsync : out STD_LOGIC;
    iw11_block_right_pos : in STD_LOGIC_VECTOR ( 10 downto 0 );
    iw11_block_left_pos : in STD_LOGIC_VECTOR ( 10 downto 0 );
    iw11_y_pos : in STD_LOGIC_VECTOR ( 10 downto 0 );
    iw11_x_pos : in STD_LOGIC_VECTOR ( 10 downto 0 );
    iw_pix_clk : in STD_LOGIC;
    iw2_State : in STD_LOGIC_VECTOR ( 1 downto 0 );
    iw4_blue : in STD_LOGIC_VECTOR ( 3 downto 0 );
    iw4_result_right : in STD_LOGIC_VECTOR ( 3 downto 0 );
    iw4_green : in STD_LOGIC_VECTOR ( 3 downto 0 );
    iw4_red : in STD_LOGIC_VECTOR ( 3 downto 0 );
    iw4_result_left : in STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of Uvod2_svga_0_0_svga : entity is "svga";
end Uvod2_svga_0_0_svga;

architecture STRUCTURE of Uvod2_svga_0_0_svga is
  signal State : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \g0_b0__0_n_0\ : STD_LOGIC;
  signal \g0_b0__1_n_0\ : STD_LOGIC;
  signal \g0_b0__2_n_0\ : STD_LOGIC;
  signal \g0_b0__3_n_0\ : STD_LOGIC;
  signal \g0_b0__4_n_0\ : STD_LOGIC;
  signal g0_b0_i_1_n_0 : STD_LOGIC;
  signal g0_b0_i_2_n_0 : STD_LOGIC;
  signal g0_b0_i_3_n_0 : STD_LOGIC;
  signal g0_b0_i_4_n_0 : STD_LOGIC;
  signal \g0_b1__0_n_0\ : STD_LOGIC;
  signal \g0_b1__1_n_0\ : STD_LOGIC;
  signal \g0_b1__2_n_0\ : STD_LOGIC;
  signal \g0_b1__4_n_0\ : STD_LOGIC;
  signal g0_b1_n_0 : STD_LOGIC;
  signal \g0_b2__0_n_0\ : STD_LOGIC;
  signal \g0_b2__1_n_0\ : STD_LOGIC;
  signal \g0_b2__2_n_0\ : STD_LOGIC;
  signal \g0_b2__4_n_0\ : STD_LOGIC;
  signal g0_b2_n_0 : STD_LOGIC;
  signal \g0_b3__0_n_0\ : STD_LOGIC;
  signal \g0_b3__2_n_0\ : STD_LOGIC;
  signal g0_b3_n_0 : STD_LOGIC;
  signal \g0_b4__0_n_0\ : STD_LOGIC;
  signal \g0_b4__1_n_0\ : STD_LOGIC;
  signal \g0_b4__2_n_0\ : STD_LOGIC;
  signal g0_b4_n_0 : STD_LOGIC;
  signal \g0_b5__0_n_0\ : STD_LOGIC;
  signal \g0_b5__1_n_0\ : STD_LOGIC;
  signal \g0_b5__2_n_0\ : STD_LOGIC;
  signal g0_b5_n_0 : STD_LOGIC;
  signal \g0_b6__0_n_0\ : STD_LOGIC;
  signal \g0_b6__1_n_0\ : STD_LOGIC;
  signal \g0_b6__2_n_0\ : STD_LOGIC;
  signal \g0_b6__3_n_0\ : STD_LOGIC;
  signal g0_b6_n_0 : STD_LOGIC;
  signal \g0_b7__0_n_0\ : STD_LOGIC;
  signal g0_b7_n_0 : STD_LOGIC;
  signal g0_b8_n_0 : STD_LOGIC;
  signal g0_b9_n_0 : STD_LOGIC;
  signal \i___0_carry__0_i_1__0_n_0\ : STD_LOGIC;
  signal \i___0_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \i___0_carry__0_i_2__0_n_0\ : STD_LOGIC;
  signal \i___0_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \i___0_carry__0_i_3__0_n_0\ : STD_LOGIC;
  signal \i___0_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \i___0_carry__0_i_4__0_n_0\ : STD_LOGIC;
  signal \i___0_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \i___0_carry__0_i_5__0_n_0\ : STD_LOGIC;
  signal \i___0_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \i___0_carry__0_i_6__0_n_0\ : STD_LOGIC;
  signal \i___0_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \i___0_carry__0_i_7__0_n_0\ : STD_LOGIC;
  signal \i___0_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \i___0_carry__0_i_8__0_n_0\ : STD_LOGIC;
  signal \i___0_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \i___0_carry__1_i_1__0_n_0\ : STD_LOGIC;
  signal \i___0_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \i___0_carry__1_i_2__0_n_0\ : STD_LOGIC;
  signal \i___0_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \i___0_carry__1_i_3__0_n_0\ : STD_LOGIC;
  signal \i___0_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \i___0_carry__1_i_4__0_n_0\ : STD_LOGIC;
  signal \i___0_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \i___0_carry__1_i_5__0_n_0\ : STD_LOGIC;
  signal \i___0_carry__1_i_5_n_0\ : STD_LOGIC;
  signal \i___0_carry__1_i_6__0_n_0\ : STD_LOGIC;
  signal \i___0_carry__1_i_6_n_0\ : STD_LOGIC;
  signal \i___0_carry__1_i_7__0_n_0\ : STD_LOGIC;
  signal \i___0_carry__1_i_7_n_0\ : STD_LOGIC;
  signal \i___0_carry_i_1__0_n_0\ : STD_LOGIC;
  signal \i___0_carry_i_1_n_0\ : STD_LOGIC;
  signal \i___0_carry_i_2__0_n_0\ : STD_LOGIC;
  signal \i___0_carry_i_2_n_0\ : STD_LOGIC;
  signal \i___0_carry_i_3__0_n_0\ : STD_LOGIC;
  signal \i___0_carry_i_3_n_0\ : STD_LOGIC;
  signal \i___0_carry_i_4__0_n_0\ : STD_LOGIC;
  signal \i___0_carry_i_4_n_0\ : STD_LOGIC;
  signal \i___0_carry_i_5__0_n_0\ : STD_LOGIC;
  signal \i___0_carry_i_5_n_0\ : STD_LOGIC;
  signal \i___0_carry_i_6__0_n_0\ : STD_LOGIC;
  signal \i___0_carry_i_6_n_0\ : STD_LOGIC;
  signal \i___0_carry_i_7__0_n_0\ : STD_LOGIC;
  signal \i___0_carry_i_7_n_0\ : STD_LOGIC;
  signal \i___0_carry_i_8__0_n_0\ : STD_LOGIC;
  signal \i___0_carry_i_8_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_1__0_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_1__1_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_1__2_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_1_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_2__0_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_2__1_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_2__2_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_2_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_3__0_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_3__1_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_3__2_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_3_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_4__0_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_4__1_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_4__2_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_4_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_5_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_6_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_7_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_8_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_1_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_2_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_3_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_4_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_5_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_6_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_7_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_1_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_2_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_3_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_4_n_0\ : STD_LOGIC;
  signal \i__carry_i_5__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_5__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_5__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_5_n_0\ : STD_LOGIC;
  signal \i__carry_i_6__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_6__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_6_n_0\ : STD_LOGIC;
  signal \i__carry_i_7__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_7__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_7_n_0\ : STD_LOGIC;
  signal \i__carry_i_8__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_8__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_8_n_0\ : STD_LOGIC;
  signal \ow4_red[3]_INST_0_i_10_n_0\ : STD_LOGIC;
  signal \ow4_red[3]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \ow4_red[3]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \ow4_red[3]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \ow4_red[3]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \ow4_red[3]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \ow4_red[3]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal \ow4_red[3]_INST_0_i_9_n_0\ : STD_LOGIC;
  signal ow_hsync_INST_0_i_1_n_0 : STD_LOGIC;
  signal ow_hsync_INST_0_i_2_n_0 : STD_LOGIC;
  signal ow_vsync_INST_0_i_1_n_0 : STD_LOGIC;
  signal p_0_in : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal \p_0_in__0\ : STD_LOGIC_VECTOR ( 10 downto 1 );
  signal \p_0_in__1\ : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal \p_0_out_inferred__4/r4_red[3]_i_204_n_0\ : STD_LOGIC;
  signal \p_0_out_inferred__4/r4_red[3]_i_206_n_0\ : STD_LOGIC;
  signal \p_0_out_inferred__4/r4_red[3]_i_210_n_0\ : STD_LOGIC;
  signal \p_0_out_inferred__4/r4_red[3]_i_211_n_0\ : STD_LOGIC;
  signal \p_0_out_inferred__4/r4_red[3]_i_222_n_0\ : STD_LOGIC;
  signal \p_0_out_inferred__4/r4_red[3]_i_223_n_0\ : STD_LOGIC;
  signal \p_0_out_inferred__4/r4_red[3]_i_269_n_0\ : STD_LOGIC;
  signal \p_0_out_inferred__4/r4_red[3]_i_270_n_0\ : STD_LOGIC;
  signal \p_0_out_inferred__4/r4_red[3]_i_271_n_0\ : STD_LOGIC;
  signal \p_0_out_inferred__4/r4_red[3]_i_272_n_0\ : STD_LOGIC;
  signal \p_0_out_inferred__4/r4_red[3]_i_273_n_0\ : STD_LOGIC;
  signal \p_0_out_inferred__4/r4_red[3]_i_274_n_0\ : STD_LOGIC;
  signal \p_0_out_inferred__4/r4_red[3]_i_275_n_0\ : STD_LOGIC;
  signal \p_0_out_inferred__4/r4_red[3]_i_276_n_0\ : STD_LOGIC;
  signal p_1_in : STD_LOGIC_VECTOR ( 9 downto 0 );
  signal \p_1_out_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__0_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__0_n_1\ : STD_LOGIC;
  signal \p_1_out_carry__0_n_2\ : STD_LOGIC;
  signal \p_1_out_carry__0_n_3\ : STD_LOGIC;
  signal \p_1_out_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__1_i_5_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__1_i_6_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__1_i_7_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__1_n_0\ : STD_LOGIC;
  signal \p_1_out_carry__1_n_1\ : STD_LOGIC;
  signal \p_1_out_carry__1_n_2\ : STD_LOGIC;
  signal \p_1_out_carry__1_n_3\ : STD_LOGIC;
  signal p_1_out_carry_i_1_n_0 : STD_LOGIC;
  signal p_1_out_carry_i_2_n_0 : STD_LOGIC;
  signal p_1_out_carry_i_3_n_0 : STD_LOGIC;
  signal p_1_out_carry_i_4_n_0 : STD_LOGIC;
  signal p_1_out_carry_i_5_n_0 : STD_LOGIC;
  signal p_1_out_carry_n_0 : STD_LOGIC;
  signal p_1_out_carry_n_1 : STD_LOGIC;
  signal p_1_out_carry_n_2 : STD_LOGIC;
  signal p_1_out_carry_n_3 : STD_LOGIC;
  signal \p_1_out_inferred__0/i__carry__0_n_0\ : STD_LOGIC;
  signal \p_1_out_inferred__0/i__carry__0_n_1\ : STD_LOGIC;
  signal \p_1_out_inferred__0/i__carry__0_n_2\ : STD_LOGIC;
  signal \p_1_out_inferred__0/i__carry__0_n_3\ : STD_LOGIC;
  signal \p_1_out_inferred__0/i__carry__1_n_0\ : STD_LOGIC;
  signal \p_1_out_inferred__0/i__carry__1_n_1\ : STD_LOGIC;
  signal \p_1_out_inferred__0/i__carry__1_n_2\ : STD_LOGIC;
  signal \p_1_out_inferred__0/i__carry__1_n_3\ : STD_LOGIC;
  signal \p_1_out_inferred__0/i__carry_n_0\ : STD_LOGIC;
  signal \p_1_out_inferred__0/i__carry_n_1\ : STD_LOGIC;
  signal \p_1_out_inferred__0/i__carry_n_2\ : STD_LOGIC;
  signal \p_1_out_inferred__0/i__carry_n_3\ : STD_LOGIC;
  signal \p_1_out_inferred__1/i___0_carry__0_n_0\ : STD_LOGIC;
  signal \p_1_out_inferred__1/i___0_carry__0_n_1\ : STD_LOGIC;
  signal \p_1_out_inferred__1/i___0_carry__0_n_2\ : STD_LOGIC;
  signal \p_1_out_inferred__1/i___0_carry__0_n_3\ : STD_LOGIC;
  signal \p_1_out_inferred__1/i___0_carry__1_n_0\ : STD_LOGIC;
  signal \p_1_out_inferred__1/i___0_carry__1_n_1\ : STD_LOGIC;
  signal \p_1_out_inferred__1/i___0_carry__1_n_2\ : STD_LOGIC;
  signal \p_1_out_inferred__1/i___0_carry__1_n_3\ : STD_LOGIC;
  signal \p_1_out_inferred__1/i___0_carry_n_0\ : STD_LOGIC;
  signal \p_1_out_inferred__1/i___0_carry_n_1\ : STD_LOGIC;
  signal \p_1_out_inferred__1/i___0_carry_n_2\ : STD_LOGIC;
  signal \p_1_out_inferred__1/i___0_carry_n_3\ : STD_LOGIC;
  signal \p_1_out_inferred__2/i___0_carry__0_n_0\ : STD_LOGIC;
  signal \p_1_out_inferred__2/i___0_carry__0_n_1\ : STD_LOGIC;
  signal \p_1_out_inferred__2/i___0_carry__0_n_2\ : STD_LOGIC;
  signal \p_1_out_inferred__2/i___0_carry__0_n_3\ : STD_LOGIC;
  signal \p_1_out_inferred__2/i___0_carry__1_n_0\ : STD_LOGIC;
  signal \p_1_out_inferred__2/i___0_carry__1_n_1\ : STD_LOGIC;
  signal \p_1_out_inferred__2/i___0_carry__1_n_2\ : STD_LOGIC;
  signal \p_1_out_inferred__2/i___0_carry__1_n_3\ : STD_LOGIC;
  signal \p_1_out_inferred__2/i___0_carry_n_0\ : STD_LOGIC;
  signal \p_1_out_inferred__2/i___0_carry_n_1\ : STD_LOGIC;
  signal \p_1_out_inferred__2/i___0_carry_n_2\ : STD_LOGIC;
  signal \p_1_out_inferred__2/i___0_carry_n_3\ : STD_LOGIC;
  signal p_43_in : STD_LOGIC;
  signal \r11_active_x[0]_i_1_n_0\ : STD_LOGIC;
  signal \r11_active_x[10]_i_3_n_0\ : STD_LOGIC;
  signal \r11_active_x[8]_i_2_n_0\ : STD_LOGIC;
  signal \r11_active_x[8]_i_3_n_0\ : STD_LOGIC;
  signal r11_active_x_reg : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal r11_active_y : STD_LOGIC;
  signal \r11_active_y[10]_i_3_n_0\ : STD_LOGIC;
  signal \r11_active_y[7]_i_2_n_0\ : STD_LOGIC;
  signal \r11_active_y[7]_i_3_n_0\ : STD_LOGIC;
  signal r11_active_y_reg : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal \r11_h_count[10]_i_2_n_0\ : STD_LOGIC;
  signal r11_h_count_reg : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal r11_v_count : STD_LOGIC;
  signal \r11_v_count[9]_i_2_n_0\ : STD_LOGIC;
  signal \r11_v_count[9]_i_4_n_0\ : STD_LOGIC;
  signal \r11_v_count[9]_i_5_n_0\ : STD_LOGIC;
  signal \r11_v_count[9]_i_6_n_0\ : STD_LOGIC;
  signal \r11_v_count_reg_n_0_[0]\ : STD_LOGIC;
  signal \r11_v_count_reg_n_0_[1]\ : STD_LOGIC;
  signal \r11_v_count_reg_n_0_[2]\ : STD_LOGIC;
  signal \r11_v_count_reg_n_0_[3]\ : STD_LOGIC;
  signal \r11_v_count_reg_n_0_[4]\ : STD_LOGIC;
  signal \r11_v_count_reg_n_0_[5]\ : STD_LOGIC;
  signal \r11_v_count_reg_n_0_[6]\ : STD_LOGIC;
  signal \r11_v_count_reg_n_0_[7]\ : STD_LOGIC;
  signal \r11_v_count_reg_n_0_[8]\ : STD_LOGIC;
  signal \r11_v_count_reg_n_0_[9]\ : STD_LOGIC;
  signal r4_blue : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \r4_blue[0]_i_1_n_0\ : STD_LOGIC;
  signal \r4_blue[0]_i_2_n_0\ : STD_LOGIC;
  signal \r4_blue[0]_i_3_n_0\ : STD_LOGIC;
  signal \r4_blue[1]_i_1_n_0\ : STD_LOGIC;
  signal \r4_blue[1]_i_2_n_0\ : STD_LOGIC;
  signal \r4_blue[1]_i_3_n_0\ : STD_LOGIC;
  signal \r4_blue[2]_i_1_n_0\ : STD_LOGIC;
  signal \r4_blue[2]_i_2_n_0\ : STD_LOGIC;
  signal \r4_blue[2]_i_3_n_0\ : STD_LOGIC;
  signal \r4_blue[3]_i_1_n_0\ : STD_LOGIC;
  signal \r4_blue[3]_i_2_n_0\ : STD_LOGIC;
  signal \r4_blue[3]_i_3_n_0\ : STD_LOGIC;
  signal \r4_blue_reg_n_0_[0]\ : STD_LOGIC;
  signal \r4_blue_reg_n_0_[1]\ : STD_LOGIC;
  signal \r4_blue_reg_n_0_[2]\ : STD_LOGIC;
  signal \r4_blue_reg_n_0_[3]\ : STD_LOGIC;
  signal r4_green : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \r4_green[0]_i_2_n_0\ : STD_LOGIC;
  signal \r4_green[0]_i_3_n_0\ : STD_LOGIC;
  signal \r4_green[1]_i_2_n_0\ : STD_LOGIC;
  signal \r4_green[1]_i_3_n_0\ : STD_LOGIC;
  signal \r4_green[2]_i_2_n_0\ : STD_LOGIC;
  signal \r4_green[2]_i_3_n_0\ : STD_LOGIC;
  signal \r4_green[3]_i_2_n_0\ : STD_LOGIC;
  signal \r4_green[3]_i_3_n_0\ : STD_LOGIC;
  signal \r4_green_reg_n_0_[0]\ : STD_LOGIC;
  signal \r4_green_reg_n_0_[1]\ : STD_LOGIC;
  signal \r4_green_reg_n_0_[2]\ : STD_LOGIC;
  signal \r4_green_reg_n_0_[3]\ : STD_LOGIC;
  signal r4_red : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal r4_red115_out : STD_LOGIC;
  signal r4_red120_out : STD_LOGIC;
  signal r4_red125_out : STD_LOGIC;
  signal r4_red128_out : STD_LOGIC;
  signal r4_red2 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal r4_red310_in : STD_LOGIC;
  signal r4_red311_in : STD_LOGIC;
  signal r4_red313_in : STD_LOGIC;
  signal r4_red318_in : STD_LOGIC;
  signal r4_red31_in : STD_LOGIC;
  signal r4_red35_in : STD_LOGIC;
  signal \r4_red3_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \r4_red3_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \r4_red3_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \r4_red3_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \r4_red3_carry__0_n_3\ : STD_LOGIC;
  signal r4_red3_carry_i_1_n_0 : STD_LOGIC;
  signal r4_red3_carry_i_2_n_0 : STD_LOGIC;
  signal r4_red3_carry_i_3_n_0 : STD_LOGIC;
  signal r4_red3_carry_i_4_n_0 : STD_LOGIC;
  signal r4_red3_carry_i_5_n_0 : STD_LOGIC;
  signal r4_red3_carry_i_6_n_0 : STD_LOGIC;
  signal r4_red3_carry_i_7_n_0 : STD_LOGIC;
  signal r4_red3_carry_i_8_n_0 : STD_LOGIC;
  signal r4_red3_carry_n_0 : STD_LOGIC;
  signal r4_red3_carry_n_1 : STD_LOGIC;
  signal r4_red3_carry_n_2 : STD_LOGIC;
  signal r4_red3_carry_n_3 : STD_LOGIC;
  signal \r4_red3_inferred__0/i__carry__0_n_3\ : STD_LOGIC;
  signal \r4_red3_inferred__0/i__carry_n_0\ : STD_LOGIC;
  signal \r4_red3_inferred__0/i__carry_n_1\ : STD_LOGIC;
  signal \r4_red3_inferred__0/i__carry_n_2\ : STD_LOGIC;
  signal \r4_red3_inferred__0/i__carry_n_3\ : STD_LOGIC;
  signal \r4_red3_inferred__1/i__carry__0_n_3\ : STD_LOGIC;
  signal \r4_red3_inferred__1/i__carry_n_0\ : STD_LOGIC;
  signal \r4_red3_inferred__1/i__carry_n_1\ : STD_LOGIC;
  signal \r4_red3_inferred__1/i__carry_n_2\ : STD_LOGIC;
  signal \r4_red3_inferred__1/i__carry_n_3\ : STD_LOGIC;
  signal \r4_red3_inferred__2/i__carry__0_n_3\ : STD_LOGIC;
  signal \r4_red3_inferred__2/i__carry_n_0\ : STD_LOGIC;
  signal \r4_red3_inferred__2/i__carry_n_1\ : STD_LOGIC;
  signal \r4_red3_inferred__2/i__carry_n_2\ : STD_LOGIC;
  signal \r4_red3_inferred__2/i__carry_n_3\ : STD_LOGIC;
  signal r4_red434_in : STD_LOGIC;
  signal \r4_red[0]_i_2_n_0\ : STD_LOGIC;
  signal \r4_red[0]_i_3_n_0\ : STD_LOGIC;
  signal \r4_red[1]_i_2_n_0\ : STD_LOGIC;
  signal \r4_red[1]_i_3_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_10_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_11_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_12_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_13_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_14_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_15_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_16_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_17_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_18_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_19_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_20_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_21_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_2_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_4_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_5_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_6_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_7_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_8_n_0\ : STD_LOGIC;
  signal \r4_red[2]_i_9_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_100_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_101_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_102_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_103_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_104_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_105_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_106_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_107_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_108_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_109_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_10_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_110_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_111_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_112_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_113_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_114_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_115_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_116_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_117_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_118_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_119_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_11_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_120_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_121_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_122_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_123_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_124_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_125_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_126_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_127_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_128_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_129_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_12_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_130_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_131_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_132_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_133_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_134_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_135_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_136_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_137_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_138_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_139_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_13_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_140_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_141_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_142_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_143_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_144_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_145_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_146_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_147_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_148_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_149_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_14_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_150_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_151_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_152_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_153_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_154_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_155_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_156_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_157_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_158_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_159_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_15_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_160_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_161_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_162_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_163_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_164_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_165_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_166_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_167_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_168_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_169_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_16_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_170_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_171_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_172_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_173_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_174_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_175_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_176_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_177_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_178_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_179_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_17_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_180_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_181_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_182_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_183_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_184_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_185_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_186_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_187_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_188_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_189_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_18_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_190_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_191_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_192_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_193_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_194_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_195_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_196_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_197_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_198_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_199_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_19_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_200_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_201_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_202_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_203_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_205_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_207_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_208_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_209_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_20_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_212_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_213_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_214_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_215_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_216_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_217_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_218_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_219_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_220_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_221_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_224_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_225_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_226_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_227_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_228_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_229_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_22_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_230_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_231_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_232_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_233_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_234_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_235_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_236_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_237_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_238_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_239_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_23_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_240_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_241_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_242_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_243_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_244_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_245_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_246_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_247_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_248_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_249_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_250_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_251_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_252_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_253_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_254_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_255_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_256_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_257_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_258_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_259_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_25_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_260_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_261_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_262_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_263_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_264_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_265_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_266_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_267_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_268_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_27_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_28_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_29_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_2_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_30_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_31_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_32_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_33_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_34_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_35_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_36_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_38_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_39_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_40_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_41_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_42_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_43_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_44_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_45_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_46_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_47_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_48_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_49_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_4_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_50_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_51_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_53_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_54_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_55_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_56_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_57_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_59_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_5_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_60_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_61_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_62_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_63_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_64_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_65_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_66_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_67_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_68_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_69_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_6_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_70_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_71_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_72_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_73_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_74_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_75_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_76_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_77_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_78_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_79_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_7_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_80_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_81_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_82_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_83_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_84_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_85_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_86_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_87_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_88_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_89_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_8_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_90_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_91_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_92_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_94_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_95_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_96_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_97_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_98_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_99_n_0\ : STD_LOGIC;
  signal \r4_red[3]_i_9_n_0\ : STD_LOGIC;
  signal \r4_red_reg_n_0_[0]\ : STD_LOGIC;
  signal \r4_red_reg_n_0_[1]\ : STD_LOGIC;
  signal \r4_red_reg_n_0_[2]\ : STD_LOGIC;
  signal \r4_red_reg_n_0_[3]\ : STD_LOGIC;
  signal w_hactive041_in : STD_LOGIC;
  signal w_vactive040_in : STD_LOGIC;
  signal NLW_p_1_out_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_p_1_out_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_p_1_out_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_p_1_out_inferred__0/i__carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_p_1_out_inferred__0/i__carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_p_1_out_inferred__0/i__carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_p_1_out_inferred__1/i___0_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_p_1_out_inferred__1/i___0_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_p_1_out_inferred__1/i___0_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_p_1_out_inferred__2/i___0_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_p_1_out_inferred__2/i___0_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_p_1_out_inferred__2/i___0_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_r4_red3_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_r4_red3_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_r4_red3_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_r4_red3_inferred__0/i__carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_r4_red3_inferred__0/i__carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_r4_red3_inferred__0/i__carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_r4_red3_inferred__1/i__carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_r4_red3_inferred__1/i__carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_r4_red3_inferred__1/i__carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_r4_red3_inferred__2/i__carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_r4_red3_inferred__2/i__carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_r4_red3_inferred__2/i__carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of g0_b0 : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \g0_b0__0\ : label is "soft_lutpair47";
  attribute SOFT_HLUTNM of \g0_b0__1\ : label is "soft_lutpair52";
  attribute SOFT_HLUTNM of \g0_b0__2\ : label is "soft_lutpair55";
  attribute SOFT_HLUTNM of \g0_b0__3\ : label is "soft_lutpair57";
  attribute SOFT_HLUTNM of \g0_b0__4\ : label is "soft_lutpair74";
  attribute SOFT_HLUTNM of g0_b1 : label is "soft_lutpair47";
  attribute SOFT_HLUTNM of \g0_b1__0\ : label is "soft_lutpair53";
  attribute SOFT_HLUTNM of \g0_b1__1\ : label is "soft_lutpair56";
  attribute SOFT_HLUTNM of \g0_b1__2\ : label is "soft_lutpair57";
  attribute SOFT_HLUTNM of \g0_b1__3\ : label is "soft_lutpair72";
  attribute SOFT_HLUTNM of \g0_b1__4\ : label is "soft_lutpair73";
  attribute SOFT_HLUTNM of g0_b2 : label is "soft_lutpair48";
  attribute SOFT_HLUTNM of \g0_b2__0\ : label is "soft_lutpair53";
  attribute SOFT_HLUTNM of \g0_b2__1\ : label is "soft_lutpair56";
  attribute SOFT_HLUTNM of \g0_b2__2\ : label is "soft_lutpair58";
  attribute SOFT_HLUTNM of \g0_b2__3\ : label is "soft_lutpair61";
  attribute SOFT_HLUTNM of \g0_b2__4\ : label is "soft_lutpair74";
  attribute SOFT_HLUTNM of g0_b3 : label is "soft_lutpair48";
  attribute SOFT_HLUTNM of \g0_b3__0\ : label is "soft_lutpair58";
  attribute SOFT_HLUTNM of \g0_b3__1\ : label is "soft_lutpair72";
  attribute SOFT_HLUTNM of \g0_b3__2\ : label is "soft_lutpair73";
  attribute SOFT_HLUTNM of g0_b4 : label is "soft_lutpair49";
  attribute SOFT_HLUTNM of \g0_b4__0\ : label is "soft_lutpair54";
  attribute SOFT_HLUTNM of \g0_b4__1\ : label is "soft_lutpair59";
  attribute SOFT_HLUTNM of \g0_b4__2\ : label is "soft_lutpair60";
  attribute SOFT_HLUTNM of g0_b5 : label is "soft_lutpair49";
  attribute SOFT_HLUTNM of \g0_b5__0\ : label is "soft_lutpair51";
  attribute SOFT_HLUTNM of \g0_b5__1\ : label is "soft_lutpair54";
  attribute SOFT_HLUTNM of \g0_b5__2\ : label is "soft_lutpair60";
  attribute SOFT_HLUTNM of g0_b6 : label is "soft_lutpair52";
  attribute SOFT_HLUTNM of \g0_b6__0\ : label is "soft_lutpair55";
  attribute SOFT_HLUTNM of \g0_b6__1\ : label is "soft_lutpair75";
  attribute SOFT_HLUTNM of \g0_b6__2\ : label is "soft_lutpair61";
  attribute SOFT_HLUTNM of \g0_b6__3\ : label is "soft_lutpair75";
  attribute SOFT_HLUTNM of g0_b7 : label is "soft_lutpair50";
  attribute SOFT_HLUTNM of \g0_b7__0\ : label is "soft_lutpair59";
  attribute SOFT_HLUTNM of g0_b8 : label is "soft_lutpair50";
  attribute SOFT_HLUTNM of g0_b9 : label is "soft_lutpair51";
  attribute SOFT_HLUTNM of \ow4_red[3]_INST_0_i_1\ : label is "soft_lutpair76";
  attribute SOFT_HLUTNM of \ow4_red[3]_INST_0_i_10\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \ow4_red[3]_INST_0_i_6\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \ow4_red[3]_INST_0_i_8\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \ow4_red[3]_INST_0_i_9\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of ow_hsync_INST_0_i_1 : label is "soft_lutpair71";
  attribute SOFT_HLUTNM of ow_vsync_INST_0 : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \p_0_out_inferred__4/r4_red[3]_i_204\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \p_0_out_inferred__4/r4_red[3]_i_206\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \p_0_out_inferred__4/r4_red[3]_i_210\ : label is "soft_lutpair44";
  attribute SOFT_HLUTNM of \p_0_out_inferred__4/r4_red[3]_i_211\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \p_0_out_inferred__4/r4_red[3]_i_222\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \p_0_out_inferred__4/r4_red[3]_i_223\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \p_0_out_inferred__4/r4_red[3]_i_269\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \p_0_out_inferred__4/r4_red[3]_i_270\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \p_0_out_inferred__4/r4_red[3]_i_271\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \p_0_out_inferred__4/r4_red[3]_i_272\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \p_0_out_inferred__4/r4_red[3]_i_273\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \p_0_out_inferred__4/r4_red[3]_i_274\ : label is "soft_lutpair46";
  attribute SOFT_HLUTNM of \p_0_out_inferred__4/r4_red[3]_i_275\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \p_0_out_inferred__4/r4_red[3]_i_276\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \r11_active_x[1]_i_1\ : label is "soft_lutpair83";
  attribute SOFT_HLUTNM of \r11_active_x[2]_i_1\ : label is "soft_lutpair78";
  attribute SOFT_HLUTNM of \r11_active_x[3]_i_1\ : label is "soft_lutpair63";
  attribute SOFT_HLUTNM of \r11_active_x[4]_i_1\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \r11_active_x[6]_i_1\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of \r11_active_x[8]_i_2\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of \r11_active_x[8]_i_3\ : label is "soft_lutpair70";
  attribute SOFT_HLUTNM of \r11_active_x[9]_i_1\ : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of \r11_active_y[1]_i_1\ : label is "soft_lutpair84";
  attribute SOFT_HLUTNM of \r11_active_y[2]_i_1\ : label is "soft_lutpair66";
  attribute SOFT_HLUTNM of \r11_active_y[3]_i_1\ : label is "soft_lutpair66";
  attribute SOFT_HLUTNM of \r11_active_y[4]_i_1\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \r11_active_y[7]_i_2\ : label is "soft_lutpair65";
  attribute SOFT_HLUTNM of \r11_active_y[7]_i_3\ : label is "soft_lutpair84";
  attribute SOFT_HLUTNM of \r11_active_y[8]_i_1\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \r11_active_y[9]_i_1\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \r11_h_count[1]_i_1\ : label is "soft_lutpair77";
  attribute SOFT_HLUTNM of \r11_h_count[2]_i_1\ : label is "soft_lutpair77";
  attribute SOFT_HLUTNM of \r11_h_count[3]_i_1\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \r11_h_count[4]_i_1\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \r11_h_count[6]_i_1\ : label is "soft_lutpair71";
  attribute SOFT_HLUTNM of \r11_h_count[8]_i_1\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \r11_h_count[9]_i_1\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \r11_v_count[1]_i_1\ : label is "soft_lutpair82";
  attribute SOFT_HLUTNM of \r11_v_count[2]_i_1\ : label is "soft_lutpair82";
  attribute SOFT_HLUTNM of \r11_v_count[3]_i_1\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \r11_v_count[4]_i_1\ : label is "soft_lutpair42";
  attribute SOFT_HLUTNM of \r11_v_count[6]_i_1\ : label is "soft_lutpair76";
  attribute SOFT_HLUTNM of \r11_v_count[7]_i_1\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \r11_v_count[8]_i_1\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \r11_v_count[9]_i_4\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \r11_v_count[9]_i_5\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \r11_v_count[9]_i_6\ : label is "soft_lutpair42";
  attribute COMPARATOR_THRESHOLD : integer;
  attribute COMPARATOR_THRESHOLD of r4_red3_carry : label is 11;
  attribute COMPARATOR_THRESHOLD of \r4_red3_carry__0\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \r4_red3_inferred__0/i__carry\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \r4_red3_inferred__0/i__carry__0\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \r4_red3_inferred__1/i__carry\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \r4_red3_inferred__1/i__carry__0\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \r4_red3_inferred__2/i__carry\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \r4_red3_inferred__2/i__carry__0\ : label is 11;
  attribute SOFT_HLUTNM of \r4_red[2]_i_10\ : label is "soft_lutpair62";
  attribute SOFT_HLUTNM of \r4_red[2]_i_11\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \r4_red[2]_i_12\ : label is "soft_lutpair40";
  attribute SOFT_HLUTNM of \r4_red[2]_i_16\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \r4_red[2]_i_17\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \r4_red[2]_i_19\ : label is "soft_lutpair41";
  attribute SOFT_HLUTNM of \r4_red[2]_i_4\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \r4_red[3]_i_108\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \r4_red[3]_i_110\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \r4_red[3]_i_113\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \r4_red[3]_i_114\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \r4_red[3]_i_115\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \r4_red[3]_i_119\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \r4_red[3]_i_120\ : label is "soft_lutpair46";
  attribute SOFT_HLUTNM of \r4_red[3]_i_122\ : label is "soft_lutpair65";
  attribute SOFT_HLUTNM of \r4_red[3]_i_133\ : label is "soft_lutpair69";
  attribute SOFT_HLUTNM of \r4_red[3]_i_135\ : label is "soft_lutpair87";
  attribute SOFT_HLUTNM of \r4_red[3]_i_161\ : label is "soft_lutpair88";
  attribute SOFT_HLUTNM of \r4_red[3]_i_176\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \r4_red[3]_i_177\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \r4_red[3]_i_179\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \r4_red[3]_i_180\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \r4_red[3]_i_181\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \r4_red[3]_i_182\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \r4_red[3]_i_183\ : label is "soft_lutpair85";
  attribute SOFT_HLUTNM of \r4_red[3]_i_184\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \r4_red[3]_i_185\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \r4_red[3]_i_186\ : label is "soft_lutpair45";
  attribute SOFT_HLUTNM of \r4_red[3]_i_187\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \r4_red[3]_i_188\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \r4_red[3]_i_190\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \r4_red[3]_i_191\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \r4_red[3]_i_192\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \r4_red[3]_i_193\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \r4_red[3]_i_194\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \r4_red[3]_i_195\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \r4_red[3]_i_196\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \r4_red[3]_i_197\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \r4_red[3]_i_198\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \r4_red[3]_i_199\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \r4_red[3]_i_200\ : label is "soft_lutpair45";
  attribute SOFT_HLUTNM of \r4_red[3]_i_201\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \r4_red[3]_i_202\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \r4_red[3]_i_203\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \r4_red[3]_i_205\ : label is "soft_lutpair87";
  attribute SOFT_HLUTNM of \r4_red[3]_i_207\ : label is "soft_lutpair70";
  attribute SOFT_HLUTNM of \r4_red[3]_i_208\ : label is "soft_lutpair79";
  attribute SOFT_HLUTNM of \r4_red[3]_i_216\ : label is "soft_lutpair43";
  attribute SOFT_HLUTNM of \r4_red[3]_i_217\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \r4_red[3]_i_22\ : label is "soft_lutpair88";
  attribute SOFT_HLUTNM of \r4_red[3]_i_220\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \r4_red[3]_i_228\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \r4_red[3]_i_23\ : label is "soft_lutpair81";
  attribute SOFT_HLUTNM of \r4_red[3]_i_230\ : label is "soft_lutpair69";
  attribute SOFT_HLUTNM of \r4_red[3]_i_231\ : label is "soft_lutpair44";
  attribute SOFT_HLUTNM of \r4_red[3]_i_235\ : label is "soft_lutpair86";
  attribute SOFT_HLUTNM of \r4_red[3]_i_236\ : label is "soft_lutpair86";
  attribute SOFT_HLUTNM of \r4_red[3]_i_238\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \r4_red[3]_i_253\ : label is "soft_lutpair68";
  attribute SOFT_HLUTNM of \r4_red[3]_i_259\ : label is "soft_lutpair41";
  attribute SOFT_HLUTNM of \r4_red[3]_i_262\ : label is "soft_lutpair67";
  attribute SOFT_HLUTNM of \r4_red[3]_i_28\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \r4_red[3]_i_29\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \r4_red[3]_i_32\ : label is "soft_lutpair62";
  attribute SOFT_HLUTNM of \r4_red[3]_i_38\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \r4_red[3]_i_40\ : label is "soft_lutpair80";
  attribute SOFT_HLUTNM of \r4_red[3]_i_42\ : label is "soft_lutpair64";
  attribute SOFT_HLUTNM of \r4_red[3]_i_44\ : label is "soft_lutpair39";
  attribute SOFT_HLUTNM of \r4_red[3]_i_45\ : label is "soft_lutpair39";
  attribute SOFT_HLUTNM of \r4_red[3]_i_46\ : label is "soft_lutpair85";
  attribute SOFT_HLUTNM of \r4_red[3]_i_47\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \r4_red[3]_i_48\ : label is "soft_lutpair68";
  attribute SOFT_HLUTNM of \r4_red[3]_i_49\ : label is "soft_lutpair78";
  attribute SOFT_HLUTNM of \r4_red[3]_i_54\ : label is "soft_lutpair40";
  attribute SOFT_HLUTNM of \r4_red[3]_i_57\ : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of \r4_red[3]_i_65\ : label is "soft_lutpair64";
  attribute SOFT_HLUTNM of \r4_red[3]_i_66\ : label is "soft_lutpair79";
  attribute SOFT_HLUTNM of \r4_red[3]_i_69\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \r4_red[3]_i_72\ : label is "soft_lutpair43";
  attribute SOFT_HLUTNM of \r4_red[3]_i_75\ : label is "soft_lutpair81";
  attribute SOFT_HLUTNM of \r4_red[3]_i_83\ : label is "soft_lutpair67";
  attribute SOFT_HLUTNM of \r4_red[3]_i_88\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \r4_red[3]_i_89\ : label is "soft_lutpair80";
  attribute SOFT_HLUTNM of \r4_red[3]_i_90\ : label is "soft_lutpair63";
  attribute SOFT_HLUTNM of \r4_red[3]_i_91\ : label is "soft_lutpair83";
begin
\State_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => iw_pix_clk,
      CE => '1',
      D => iw2_State(0),
      Q => State(0),
      R => '0'
    );
\State_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => iw_pix_clk,
      CE => '1',
      D => iw2_State(1),
      Q => State(1),
      R => '0'
    );
g0_b0: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6003"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => r4_red2(0)
    );
\g0_b0__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"607C"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b0__0_n_0\
    );
\g0_b0__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1F03"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b0__1_n_0\
    );
\g0_b0__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1F0C"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b0__2_n_0\
    );
\g0_b0__3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"001F"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b0__3_n_0\
    );
\g0_b0__4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"60C3"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b0__4_n_0\
    );
g0_b0_i_1: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A9"
    )
        port map (
      I0 => r11_active_y_reg(2),
      I1 => r11_active_y_reg(1),
      I2 => r11_active_y_reg(0),
      O => g0_b0_i_1_n_0
    );
g0_b0_i_2: unisim.vcomponents.LUT4
    generic map(
      INIT => X"01FE"
    )
        port map (
      I0 => r11_active_y_reg(2),
      I1 => r11_active_y_reg(1),
      I2 => r11_active_y_reg(0),
      I3 => r11_active_y_reg(3),
      O => g0_b0_i_2_n_0
    );
g0_b0_i_3: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F0E00F1F"
    )
        port map (
      I0 => r11_active_y_reg(0),
      I1 => r11_active_y_reg(1),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(4),
      O => g0_b0_i_3_n_0
    );
g0_b0_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555555666666666"
    )
        port map (
      I0 => r11_active_y_reg(5),
      I1 => r11_active_y_reg(4),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(0),
      I5 => r11_active_y_reg(3),
      O => g0_b0_i_4_n_0
    );
g0_b1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"60FE"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => g0_b1_n_0
    );
\g0_b1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"3F83"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b1__0_n_0\
    );
\g0_b1__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"3F8E"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b1__1_n_0\
    );
\g0_b1__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"007F"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b1__2_n_0\
    );
\g0_b1__3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7007"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => r4_red2(1)
    );
\g0_b1__4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"71E7"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b1__4_n_0\
    );
g0_b2: unisim.vcomponents.LUT4
    generic map(
      INIT => X"61C7"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => g0_b2_n_0
    );
\g0_b2__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"71C3"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b2__0_n_0\
    );
\g0_b2__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"71C7"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b2__1_n_0\
    );
\g0_b2__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"01F3"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b2__2_n_0\
    );
\g0_b2__3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"3FFE"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => r4_red2(2)
    );
\g0_b2__4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"70C7"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b2__4_n_0\
    );
g0_b3: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6383"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => g0_b3_n_0
    );
\g0_b3__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"07C3"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b3__0_n_0\
    );
\g0_b3__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1FFC"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => r4_red2(3)
    );
\g0_b3__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1F3C"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b3__2_n_0\
    );
g0_b4: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6703"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => g0_b4_n_0
    );
\g0_b4__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"70C3"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b4__0_n_0\
    );
\g0_b4__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F03"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b4__1_n_0\
    );
\g0_b4__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"70E7"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b4__2_n_0\
    );
g0_b5: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6E03"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => g0_b5_n_0
    );
\g0_b5__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"380E"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b5__0_n_0\
    );
\g0_b5__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"38FF"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b5__1_n_0\
    );
\g0_b5__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"387E"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b5__2_n_0\
    );
g0_b6: unisim.vcomponents.LUT4
    generic map(
      INIT => X"180C"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => g0_b6_n_0
    );
\g0_b6__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"18FF"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b6__0_n_0\
    );
\g0_b6__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => g0_b0_i_2_n_0,
      I1 => g0_b0_i_3_n_0,
      I2 => g0_b0_i_4_n_0,
      O => \g0_b6__1_n_0\
    );
\g0_b6__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"183C"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b6__2_n_0\
    );
\g0_b6__3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7C03"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b6__3_n_0\
    );
g0_b7: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7807"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => g0_b7_n_0
    );
\g0_b7__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0007"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => \g0_b7__0_n_0\
    );
g0_b8: unisim.vcomponents.LUT4
    generic map(
      INIT => X"700E"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => g0_b8_n_0
    );
g0_b9: unisim.vcomponents.LUT4
    generic map(
      INIT => X"600C"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_4_n_0,
      O => g0_b9_n_0
    );
\i___0_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => iw11_y_pos(6),
      O => \i___0_carry__0_i_1_n_0\
    );
\i___0_carry__0_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_x_reg(6),
      I1 => iw11_x_pos(6),
      O => \i___0_carry__0_i_1__0_n_0\
    );
\i___0_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_y_reg(5),
      I1 => iw11_y_pos(5),
      O => \i___0_carry__0_i_2_n_0\
    );
\i___0_carry__0_i_2__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => iw11_x_pos(5),
      O => \i___0_carry__0_i_2__0_n_0\
    );
\i___0_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => iw11_y_pos(4),
      O => \i___0_carry__0_i_3_n_0\
    );
\i___0_carry__0_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => iw11_x_pos(4),
      O => \i___0_carry__0_i_3__0_n_0\
    );
\i___0_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => iw11_y_pos(4),
      O => \i___0_carry__0_i_4_n_0\
    );
\i___0_carry__0_i_4__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => iw11_x_pos(4),
      I1 => r11_active_x_reg(4),
      O => \i___0_carry__0_i_4__0_n_0\
    );
\i___0_carry__0_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_y_pos(6),
      I1 => r11_active_y_reg(6),
      I2 => iw11_y_pos(7),
      I3 => r11_active_y_reg(7),
      O => \i___0_carry__0_i_5_n_0\
    );
\i___0_carry__0_i_5__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_x_pos(6),
      I1 => r11_active_x_reg(6),
      I2 => r11_active_x_reg(7),
      I3 => iw11_x_pos(7),
      O => \i___0_carry__0_i_5__0_n_0\
    );
\i___0_carry__0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_y_pos(5),
      I1 => r11_active_y_reg(5),
      I2 => iw11_y_pos(6),
      I3 => r11_active_y_reg(6),
      O => \i___0_carry__0_i_6_n_0\
    );
\i___0_carry__0_i_6__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_x_pos(5),
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(6),
      I3 => iw11_x_pos(6),
      O => \i___0_carry__0_i_6__0_n_0\
    );
\i___0_carry__0_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_y_pos(4),
      I1 => r11_active_y_reg(4),
      I2 => iw11_y_pos(5),
      I3 => r11_active_y_reg(5),
      O => \i___0_carry__0_i_7_n_0\
    );
\i___0_carry__0_i_7__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_x_pos(4),
      I1 => r11_active_x_reg(4),
      I2 => r11_active_x_reg(5),
      I3 => iw11_x_pos(5),
      O => \i___0_carry__0_i_7__0_n_0\
    );
\i___0_carry__0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6966"
    )
        port map (
      I0 => iw11_y_pos(4),
      I1 => r11_active_y_reg(4),
      I2 => iw11_y_pos(3),
      I3 => r11_active_y_reg(3),
      O => \i___0_carry__0_i_8_n_0\
    );
\i___0_carry__0_i_8__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6966"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => iw11_x_pos(4),
      I2 => iw11_x_pos(3),
      I3 => r11_active_x_reg(3),
      O => \i___0_carry__0_i_8__0_n_0\
    );
\i___0_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_y_reg(9),
      I1 => iw11_y_pos(9),
      O => \i___0_carry__1_i_1_n_0\
    );
\i___0_carry__1_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_x_reg(9),
      I1 => iw11_x_pos(9),
      O => \i___0_carry__1_i_1__0_n_0\
    );
\i___0_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => iw11_y_pos(9),
      I1 => r11_active_y_reg(9),
      O => \i___0_carry__1_i_2_n_0\
    );
\i___0_carry__1_i_2__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_x_reg(8),
      I1 => iw11_x_pos(8),
      O => \i___0_carry__1_i_2__0_n_0\
    );
\i___0_carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => iw11_y_pos(8),
      I1 => r11_active_y_reg(8),
      O => \i___0_carry__1_i_3_n_0\
    );
\i___0_carry__1_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_x_reg(7),
      I1 => iw11_x_pos(7),
      O => \i___0_carry__1_i_3__0_n_0\
    );
\i___0_carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_y_reg(10),
      I1 => iw11_y_pos(10),
      O => \i___0_carry__1_i_4_n_0\
    );
\i___0_carry__1_i_4__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_x_reg(10),
      I1 => iw11_x_pos(10),
      O => \i___0_carry__1_i_4__0_n_0\
    );
\i___0_carry__1_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_y_pos(9),
      I1 => r11_active_y_reg(9),
      I2 => iw11_y_pos(10),
      I3 => r11_active_y_reg(10),
      O => \i___0_carry__1_i_5_n_0\
    );
\i___0_carry__1_i_5__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_x_pos(9),
      I1 => r11_active_x_reg(9),
      I2 => iw11_x_pos(10),
      I3 => r11_active_x_reg(10),
      O => \i___0_carry__1_i_5__0_n_0\
    );
\i___0_carry__1_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_y_pos(8),
      I1 => r11_active_y_reg(8),
      I2 => r11_active_y_reg(9),
      I3 => iw11_y_pos(9),
      O => \i___0_carry__1_i_6_n_0\
    );
\i___0_carry__1_i_6__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_x_pos(8),
      I1 => r11_active_x_reg(8),
      I2 => r11_active_x_reg(9),
      I3 => iw11_x_pos(9),
      O => \i___0_carry__1_i_6__0_n_0\
    );
\i___0_carry__1_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_y_pos(7),
      I1 => r11_active_y_reg(7),
      I2 => r11_active_y_reg(8),
      I3 => iw11_y_pos(8),
      O => \i___0_carry__1_i_7_n_0\
    );
\i___0_carry__1_i_7__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_x_pos(7),
      I1 => r11_active_x_reg(7),
      I2 => r11_active_x_reg(8),
      I3 => iw11_x_pos(8),
      O => \i___0_carry__1_i_7__0_n_0\
    );
\i___0_carry_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_y_reg(2),
      I1 => iw11_y_pos(2),
      O => \i___0_carry_i_1_n_0\
    );
\i___0_carry_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_x_reg(2),
      I1 => iw11_x_pos(2),
      O => \i___0_carry_i_1__0_n_0\
    );
\i___0_carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => r11_active_y_reg(2),
      I1 => iw11_y_pos(2),
      O => \i___0_carry_i_2_n_0\
    );
\i___0_carry_i_2__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => r11_active_x_reg(2),
      I1 => iw11_x_pos(2),
      O => \i___0_carry_i_2__0_n_0\
    );
\i___0_carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_y_reg(0),
      I1 => iw11_y_pos(0),
      O => \i___0_carry_i_3_n_0\
    );
\i___0_carry_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_x_reg(0),
      I1 => iw11_x_pos(0),
      O => \i___0_carry_i_3__0_n_0\
    );
\i___0_carry_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => iw11_y_pos(0),
      I1 => r11_active_y_reg(0),
      O => \i___0_carry_i_4_n_0\
    );
\i___0_carry_i_4__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => iw11_x_pos(0),
      I1 => r11_active_x_reg(0),
      O => \i___0_carry_i_4__0_n_0\
    );
\i___0_carry_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2DD2"
    )
        port map (
      I0 => iw11_y_pos(2),
      I1 => r11_active_y_reg(2),
      I2 => iw11_y_pos(3),
      I3 => r11_active_y_reg(3),
      O => \i___0_carry_i_5_n_0\
    );
\i___0_carry_i_5__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2DD2"
    )
        port map (
      I0 => iw11_x_pos(2),
      I1 => r11_active_x_reg(2),
      I2 => iw11_x_pos(3),
      I3 => r11_active_x_reg(3),
      O => \i___0_carry_i_5__0_n_0\
    );
\i___0_carry_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6966"
    )
        port map (
      I0 => iw11_y_pos(2),
      I1 => r11_active_y_reg(2),
      I2 => iw11_y_pos(1),
      I3 => r11_active_y_reg(1),
      O => \i___0_carry_i_6_n_0\
    );
\i___0_carry_i_6__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6966"
    )
        port map (
      I0 => iw11_x_pos(2),
      I1 => r11_active_x_reg(2),
      I2 => iw11_x_pos(1),
      I3 => r11_active_x_reg(1),
      O => \i___0_carry_i_6__0_n_0\
    );
\i___0_carry_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2DD2"
    )
        port map (
      I0 => iw11_y_pos(0),
      I1 => r11_active_y_reg(0),
      I2 => iw11_y_pos(1),
      I3 => r11_active_y_reg(1),
      O => \i___0_carry_i_7_n_0\
    );
\i___0_carry_i_7__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2DD2"
    )
        port map (
      I0 => iw11_x_pos(0),
      I1 => r11_active_x_reg(0),
      I2 => iw11_x_pos(1),
      I3 => r11_active_x_reg(1),
      O => \i___0_carry_i_7__0_n_0\
    );
\i___0_carry_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => r11_active_y_reg(0),
      I1 => iw11_y_pos(0),
      O => \i___0_carry_i_8_n_0\
    );
\i___0_carry_i_8__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => r11_active_x_reg(0),
      I1 => iw11_x_pos(0),
      O => \i___0_carry_i_8__0_n_0\
    );
\i__carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => r11_active_y_reg(7),
      I1 => iw11_block_left_pos(7),
      O => \i__carry__0_i_1_n_0\
    );
\i__carry__0_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => r11_active_y_reg(10),
      I1 => iw11_block_left_pos(10),
      O => \i__carry__0_i_1__0_n_0\
    );
\i__carry__0_i_1__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => r11_active_y_reg(10),
      I1 => iw11_y_pos(10),
      O => \i__carry__0_i_1__1_n_0\
    );
\i__carry__0_i_1__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => r11_active_x_reg(10),
      I1 => iw11_x_pos(10),
      O => \i__carry__0_i_1__2_n_0\
    );
\i__carry__0_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_y_pos(9),
      I1 => iw11_y_pos(8),
      I2 => r11_active_y_reg(9),
      I3 => r11_active_y_reg(8),
      O => \i__carry__0_i_2_n_0\
    );
\i__carry__0_i_2__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_block_left_pos(9),
      I1 => iw11_block_left_pos(8),
      I2 => r11_active_y_reg(9),
      I3 => r11_active_y_reg(8),
      O => \i__carry__0_i_2__0_n_0\
    );
\i__carry__0_i_2__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => r11_active_y_reg(5),
      I1 => iw11_block_left_pos(5),
      O => \i__carry__0_i_2__1_n_0\
    );
\i__carry__0_i_2__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"22B2"
    )
        port map (
      I0 => r11_active_x_reg(9),
      I1 => iw11_x_pos(9),
      I2 => r11_active_x_reg(8),
      I3 => iw11_x_pos(8),
      O => \i__carry__0_i_2__2_n_0\
    );
\i__carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => iw11_block_left_pos(4),
      O => \i__carry__0_i_3_n_0\
    );
\i__carry__0_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => iw11_block_left_pos(10),
      I1 => r11_active_y_reg(10),
      O => \i__carry__0_i_3__0_n_0\
    );
\i__carry__0_i_3__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => iw11_y_pos(10),
      I1 => r11_active_y_reg(10),
      O => \i__carry__0_i_3__1_n_0\
    );
\i__carry__0_i_3__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => iw11_x_pos(10),
      I1 => r11_active_x_reg(10),
      O => \i__carry__0_i_3__2_n_0\
    );
\i__carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_y_reg(3),
      I1 => iw11_block_left_pos(3),
      O => \i__carry__0_i_4_n_0\
    );
\i__carry__0_i_4__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => r11_active_y_reg(9),
      I1 => iw11_block_left_pos(9),
      I2 => r11_active_y_reg(8),
      I3 => iw11_block_left_pos(8),
      O => \i__carry__0_i_4__0_n_0\
    );
\i__carry__0_i_4__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => r11_active_y_reg(9),
      I1 => iw11_y_pos(9),
      I2 => r11_active_y_reg(8),
      I3 => iw11_y_pos(8),
      O => \i__carry__0_i_4__1_n_0\
    );
\i__carry__0_i_4__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => iw11_x_pos(8),
      I1 => r11_active_x_reg(8),
      I2 => iw11_x_pos(9),
      I3 => r11_active_x_reg(9),
      O => \i__carry__0_i_4__2_n_0\
    );
\i__carry__0_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6966"
    )
        port map (
      I0 => iw11_block_left_pos(7),
      I1 => r11_active_y_reg(7),
      I2 => iw11_block_left_pos(6),
      I3 => r11_active_y_reg(6),
      O => \i__carry__0_i_5_n_0\
    );
\i__carry__0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => iw11_block_left_pos(5),
      I1 => r11_active_y_reg(5),
      I2 => iw11_block_left_pos(6),
      I3 => r11_active_y_reg(6),
      O => \i__carry__0_i_6_n_0\
    );
\i__carry__0_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2DD2"
    )
        port map (
      I0 => iw11_block_left_pos(4),
      I1 => r11_active_y_reg(4),
      I2 => iw11_block_left_pos(5),
      I3 => r11_active_y_reg(5),
      O => \i__carry__0_i_7_n_0\
    );
\i__carry__0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_block_left_pos(3),
      I1 => r11_active_y_reg(3),
      I2 => iw11_block_left_pos(4),
      I3 => r11_active_y_reg(4),
      O => \i__carry__0_i_8_n_0\
    );
\i__carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_y_reg(9),
      I1 => iw11_block_left_pos(9),
      O => \i__carry__1_i_1_n_0\
    );
\i__carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => iw11_block_left_pos(9),
      I1 => r11_active_y_reg(9),
      O => \i__carry__1_i_2_n_0\
    );
\i__carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => iw11_block_left_pos(8),
      I1 => r11_active_y_reg(8),
      O => \i__carry__1_i_3_n_0\
    );
\i__carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_y_reg(10),
      I1 => iw11_block_left_pos(10),
      O => \i__carry__1_i_4_n_0\
    );
\i__carry__1_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_block_left_pos(9),
      I1 => r11_active_y_reg(9),
      I2 => iw11_block_left_pos(10),
      I3 => r11_active_y_reg(10),
      O => \i__carry__1_i_5_n_0\
    );
\i__carry__1_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_block_left_pos(8),
      I1 => r11_active_y_reg(8),
      I2 => r11_active_y_reg(9),
      I3 => iw11_block_left_pos(9),
      O => \i__carry__1_i_6_n_0\
    );
\i__carry__1_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_block_left_pos(7),
      I1 => r11_active_y_reg(7),
      I2 => r11_active_y_reg(8),
      I3 => iw11_block_left_pos(8),
      O => \i__carry__1_i_7_n_0\
    );
\i__carry_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_y_pos(7),
      I1 => iw11_y_pos(6),
      I2 => r11_active_y_reg(7),
      I3 => r11_active_y_reg(6),
      O => \i__carry_i_1_n_0\
    );
\i__carry_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_block_left_pos(7),
      I1 => iw11_block_left_pos(6),
      I2 => r11_active_y_reg(7),
      I3 => r11_active_y_reg(6),
      O => \i__carry_i_1__0_n_0\
    );
\i__carry_i_1__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => iw11_block_left_pos(3),
      I1 => r11_active_y_reg(3),
      O => \i__carry_i_1__1_n_0\
    );
\i__carry_i_1__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"22B2"
    )
        port map (
      I0 => r11_active_x_reg(7),
      I1 => iw11_x_pos(7),
      I2 => r11_active_x_reg(6),
      I3 => iw11_x_pos(6),
      O => \i__carry_i_1__2_n_0\
    );
\i__carry_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_y_pos(5),
      I1 => iw11_y_pos(4),
      I2 => r11_active_y_reg(5),
      I3 => r11_active_y_reg(4),
      O => \i__carry_i_2_n_0\
    );
\i__carry_i_2__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_block_left_pos(5),
      I1 => iw11_block_left_pos(4),
      I2 => r11_active_y_reg(5),
      I3 => r11_active_y_reg(4),
      O => \i__carry_i_2__0_n_0\
    );
\i__carry_i_2__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"22B2"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => iw11_x_pos(5),
      I2 => r11_active_x_reg(4),
      I3 => iw11_x_pos(4),
      O => \i__carry_i_2__1_n_0\
    );
\i__carry_i_2__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => r11_active_y_reg(3),
      I1 => iw11_block_left_pos(3),
      I2 => iw11_block_left_pos(2),
      O => \i__carry_i_2__2_n_0\
    );
\i__carry_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_x_pos(3),
      I1 => iw11_x_pos(2),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(2),
      O => \i__carry_i_3_n_0\
    );
\i__carry_i_3__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_y_pos(3),
      I1 => iw11_y_pos(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(2),
      O => \i__carry_i_3__0_n_0\
    );
\i__carry_i_3__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_block_left_pos(3),
      I1 => iw11_block_left_pos(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(2),
      O => \i__carry_i_3__1_n_0\
    );
\i__carry_i_3__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => iw11_block_left_pos(2),
      I1 => r11_active_y_reg(2),
      O => \i__carry_i_3__2_n_0\
    );
\i__carry_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_x_pos(1),
      I1 => iw11_x_pos(0),
      I2 => r11_active_x_reg(1),
      I3 => r11_active_x_reg(0),
      O => \i__carry_i_4_n_0\
    );
\i__carry_i_4__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_y_pos(1),
      I1 => iw11_y_pos(0),
      I2 => r11_active_y_reg(1),
      I3 => r11_active_y_reg(0),
      O => \i__carry_i_4__0_n_0\
    );
\i__carry_i_4__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_block_left_pos(1),
      I1 => iw11_block_left_pos(0),
      I2 => r11_active_y_reg(1),
      I3 => r11_active_y_reg(0),
      O => \i__carry_i_4__1_n_0\
    );
\i__carry_i_4__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => r11_active_y_reg(1),
      I1 => iw11_block_left_pos(1),
      O => \i__carry_i_4__2_n_0\
    );
\i__carry_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8241"
    )
        port map (
      I0 => iw11_y_pos(7),
      I1 => iw11_y_pos(6),
      I2 => r11_active_y_reg(6),
      I3 => r11_active_y_reg(7),
      O => \i__carry_i_5_n_0\
    );
\i__carry_i_5__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8241"
    )
        port map (
      I0 => iw11_block_left_pos(7),
      I1 => iw11_block_left_pos(6),
      I2 => r11_active_y_reg(6),
      I3 => r11_active_y_reg(7),
      O => \i__carry_i_5__0_n_0\
    );
\i__carry_i_5__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => iw11_x_pos(6),
      I1 => r11_active_x_reg(6),
      I2 => iw11_x_pos(7),
      I3 => r11_active_x_reg(7),
      O => \i__carry_i_5__1_n_0\
    );
\i__carry_i_5__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => r11_active_y_reg(0),
      I1 => iw11_block_left_pos(0),
      O => \i__carry_i_5__2_n_0\
    );
\i__carry_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8241"
    )
        port map (
      I0 => iw11_y_pos(5),
      I1 => iw11_y_pos(4),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(5),
      O => \i__carry_i_6_n_0\
    );
\i__carry_i_6__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8241"
    )
        port map (
      I0 => iw11_block_left_pos(5),
      I1 => iw11_block_left_pos(4),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(5),
      O => \i__carry_i_6__0_n_0\
    );
\i__carry_i_6__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => iw11_x_pos(4),
      I1 => r11_active_x_reg(4),
      I2 => iw11_x_pos(5),
      I3 => r11_active_x_reg(5),
      O => \i__carry_i_6__1_n_0\
    );
\i__carry_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => r11_active_y_reg(3),
      I1 => iw11_block_left_pos(3),
      I2 => r11_active_y_reg(2),
      I3 => iw11_block_left_pos(2),
      O => \i__carry_i_7_n_0\
    );
\i__carry_i_7__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8241"
    )
        port map (
      I0 => iw11_x_pos(3),
      I1 => iw11_x_pos(2),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(3),
      O => \i__carry_i_7__0_n_0\
    );
\i__carry_i_7__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8241"
    )
        port map (
      I0 => iw11_y_pos(3),
      I1 => iw11_y_pos(2),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(3),
      O => \i__carry_i_7__1_n_0\
    );
\i__carry_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8241"
    )
        port map (
      I0 => iw11_x_pos(1),
      I1 => iw11_x_pos(0),
      I2 => r11_active_x_reg(0),
      I3 => r11_active_x_reg(1),
      O => \i__carry_i_8_n_0\
    );
\i__carry_i_8__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8241"
    )
        port map (
      I0 => iw11_y_pos(1),
      I1 => iw11_y_pos(0),
      I2 => r11_active_y_reg(0),
      I3 => r11_active_y_reg(1),
      O => \i__carry_i_8__0_n_0\
    );
\i__carry_i_8__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8241"
    )
        port map (
      I0 => iw11_block_left_pos(1),
      I1 => iw11_block_left_pos(0),
      I2 => r11_active_y_reg(0),
      I3 => r11_active_y_reg(1),
      O => \i__carry_i_8__1_n_0\
    );
\ow4_blue[0]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => w_vactive040_in,
      I1 => \ow4_red[3]_INST_0_i_2_n_0\,
      I2 => w_hactive041_in,
      I3 => \ow4_red[3]_INST_0_i_4_n_0\,
      I4 => \r4_blue_reg_n_0_[0]\,
      O => ow4_blue(0)
    );
\ow4_blue[1]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => w_vactive040_in,
      I1 => \ow4_red[3]_INST_0_i_2_n_0\,
      I2 => w_hactive041_in,
      I3 => \ow4_red[3]_INST_0_i_4_n_0\,
      I4 => \r4_blue_reg_n_0_[1]\,
      O => ow4_blue(1)
    );
\ow4_blue[2]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => w_vactive040_in,
      I1 => \ow4_red[3]_INST_0_i_2_n_0\,
      I2 => w_hactive041_in,
      I3 => \ow4_red[3]_INST_0_i_4_n_0\,
      I4 => \r4_blue_reg_n_0_[2]\,
      O => ow4_blue(2)
    );
\ow4_blue[3]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => w_vactive040_in,
      I1 => \ow4_red[3]_INST_0_i_2_n_0\,
      I2 => w_hactive041_in,
      I3 => \ow4_red[3]_INST_0_i_4_n_0\,
      I4 => \r4_blue_reg_n_0_[3]\,
      O => ow4_blue(3)
    );
\ow4_green[0]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => w_vactive040_in,
      I1 => \ow4_red[3]_INST_0_i_2_n_0\,
      I2 => w_hactive041_in,
      I3 => \ow4_red[3]_INST_0_i_4_n_0\,
      I4 => \r4_green_reg_n_0_[0]\,
      O => ow4_green(0)
    );
\ow4_green[1]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => w_vactive040_in,
      I1 => \ow4_red[3]_INST_0_i_2_n_0\,
      I2 => w_hactive041_in,
      I3 => \ow4_red[3]_INST_0_i_4_n_0\,
      I4 => \r4_green_reg_n_0_[1]\,
      O => ow4_green(1)
    );
\ow4_green[2]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => w_vactive040_in,
      I1 => \ow4_red[3]_INST_0_i_2_n_0\,
      I2 => w_hactive041_in,
      I3 => \ow4_red[3]_INST_0_i_4_n_0\,
      I4 => \r4_green_reg_n_0_[2]\,
      O => ow4_green(2)
    );
\ow4_green[3]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => w_vactive040_in,
      I1 => \ow4_red[3]_INST_0_i_2_n_0\,
      I2 => w_hactive041_in,
      I3 => \ow4_red[3]_INST_0_i_4_n_0\,
      I4 => \r4_green_reg_n_0_[3]\,
      O => ow4_green(3)
    );
\ow4_red[0]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => w_vactive040_in,
      I1 => \ow4_red[3]_INST_0_i_2_n_0\,
      I2 => w_hactive041_in,
      I3 => \ow4_red[3]_INST_0_i_4_n_0\,
      I4 => \r4_red_reg_n_0_[0]\,
      O => ow4_red(0)
    );
\ow4_red[1]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => w_vactive040_in,
      I1 => \ow4_red[3]_INST_0_i_2_n_0\,
      I2 => w_hactive041_in,
      I3 => \ow4_red[3]_INST_0_i_4_n_0\,
      I4 => \r4_red_reg_n_0_[1]\,
      O => ow4_red(1)
    );
\ow4_red[2]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => w_vactive040_in,
      I1 => \ow4_red[3]_INST_0_i_2_n_0\,
      I2 => w_hactive041_in,
      I3 => \ow4_red[3]_INST_0_i_4_n_0\,
      I4 => \r4_red_reg_n_0_[2]\,
      O => ow4_red(2)
    );
\ow4_red[3]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => w_vactive040_in,
      I1 => \ow4_red[3]_INST_0_i_2_n_0\,
      I2 => w_hactive041_in,
      I3 => \ow4_red[3]_INST_0_i_4_n_0\,
      I4 => \r4_red_reg_n_0_[3]\,
      O => ow4_red(3)
    );
\ow4_red[3]_INST_0_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \ow4_red[3]_INST_0_i_5_n_0\,
      I1 => \r11_v_count_reg_n_0_[5]\,
      I2 => \r11_v_count_reg_n_0_[9]\,
      O => w_vactive040_in
    );
\ow4_red[3]_INST_0_i_10\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7777777F"
    )
        port map (
      I0 => r11_h_count_reg(5),
      I1 => r11_h_count_reg(4),
      I2 => r11_h_count_reg(0),
      I3 => r11_h_count_reg(1),
      I4 => r11_h_count_reg(2),
      O => \ow4_red[3]_INST_0_i_10_n_0\
    );
\ow4_red[3]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00FF00FFFFFF57FF"
    )
        port map (
      I0 => \r11_v_count_reg_n_0_[4]\,
      I1 => \r11_v_count_reg_n_0_[3]\,
      I2 => \r11_v_count_reg_n_0_[2]\,
      I3 => \r11_v_count_reg_n_0_[9]\,
      I4 => \ow4_red[3]_INST_0_i_6_n_0\,
      I5 => \ow4_red[3]_INST_0_i_7_n_0\,
      O => \ow4_red[3]_INST_0_i_2_n_0\
    );
\ow4_red[3]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAFEEEEEEE"
    )
        port map (
      I0 => ow_hsync_INST_0_i_2_n_0,
      I1 => r11_h_count_reg(5),
      I2 => \ow4_red[3]_INST_0_i_8_n_0\,
      I3 => r11_h_count_reg(4),
      I4 => r11_h_count_reg(3),
      I5 => \ow4_red[3]_INST_0_i_9_n_0\,
      O => w_hactive041_in
    );
\ow4_red[3]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FBFFFFFF"
    )
        port map (
      I0 => \ow4_red[3]_INST_0_i_10_n_0\,
      I1 => r11_h_count_reg(8),
      I2 => \ow4_red[3]_INST_0_i_9_n_0\,
      I3 => r11_h_count_reg(3),
      I4 => r11_h_count_reg(9),
      I5 => r11_h_count_reg(10),
      O => \ow4_red[3]_INST_0_i_4_n_0\
    );
\ow4_red[3]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFEFEFEFEFEFEFE"
    )
        port map (
      I0 => \r11_v_count_reg_n_0_[7]\,
      I1 => \r11_v_count_reg_n_0_[8]\,
      I2 => \r11_v_count_reg_n_0_[6]\,
      I3 => \r11_v_count_reg_n_0_[2]\,
      I4 => \r11_v_count_reg_n_0_[3]\,
      I5 => \r11_v_count_reg_n_0_[4]\,
      O => \ow4_red[3]_INST_0_i_5_n_0\
    );
\ow4_red[3]_INST_0_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \r11_v_count_reg_n_0_[5]\,
      I1 => \r11_v_count_reg_n_0_[6]\,
      O => \ow4_red[3]_INST_0_i_6_n_0\
    );
\ow4_red[3]_INST_0_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \r11_v_count_reg_n_0_[7]\,
      I1 => \r11_v_count_reg_n_0_[8]\,
      O => \ow4_red[3]_INST_0_i_7_n_0\
    );
\ow4_red[3]_INST_0_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => r11_h_count_reg(2),
      I1 => r11_h_count_reg(1),
      I2 => r11_h_count_reg(0),
      O => \ow4_red[3]_INST_0_i_8_n_0\
    );
\ow4_red[3]_INST_0_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => r11_h_count_reg(6),
      I1 => r11_h_count_reg(7),
      O => \ow4_red[3]_INST_0_i_9_n_0\
    );
ow_hsync_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000002FFFF"
    )
        port map (
      I0 => ow_hsync_INST_0_i_1_n_0,
      I1 => r11_h_count_reg(0),
      I2 => r11_h_count_reg(1),
      I3 => r11_h_count_reg(2),
      I4 => r11_h_count_reg(7),
      I5 => ow_hsync_INST_0_i_2_n_0,
      O => ow_hsync
    );
ow_hsync_INST_0_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => r11_h_count_reg(4),
      I1 => r11_h_count_reg(3),
      I2 => r11_h_count_reg(6),
      I3 => r11_h_count_reg(5),
      O => ow_hsync_INST_0_i_1_n_0
    );
ow_hsync_INST_0_i_2: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => r11_h_count_reg(9),
      I1 => r11_h_count_reg(8),
      I2 => r11_h_count_reg(10),
      O => ow_hsync_INST_0_i_2_n_0
    );
ow_vsync_INST_0: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0202020A"
    )
        port map (
      I0 => ow_vsync_INST_0_i_1_n_0,
      I1 => \r11_v_count_reg_n_0_[2]\,
      I2 => \r11_v_count_reg_n_0_[3]\,
      I3 => \r11_v_count_reg_n_0_[1]\,
      I4 => \r11_v_count_reg_n_0_[0]\,
      O => ow_vsync
    );
ow_vsync_INST_0_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => \r11_v_count_reg_n_0_[6]\,
      I1 => \r11_v_count_reg_n_0_[9]\,
      I2 => \r11_v_count_reg_n_0_[4]\,
      I3 => \r11_v_count_reg_n_0_[5]\,
      I4 => \r11_v_count_reg_n_0_[8]\,
      I5 => \r11_v_count_reg_n_0_[7]\,
      O => ow_vsync_INST_0_i_1_n_0
    );
\p_0_out_inferred__4/r4_red[3]_i_204\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"99280089"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(4),
      I4 => r11_active_y_reg(5),
      O => \p_0_out_inferred__4/r4_red[3]_i_204_n_0\
    );
\p_0_out_inferred__4/r4_red[3]_i_206\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"80BF"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(5),
      O => \p_0_out_inferred__4/r4_red[3]_i_206_n_0\
    );
\p_0_out_inferred__4/r4_red[3]_i_210\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FBFF"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(5),
      O => \p_0_out_inferred__4/r4_red[3]_i_210_n_0\
    );
\p_0_out_inferred__4/r4_red[3]_i_211\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FF3BFFFF"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(4),
      I4 => r11_active_y_reg(5),
      O => \p_0_out_inferred__4/r4_red[3]_i_211_n_0\
    );
\p_0_out_inferred__4/r4_red[3]_i_222\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"17BB00A8"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(4),
      I4 => r11_active_y_reg(5),
      O => \p_0_out_inferred__4/r4_red[3]_i_222_n_0\
    );
\p_0_out_inferred__4/r4_red[3]_i_223\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B9280000"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(4),
      I4 => r11_active_y_reg(5),
      O => \p_0_out_inferred__4/r4_red[3]_i_223_n_0\
    );
\p_0_out_inferred__4/r4_red[3]_i_269\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55115402"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(4),
      I4 => r11_active_y_reg(5),
      O => \p_0_out_inferred__4/r4_red[3]_i_269_n_0\
    );
\p_0_out_inferred__4/r4_red[3]_i_270\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"91280011"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(4),
      I4 => r11_active_y_reg(5),
      O => \p_0_out_inferred__4/r4_red[3]_i_270_n_0\
    );
\p_0_out_inferred__4/r4_red[3]_i_271\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"551157FE"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(4),
      I4 => r11_active_y_reg(5),
      O => \p_0_out_inferred__4/r4_red[3]_i_271_n_0\
    );
\p_0_out_inferred__4/r4_red[3]_i_272\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"91280099"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(4),
      I4 => r11_active_y_reg(5),
      O => \p_0_out_inferred__4/r4_red[3]_i_272_n_0\
    );
\p_0_out_inferred__4/r4_red[3]_i_273\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B9280088"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(4),
      I4 => r11_active_y_reg(5),
      O => \p_0_out_inferred__4/r4_red[3]_i_273_n_0\
    );
\p_0_out_inferred__4/r4_red[3]_i_274\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"A2B1"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(5),
      O => \p_0_out_inferred__4/r4_red[3]_i_274_n_0\
    );
\p_0_out_inferred__4/r4_red[3]_i_275\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7E23FFEE"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(4),
      I4 => r11_active_y_reg(5),
      O => \p_0_out_inferred__4/r4_red[3]_i_275_n_0\
    );
\p_0_out_inferred__4/r4_red[3]_i_276\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"37BB4044"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(4),
      I4 => r11_active_y_reg(5),
      O => \p_0_out_inferred__4/r4_red[3]_i_276_n_0\
    );
p_1_out_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => p_1_out_carry_n_0,
      CO(2) => p_1_out_carry_n_1,
      CO(1) => p_1_out_carry_n_2,
      CO(0) => p_1_out_carry_n_3,
      CYINIT => '1',
      DI(3) => p_1_out_carry_i_1_n_0,
      DI(2) => iw11_block_right_pos(2),
      DI(1 downto 0) => r11_active_y_reg(1 downto 0),
      O(3 downto 0) => NLW_p_1_out_carry_O_UNCONNECTED(3 downto 0),
      S(3) => p_1_out_carry_i_2_n_0,
      S(2) => p_1_out_carry_i_3_n_0,
      S(1) => p_1_out_carry_i_4_n_0,
      S(0) => p_1_out_carry_i_5_n_0
    );
\p_1_out_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => p_1_out_carry_n_0,
      CO(3) => \p_1_out_carry__0_n_0\,
      CO(2) => \p_1_out_carry__0_n_1\,
      CO(1) => \p_1_out_carry__0_n_2\,
      CO(0) => \p_1_out_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \p_1_out_carry__0_i_1_n_0\,
      DI(2) => \p_1_out_carry__0_i_2_n_0\,
      DI(1) => \p_1_out_carry__0_i_3_n_0\,
      DI(0) => \p_1_out_carry__0_i_4_n_0\,
      O(3 downto 0) => \NLW_p_1_out_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \p_1_out_carry__0_i_5_n_0\,
      S(2) => \p_1_out_carry__0_i_6_n_0\,
      S(1) => \p_1_out_carry__0_i_7_n_0\,
      S(0) => \p_1_out_carry__0_i_8_n_0\
    );
\p_1_out_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => r11_active_y_reg(7),
      I1 => iw11_block_right_pos(7),
      O => \p_1_out_carry__0_i_1_n_0\
    );
\p_1_out_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => r11_active_y_reg(5),
      I1 => iw11_block_right_pos(5),
      O => \p_1_out_carry__0_i_2_n_0\
    );
\p_1_out_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => iw11_block_right_pos(4),
      O => \p_1_out_carry__0_i_3_n_0\
    );
\p_1_out_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_y_reg(3),
      I1 => iw11_block_right_pos(3),
      O => \p_1_out_carry__0_i_4_n_0\
    );
\p_1_out_carry__0_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6966"
    )
        port map (
      I0 => iw11_block_right_pos(7),
      I1 => r11_active_y_reg(7),
      I2 => iw11_block_right_pos(6),
      I3 => r11_active_y_reg(6),
      O => \p_1_out_carry__0_i_5_n_0\
    );
\p_1_out_carry__0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => iw11_block_right_pos(5),
      I1 => r11_active_y_reg(5),
      I2 => iw11_block_right_pos(6),
      I3 => r11_active_y_reg(6),
      O => \p_1_out_carry__0_i_6_n_0\
    );
\p_1_out_carry__0_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2DD2"
    )
        port map (
      I0 => iw11_block_right_pos(4),
      I1 => r11_active_y_reg(4),
      I2 => iw11_block_right_pos(5),
      I3 => r11_active_y_reg(5),
      O => \p_1_out_carry__0_i_7_n_0\
    );
\p_1_out_carry__0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_block_right_pos(3),
      I1 => r11_active_y_reg(3),
      I2 => iw11_block_right_pos(4),
      I3 => r11_active_y_reg(4),
      O => \p_1_out_carry__0_i_8_n_0\
    );
\p_1_out_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \p_1_out_carry__0_n_0\,
      CO(3) => \p_1_out_carry__1_n_0\,
      CO(2) => \p_1_out_carry__1_n_1\,
      CO(1) => \p_1_out_carry__1_n_2\,
      CO(0) => \p_1_out_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \p_1_out_carry__1_i_1_n_0\,
      DI(1) => \p_1_out_carry__1_i_2_n_0\,
      DI(0) => \p_1_out_carry__1_i_3_n_0\,
      O(3 downto 0) => \NLW_p_1_out_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \p_1_out_carry__1_i_4_n_0\,
      S(2) => \p_1_out_carry__1_i_5_n_0\,
      S(1) => \p_1_out_carry__1_i_6_n_0\,
      S(0) => \p_1_out_carry__1_i_7_n_0\
    );
\p_1_out_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_y_reg(9),
      I1 => iw11_block_right_pos(9),
      O => \p_1_out_carry__1_i_1_n_0\
    );
\p_1_out_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => iw11_block_right_pos(9),
      I1 => r11_active_y_reg(9),
      O => \p_1_out_carry__1_i_2_n_0\
    );
\p_1_out_carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => iw11_block_right_pos(8),
      I1 => r11_active_y_reg(8),
      O => \p_1_out_carry__1_i_3_n_0\
    );
\p_1_out_carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => r11_active_y_reg(10),
      I1 => iw11_block_right_pos(10),
      O => \p_1_out_carry__1_i_4_n_0\
    );
\p_1_out_carry__1_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_block_right_pos(9),
      I1 => r11_active_y_reg(9),
      I2 => iw11_block_right_pos(10),
      I3 => r11_active_y_reg(10),
      O => \p_1_out_carry__1_i_5_n_0\
    );
\p_1_out_carry__1_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_block_right_pos(8),
      I1 => r11_active_y_reg(8),
      I2 => r11_active_y_reg(9),
      I3 => iw11_block_right_pos(9),
      O => \p_1_out_carry__1_i_6_n_0\
    );
\p_1_out_carry__1_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => iw11_block_right_pos(7),
      I1 => r11_active_y_reg(7),
      I2 => r11_active_y_reg(8),
      I3 => iw11_block_right_pos(8),
      O => \p_1_out_carry__1_i_7_n_0\
    );
p_1_out_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => iw11_block_right_pos(3),
      I1 => r11_active_y_reg(3),
      O => p_1_out_carry_i_1_n_0
    );
p_1_out_carry_i_2: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => r11_active_y_reg(3),
      I1 => iw11_block_right_pos(3),
      I2 => iw11_block_right_pos(2),
      O => p_1_out_carry_i_2_n_0
    );
p_1_out_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => iw11_block_right_pos(2),
      I1 => r11_active_y_reg(2),
      O => p_1_out_carry_i_3_n_0
    );
p_1_out_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => r11_active_y_reg(1),
      I1 => iw11_block_right_pos(1),
      O => p_1_out_carry_i_4_n_0
    );
p_1_out_carry_i_5: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => r11_active_y_reg(0),
      I1 => iw11_block_right_pos(0),
      O => p_1_out_carry_i_5_n_0
    );
\p_1_out_inferred__0/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \p_1_out_inferred__0/i__carry_n_0\,
      CO(2) => \p_1_out_inferred__0/i__carry_n_1\,
      CO(1) => \p_1_out_inferred__0/i__carry_n_2\,
      CO(0) => \p_1_out_inferred__0/i__carry_n_3\,
      CYINIT => '1',
      DI(3) => \i__carry_i_1__1_n_0\,
      DI(2) => iw11_block_left_pos(2),
      DI(1 downto 0) => r11_active_y_reg(1 downto 0),
      O(3 downto 0) => \NLW_p_1_out_inferred__0/i__carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_2__2_n_0\,
      S(2) => \i__carry_i_3__2_n_0\,
      S(1) => \i__carry_i_4__2_n_0\,
      S(0) => \i__carry_i_5__2_n_0\
    );
\p_1_out_inferred__0/i__carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \p_1_out_inferred__0/i__carry_n_0\,
      CO(3) => \p_1_out_inferred__0/i__carry__0_n_0\,
      CO(2) => \p_1_out_inferred__0/i__carry__0_n_1\,
      CO(1) => \p_1_out_inferred__0/i__carry__0_n_2\,
      CO(0) => \p_1_out_inferred__0/i__carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \i__carry__0_i_1_n_0\,
      DI(2) => \i__carry__0_i_2__1_n_0\,
      DI(1) => \i__carry__0_i_3_n_0\,
      DI(0) => \i__carry__0_i_4_n_0\,
      O(3 downto 0) => \NLW_p_1_out_inferred__0/i__carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry__0_i_5_n_0\,
      S(2) => \i__carry__0_i_6_n_0\,
      S(1) => \i__carry__0_i_7_n_0\,
      S(0) => \i__carry__0_i_8_n_0\
    );
\p_1_out_inferred__0/i__carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \p_1_out_inferred__0/i__carry__0_n_0\,
      CO(3) => \p_1_out_inferred__0/i__carry__1_n_0\,
      CO(2) => \p_1_out_inferred__0/i__carry__1_n_1\,
      CO(1) => \p_1_out_inferred__0/i__carry__1_n_2\,
      CO(0) => \p_1_out_inferred__0/i__carry__1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \i__carry__1_i_1_n_0\,
      DI(1) => \i__carry__1_i_2_n_0\,
      DI(0) => \i__carry__1_i_3_n_0\,
      O(3 downto 0) => \NLW_p_1_out_inferred__0/i__carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry__1_i_4_n_0\,
      S(2) => \i__carry__1_i_5_n_0\,
      S(1) => \i__carry__1_i_6_n_0\,
      S(0) => \i__carry__1_i_7_n_0\
    );
\p_1_out_inferred__1/i___0_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \p_1_out_inferred__1/i___0_carry_n_0\,
      CO(2) => \p_1_out_inferred__1/i___0_carry_n_1\,
      CO(1) => \p_1_out_inferred__1/i___0_carry_n_2\,
      CO(0) => \p_1_out_inferred__1/i___0_carry_n_3\,
      CYINIT => '1',
      DI(3) => \i___0_carry_i_1_n_0\,
      DI(2) => \i___0_carry_i_2_n_0\,
      DI(1) => \i___0_carry_i_3_n_0\,
      DI(0) => \i___0_carry_i_4_n_0\,
      O(3 downto 0) => \NLW_p_1_out_inferred__1/i___0_carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \i___0_carry_i_5_n_0\,
      S(2) => \i___0_carry_i_6_n_0\,
      S(1) => \i___0_carry_i_7_n_0\,
      S(0) => \i___0_carry_i_8_n_0\
    );
\p_1_out_inferred__1/i___0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \p_1_out_inferred__1/i___0_carry_n_0\,
      CO(3) => \p_1_out_inferred__1/i___0_carry__0_n_0\,
      CO(2) => \p_1_out_inferred__1/i___0_carry__0_n_1\,
      CO(1) => \p_1_out_inferred__1/i___0_carry__0_n_2\,
      CO(0) => \p_1_out_inferred__1/i___0_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \i___0_carry__0_i_1_n_0\,
      DI(2) => \i___0_carry__0_i_2_n_0\,
      DI(1) => \i___0_carry__0_i_3_n_0\,
      DI(0) => \i___0_carry__0_i_4_n_0\,
      O(3 downto 0) => \NLW_p_1_out_inferred__1/i___0_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \i___0_carry__0_i_5_n_0\,
      S(2) => \i___0_carry__0_i_6_n_0\,
      S(1) => \i___0_carry__0_i_7_n_0\,
      S(0) => \i___0_carry__0_i_8_n_0\
    );
\p_1_out_inferred__1/i___0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \p_1_out_inferred__1/i___0_carry__0_n_0\,
      CO(3) => \p_1_out_inferred__1/i___0_carry__1_n_0\,
      CO(2) => \p_1_out_inferred__1/i___0_carry__1_n_1\,
      CO(1) => \p_1_out_inferred__1/i___0_carry__1_n_2\,
      CO(0) => \p_1_out_inferred__1/i___0_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \i___0_carry__1_i_1_n_0\,
      DI(1) => \i___0_carry__1_i_2_n_0\,
      DI(0) => \i___0_carry__1_i_3_n_0\,
      O(3 downto 0) => \NLW_p_1_out_inferred__1/i___0_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \i___0_carry__1_i_4_n_0\,
      S(2) => \i___0_carry__1_i_5_n_0\,
      S(1) => \i___0_carry__1_i_6_n_0\,
      S(0) => \i___0_carry__1_i_7_n_0\
    );
\p_1_out_inferred__2/i___0_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \p_1_out_inferred__2/i___0_carry_n_0\,
      CO(2) => \p_1_out_inferred__2/i___0_carry_n_1\,
      CO(1) => \p_1_out_inferred__2/i___0_carry_n_2\,
      CO(0) => \p_1_out_inferred__2/i___0_carry_n_3\,
      CYINIT => '1',
      DI(3) => \i___0_carry_i_1__0_n_0\,
      DI(2) => \i___0_carry_i_2__0_n_0\,
      DI(1) => \i___0_carry_i_3__0_n_0\,
      DI(0) => \i___0_carry_i_4__0_n_0\,
      O(3 downto 0) => \NLW_p_1_out_inferred__2/i___0_carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \i___0_carry_i_5__0_n_0\,
      S(2) => \i___0_carry_i_6__0_n_0\,
      S(1) => \i___0_carry_i_7__0_n_0\,
      S(0) => \i___0_carry_i_8__0_n_0\
    );
\p_1_out_inferred__2/i___0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \p_1_out_inferred__2/i___0_carry_n_0\,
      CO(3) => \p_1_out_inferred__2/i___0_carry__0_n_0\,
      CO(2) => \p_1_out_inferred__2/i___0_carry__0_n_1\,
      CO(1) => \p_1_out_inferred__2/i___0_carry__0_n_2\,
      CO(0) => \p_1_out_inferred__2/i___0_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \i___0_carry__0_i_1__0_n_0\,
      DI(2) => \i___0_carry__0_i_2__0_n_0\,
      DI(1) => \i___0_carry__0_i_3__0_n_0\,
      DI(0) => \i___0_carry__0_i_4__0_n_0\,
      O(3 downto 0) => \NLW_p_1_out_inferred__2/i___0_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \i___0_carry__0_i_5__0_n_0\,
      S(2) => \i___0_carry__0_i_6__0_n_0\,
      S(1) => \i___0_carry__0_i_7__0_n_0\,
      S(0) => \i___0_carry__0_i_8__0_n_0\
    );
\p_1_out_inferred__2/i___0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \p_1_out_inferred__2/i___0_carry__0_n_0\,
      CO(3) => \p_1_out_inferred__2/i___0_carry__1_n_0\,
      CO(2) => \p_1_out_inferred__2/i___0_carry__1_n_1\,
      CO(1) => \p_1_out_inferred__2/i___0_carry__1_n_2\,
      CO(0) => \p_1_out_inferred__2/i___0_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \i___0_carry__1_i_1__0_n_0\,
      DI(1) => \i___0_carry__1_i_2__0_n_0\,
      DI(0) => \i___0_carry__1_i_3__0_n_0\,
      O(3 downto 0) => \NLW_p_1_out_inferred__2/i___0_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \i___0_carry__1_i_4__0_n_0\,
      S(2) => \i___0_carry__1_i_5__0_n_0\,
      S(1) => \i___0_carry__1_i_6__0_n_0\,
      S(0) => \i___0_carry__1_i_7__0_n_0\
    );
\r11_active_x[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => r11_active_x_reg(0),
      O => \r11_active_x[0]_i_1_n_0\
    );
\r11_active_x[10]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \ow4_red[3]_INST_0_i_4_n_0\,
      I1 => w_hactive041_in,
      O => p_43_in
    );
\r11_active_x[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF7FFF00008000"
    )
        port map (
      I0 => r11_active_x_reg(9),
      I1 => r11_active_x_reg(6),
      I2 => r11_active_x_reg(8),
      I3 => r11_active_x_reg(7),
      I4 => \r11_active_x[10]_i_3_n_0\,
      I5 => r11_active_x_reg(10),
      O => \p_0_in__0\(10)
    );
\r11_active_x[10]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFFFFFFFFFF"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => r11_active_x_reg(2),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(4),
      I4 => r11_active_x_reg(1),
      I5 => r11_active_x_reg(0),
      O => \r11_active_x[10]_i_3_n_0\
    );
\r11_active_x[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => r11_active_x_reg(0),
      I1 => r11_active_x_reg(1),
      O => \p_0_in__0\(1)
    );
\r11_active_x[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => r11_active_x_reg(0),
      I1 => r11_active_x_reg(1),
      I2 => r11_active_x_reg(2),
      O => \p_0_in__0\(2)
    );
\r11_active_x[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => r11_active_x_reg(2),
      I1 => r11_active_x_reg(1),
      I2 => r11_active_x_reg(0),
      I3 => r11_active_x_reg(3),
      O => \p_0_in__0\(3)
    );
\r11_active_x[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => r11_active_x_reg(3),
      I1 => r11_active_x_reg(2),
      I2 => r11_active_x_reg(1),
      I3 => r11_active_x_reg(0),
      I4 => r11_active_x_reg(4),
      O => \p_0_in__0\(4)
    );
\r11_active_x[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => r11_active_x_reg(2),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(1),
      I4 => r11_active_x_reg(0),
      I5 => r11_active_x_reg(5),
      O => \p_0_in__0\(5)
    );
\r11_active_x[6]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F7FF0800"
    )
        port map (
      I0 => r11_active_x_reg(0),
      I1 => r11_active_x_reg(1),
      I2 => \r11_active_x[8]_i_3_n_0\,
      I3 => r11_active_x_reg(5),
      I4 => r11_active_x_reg(6),
      O => \p_0_in__0\(6)
    );
\r11_active_x[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F7FFFFFF08000000"
    )
        port map (
      I0 => r11_active_x_reg(6),
      I1 => r11_active_x_reg(5),
      I2 => \r11_active_x[8]_i_3_n_0\,
      I3 => r11_active_x_reg(1),
      I4 => r11_active_x_reg(0),
      I5 => r11_active_x_reg(7),
      O => \p_0_in__0\(7)
    );
\r11_active_x[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FDFFFFFF02000000"
    )
        port map (
      I0 => r11_active_x_reg(7),
      I1 => \r11_active_x[8]_i_2_n_0\,
      I2 => \r11_active_x[8]_i_3_n_0\,
      I3 => r11_active_x_reg(5),
      I4 => r11_active_x_reg(6),
      I5 => r11_active_x_reg(8),
      O => \p_0_in__0\(8)
    );
\r11_active_x[8]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => r11_active_x_reg(1),
      I1 => r11_active_x_reg(0),
      O => \r11_active_x[8]_i_2_n_0\
    );
\r11_active_x[8]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => r11_active_x_reg(2),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(4),
      O => \r11_active_x[8]_i_3_n_0\
    );
\r11_active_x[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BFFF4000"
    )
        port map (
      I0 => \r11_active_x[10]_i_3_n_0\,
      I1 => r11_active_x_reg(7),
      I2 => r11_active_x_reg(8),
      I3 => r11_active_x_reg(6),
      I4 => r11_active_x_reg(9),
      O => \p_0_in__0\(9)
    );
\r11_active_x_reg[0]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => iw_pix_clk,
      CE => p_43_in,
      D => \r11_active_x[0]_i_1_n_0\,
      Q => r11_active_x_reg(0),
      S => \r11_v_count[9]_i_2_n_0\
    );
\r11_active_x_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => p_43_in,
      D => \p_0_in__0\(10),
      Q => r11_active_x_reg(10),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_active_x_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => p_43_in,
      D => \p_0_in__0\(1),
      Q => r11_active_x_reg(1),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_active_x_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => p_43_in,
      D => \p_0_in__0\(2),
      Q => r11_active_x_reg(2),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_active_x_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => p_43_in,
      D => \p_0_in__0\(3),
      Q => r11_active_x_reg(3),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_active_x_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => p_43_in,
      D => \p_0_in__0\(4),
      Q => r11_active_x_reg(4),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_active_x_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => p_43_in,
      D => \p_0_in__0\(5),
      Q => r11_active_x_reg(5),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_active_x_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => p_43_in,
      D => \p_0_in__0\(6),
      Q => r11_active_x_reg(6),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_active_x_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => p_43_in,
      D => \p_0_in__0\(7),
      Q => r11_active_x_reg(7),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_active_x_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => p_43_in,
      D => \p_0_in__0\(8),
      Q => r11_active_x_reg(8),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_active_x_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => p_43_in,
      D => \p_0_in__0\(9),
      Q => r11_active_x_reg(9),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_active_y[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => r11_active_y_reg(0),
      O => \p_0_in__1\(0)
    );
\r11_active_y[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => \ow4_red[3]_INST_0_i_2_n_0\,
      I1 => \r11_v_count[9]_i_2_n_0\,
      I2 => w_vactive040_in,
      O => r11_active_y
    );
\r11_active_y[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BFFFFFFF40000000"
    )
        port map (
      I0 => \r11_active_y[10]_i_3_n_0\,
      I1 => r11_active_y_reg(6),
      I2 => r11_active_y_reg(7),
      I3 => r11_active_y_reg(9),
      I4 => r11_active_y_reg(8),
      I5 => r11_active_y_reg(10),
      O => \p_0_in__1\(10)
    );
\r11_active_y[10]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFFFFFFFFFF"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(5),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(1),
      I5 => r11_active_y_reg(0),
      O => \r11_active_y[10]_i_3_n_0\
    );
\r11_active_y[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => r11_active_y_reg(1),
      I1 => r11_active_y_reg(0),
      O => \p_0_in__1\(1)
    );
\r11_active_y[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => r11_active_y_reg(0),
      I1 => r11_active_y_reg(1),
      I2 => r11_active_y_reg(2),
      O => \p_0_in__1\(2)
    );
\r11_active_y[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6CCC"
    )
        port map (
      I0 => r11_active_y_reg(2),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(1),
      I3 => r11_active_y_reg(0),
      O => \p_0_in__1\(3)
    );
\r11_active_y[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => r11_active_y_reg(3),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(1),
      I3 => r11_active_y_reg(0),
      I4 => r11_active_y_reg(4),
      O => \p_0_in__1\(4)
    );
\r11_active_y[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(0),
      I2 => r11_active_y_reg(1),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(3),
      I5 => r11_active_y_reg(5),
      O => \p_0_in__1\(5)
    );
\r11_active_y[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BFFFFFFF40000000"
    )
        port map (
      I0 => \r11_active_y[7]_i_3_n_0\,
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(5),
      I4 => r11_active_y_reg(4),
      I5 => r11_active_y_reg(6),
      O => \p_0_in__1\(6)
    );
\r11_active_y[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCCCCCCCCCCC6CCC"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(7),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(5),
      I4 => \r11_active_y[7]_i_2_n_0\,
      I5 => \r11_active_y[7]_i_3_n_0\,
      O => \p_0_in__1\(7)
    );
\r11_active_y[7]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => r11_active_y_reg(3),
      I1 => r11_active_y_reg(2),
      O => \r11_active_y[7]_i_2_n_0\
    );
\r11_active_y[7]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => r11_active_y_reg(1),
      I1 => r11_active_y_reg(0),
      O => \r11_active_y[7]_i_3_n_0\
    );
\r11_active_y[8]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F708"
    )
        port map (
      I0 => r11_active_y_reg(7),
      I1 => r11_active_y_reg(6),
      I2 => \r11_active_y[10]_i_3_n_0\,
      I3 => r11_active_y_reg(8),
      O => \p_0_in__1\(8)
    );
\r11_active_y[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"DFFF2000"
    )
        port map (
      I0 => r11_active_y_reg(8),
      I1 => \r11_active_y[10]_i_3_n_0\,
      I2 => r11_active_y_reg(6),
      I3 => r11_active_y_reg(7),
      I4 => r11_active_y_reg(9),
      O => \p_0_in__1\(9)
    );
\r11_active_y_reg[0]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => iw_pix_clk,
      CE => r11_active_y,
      D => \p_0_in__1\(0),
      Q => r11_active_y_reg(0),
      S => r11_v_count
    );
\r11_active_y_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => r11_active_y,
      D => \p_0_in__1\(10),
      Q => r11_active_y_reg(10),
      R => r11_v_count
    );
\r11_active_y_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => r11_active_y,
      D => \p_0_in__1\(1),
      Q => r11_active_y_reg(1),
      R => r11_v_count
    );
\r11_active_y_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => r11_active_y,
      D => \p_0_in__1\(2),
      Q => r11_active_y_reg(2),
      R => r11_v_count
    );
\r11_active_y_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => r11_active_y,
      D => \p_0_in__1\(3),
      Q => r11_active_y_reg(3),
      R => r11_v_count
    );
\r11_active_y_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => r11_active_y,
      D => \p_0_in__1\(4),
      Q => r11_active_y_reg(4),
      R => r11_v_count
    );
\r11_active_y_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => r11_active_y,
      D => \p_0_in__1\(5),
      Q => r11_active_y_reg(5),
      R => r11_v_count
    );
\r11_active_y_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => r11_active_y,
      D => \p_0_in__1\(6),
      Q => r11_active_y_reg(6),
      R => r11_v_count
    );
\r11_active_y_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => r11_active_y,
      D => \p_0_in__1\(7),
      Q => r11_active_y_reg(7),
      R => r11_v_count
    );
\r11_active_y_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => r11_active_y,
      D => \p_0_in__1\(8),
      Q => r11_active_y_reg(8),
      R => r11_v_count
    );
\r11_active_y_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => r11_active_y,
      D => \p_0_in__1\(9),
      Q => r11_active_y_reg(9),
      R => r11_v_count
    );
\r11_h_count[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => r11_h_count_reg(0),
      O => p_0_in(0)
    );
\r11_h_count[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"DFFFFFFF20000000"
    )
        port map (
      I0 => r11_h_count_reg(9),
      I1 => \r11_h_count[10]_i_2_n_0\,
      I2 => r11_h_count_reg(6),
      I3 => r11_h_count_reg(7),
      I4 => r11_h_count_reg(8),
      I5 => r11_h_count_reg(10),
      O => p_0_in(10)
    );
\r11_h_count[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFFFFFFFFFF"
    )
        port map (
      I0 => r11_h_count_reg(2),
      I1 => r11_h_count_reg(0),
      I2 => r11_h_count_reg(1),
      I3 => r11_h_count_reg(3),
      I4 => r11_h_count_reg(4),
      I5 => r11_h_count_reg(5),
      O => \r11_h_count[10]_i_2_n_0\
    );
\r11_h_count[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => r11_h_count_reg(0),
      I1 => r11_h_count_reg(1),
      O => p_0_in(1)
    );
\r11_h_count[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => r11_h_count_reg(1),
      I1 => r11_h_count_reg(0),
      I2 => r11_h_count_reg(2),
      O => p_0_in(2)
    );
\r11_h_count[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => r11_h_count_reg(2),
      I1 => r11_h_count_reg(0),
      I2 => r11_h_count_reg(1),
      I3 => r11_h_count_reg(3),
      O => p_0_in(3)
    );
\r11_h_count[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => r11_h_count_reg(3),
      I1 => r11_h_count_reg(1),
      I2 => r11_h_count_reg(0),
      I3 => r11_h_count_reg(2),
      I4 => r11_h_count_reg(4),
      O => p_0_in(4)
    );
\r11_h_count[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => r11_h_count_reg(2),
      I1 => r11_h_count_reg(0),
      I2 => r11_h_count_reg(1),
      I3 => r11_h_count_reg(3),
      I4 => r11_h_count_reg(4),
      I5 => r11_h_count_reg(5),
      O => p_0_in(5)
    );
\r11_h_count[6]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \r11_h_count[10]_i_2_n_0\,
      I1 => r11_h_count_reg(6),
      O => p_0_in(6)
    );
\r11_h_count[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D2"
    )
        port map (
      I0 => r11_h_count_reg(6),
      I1 => \r11_h_count[10]_i_2_n_0\,
      I2 => r11_h_count_reg(7),
      O => p_0_in(7)
    );
\r11_h_count[8]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"BF40"
    )
        port map (
      I0 => \r11_h_count[10]_i_2_n_0\,
      I1 => r11_h_count_reg(6),
      I2 => r11_h_count_reg(7),
      I3 => r11_h_count_reg(8),
      O => p_0_in(8)
    );
\r11_h_count[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FF7F0080"
    )
        port map (
      I0 => r11_h_count_reg(8),
      I1 => r11_h_count_reg(7),
      I2 => r11_h_count_reg(6),
      I3 => \r11_h_count[10]_i_2_n_0\,
      I4 => r11_h_count_reg(9),
      O => p_0_in(9)
    );
\r11_h_count_reg[0]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => iw_pix_clk,
      CE => '1',
      D => p_0_in(0),
      Q => r11_h_count_reg(0),
      S => \r11_v_count[9]_i_2_n_0\
    );
\r11_h_count_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => '1',
      D => p_0_in(10),
      Q => r11_h_count_reg(10),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_h_count_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => '1',
      D => p_0_in(1),
      Q => r11_h_count_reg(1),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_h_count_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => '1',
      D => p_0_in(2),
      Q => r11_h_count_reg(2),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_h_count_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => '1',
      D => p_0_in(3),
      Q => r11_h_count_reg(3),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_h_count_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => '1',
      D => p_0_in(4),
      Q => r11_h_count_reg(4),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_h_count_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => '1',
      D => p_0_in(5),
      Q => r11_h_count_reg(5),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_h_count_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => '1',
      D => p_0_in(6),
      Q => r11_h_count_reg(6),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_h_count_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => '1',
      D => p_0_in(7),
      Q => r11_h_count_reg(7),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_h_count_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => '1',
      D => p_0_in(8),
      Q => r11_h_count_reg(8),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_h_count_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => '1',
      D => p_0_in(9),
      Q => r11_h_count_reg(9),
      R => \r11_v_count[9]_i_2_n_0\
    );
\r11_v_count[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \r11_v_count_reg_n_0_[0]\,
      O => p_1_in(0)
    );
\r11_v_count[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \r11_v_count_reg_n_0_[0]\,
      I1 => \r11_v_count_reg_n_0_[1]\,
      O => p_1_in(1)
    );
\r11_v_count[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \r11_v_count_reg_n_0_[0]\,
      I1 => \r11_v_count_reg_n_0_[1]\,
      I2 => \r11_v_count_reg_n_0_[2]\,
      O => p_1_in(2)
    );
\r11_v_count[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \r11_v_count_reg_n_0_[2]\,
      I1 => \r11_v_count_reg_n_0_[1]\,
      I2 => \r11_v_count_reg_n_0_[0]\,
      I3 => \r11_v_count_reg_n_0_[3]\,
      O => p_1_in(3)
    );
\r11_v_count[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => \r11_v_count_reg_n_0_[3]\,
      I1 => \r11_v_count_reg_n_0_[0]\,
      I2 => \r11_v_count_reg_n_0_[1]\,
      I3 => \r11_v_count_reg_n_0_[2]\,
      I4 => \r11_v_count_reg_n_0_[4]\,
      O => p_1_in(4)
    );
\r11_v_count[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => \r11_v_count_reg_n_0_[2]\,
      I1 => \r11_v_count_reg_n_0_[1]\,
      I2 => \r11_v_count_reg_n_0_[0]\,
      I3 => \r11_v_count_reg_n_0_[3]\,
      I4 => \r11_v_count_reg_n_0_[4]\,
      I5 => \r11_v_count_reg_n_0_[5]\,
      O => p_1_in(5)
    );
\r11_v_count[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \r11_v_count_reg_n_0_[5]\,
      I1 => \r11_v_count[9]_i_6_n_0\,
      I2 => \r11_v_count_reg_n_0_[6]\,
      O => p_1_in(6)
    );
\r11_v_count[7]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \r11_v_count[9]_i_6_n_0\,
      I1 => \r11_v_count_reg_n_0_[5]\,
      I2 => \r11_v_count_reg_n_0_[6]\,
      I3 => \r11_v_count_reg_n_0_[7]\,
      O => p_1_in(7)
    );
\r11_v_count[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => \r11_v_count_reg_n_0_[7]\,
      I1 => \r11_v_count_reg_n_0_[6]\,
      I2 => \r11_v_count_reg_n_0_[5]\,
      I3 => \r11_v_count[9]_i_6_n_0\,
      I4 => \r11_v_count_reg_n_0_[8]\,
      O => p_1_in(8)
    );
\r11_v_count[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4040404040404000"
    )
        port map (
      I0 => \r11_v_count[9]_i_4_n_0\,
      I1 => \r11_v_count_reg_n_0_[9]\,
      I2 => r11_h_count_reg(10),
      I3 => \r11_v_count_reg_n_0_[7]\,
      I4 => \r11_v_count_reg_n_0_[8]\,
      I5 => \r11_v_count[9]_i_5_n_0\,
      O => r11_v_count
    );
\r11_v_count[9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => r11_h_count_reg(10),
      I1 => r11_h_count_reg(8),
      I2 => r11_h_count_reg(9),
      I3 => r11_h_count_reg(7),
      I4 => r11_h_count_reg(6),
      I5 => r11_h_count_reg(5),
      O => \r11_v_count[9]_i_2_n_0\
    );
\r11_v_count[9]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => \r11_v_count_reg_n_0_[8]\,
      I1 => \r11_v_count[9]_i_6_n_0\,
      I2 => \r11_v_count_reg_n_0_[5]\,
      I3 => \r11_v_count_reg_n_0_[6]\,
      I4 => \r11_v_count_reg_n_0_[7]\,
      I5 => \r11_v_count_reg_n_0_[9]\,
      O => p_1_in(9)
    );
\r11_v_count[9]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => r11_h_count_reg(5),
      I1 => r11_h_count_reg(6),
      I2 => r11_h_count_reg(7),
      I3 => r11_h_count_reg(9),
      I4 => r11_h_count_reg(8),
      O => \r11_v_count[9]_i_4_n_0\
    );
\r11_v_count[9]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80808000"
    )
        port map (
      I0 => \r11_v_count_reg_n_0_[5]\,
      I1 => \r11_v_count_reg_n_0_[6]\,
      I2 => \r11_v_count_reg_n_0_[4]\,
      I3 => \r11_v_count_reg_n_0_[3]\,
      I4 => \r11_v_count_reg_n_0_[2]\,
      O => \r11_v_count[9]_i_5_n_0\
    );
\r11_v_count[9]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => \r11_v_count_reg_n_0_[4]\,
      I1 => \r11_v_count_reg_n_0_[3]\,
      I2 => \r11_v_count_reg_n_0_[0]\,
      I3 => \r11_v_count_reg_n_0_[1]\,
      I4 => \r11_v_count_reg_n_0_[2]\,
      O => \r11_v_count[9]_i_6_n_0\
    );
\r11_v_count_reg[0]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => iw_pix_clk,
      CE => \r11_v_count[9]_i_2_n_0\,
      D => p_1_in(0),
      Q => \r11_v_count_reg_n_0_[0]\,
      S => r11_v_count
    );
\r11_v_count_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => \r11_v_count[9]_i_2_n_0\,
      D => p_1_in(1),
      Q => \r11_v_count_reg_n_0_[1]\,
      R => r11_v_count
    );
\r11_v_count_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => \r11_v_count[9]_i_2_n_0\,
      D => p_1_in(2),
      Q => \r11_v_count_reg_n_0_[2]\,
      R => r11_v_count
    );
\r11_v_count_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => \r11_v_count[9]_i_2_n_0\,
      D => p_1_in(3),
      Q => \r11_v_count_reg_n_0_[3]\,
      R => r11_v_count
    );
\r11_v_count_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => \r11_v_count[9]_i_2_n_0\,
      D => p_1_in(4),
      Q => \r11_v_count_reg_n_0_[4]\,
      R => r11_v_count
    );
\r11_v_count_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => \r11_v_count[9]_i_2_n_0\,
      D => p_1_in(5),
      Q => \r11_v_count_reg_n_0_[5]\,
      R => r11_v_count
    );
\r11_v_count_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => \r11_v_count[9]_i_2_n_0\,
      D => p_1_in(6),
      Q => \r11_v_count_reg_n_0_[6]\,
      R => r11_v_count
    );
\r11_v_count_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => \r11_v_count[9]_i_2_n_0\,
      D => p_1_in(7),
      Q => \r11_v_count_reg_n_0_[7]\,
      R => r11_v_count
    );
\r11_v_count_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => \r11_v_count[9]_i_2_n_0\,
      D => p_1_in(8),
      Q => \r11_v_count_reg_n_0_[8]\,
      R => r11_v_count
    );
\r11_v_count_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => \r11_v_count[9]_i_2_n_0\,
      D => p_1_in(9),
      Q => \r11_v_count_reg_n_0_[9]\,
      R => r11_v_count
    );
\r4_blue[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFEFEFE"
    )
        port map (
      I0 => \r4_blue[0]_i_2_n_0\,
      I1 => \r4_blue[0]_i_3_n_0\,
      I2 => \r4_red[2]_i_10_n_0\,
      I3 => \r4_red[3]_i_8_n_0\,
      I4 => iw4_blue(0),
      O => \r4_blue[0]_i_1_n_0\
    );
\r4_blue[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_29_n_0\,
      I1 => \r4_red[3]_i_30_n_0\,
      I2 => iw4_blue(0),
      I3 => iw4_result_right(3),
      I4 => iw4_result_right(2),
      I5 => \r4_red[3]_i_31_n_0\,
      O => \r4_blue[0]_i_2_n_0\
    );
\r4_blue[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_32_n_0\,
      I1 => \r4_red[2]_i_15_n_0\,
      I2 => iw4_blue(0),
      I3 => iw4_result_left(3),
      I4 => iw4_result_left(2),
      I5 => \r4_red[3]_i_34_n_0\,
      O => \r4_blue[0]_i_3_n_0\
    );
\r4_blue[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFF8"
    )
        port map (
      I0 => \r4_red[3]_i_8_n_0\,
      I1 => iw4_blue(1),
      I2 => \r4_blue[1]_i_2_n_0\,
      I3 => \r4_blue[1]_i_3_n_0\,
      O => \r4_blue[1]_i_1_n_0\
    );
\r4_blue[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_29_n_0\,
      I1 => \r4_red[3]_i_30_n_0\,
      I2 => iw4_blue(1),
      I3 => iw4_result_right(3),
      I4 => iw4_result_right(2),
      I5 => \r4_red[3]_i_31_n_0\,
      O => \r4_blue[1]_i_2_n_0\
    );
\r4_blue[1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_32_n_0\,
      I1 => \r4_red[3]_i_33_n_0\,
      I2 => iw4_blue(1),
      I3 => iw4_result_left(3),
      I4 => iw4_result_left(2),
      I5 => \r4_red[3]_i_34_n_0\,
      O => \r4_blue[1]_i_3_n_0\
    );
\r4_blue[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFEFEFE"
    )
        port map (
      I0 => \r4_blue[2]_i_2_n_0\,
      I1 => \r4_blue[2]_i_3_n_0\,
      I2 => \r4_red[2]_i_10_n_0\,
      I3 => \r4_red[3]_i_8_n_0\,
      I4 => iw4_blue(2),
      O => \r4_blue[2]_i_1_n_0\
    );
\r4_blue[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_29_n_0\,
      I1 => \r4_red[3]_i_30_n_0\,
      I2 => iw4_blue(2),
      I3 => iw4_result_right(3),
      I4 => iw4_result_right(2),
      I5 => \r4_red[3]_i_31_n_0\,
      O => \r4_blue[2]_i_2_n_0\
    );
\r4_blue[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_32_n_0\,
      I1 => \r4_red[2]_i_15_n_0\,
      I2 => iw4_blue(2),
      I3 => iw4_result_left(3),
      I4 => iw4_result_left(2),
      I5 => \r4_red[3]_i_34_n_0\,
      O => \r4_blue[2]_i_3_n_0\
    );
\r4_blue[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFF8"
    )
        port map (
      I0 => \r4_red[3]_i_8_n_0\,
      I1 => iw4_blue(3),
      I2 => \r4_blue[3]_i_2_n_0\,
      I3 => \r4_blue[3]_i_3_n_0\,
      O => \r4_blue[3]_i_1_n_0\
    );
\r4_blue[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_29_n_0\,
      I1 => \r4_red[3]_i_30_n_0\,
      I2 => iw4_blue(3),
      I3 => iw4_result_right(3),
      I4 => iw4_result_right(2),
      I5 => \r4_red[3]_i_31_n_0\,
      O => \r4_blue[3]_i_2_n_0\
    );
\r4_blue[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_32_n_0\,
      I1 => \r4_red[3]_i_33_n_0\,
      I2 => iw4_blue(3),
      I3 => iw4_result_left(3),
      I4 => iw4_result_left(2),
      I5 => \r4_red[3]_i_34_n_0\,
      O => \r4_blue[3]_i_3_n_0\
    );
\r4_blue_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => iw_pix_clk,
      CE => \r4_red[2]_i_2_n_0\,
      D => \r4_blue[0]_i_1_n_0\,
      Q => \r4_blue_reg_n_0_[0]\,
      R => r4_blue(2)
    );
\r4_blue_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => iw_pix_clk,
      CE => \r4_red[3]_i_2_n_0\,
      D => \r4_blue[1]_i_1_n_0\,
      Q => \r4_blue_reg_n_0_[1]\,
      R => r4_blue(3)
    );
\r4_blue_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => iw_pix_clk,
      CE => \r4_red[2]_i_2_n_0\,
      D => \r4_blue[2]_i_1_n_0\,
      Q => \r4_blue_reg_n_0_[2]\,
      R => r4_blue(2)
    );
\r4_blue_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => \r4_red[3]_i_2_n_0\,
      D => \r4_blue[3]_i_1_n_0\,
      Q => \r4_blue_reg_n_0_[3]\,
      R => r4_blue(3)
    );
\r4_green[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFEFEFE"
    )
        port map (
      I0 => \r4_green[0]_i_2_n_0\,
      I1 => \r4_green[0]_i_3_n_0\,
      I2 => \r4_red[2]_i_10_n_0\,
      I3 => \r4_red[3]_i_8_n_0\,
      I4 => iw4_green(0),
      O => r4_green(0)
    );
\r4_green[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_29_n_0\,
      I1 => \r4_red[3]_i_30_n_0\,
      I2 => iw4_green(0),
      I3 => iw4_result_right(3),
      I4 => iw4_result_right(2),
      I5 => \r4_red[3]_i_31_n_0\,
      O => \r4_green[0]_i_2_n_0\
    );
\r4_green[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_32_n_0\,
      I1 => \r4_red[2]_i_15_n_0\,
      I2 => iw4_green(0),
      I3 => iw4_result_left(3),
      I4 => iw4_result_left(2),
      I5 => \r4_red[3]_i_34_n_0\,
      O => \r4_green[0]_i_3_n_0\
    );
\r4_green[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFF8"
    )
        port map (
      I0 => \r4_red[3]_i_8_n_0\,
      I1 => iw4_green(1),
      I2 => \r4_green[1]_i_2_n_0\,
      I3 => \r4_green[1]_i_3_n_0\,
      O => r4_green(1)
    );
\r4_green[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_29_n_0\,
      I1 => \r4_red[3]_i_30_n_0\,
      I2 => iw4_green(1),
      I3 => iw4_result_right(3),
      I4 => iw4_result_right(2),
      I5 => \r4_red[3]_i_31_n_0\,
      O => \r4_green[1]_i_2_n_0\
    );
\r4_green[1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_32_n_0\,
      I1 => \r4_red[3]_i_33_n_0\,
      I2 => iw4_green(1),
      I3 => iw4_result_left(3),
      I4 => iw4_result_left(2),
      I5 => \r4_red[3]_i_34_n_0\,
      O => \r4_green[1]_i_3_n_0\
    );
\r4_green[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFEFEFE"
    )
        port map (
      I0 => \r4_green[2]_i_2_n_0\,
      I1 => \r4_green[2]_i_3_n_0\,
      I2 => \r4_red[2]_i_10_n_0\,
      I3 => \r4_red[3]_i_8_n_0\,
      I4 => iw4_green(2),
      O => r4_green(2)
    );
\r4_green[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_29_n_0\,
      I1 => \r4_red[3]_i_30_n_0\,
      I2 => iw4_green(2),
      I3 => iw4_result_right(3),
      I4 => iw4_result_right(2),
      I5 => \r4_red[3]_i_31_n_0\,
      O => \r4_green[2]_i_2_n_0\
    );
\r4_green[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_32_n_0\,
      I1 => \r4_red[2]_i_15_n_0\,
      I2 => iw4_green(2),
      I3 => iw4_result_left(3),
      I4 => iw4_result_left(2),
      I5 => \r4_red[3]_i_34_n_0\,
      O => \r4_green[2]_i_3_n_0\
    );
\r4_green[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFF8"
    )
        port map (
      I0 => \r4_red[3]_i_8_n_0\,
      I1 => iw4_green(3),
      I2 => \r4_green[3]_i_2_n_0\,
      I3 => \r4_green[3]_i_3_n_0\,
      O => r4_green(3)
    );
\r4_green[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_29_n_0\,
      I1 => \r4_red[3]_i_30_n_0\,
      I2 => iw4_green(3),
      I3 => iw4_result_right(3),
      I4 => iw4_result_right(2),
      I5 => \r4_red[3]_i_31_n_0\,
      O => \r4_green[3]_i_2_n_0\
    );
\r4_green[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_32_n_0\,
      I1 => \r4_red[3]_i_33_n_0\,
      I2 => iw4_green(3),
      I3 => iw4_result_left(3),
      I4 => iw4_result_left(2),
      I5 => \r4_red[3]_i_34_n_0\,
      O => \r4_green[3]_i_3_n_0\
    );
\r4_green_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => iw_pix_clk,
      CE => \r4_red[2]_i_2_n_0\,
      D => r4_green(0),
      Q => \r4_green_reg_n_0_[0]\,
      R => r4_blue(2)
    );
\r4_green_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => iw_pix_clk,
      CE => \r4_red[3]_i_2_n_0\,
      D => r4_green(1),
      Q => \r4_green_reg_n_0_[1]\,
      R => r4_blue(3)
    );
\r4_green_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => iw_pix_clk,
      CE => \r4_red[2]_i_2_n_0\,
      D => r4_green(2),
      Q => \r4_green_reg_n_0_[2]\,
      R => r4_blue(2)
    );
\r4_green_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => \r4_red[3]_i_2_n_0\,
      D => r4_green(3),
      Q => \r4_green_reg_n_0_[3]\,
      R => r4_blue(3)
    );
r4_red3_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => r4_red3_carry_n_0,
      CO(2) => r4_red3_carry_n_1,
      CO(1) => r4_red3_carry_n_2,
      CO(0) => r4_red3_carry_n_3,
      CYINIT => '1',
      DI(3) => r4_red3_carry_i_1_n_0,
      DI(2) => r4_red3_carry_i_2_n_0,
      DI(1) => r4_red3_carry_i_3_n_0,
      DI(0) => r4_red3_carry_i_4_n_0,
      O(3 downto 0) => NLW_r4_red3_carry_O_UNCONNECTED(3 downto 0),
      S(3) => r4_red3_carry_i_5_n_0,
      S(2) => r4_red3_carry_i_6_n_0,
      S(1) => r4_red3_carry_i_7_n_0,
      S(0) => r4_red3_carry_i_8_n_0
    );
\r4_red3_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => r4_red3_carry_n_0,
      CO(3 downto 2) => \NLW_r4_red3_carry__0_CO_UNCONNECTED\(3 downto 2),
      CO(1) => r4_red31_in,
      CO(0) => \r4_red3_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \r4_red3_carry__0_i_1_n_0\,
      DI(0) => \r4_red3_carry__0_i_2_n_0\,
      O(3 downto 0) => \NLW_r4_red3_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \r4_red3_carry__0_i_3_n_0\,
      S(0) => \r4_red3_carry__0_i_4_n_0\
    );
\r4_red3_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => r11_active_y_reg(10),
      I1 => iw11_block_right_pos(10),
      O => \r4_red3_carry__0_i_1_n_0\
    );
\r4_red3_carry__0_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_block_right_pos(9),
      I1 => iw11_block_right_pos(8),
      I2 => r11_active_y_reg(9),
      I3 => r11_active_y_reg(8),
      O => \r4_red3_carry__0_i_2_n_0\
    );
\r4_red3_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => iw11_block_right_pos(10),
      I1 => r11_active_y_reg(10),
      O => \r4_red3_carry__0_i_3_n_0\
    );
\r4_red3_carry__0_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => r11_active_y_reg(9),
      I1 => iw11_block_right_pos(9),
      I2 => r11_active_y_reg(8),
      I3 => iw11_block_right_pos(8),
      O => \r4_red3_carry__0_i_4_n_0\
    );
r4_red3_carry_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_block_right_pos(7),
      I1 => iw11_block_right_pos(6),
      I2 => r11_active_y_reg(7),
      I3 => r11_active_y_reg(6),
      O => r4_red3_carry_i_1_n_0
    );
r4_red3_carry_i_2: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_block_right_pos(5),
      I1 => iw11_block_right_pos(4),
      I2 => r11_active_y_reg(5),
      I3 => r11_active_y_reg(4),
      O => r4_red3_carry_i_2_n_0
    );
r4_red3_carry_i_3: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_block_right_pos(3),
      I1 => iw11_block_right_pos(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(2),
      O => r4_red3_carry_i_3_n_0
    );
r4_red3_carry_i_4: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7150"
    )
        port map (
      I0 => iw11_block_right_pos(1),
      I1 => iw11_block_right_pos(0),
      I2 => r11_active_y_reg(1),
      I3 => r11_active_y_reg(0),
      O => r4_red3_carry_i_4_n_0
    );
r4_red3_carry_i_5: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8241"
    )
        port map (
      I0 => iw11_block_right_pos(7),
      I1 => iw11_block_right_pos(6),
      I2 => r11_active_y_reg(6),
      I3 => r11_active_y_reg(7),
      O => r4_red3_carry_i_5_n_0
    );
r4_red3_carry_i_6: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8241"
    )
        port map (
      I0 => iw11_block_right_pos(5),
      I1 => iw11_block_right_pos(4),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(5),
      O => r4_red3_carry_i_6_n_0
    );
r4_red3_carry_i_7: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => r11_active_y_reg(3),
      I1 => iw11_block_right_pos(3),
      I2 => r11_active_y_reg(2),
      I3 => iw11_block_right_pos(2),
      O => r4_red3_carry_i_7_n_0
    );
r4_red3_carry_i_8: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8241"
    )
        port map (
      I0 => iw11_block_right_pos(1),
      I1 => iw11_block_right_pos(0),
      I2 => r11_active_y_reg(0),
      I3 => r11_active_y_reg(1),
      O => r4_red3_carry_i_8_n_0
    );
\r4_red3_inferred__0/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \r4_red3_inferred__0/i__carry_n_0\,
      CO(2) => \r4_red3_inferred__0/i__carry_n_1\,
      CO(1) => \r4_red3_inferred__0/i__carry_n_2\,
      CO(0) => \r4_red3_inferred__0/i__carry_n_3\,
      CYINIT => '1',
      DI(3) => \i__carry_i_1__0_n_0\,
      DI(2) => \i__carry_i_2__0_n_0\,
      DI(1) => \i__carry_i_3__1_n_0\,
      DI(0) => \i__carry_i_4__1_n_0\,
      O(3 downto 0) => \NLW_r4_red3_inferred__0/i__carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_5__0_n_0\,
      S(2) => \i__carry_i_6__0_n_0\,
      S(1) => \i__carry_i_7_n_0\,
      S(0) => \i__carry_i_8__1_n_0\
    );
\r4_red3_inferred__0/i__carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \r4_red3_inferred__0/i__carry_n_0\,
      CO(3 downto 2) => \NLW_r4_red3_inferred__0/i__carry__0_CO_UNCONNECTED\(3 downto 2),
      CO(1) => r4_red35_in,
      CO(0) => \r4_red3_inferred__0/i__carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \i__carry__0_i_1__0_n_0\,
      DI(0) => \i__carry__0_i_2__0_n_0\,
      O(3 downto 0) => \NLW_r4_red3_inferred__0/i__carry__0_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \i__carry__0_i_3__0_n_0\,
      S(0) => \i__carry__0_i_4__0_n_0\
    );
\r4_red3_inferred__1/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \r4_red3_inferred__1/i__carry_n_0\,
      CO(2) => \r4_red3_inferred__1/i__carry_n_1\,
      CO(1) => \r4_red3_inferred__1/i__carry_n_2\,
      CO(0) => \r4_red3_inferred__1/i__carry_n_3\,
      CYINIT => '1',
      DI(3) => \i__carry_i_1_n_0\,
      DI(2) => \i__carry_i_2_n_0\,
      DI(1) => \i__carry_i_3__0_n_0\,
      DI(0) => \i__carry_i_4__0_n_0\,
      O(3 downto 0) => \NLW_r4_red3_inferred__1/i__carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_5_n_0\,
      S(2) => \i__carry_i_6_n_0\,
      S(1) => \i__carry_i_7__1_n_0\,
      S(0) => \i__carry_i_8__0_n_0\
    );
\r4_red3_inferred__1/i__carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \r4_red3_inferred__1/i__carry_n_0\,
      CO(3 downto 2) => \NLW_r4_red3_inferred__1/i__carry__0_CO_UNCONNECTED\(3 downto 2),
      CO(1) => r4_red310_in,
      CO(0) => \r4_red3_inferred__1/i__carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \i__carry__0_i_1__1_n_0\,
      DI(0) => \i__carry__0_i_2_n_0\,
      O(3 downto 0) => \NLW_r4_red3_inferred__1/i__carry__0_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \i__carry__0_i_3__1_n_0\,
      S(0) => \i__carry__0_i_4__1_n_0\
    );
\r4_red3_inferred__2/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \r4_red3_inferred__2/i__carry_n_0\,
      CO(2) => \r4_red3_inferred__2/i__carry_n_1\,
      CO(1) => \r4_red3_inferred__2/i__carry_n_2\,
      CO(0) => \r4_red3_inferred__2/i__carry_n_3\,
      CYINIT => '1',
      DI(3) => \i__carry_i_1__2_n_0\,
      DI(2) => \i__carry_i_2__1_n_0\,
      DI(1) => \i__carry_i_3_n_0\,
      DI(0) => \i__carry_i_4_n_0\,
      O(3 downto 0) => \NLW_r4_red3_inferred__2/i__carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_5__1_n_0\,
      S(2) => \i__carry_i_6__1_n_0\,
      S(1) => \i__carry_i_7__0_n_0\,
      S(0) => \i__carry_i_8_n_0\
    );
\r4_red3_inferred__2/i__carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \r4_red3_inferred__2/i__carry_n_0\,
      CO(3 downto 2) => \NLW_r4_red3_inferred__2/i__carry__0_CO_UNCONNECTED\(3 downto 2),
      CO(1) => r4_red311_in,
      CO(0) => \r4_red3_inferred__2/i__carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \i__carry__0_i_1__2_n_0\,
      DI(0) => \i__carry__0_i_2__2_n_0\,
      O(3 downto 0) => \NLW_r4_red3_inferred__2/i__carry__0_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \i__carry__0_i_3__2_n_0\,
      S(0) => \i__carry__0_i_4__2_n_0\
    );
\r4_red[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFEFEFE"
    )
        port map (
      I0 => \r4_red[0]_i_2_n_0\,
      I1 => \r4_red[0]_i_3_n_0\,
      I2 => \r4_red[2]_i_10_n_0\,
      I3 => \r4_red[3]_i_8_n_0\,
      I4 => iw4_red(0),
      O => r4_red(0)
    );
\r4_red[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_29_n_0\,
      I1 => \r4_red[3]_i_30_n_0\,
      I2 => iw4_red(0),
      I3 => iw4_result_right(3),
      I4 => iw4_result_right(2),
      I5 => \r4_red[3]_i_31_n_0\,
      O => \r4_red[0]_i_2_n_0\
    );
\r4_red[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_32_n_0\,
      I1 => \r4_red[2]_i_15_n_0\,
      I2 => iw4_red(0),
      I3 => iw4_result_left(3),
      I4 => iw4_result_left(2),
      I5 => \r4_red[3]_i_34_n_0\,
      O => \r4_red[0]_i_3_n_0\
    );
\r4_red[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFF8"
    )
        port map (
      I0 => \r4_red[3]_i_8_n_0\,
      I1 => iw4_red(1),
      I2 => \r4_red[1]_i_2_n_0\,
      I3 => \r4_red[1]_i_3_n_0\,
      O => r4_red(1)
    );
\r4_red[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_29_n_0\,
      I1 => \r4_red[3]_i_30_n_0\,
      I2 => iw4_red(1),
      I3 => iw4_result_right(3),
      I4 => iw4_result_right(2),
      I5 => \r4_red[3]_i_31_n_0\,
      O => \r4_red[1]_i_2_n_0\
    );
\r4_red[1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_32_n_0\,
      I1 => \r4_red[3]_i_33_n_0\,
      I2 => iw4_red(1),
      I3 => iw4_result_left(3),
      I4 => iw4_result_left(2),
      I5 => \r4_red[3]_i_34_n_0\,
      O => \r4_red[1]_i_3_n_0\
    );
\r4_red[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF8AAA00000000"
    )
        port map (
      I0 => \r4_red[2]_i_4_n_0\,
      I1 => \r4_red[2]_i_5_n_0\,
      I2 => r11_active_x_reg(8),
      I3 => r11_active_x_reg(9),
      I4 => \r4_red[2]_i_6_n_0\,
      I5 => \r4_red[2]_i_7_n_0\,
      O => r4_blue(2)
    );
\r4_red[2]_i_10\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0800"
    )
        port map (
      I0 => \r4_red[3]_i_4_n_0\,
      I1 => State(0),
      I2 => State(1),
      I3 => \r4_red[3]_i_11_n_0\,
      O => \r4_red[2]_i_10_n_0\
    );
\r4_red[2]_i_11\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CCCCCCC8"
    )
        port map (
      I0 => \r4_red[2]_i_16_n_0\,
      I1 => r11_active_x_reg(8),
      I2 => r11_active_x_reg(7),
      I3 => r11_active_x_reg(5),
      I4 => r11_active_x_reg(6),
      O => \r4_red[2]_i_11_n_0\
    );
\r4_red[2]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => r11_active_x_reg(6),
      I1 => r11_active_x_reg(5),
      O => \r4_red[2]_i_12_n_0\
    );
\r4_red[2]_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFD"
    )
        port map (
      I0 => \r4_red[3]_i_66_n_0\,
      I1 => r11_active_x_reg(7),
      I2 => \r4_red[2]_i_12_n_0\,
      I3 => r11_active_x_reg(8),
      I4 => \r4_red[3]_i_38_n_0\,
      I5 => \p_1_out_inferred__0/i__carry__1_n_0\,
      O => \r4_red[2]_i_13_n_0\
    );
\r4_red[2]_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEE00000000"
    )
        port map (
      I0 => \r4_red[3]_i_38_n_0\,
      I1 => \r4_red[2]_i_16_n_0\,
      I2 => r11_active_x_reg(1),
      I3 => r11_active_x_reg(3),
      I4 => \r4_red[2]_i_17_n_0\,
      I5 => r4_red35_in,
      O => \r4_red[2]_i_14_n_0\
    );
\r4_red[2]_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFEAAAAA"
    )
        port map (
      I0 => \r4_red[2]_i_18_n_0\,
      I1 => \r4_red[3]_i_25_n_0\,
      I2 => \r4_red[3]_i_22_n_0\,
      I3 => \r4_red[3]_i_83_n_0\,
      I4 => iw4_result_left(3),
      I5 => \r4_red[2]_i_19_n_0\,
      O => \r4_red[2]_i_15_n_0\
    );
\r4_red[2]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(2),
      I2 => r11_active_x_reg(3),
      O => \r4_red[2]_i_16_n_0\
    );
\r4_red[2]_i_17\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => r11_active_x_reg(7),
      I1 => r11_active_x_reg(6),
      I2 => r11_active_x_reg(5),
      I3 => r11_active_x_reg(8),
      O => \r4_red[2]_i_17_n_0\
    );
\r4_red[2]_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFEA00"
    )
        port map (
      I0 => \r4_red[2]_i_20_n_0\,
      I1 => \r4_red[3]_i_160_n_0\,
      I2 => \r4_red[2]_i_21_n_0\,
      I3 => \r4_red[3]_i_161_n_0\,
      I4 => \r4_red[3]_i_162_n_0\,
      I5 => \r4_red[3]_i_163_n_0\,
      O => \r4_red[2]_i_18_n_0\
    );
\r4_red[2]_i_19\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010000"
    )
        port map (
      I0 => iw4_result_left(1),
      I1 => iw4_result_left(2),
      I2 => iw4_result_left(3),
      I3 => iw4_result_left(0),
      I4 => \r4_red[3]_i_5_n_0\,
      O => \r4_red[2]_i_19_n_0\
    );
\r4_red[2]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"5F5D"
    )
        port map (
      I0 => State(0),
      I1 => \r4_red[3]_i_4_n_0\,
      I2 => State(1),
      I3 => \r4_red[3]_i_7_n_0\,
      O => \r4_red[2]_i_2_n_0\
    );
\r4_red[2]_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4044400044444444"
    )
        port map (
      I0 => iw4_result_left(1),
      I1 => iw4_result_left(0),
      I2 => \r4_red[3]_i_237_n_0\,
      I3 => \r4_red[3]_i_47_n_0\,
      I4 => \r4_red[3]_i_238_n_0\,
      I5 => \r4_red[3]_i_50_n_0\,
      O => \r4_red[2]_i_20_n_0\
    );
\r4_red[2]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => iw4_result_left(1),
      I1 => iw4_result_left(0),
      O => \r4_red[2]_i_21_n_0\
    );
\r4_red[2]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFEFEFE"
    )
        port map (
      I0 => \r4_red[2]_i_8_n_0\,
      I1 => \r4_red[2]_i_9_n_0\,
      I2 => \r4_red[2]_i_10_n_0\,
      I3 => \r4_red[3]_i_8_n_0\,
      I4 => iw4_red(2),
      O => r4_red(2)
    );
\r4_red[2]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00200000"
    )
        port map (
      I0 => r11_active_x_reg(9),
      I1 => r11_active_x_reg(10),
      I2 => r4_red31_in,
      I3 => \p_1_out_carry__1_n_0\,
      I4 => \r4_red[2]_i_11_n_0\,
      O => \r4_red[2]_i_4_n_0\
    );
\r4_red[2]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000001F3F"
    )
        port map (
      I0 => r11_active_x_reg(2),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(1),
      I4 => r11_active_x_reg(7),
      I5 => \r4_red[2]_i_12_n_0\,
      O => \r4_red[2]_i_5_n_0\
    );
\r4_red[2]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1000FFFF10001000"
    )
        port map (
      I0 => \p_1_out_inferred__2/i___0_carry__1_n_0\,
      I1 => \p_1_out_inferred__1/i___0_carry__1_n_0\,
      I2 => r4_red311_in,
      I3 => r4_red310_in,
      I4 => \r4_red[2]_i_13_n_0\,
      I5 => \r4_red[2]_i_14_n_0\,
      O => \r4_red[2]_i_6_n_0\
    );
\r4_red[2]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => State(0),
      I1 => State(1),
      O => \r4_red[2]_i_7_n_0\
    );
\r4_red[2]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_29_n_0\,
      I1 => \r4_red[3]_i_30_n_0\,
      I2 => iw4_red(2),
      I3 => iw4_result_right(3),
      I4 => iw4_result_right(2),
      I5 => \r4_red[3]_i_31_n_0\,
      O => \r4_red[2]_i_8_n_0\
    );
\r4_red[2]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_32_n_0\,
      I1 => \r4_red[2]_i_15_n_0\,
      I2 => iw4_red(2),
      I3 => iw4_result_left(3),
      I4 => iw4_result_left(2),
      I5 => \r4_red[3]_i_34_n_0\,
      O => \r4_red[2]_i_9_n_0\
    );
\r4_red[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AEAAFFFFAEAAAEAA"
    )
        port map (
      I0 => r4_blue(2),
      I1 => \r4_red[3]_i_4_n_0\,
      I2 => State(1),
      I3 => State(0),
      I4 => \r4_red[3]_i_5_n_0\,
      I5 => \r4_red[3]_i_6_n_0\,
      O => r4_blue(3)
    );
\r4_red[3]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_32_n_0\,
      I1 => \r4_red[3]_i_33_n_0\,
      I2 => iw4_red(3),
      I3 => iw4_result_left(3),
      I4 => iw4_result_left(2),
      I5 => \r4_red[3]_i_34_n_0\,
      O => \r4_red[3]_i_10_n_0\
    );
\r4_red[3]_i_100\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000380000000"
    )
        port map (
      I0 => \r4_red[3]_i_187_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(4),
      I5 => \r4_red[3]_i_188_n_0\,
      O => \r4_red[3]_i_100_n_0\
    );
\r4_red[3]_i_101\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"222E222822222228"
    )
        port map (
      I0 => \r4_red[3]_i_189_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(2),
      I5 => \r4_red[3]_i_190_n_0\,
      O => \r4_red[3]_i_101_n_0\
    );
\r4_red[3]_i_102\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2000000C20000000"
    )
        port map (
      I0 => \r4_red[3]_i_191_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(4),
      I5 => \r4_red[3]_i_192_n_0\,
      O => \r4_red[3]_i_102_n_0\
    );
\r4_red[3]_i_103\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8380000380800000"
    )
        port map (
      I0 => \r4_red[3]_i_193_n_0\,
      I1 => r11_active_x_reg(2),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(4),
      I4 => r11_active_x_reg(5),
      I5 => \r4_red[3]_i_194_n_0\,
      O => \r4_red[3]_i_103_n_0\
    );
\r4_red[3]_i_104\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0E00000002000000"
    )
        port map (
      I0 => \r4_red[3]_i_195_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(4),
      I5 => \r4_red[3]_i_196_n_0\,
      O => \r4_red[3]_i_104_n_0\
    );
\r4_red[3]_i_105\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CC4C444C"
    )
        port map (
      I0 => \r4_red[3]_i_108_n_0\,
      I1 => \r4_red[3]_i_113_n_0\,
      I2 => \r4_red[3]_i_186_n_0\,
      I3 => \r4_red[3]_i_184_n_0\,
      I4 => \r4_red[3]_i_197_n_0\,
      I5 => \r4_red[3]_i_109_n_0\,
      O => \r4_red[3]_i_105_n_0\
    );
\r4_red[3]_i_106\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0080030000800000"
    )
        port map (
      I0 => \r4_red[3]_i_198_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(4),
      I5 => \r4_red[3]_i_199_n_0\,
      O => \r4_red[3]_i_106_n_0\
    );
\r4_red[3]_i_107\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0030002000000020"
    )
        port map (
      I0 => \r4_red[3]_i_195_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(4),
      I5 => \r4_red[3]_i_199_n_0\,
      O => \r4_red[3]_i_107_n_0\
    );
\r4_red[3]_i_108\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"01FE"
    )
        port map (
      I0 => r11_active_x_reg(2),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(5),
      O => \r4_red[3]_i_108_n_0\
    );
\r4_red[3]_i_109\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => r11_active_x_reg(2),
      I1 => r11_active_x_reg(3),
      O => \r4_red[3]_i_109_n_0\
    );
\r4_red[3]_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFF0FF02"
    )
        port map (
      I0 => \r4_red[3]_i_35_n_0\,
      I1 => r11_active_y_reg(7),
      I2 => r11_active_y_reg(9),
      I3 => r11_active_y_reg(10),
      I4 => r11_active_y_reg(8),
      I5 => \r4_red[3]_i_36_n_0\,
      O => \r4_red[3]_i_11_n_0\
    );
\r4_red[3]_i_110\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"01054000"
    )
        port map (
      I0 => r11_active_y_reg(5),
      I1 => r11_active_y_reg(1),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(4),
      O => \r4_red[3]_i_110_n_0\
    );
\r4_red[3]_i_111\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4444444444444442"
    )
        port map (
      I0 => r11_active_x_reg(7),
      I1 => r11_active_x_reg(6),
      I2 => r11_active_x_reg(5),
      I3 => r11_active_x_reg(4),
      I4 => r11_active_x_reg(3),
      I5 => r11_active_x_reg(2),
      O => \r4_red[3]_i_111_n_0\
    );
\r4_red[3]_i_112\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9190901091909090"
    )
        port map (
      I0 => r11_active_x_reg(3),
      I1 => r11_active_x_reg(2),
      I2 => \r4_red[3]_i_184_n_0\,
      I3 => \r4_red[3]_i_185_n_0\,
      I4 => \r4_red[3]_i_186_n_0\,
      I5 => \r4_red[3]_i_200_n_0\,
      O => \r4_red[3]_i_112_n_0\
    );
\r4_red[3]_i_113\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"56"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(2),
      O => \r4_red[3]_i_113_n_0\
    );
\r4_red[3]_i_114\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"22242004"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(3),
      I4 => \r4_red[3]_i_110_n_0\,
      O => \r4_red[3]_i_114_n_0\
    );
\r4_red[3]_i_115\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0302C000"
    )
        port map (
      I0 => \r4_red[3]_i_201_n_0\,
      I1 => r11_active_x_reg(2),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(5),
      I4 => r11_active_x_reg(4),
      O => \r4_red[3]_i_115_n_0\
    );
\r4_red[3]_i_116\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0F00040000000400"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => \r4_red[3]_i_190_n_0\,
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(2),
      I5 => \r4_red[3]_i_202_n_0\,
      O => \r4_red[3]_i_116_n_0\
    );
\r4_red[3]_i_117\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A88888BAA888888A"
    )
        port map (
      I0 => \r4_red[3]_i_110_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(4),
      I5 => \r4_red[3]_i_203_n_0\,
      O => \r4_red[3]_i_117_n_0\
    );
\r4_red[3]_i_118\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555555555555556"
    )
        port map (
      I0 => r11_active_x_reg(7),
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(6),
      I3 => r11_active_x_reg(4),
      I4 => r11_active_x_reg(3),
      I5 => r11_active_x_reg(2),
      O => \r4_red[3]_i_118_n_0\
    );
\r4_red[3]_i_119\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0001FFFE"
    )
        port map (
      I0 => r11_active_x_reg(2),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(5),
      I4 => r11_active_x_reg(6),
      O => \r4_red[3]_i_119_n_0\
    );
\r4_red[3]_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00FF4FFF00FFFFFF"
    )
        port map (
      I0 => r11_active_y_reg(2),
      I1 => \r11_active_y[7]_i_3_n_0\,
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(6),
      I4 => r11_active_y_reg(5),
      I5 => r11_active_y_reg(4),
      O => \r4_red[3]_i_12_n_0\
    );
\r4_red[3]_i_120\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"07FF"
    )
        port map (
      I0 => r11_active_y_reg(3),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(5),
      O => \r4_red[3]_i_120_n_0\
    );
\r4_red[3]_i_121\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0101000101010101"
    )
        port map (
      I0 => r11_active_y_reg(10),
      I1 => r11_active_y_reg(9),
      I2 => \r4_red[3]_i_38_n_0\,
      I3 => \r4_red[2]_i_16_n_0\,
      I4 => \r4_red[3]_i_57_n_0\,
      I5 => r11_active_x_reg(5),
      O => \r4_red[3]_i_121_n_0\
    );
\r4_red[3]_i_122\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F800"
    )
        port map (
      I0 => r11_active_y_reg(3),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(5),
      O => \r4_red[3]_i_122_n_0\
    );
\r4_red[3]_i_123\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4444400022222AAA"
    )
        port map (
      I0 => r11_active_x_reg(7),
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(4),
      I5 => r11_active_x_reg(6),
      O => \r4_red[3]_i_123_n_0\
    );
\r4_red[3]_i_124\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF00C0880000C088"
    )
        port map (
      I0 => \p_0_out_inferred__4/r4_red[3]_i_204_n_0\,
      I1 => \r4_red[3]_i_205_n_0\,
      I2 => \p_0_out_inferred__4/r4_red[3]_i_206_n_0\,
      I3 => \r4_red[3]_i_207_n_0\,
      I4 => \r4_red[3]_i_208_n_0\,
      I5 => \r4_red[3]_i_209_n_0\,
      O => \r4_red[3]_i_124_n_0\
    );
\r4_red[3]_i_125\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0320000000200000"
    )
        port map (
      I0 => \p_0_out_inferred__4/r4_red[3]_i_210_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(4),
      I5 => \p_0_out_inferred__4/r4_red[3]_i_211_n_0\,
      O => \r4_red[3]_i_125_n_0\
    );
\r4_red[3]_i_126\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \r4_red[3]_i_212_n_0\,
      I1 => \r4_red[3]_i_213_n_0\,
      I2 => \r4_red[3]_i_214_n_0\,
      I3 => \r4_red[3]_i_215_n_0\,
      O => \r4_red[3]_i_126_n_0\
    );
\r4_red[3]_i_127\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAA88A888"
    )
        port map (
      I0 => \r4_red[3]_i_216_n_0\,
      I1 => \r4_red[3]_i_217_n_0\,
      I2 => \r4_red[3]_i_218_n_0\,
      I3 => \r4_red[3]_i_208_n_0\,
      I4 => \r4_red[3]_i_219_n_0\,
      I5 => \r4_red[3]_i_220_n_0\,
      O => \r4_red[3]_i_127_n_0\
    );
\r4_red[3]_i_128\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0880808000000000"
    )
        port map (
      I0 => \r4_red[3]_i_221_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(2),
      I5 => \r4_red[3]_i_68_n_0\,
      O => \r4_red[3]_i_128_n_0\
    );
\r4_red[3]_i_129\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C000FF88C0000088"
    )
        port map (
      I0 => \p_0_out_inferred__4/r4_red[3]_i_222_n_0\,
      I1 => \r4_red[3]_i_205_n_0\,
      I2 => \p_0_out_inferred__4/r4_red[3]_i_223_n_0\,
      I3 => \r4_red[3]_i_208_n_0\,
      I4 => \r4_red[3]_i_207_n_0\,
      I5 => \r4_red[3]_i_224_n_0\,
      O => \r4_red[3]_i_129_n_0\
    );
\r4_red[3]_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002020200"
    )
        port map (
      I0 => r4_red434_in,
      I1 => r11_active_y_reg(7),
      I2 => \r4_red[3]_i_38_n_0\,
      I3 => \r4_red[3]_i_39_n_0\,
      I4 => \r4_red[3]_i_40_n_0\,
      I5 => \r4_red[3]_i_41_n_0\,
      O => \r4_red[3]_i_13_n_0\
    );
\r4_red[3]_i_130\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFE00FE00FE00"
    )
        port map (
      I0 => \r4_red[3]_i_225_n_0\,
      I1 => \r4_red[3]_i_226_n_0\,
      I2 => \r4_red[3]_i_227_n_0\,
      I3 => \r4_red[3]_i_228_n_0\,
      I4 => \r4_red[3]_i_229_n_0\,
      I5 => \r4_red[3]_i_230_n_0\,
      O => \r4_red[3]_i_130_n_0\
    );
\r4_red[3]_i_131\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFAACC00F0AACC00"
    )
        port map (
      I0 => \r4_red[3]_i_231_n_0\,
      I1 => \r4_red[3]_i_232_n_0\,
      I2 => \r4_red[3]_i_233_n_0\,
      I3 => \r4_red[3]_i_208_n_0\,
      I4 => \r4_red[3]_i_207_n_0\,
      I5 => \r4_red[3]_i_234_n_0\,
      O => \r4_red[3]_i_131_n_0\
    );
\r4_red[3]_i_132\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2A22008800008888"
    )
        port map (
      I0 => \r4_red[3]_i_235_n_0\,
      I1 => r11_active_y_reg(5),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(3),
      I5 => r11_active_y_reg(6),
      O => \r4_red[3]_i_132_n_0\
    );
\r4_red[3]_i_133\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1540"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => r11_active_x_reg(2),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(4),
      O => \r4_red[3]_i_133_n_0\
    );
\r4_red[3]_i_134\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2A22208000028A88"
    )
        port map (
      I0 => \r4_red[3]_i_236_n_0\,
      I1 => r11_active_y_reg(5),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(3),
      I5 => r11_active_y_reg(6),
      O => \r4_red[3]_i_134_n_0\
    );
\r4_red[3]_i_135\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => r11_active_x_reg(3),
      I1 => r11_active_x_reg(2),
      O => \r4_red[3]_i_135_n_0\
    );
\r4_red[3]_i_136\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FD5D"
    )
        port map (
      I0 => \r4_red[3]_i_157_n_0\,
      I1 => \r4_red[3]_i_237_n_0\,
      I2 => \r4_red[3]_i_47_n_0\,
      I3 => \r4_red[3]_i_238_n_0\,
      O => \r4_red[3]_i_136_n_0\
    );
\r4_red[3]_i_137\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFAEFFAEFFFFFFAE"
    )
        port map (
      I0 => \r4_red[3]_i_145_n_0\,
      I1 => \r4_red[3]_i_239_n_0\,
      I2 => \g0_b1__4_n_0\,
      I3 => \r4_red[3]_i_240_n_0\,
      I4 => \r4_red[3]_i_241_n_0\,
      I5 => \g0_b3__2_n_0\,
      O => \r4_red[3]_i_137_n_0\
    );
\r4_red[3]_i_138\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF22F2"
    )
        port map (
      I0 => \r4_red[3]_i_242_n_0\,
      I1 => g0_b2_n_0,
      I2 => \r4_red[3]_i_243_n_0\,
      I3 => \g0_b0__0_n_0\,
      I4 => \r4_red[3]_i_244_n_0\,
      O => \r4_red[3]_i_138_n_0\
    );
\r4_red[3]_i_139\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF2020FF20"
    )
        port map (
      I0 => \r4_red[3]_i_245_n_0\,
      I1 => \r4_red[3]_i_47_n_0\,
      I2 => \r4_red[3]_i_157_n_0\,
      I3 => \r4_red[3]_i_158_n_0\,
      I4 => g0_b1_n_0,
      I5 => \r4_red[3]_i_246_n_0\,
      O => \r4_red[3]_i_139_n_0\
    );
\r4_red[3]_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF05150555"
    )
        port map (
      I0 => \r4_red[2]_i_12_n_0\,
      I1 => r11_active_x_reg(1),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(2),
      I5 => \r4_red[3]_i_42_n_0\,
      O => \r4_red[3]_i_14_n_0\
    );
\r4_red[3]_i_140\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF2222FFF2"
    )
        port map (
      I0 => \r4_red[3]_i_247_n_0\,
      I1 => r4_red2(0),
      I2 => \r4_red[3]_i_242_n_0\,
      I3 => \r4_red[3]_i_144_n_0\,
      I4 => r4_red2(1),
      I5 => \r4_red[3]_i_248_n_0\,
      O => \r4_red[3]_i_140_n_0\
    );
\r4_red[3]_i_141\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFF4"
    )
        port map (
      I0 => \g0_b4__2_n_0\,
      I1 => \r4_red[3]_i_144_n_0\,
      I2 => \r4_red[3]_i_145_n_0\,
      I3 => \r4_red[3]_i_249_n_0\,
      I4 => \r4_red[3]_i_250_n_0\,
      O => \r4_red[3]_i_141_n_0\
    );
\r4_red[3]_i_142\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0123FFFF01230123"
    )
        port map (
      I0 => \r4_red[3]_i_49_n_0\,
      I1 => \r4_red[3]_i_157_n_0\,
      I2 => \g0_b5__0_n_0\,
      I3 => g0_b6_n_0,
      I4 => r4_red2(2),
      I5 => \r4_red[3]_i_158_n_0\,
      O => \r4_red[3]_i_142_n_0\
    );
\r4_red[3]_i_143\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFF22F2"
    )
        port map (
      I0 => \r4_red[3]_i_242_n_0\,
      I1 => \g0_b1__4_n_0\,
      I2 => \r4_red[3]_i_243_n_0\,
      I3 => \g0_b3__2_n_0\,
      I4 => \r4_red[3]_i_145_n_0\,
      I5 => \r4_red[3]_i_251_n_0\,
      O => \r4_red[3]_i_143_n_0\
    );
\r4_red[3]_i_144\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4440000000000008"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(0),
      I3 => r11_active_x_reg(1),
      I4 => r11_active_x_reg(2),
      I5 => r11_active_x_reg(3),
      O => \r4_red[3]_i_144_n_0\
    );
\r4_red[3]_i_145\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FE000001"
    )
        port map (
      I0 => \r4_red[3]_i_91_n_0\,
      I1 => r11_active_x_reg(2),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(4),
      I4 => r11_active_x_reg(5),
      I5 => \g0_b0__4_n_0\,
      O => \r4_red[3]_i_145_n_0\
    );
\r4_red[3]_i_146\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0550033000000000"
    )
        port map (
      I0 => \g0_b0__1_n_0\,
      I1 => \g0_b2__0_n_0\,
      I2 => \r4_red[3]_i_91_n_0\,
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => \r4_red[3]_i_252_n_0\,
      O => \r4_red[3]_i_146_n_0\
    );
\r4_red[3]_i_147\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0123FFFF01230123"
    )
        port map (
      I0 => \r4_red[3]_i_49_n_0\,
      I1 => \r4_red[3]_i_157_n_0\,
      I2 => \g0_b5__1_n_0\,
      I3 => \g0_b6__0_n_0\,
      I4 => \g0_b1__0_n_0\,
      I5 => \r4_red[3]_i_158_n_0\,
      O => \r4_red[3]_i_147_n_0\
    );
\r4_red[3]_i_148\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0550033000000000"
    )
        port map (
      I0 => \g0_b0__2_n_0\,
      I1 => \g0_b2__1_n_0\,
      I2 => \r4_red[3]_i_91_n_0\,
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => \r4_red[3]_i_252_n_0\,
      O => \r4_red[3]_i_148_n_0\
    );
\r4_red[3]_i_149\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0123FFFF01230123"
    )
        port map (
      I0 => \r4_red[3]_i_49_n_0\,
      I1 => \r4_red[3]_i_157_n_0\,
      I2 => r4_red2(2),
      I3 => r4_red2(3),
      I4 => \g0_b1__1_n_0\,
      I5 => \r4_red[3]_i_158_n_0\,
      O => \r4_red[3]_i_149_n_0\
    );
\r4_red[3]_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF00FD00000000"
    )
        port map (
      I0 => \r11_active_y[7]_i_3_n_0\,
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(2),
      I3 => \r4_red[3]_i_43_n_0\,
      I4 => \r4_red[3]_i_44_n_0\,
      I5 => r4_red434_in,
      O => \r4_red[3]_i_15_n_0\
    );
\r4_red[3]_i_150\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000AA8AF3C3"
    )
        port map (
      I0 => \r4_red[3]_i_48_n_0\,
      I1 => g0_b0_i_3_n_0,
      I2 => g0_b0_i_4_n_0,
      I3 => g0_b0_i_2_n_0,
      I4 => \r4_red[3]_i_157_n_0\,
      I5 => \r4_red[3]_i_49_n_0\,
      O => \r4_red[3]_i_150_n_0\
    );
\r4_red[3]_i_151\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF2FF0FF22222022"
    )
        port map (
      I0 => \r4_red[3]_i_252_n_0\,
      I1 => \r4_red[3]_i_253_n_0\,
      I2 => g0_b0_i_2_n_0,
      I3 => g0_b0_i_4_n_0,
      I4 => g0_b0_i_3_n_0,
      I5 => \r4_red[3]_i_254_n_0\,
      O => \r4_red[3]_i_151_n_0\
    );
\r4_red[3]_i_152\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9989998999899895"
    )
        port map (
      I0 => r11_active_y_reg(5),
      I1 => r11_active_y_reg(4),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(3),
      I4 => r11_active_y_reg(1),
      I5 => r11_active_y_reg(0),
      O => \r4_red[3]_i_152_n_0\
    );
\r4_red[3]_i_153\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEAA00000000FAA8"
    )
        port map (
      I0 => g0_b0_i_3_n_0,
      I1 => g0_b0_i_1_n_0,
      I2 => g0_b0_i_4_n_0,
      I3 => g0_b0_i_2_n_0,
      I4 => \r4_red[3]_i_48_n_0\,
      I5 => \r4_red[3]_i_49_n_0\,
      O => \r4_red[3]_i_153_n_0\
    );
\r4_red[3]_i_154\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"02AAAAAAA8000000"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => r11_active_x_reg(0),
      I2 => r11_active_x_reg(1),
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => r11_active_x_reg(4),
      O => \r4_red[3]_i_154_n_0\
    );
\r4_red[3]_i_155\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"ABABABFBABABABAB"
    )
        port map (
      I0 => \r4_red[3]_i_255_n_0\,
      I1 => \g0_b7__0_n_0\,
      I2 => \r4_red[3]_i_157_n_0\,
      I3 => \g0_b3__0_n_0\,
      I4 => \r4_red[3]_i_253_n_0\,
      I5 => \r4_red[3]_i_47_n_0\,
      O => \r4_red[3]_i_155_n_0\
    );
\r4_red[3]_i_156\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"305305333F53F533"
    )
        port map (
      I0 => \g0_b6__3_n_0\,
      I1 => \g0_b6__1_n_0\,
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(3),
      I4 => \r4_red[3]_i_91_n_0\,
      I5 => \g0_b4__1_n_0\,
      O => \r4_red[3]_i_156_n_0\
    );
\r4_red[3]_i_157\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AA95AA95AA95AA55"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => r11_active_x_reg(2),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(4),
      I4 => r11_active_x_reg(0),
      I5 => r11_active_x_reg(1),
      O => \r4_red[3]_i_157_n_0\
    );
\r4_red[3]_i_158\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000010101004"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(1),
      I4 => r11_active_x_reg(0),
      I5 => r11_active_x_reg(5),
      O => \r4_red[3]_i_158_n_0\
    );
\r4_red[3]_i_159\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000B8FF"
    )
        port map (
      I0 => \r4_red[3]_i_237_n_0\,
      I1 => \r4_red[3]_i_47_n_0\,
      I2 => \r4_red[3]_i_238_n_0\,
      I3 => \r4_red[3]_i_50_n_0\,
      I4 => iw4_result_left(1),
      O => \r4_red[3]_i_159_n_0\
    );
\r4_red[3]_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0101010101010001"
    )
        port map (
      I0 => \r4_red[3]_i_45_n_0\,
      I1 => \r4_red[3]_i_38_n_0\,
      I2 => r11_active_y_reg(6),
      I3 => \r4_red[3]_i_46_n_0\,
      I4 => \r4_red[3]_i_43_n_0\,
      I5 => \r11_active_y[7]_i_2_n_0\,
      O => \r4_red[3]_i_16_n_0\
    );
\r4_red[3]_i_160\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFEEEEEEE"
    )
        port map (
      I0 => \r4_red[3]_i_256_n_0\,
      I1 => \r4_red[3]_i_257_n_0\,
      I2 => \r4_red[3]_i_245_n_0\,
      I3 => \r4_red[3]_i_47_n_0\,
      I4 => \r4_red[3]_i_50_n_0\,
      I5 => \r4_red[3]_i_258_n_0\,
      O => \r4_red[3]_i_160_n_0\
    );
\r4_red[3]_i_161\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => iw4_result_left(2),
      I1 => iw4_result_left(3),
      O => \r4_red[3]_i_161_n_0\
    );
\r4_red[3]_i_162\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAA88A8"
    )
        port map (
      I0 => \r4_red[3]_i_259_n_0\,
      I1 => \r4_red[3]_i_260_n_0\,
      I2 => \r4_red[3]_i_167_n_0\,
      I3 => r4_red2(2),
      I4 => \r4_red[3]_i_166_n_0\,
      I5 => \r4_red[3]_i_261_n_0\,
      O => \r4_red[3]_i_162_n_0\
    );
\r4_red[3]_i_163\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAA88A8"
    )
        port map (
      I0 => \r4_red[3]_i_262_n_0\,
      I1 => \r4_red[3]_i_263_n_0\,
      I2 => \r4_red[3]_i_167_n_0\,
      I3 => r4_red2(2),
      I4 => \r4_red[3]_i_166_n_0\,
      I5 => \r4_red[3]_i_264_n_0\,
      O => \r4_red[3]_i_163_n_0\
    );
\r4_red[3]_i_164\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF2FFF2FFFFFFF2"
    )
        port map (
      I0 => \r4_red[3]_i_265_n_0\,
      I1 => \g0_b1__4_n_0\,
      I2 => \r4_red[3]_i_166_n_0\,
      I3 => \r4_red[3]_i_266_n_0\,
      I4 => \r4_red[3]_i_267_n_0\,
      I5 => \g0_b3__2_n_0\,
      O => \r4_red[3]_i_164_n_0\
    );
\r4_red[3]_i_165\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0550033000000000"
    )
        port map (
      I0 => \g0_b0__2_n_0\,
      I1 => \g0_b2__1_n_0\,
      I2 => \r4_red[3]_i_91_n_0\,
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => \r4_red[3]_i_154_n_0\,
      O => \r4_red[3]_i_165_n_0\
    );
\r4_red[3]_i_166\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000055005600"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(5),
      I4 => \r4_red[3]_i_91_n_0\,
      I5 => \g0_b0__4_n_0\,
      O => \r4_red[3]_i_166_n_0\
    );
\r4_red[3]_i_167\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2020200800000000"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(1),
      I4 => r11_active_x_reg(0),
      I5 => r11_active_x_reg(5),
      O => \r4_red[3]_i_167_n_0\
    );
\r4_red[3]_i_168\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0123FFFF01230123"
    )
        port map (
      I0 => \r4_red[3]_i_49_n_0\,
      I1 => \r4_red[3]_i_50_n_0\,
      I2 => r4_red2(2),
      I3 => r4_red2(3),
      I4 => \g0_b2__4_n_0\,
      I5 => \r4_red[3]_i_18_n_0\,
      O => \r4_red[3]_i_168_n_0\
    );
\r4_red[3]_i_169\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0550033000000000"
    )
        port map (
      I0 => \g0_b0__1_n_0\,
      I1 => \g0_b2__0_n_0\,
      I2 => \r4_red[3]_i_91_n_0\,
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => \r4_red[3]_i_154_n_0\,
      O => \r4_red[3]_i_169_n_0\
    );
\r4_red[3]_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0202022000000000"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(1),
      I4 => r11_active_x_reg(0),
      I5 => r11_active_x_reg(5),
      O => \r4_red[3]_i_17_n_0\
    );
\r4_red[3]_i_170\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0123FFFF01230123"
    )
        port map (
      I0 => \r4_red[3]_i_49_n_0\,
      I1 => \r4_red[3]_i_50_n_0\,
      I2 => \g0_b5__1_n_0\,
      I3 => \g0_b6__0_n_0\,
      I4 => \g0_b4__0_n_0\,
      I5 => \r4_red[3]_i_18_n_0\,
      O => \r4_red[3]_i_170_n_0\
    );
\r4_red[3]_i_171\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00DB00D900D900DB"
    )
        port map (
      I0 => g0_b0_i_3_n_0,
      I1 => g0_b0_i_4_n_0,
      I2 => g0_b0_i_2_n_0,
      I3 => \r4_red[3]_i_50_n_0\,
      I4 => r11_active_x_reg(2),
      I5 => \r4_red[3]_i_91_n_0\,
      O => \r4_red[3]_i_171_n_0\
    );
\r4_red[3]_i_172\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5400000002AAAAAA"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => r11_active_x_reg(0),
      I2 => r11_active_x_reg(1),
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => r11_active_x_reg(4),
      O => \r4_red[3]_i_172_n_0\
    );
\r4_red[3]_i_173\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000004C00C200"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(5),
      I4 => \r4_red[3]_i_91_n_0\,
      I5 => \r4_red[3]_i_268_n_0\,
      O => \r4_red[3]_i_173_n_0\
    );
\r4_red[3]_i_174\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04400000C440000C"
    )
        port map (
      I0 => \g0_b0__3_n_0\,
      I1 => \r4_red[3]_i_154_n_0\,
      I2 => \r4_red[3]_i_91_n_0\,
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => \g0_b3__0_n_0\,
      O => \r4_red[3]_i_174_n_0\
    );
\r4_red[3]_i_175\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80FF8080"
    )
        port map (
      I0 => \r4_red[3]_i_50_n_0\,
      I1 => \r4_red[3]_i_47_n_0\,
      I2 => \r4_red[3]_i_156_n_0\,
      I3 => \g0_b1__2_n_0\,
      I4 => \r4_red[3]_i_167_n_0\,
      O => \r4_red[3]_i_175_n_0\
    );
\r4_red[3]_i_176\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FEEEEEEE"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(5),
      I2 => r11_active_y_reg(1),
      I3 => r11_active_y_reg(3),
      I4 => r11_active_y_reg(2),
      O => \r4_red[3]_i_176_n_0\
    );
\r4_red[3]_i_177\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80808000"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(8),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(1),
      O => \r4_red[3]_i_177_n_0\
    );
\r4_red[3]_i_178\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F8F8F8F8F8F8F888"
    )
        port map (
      I0 => r11_active_y_reg(7),
      I1 => r11_active_y_reg(8),
      I2 => r11_active_x_reg(9),
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => r11_active_x_reg(4),
      O => \r4_red[3]_i_178_n_0\
    );
\r4_red[3]_i_179\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"5042575E"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_179_n_0\
    );
\r4_red[3]_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2220000000000004"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(0),
      I3 => r11_active_x_reg(1),
      I4 => r11_active_x_reg(2),
      I5 => r11_active_x_reg(3),
      O => \r4_red[3]_i_18_n_0\
    );
\r4_red[3]_i_180\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"1450575E"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_180_n_0\
    );
\r4_red[3]_i_181\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"D24A5F7F"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_181_n_0\
    );
\r4_red[3]_i_182\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"5452575E"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_182_n_0\
    );
\r4_red[3]_i_183\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => r11_active_y_reg(1),
      I1 => r11_active_y_reg(2),
      O => \r4_red[3]_i_183_n_0\
    );
\r4_red[3]_i_184\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EAAA1555"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_184_n_0\
    );
\r4_red[3]_i_185\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => r11_active_y_reg(1),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      O => \r4_red[3]_i_185_n_0\
    );
\r4_red[3]_i_186\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"807F"
    )
        port map (
      I0 => r11_active_y_reg(2),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(1),
      I3 => r11_active_y_reg(4),
      O => \r4_red[3]_i_186_n_0\
    );
\r4_red[3]_i_187\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EAAA2BAD"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_187_n_0\
    );
\r4_red[3]_i_188\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAA828A1"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_188_n_0\
    );
\r4_red[3]_i_189\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000F5D40B2F"
    )
        port map (
      I0 => r11_active_y_reg(5),
      I1 => r11_active_y_reg(1),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(4),
      I5 => r11_active_x_reg(2),
      O => \r4_red[3]_i_189_n_0\
    );
\r4_red[3]_i_19\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000010F0F0F0E0"
    )
        port map (
      I0 => r11_active_x_reg(0),
      I1 => r11_active_x_reg(1),
      I2 => r11_active_x_reg(5),
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => r11_active_x_reg(4),
      O => \r4_red[3]_i_19_n_0\
    );
\r4_red[3]_i_190\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"95545F7F"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_190_n_0\
    );
\r4_red[3]_i_191\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAABFD5"
    )
        port map (
      I0 => r11_active_y_reg(5),
      I1 => r11_active_y_reg(1),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(3),
      I4 => r11_active_y_reg(4),
      O => \r4_red[3]_i_191_n_0\
    );
\r4_red[3]_i_192\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"89919911"
    )
        port map (
      I0 => r11_active_y_reg(5),
      I1 => r11_active_y_reg(4),
      I2 => r11_active_y_reg(1),
      I3 => r11_active_y_reg(3),
      I4 => r11_active_y_reg(2),
      O => \r4_red[3]_i_192_n_0\
    );
\r4_red[3]_i_193\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"3EF8420A"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_193_n_0\
    );
\r4_red[3]_i_194\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BCF0420B"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_194_n_0\
    );
\r4_red[3]_i_195\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"5F7FA080"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_195_n_0\
    );
\r4_red[3]_i_196\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"5E7A420A"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_196_n_0\
    );
\r4_red[3]_i_197\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"5600"
    )
        port map (
      I0 => r11_active_y_reg(3),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(1),
      I3 => r11_active_y_reg(4),
      O => \r4_red[3]_i_197_n_0\
    );
\r4_red[3]_i_198\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"565A420A"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_198_n_0\
    );
\r4_red[3]_i_199\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0F3DAAA8"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_199_n_0\
    );
\r4_red[3]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"02FF"
    )
        port map (
      I0 => \r4_red[3]_i_7_n_0\,
      I1 => \r4_red[3]_i_4_n_0\,
      I2 => State(1),
      I3 => State(0),
      O => \r4_red[3]_i_2_n_0\
    );
\r4_red[3]_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0300050055553333"
    )
        port map (
      I0 => r4_red2(3),
      I1 => r4_red2(2),
      I2 => \r4_red[3]_i_47_n_0\,
      I3 => \r4_red[3]_i_48_n_0\,
      I4 => \r4_red[3]_i_49_n_0\,
      I5 => \r4_red[3]_i_50_n_0\,
      O => \r4_red[3]_i_20_n_0\
    );
\r4_red[3]_i_200\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6ABE"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(1),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(3),
      O => \r4_red[3]_i_200_n_0\
    );
\r4_red[3]_i_201\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0105BCF0"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_201_n_0\
    );
\r4_red[3]_i_202\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0515BFFC"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_202_n_0\
    );
\r4_red[3]_i_203\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B4D0430F"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(1),
      I4 => r11_active_y_reg(5),
      O => \r4_red[3]_i_203_n_0\
    );
\r4_red[3]_i_205\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => r11_active_x_reg(3),
      I1 => r11_active_x_reg(2),
      O => \r4_red[3]_i_205_n_0\
    );
\r4_red[3]_i_207\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EA15"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(5),
      O => \r4_red[3]_i_207_n_0\
    );
\r4_red[3]_i_208\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => r11_active_x_reg(2),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(4),
      O => \r4_red[3]_i_208_n_0\
    );
\r4_red[3]_i_209\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2888888800002020"
    )
        port map (
      I0 => \r4_red[3]_i_109_n_0\,
      I1 => r11_active_y_reg(5),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(3),
      I5 => r11_active_y_reg(6),
      O => \r4_red[3]_i_209_n_0\
    );
\r4_red[3]_i_21\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0040000000000000"
    )
        port map (
      I0 => \r4_red[3]_i_51_n_0\,
      I1 => r4_red313_in,
      I2 => \r4_red[3]_i_53_n_0\,
      I3 => \r4_red[3]_i_38_n_0\,
      I4 => \r4_red[3]_i_42_n_0\,
      I5 => \r4_red[3]_i_54_n_0\,
      O => r4_red128_out
    );
\r4_red[3]_i_212\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000E0000000200"
    )
        port map (
      I0 => \p_0_out_inferred__4/r4_red[3]_i_269_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(2),
      I5 => \p_0_out_inferred__4/r4_red[3]_i_270_n_0\,
      O => \r4_red[3]_i_212_n_0\
    );
\r4_red[3]_i_213\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000E000000020000"
    )
        port map (
      I0 => \p_0_out_inferred__4/r4_red[3]_i_271_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(2),
      I5 => \p_0_out_inferred__4/r4_red[3]_i_272_n_0\,
      O => \r4_red[3]_i_213_n_0\
    );
\r4_red[3]_i_214\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"200000C020000000"
    )
        port map (
      I0 => \p_0_out_inferred__4/r4_red[3]_i_273_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(2),
      I5 => \p_0_out_inferred__4/r4_red[3]_i_274_n_0\,
      O => \r4_red[3]_i_214_n_0\
    );
\r4_red[3]_i_215\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C800000008000000"
    )
        port map (
      I0 => \p_0_out_inferred__4/r4_red[3]_i_206_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(2),
      I5 => \p_0_out_inferred__4/r4_red[3]_i_274_n_0\,
      O => \r4_red[3]_i_215_n_0\
    );
\r4_red[3]_i_216\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"11111444"
    )
        port map (
      I0 => r11_active_x_reg(7),
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(4),
      O => \r4_red[3]_i_216_n_0\
    );
\r4_red[3]_i_217\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"080C0800"
    )
        port map (
      I0 => \p_0_out_inferred__4/r4_red[3]_i_275_n_0\,
      I1 => r11_active_x_reg(2),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(4),
      I4 => \p_0_out_inferred__4/r4_red[3]_i_269_n_0\,
      O => \r4_red[3]_i_217_n_0\
    );
\r4_red[3]_i_218\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"22A2A22AA2A22020"
    )
        port map (
      I0 => \r4_red[3]_i_235_n_0\,
      I1 => r11_active_y_reg(5),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(3),
      I5 => r11_active_y_reg(6),
      O => \r4_red[3]_i_218_n_0\
    );
\r4_red[3]_i_219\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000222811AA"
    )
        port map (
      I0 => r11_active_y_reg(5),
      I1 => r11_active_y_reg(4),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(3),
      I4 => r11_active_y_reg(6),
      I5 => \r4_red[3]_i_135_n_0\,
      O => \r4_red[3]_i_219_n_0\
    );
\r4_red[3]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => iw4_result_left(1),
      I1 => iw4_result_left(2),
      O => \r4_red[3]_i_22_n_0\
    );
\r4_red[3]_i_220\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"03200020"
    )
        port map (
      I0 => \p_0_out_inferred__4/r4_red[3]_i_271_n_0\,
      I1 => r11_active_x_reg(2),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(4),
      I4 => \p_0_out_inferred__4/r4_red[3]_i_276_n_0\,
      O => \r4_red[3]_i_220_n_0\
    );
\r4_red[3]_i_221\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FDF4040DFFFFFFFF"
    )
        port map (
      I0 => r11_active_x_reg(2),
      I1 => r11_active_y_reg(6),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(4),
      I5 => r11_active_y_reg(5),
      O => \r4_red[3]_i_221_n_0\
    );
\r4_red[3]_i_224\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000314C01BA"
    )
        port map (
      I0 => r11_active_y_reg(5),
      I1 => r11_active_y_reg(4),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(3),
      I4 => r11_active_y_reg(6),
      I5 => \r4_red[3]_i_135_n_0\,
      O => \r4_red[3]_i_224_n_0\
    );
\r4_red[3]_i_225\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0808028280800808"
    )
        port map (
      I0 => \r4_red[3]_i_235_n_0\,
      I1 => r11_active_y_reg(5),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(3),
      I5 => r11_active_y_reg(6),
      O => \r4_red[3]_i_225_n_0\
    );
\r4_red[3]_i_226\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"080A0A8280808808"
    )
        port map (
      I0 => \r4_red[3]_i_236_n_0\,
      I1 => r11_active_y_reg(5),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(3),
      I5 => r11_active_y_reg(6),
      O => \r4_red[3]_i_226_n_0\
    );
\r4_red[3]_i_227\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000712A00AA"
    )
        port map (
      I0 => r11_active_y_reg(5),
      I1 => r11_active_y_reg(4),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(3),
      I4 => r11_active_y_reg(6),
      I5 => \r4_red[3]_i_135_n_0\,
      O => \r4_red[3]_i_227_n_0\
    );
\r4_red[3]_i_228\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4222"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => r11_active_x_reg(4),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(2),
      O => \r4_red[3]_i_228_n_0\
    );
\r4_red[3]_i_229\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000008A200089"
    )
        port map (
      I0 => r11_active_y_reg(5),
      I1 => r11_active_y_reg(4),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(3),
      I4 => r11_active_y_reg(6),
      I5 => \r4_red[3]_i_135_n_0\,
      O => \r4_red[3]_i_229_n_0\
    );
\r4_red[3]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => iw4_result_right(1),
      I1 => iw4_result_right(2),
      O => \r4_red[3]_i_23_n_0\
    );
\r4_red[3]_i_230\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2888"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => r11_active_x_reg(4),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(2),
      O => \r4_red[3]_i_230_n_0\
    );
\r4_red[3]_i_231\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAA2AA"
    )
        port map (
      I0 => \r4_red[3]_i_109_n_0\,
      I1 => r11_active_y_reg(5),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(3),
      I4 => r11_active_y_reg(6),
      O => \r4_red[3]_i_231_n_0\
    );
\r4_red[3]_i_232\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0A2220A000028A88"
    )
        port map (
      I0 => \r4_red[3]_i_205_n_0\,
      I1 => r11_active_y_reg(5),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(3),
      I5 => r11_active_y_reg(6),
      O => \r4_red[3]_i_232_n_0\
    );
\r4_red[3]_i_233\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"888888802222AAAA"
    )
        port map (
      I0 => \r4_red[3]_i_235_n_0\,
      I1 => r11_active_y_reg(5),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(3),
      I5 => r11_active_y_reg(6),
      O => \r4_red[3]_i_233_n_0\
    );
\r4_red[3]_i_234\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"808888802222AAAA"
    )
        port map (
      I0 => \r4_red[3]_i_236_n_0\,
      I1 => r11_active_y_reg(5),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(3),
      I5 => r11_active_y_reg(6),
      O => \r4_red[3]_i_234_n_0\
    );
\r4_red[3]_i_235\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => r11_active_x_reg(3),
      I1 => r11_active_x_reg(2),
      O => \r4_red[3]_i_235_n_0\
    );
\r4_red[3]_i_236\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"4"
    )
        port map (
      I0 => r11_active_x_reg(3),
      I1 => r11_active_x_reg(2),
      O => \r4_red[3]_i_236_n_0\
    );
\r4_red[3]_i_237\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00001FF300001FF1"
    )
        port map (
      I0 => g0_b0_i_1_n_0,
      I1 => g0_b0_i_2_n_0,
      I2 => g0_b0_i_4_n_0,
      I3 => g0_b0_i_3_n_0,
      I4 => \r4_red[3]_i_48_n_0\,
      I5 => \r4_red[3]_i_49_n_0\,
      O => \r4_red[3]_i_237_n_0\
    );
\r4_red[3]_i_238\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BFBFBFFF"
    )
        port map (
      I0 => \r4_red[3]_i_48_n_0\,
      I1 => g0_b0_i_4_n_0,
      I2 => g0_b0_i_3_n_0,
      I3 => g0_b0_i_2_n_0,
      I4 => g0_b0_i_1_n_0,
      O => \r4_red[3]_i_238_n_0\
    );
\r4_red[3]_i_239\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000002A8000154"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => r11_active_x_reg(0),
      I2 => r11_active_x_reg(1),
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => r11_active_x_reg(4),
      O => \r4_red[3]_i_239_n_0\
    );
\r4_red[3]_i_24\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200202000000000"
    )
        port map (
      I0 => r4_red313_in,
      I1 => \r4_red[3]_i_38_n_0\,
      I2 => \r4_red[3]_i_55_n_0\,
      I3 => \r4_red[3]_i_56_n_0\,
      I4 => \r4_red[3]_i_57_n_0\,
      I5 => \r4_red[3]_i_53_n_0\,
      O => r4_red115_out
    );
\r4_red[3]_i_240\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000015A5A04"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(5),
      I3 => r11_active_x_reg(2),
      I4 => \r4_red[3]_i_91_n_0\,
      I5 => r4_red2(2),
      O => \r4_red[3]_i_240_n_0\
    );
\r4_red[3]_i_241\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4458445844581162"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => r11_active_x_reg(2),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(4),
      I4 => r11_active_x_reg(0),
      I5 => r11_active_x_reg(1),
      O => \r4_red[3]_i_241_n_0\
    );
\r4_red[3]_i_242\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000001010110"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(1),
      I4 => r11_active_x_reg(0),
      I5 => r11_active_x_reg(5),
      O => \r4_red[3]_i_242_n_0\
    );
\r4_red[3]_i_243\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000004040440"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(1),
      I4 => r11_active_x_reg(0),
      I5 => r11_active_x_reg(5),
      O => \r4_red[3]_i_243_n_0\
    );
\r4_red[3]_i_244\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0503050305030305"
    )
        port map (
      I0 => g0_b9_n_0,
      I1 => g0_b8_n_0,
      I2 => \r4_red[3]_i_157_n_0\,
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(1),
      I5 => r11_active_x_reg(0),
      O => \r4_red[3]_i_244_n_0\
    );
\r4_red[3]_i_245\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0140017C3D403D7C"
    )
        port map (
      I0 => g0_b5_n_0,
      I1 => \r4_red[3]_i_91_n_0\,
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(3),
      I4 => \g0_b6__3_n_0\,
      I5 => g0_b4_n_0,
      O => \r4_red[3]_i_245_n_0\
    );
\r4_red[3]_i_246\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00005300"
    )
        port map (
      I0 => g0_b3_n_0,
      I1 => g0_b7_n_0,
      I2 => \r4_red[3]_i_47_n_0\,
      I3 => \r4_red[3]_i_157_n_0\,
      I4 => \r4_red[3]_i_253_n_0\,
      O => \r4_red[3]_i_246_n_0\
    );
\r4_red[3]_i_247\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888888888888881"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => r11_active_x_reg(4),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(1),
      I5 => r11_active_x_reg(0),
      O => \r4_red[3]_i_247_n_0\
    );
\r4_red[3]_i_248\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3000500055553333"
    )
        port map (
      I0 => r4_red2(3),
      I1 => r4_red2(2),
      I2 => \r4_red[3]_i_47_n_0\,
      I3 => \r4_red[3]_i_48_n_0\,
      I4 => \r4_red[3]_i_49_n_0\,
      I5 => \r4_red[3]_i_157_n_0\,
      O => \r4_red[3]_i_248_n_0\
    );
\r4_red[3]_i_249\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0550033000000000"
    )
        port map (
      I0 => r4_red2(3),
      I1 => \g0_b2__4_n_0\,
      I2 => \r4_red[3]_i_91_n_0\,
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => \r4_red[3]_i_252_n_0\,
      O => \r4_red[3]_i_249_n_0\
    );
\r4_red[3]_i_25\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555555555555777"
    )
        port map (
      I0 => r4_red120_out,
      I1 => \r4_red[3]_i_59_n_0\,
      I2 => \r4_red[3]_i_60_n_0\,
      I3 => \r4_red[3]_i_61_n_0\,
      I4 => \r4_red[3]_i_62_n_0\,
      I5 => \r4_red[3]_i_63_n_0\,
      O => \r4_red[3]_i_25_n_0\
    );
\r4_red[3]_i_250\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0123FFFF01230123"
    )
        port map (
      I0 => \r4_red[3]_i_49_n_0\,
      I1 => \r4_red[3]_i_157_n_0\,
      I2 => \g0_b5__2_n_0\,
      I3 => \g0_b6__2_n_0\,
      I4 => r4_red2(2),
      I5 => \r4_red[3]_i_158_n_0\,
      O => \r4_red[3]_i_250_n_0\
    );
\r4_red[3]_i_251\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000001008000"
    )
        port map (
      I0 => r11_active_x_reg(3),
      I1 => r11_active_x_reg(2),
      I2 => \r4_red[3]_i_91_n_0\,
      I3 => r11_active_x_reg(5),
      I4 => r11_active_x_reg(4),
      I5 => r4_red2(1),
      O => \r4_red[3]_i_251_n_0\
    );
\r4_red[3]_i_252\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A800000001555555"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => r11_active_x_reg(0),
      I2 => r11_active_x_reg(1),
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => r11_active_x_reg(4),
      O => \r4_red[3]_i_252_n_0\
    );
\r4_red[3]_i_253\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"777E"
    )
        port map (
      I0 => r11_active_x_reg(3),
      I1 => r11_active_x_reg(2),
      I2 => r11_active_x_reg(1),
      I3 => r11_active_x_reg(0),
      O => \r4_red[3]_i_253_n_0\
    );
\r4_red[3]_i_254\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000E0101EEE01010"
    )
        port map (
      I0 => r11_active_x_reg(1),
      I1 => r11_active_x_reg(0),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(2),
      I5 => r11_active_x_reg(5),
      O => \r4_red[3]_i_254_n_0\
    );
\r4_red[3]_i_255\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0550033000000000"
    )
        port map (
      I0 => \g0_b0__3_n_0\,
      I1 => \g0_b2__2_n_0\,
      I2 => \r4_red[3]_i_91_n_0\,
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => \r4_red[3]_i_252_n_0\,
      O => \r4_red[3]_i_255_n_0\
    );
\r4_red[3]_i_256\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0040004C"
    )
        port map (
      I0 => g0_b7_n_0,
      I1 => \r4_red[3]_i_50_n_0\,
      I2 => \r4_red[3]_i_47_n_0\,
      I3 => \r4_red[3]_i_253_n_0\,
      I4 => g0_b3_n_0,
      O => \r4_red[3]_i_256_n_0\
    );
\r4_red[3]_i_257\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0123FFFF01230123"
    )
        port map (
      I0 => \r4_red[3]_i_49_n_0\,
      I1 => \r4_red[3]_i_50_n_0\,
      I2 => g0_b8_n_0,
      I3 => g0_b9_n_0,
      I4 => g0_b1_n_0,
      I5 => \r4_red[3]_i_167_n_0\,
      O => \r4_red[3]_i_257_n_0\
    );
\r4_red[3]_i_258\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0550033000000000"
    )
        port map (
      I0 => \g0_b0__0_n_0\,
      I1 => g0_b2_n_0,
      I2 => \r4_red[3]_i_91_n_0\,
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => \r4_red[3]_i_154_n_0\,
      O => \r4_red[3]_i_258_n_0\
    );
\r4_red[3]_i_259\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0020"
    )
        port map (
      I0 => iw4_result_left(3),
      I1 => iw4_result_left(2),
      I2 => iw4_result_left(0),
      I3 => iw4_result_left(1),
      O => \r4_red[3]_i_259_n_0\
    );
\r4_red[3]_i_26\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA8A8888888888"
    )
        port map (
      I0 => \r4_red[3]_i_64_n_0\,
      I1 => \r4_red[3]_i_65_n_0\,
      I2 => \r4_red[3]_i_66_n_0\,
      I3 => r11_active_x_reg(5),
      I4 => r11_active_x_reg(6),
      I5 => r11_active_x_reg(8),
      O => r4_red125_out
    );
\r4_red[3]_i_260\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0123FFFF01230123"
    )
        port map (
      I0 => \r4_red[3]_i_49_n_0\,
      I1 => \r4_red[3]_i_50_n_0\,
      I2 => \g0_b5__2_n_0\,
      I3 => \g0_b6__2_n_0\,
      I4 => \g0_b4__2_n_0\,
      I5 => \r4_red[3]_i_18_n_0\,
      O => \r4_red[3]_i_260_n_0\
    );
\r4_red[3]_i_261\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0550033000000000"
    )
        port map (
      I0 => r4_red2(3),
      I1 => \g0_b2__4_n_0\,
      I2 => \r4_red[3]_i_91_n_0\,
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => \r4_red[3]_i_154_n_0\,
      O => \r4_red[3]_i_261_n_0\
    );
\r4_red[3]_i_262\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0400"
    )
        port map (
      I0 => iw4_result_left(3),
      I1 => iw4_result_left(0),
      I2 => iw4_result_left(2),
      I3 => iw4_result_left(1),
      O => \r4_red[3]_i_262_n_0\
    );
\r4_red[3]_i_263\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0123FFFF01230123"
    )
        port map (
      I0 => \r4_red[3]_i_49_n_0\,
      I1 => \r4_red[3]_i_50_n_0\,
      I2 => \g0_b5__0_n_0\,
      I3 => g0_b6_n_0,
      I4 => r4_red2(1),
      I5 => \r4_red[3]_i_18_n_0\,
      O => \r4_red[3]_i_263_n_0\
    );
\r4_red[3]_i_264\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0550033000000000"
    )
        port map (
      I0 => \g0_b3__2_n_0\,
      I1 => \g0_b1__4_n_0\,
      I2 => \r4_red[3]_i_91_n_0\,
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => \r4_red[3]_i_154_n_0\,
      O => \r4_red[3]_i_264_n_0\
    );
\r4_red[3]_i_265\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"540002A800000002"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => r11_active_x_reg(0),
      I2 => r11_active_x_reg(1),
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => r11_active_x_reg(4),
      O => \r4_red[3]_i_265_n_0\
    );
\r4_red[3]_i_266\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000020555580"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(2),
      I4 => \r4_red[3]_i_91_n_0\,
      I5 => r4_red2(2),
      O => \r4_red[3]_i_266_n_0\
    );
\r4_red[3]_i_267\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"887088708870800F"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(5),
      I4 => r11_active_x_reg(1),
      I5 => r11_active_x_reg(0),
      O => \r4_red[3]_i_267_n_0\
    );
\r4_red[3]_i_268\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1100110011001004"
    )
        port map (
      I0 => r11_active_y_reg(5),
      I1 => r11_active_y_reg(4),
      I2 => r11_active_y_reg(2),
      I3 => r11_active_y_reg(3),
      I4 => r11_active_y_reg(1),
      I5 => r11_active_y_reg(0),
      O => \r4_red[3]_i_268_n_0\
    );
\r4_red[3]_i_27\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEEEBAAABAAABAAA"
    )
        port map (
      I0 => \r4_red[3]_i_67_n_0\,
      I1 => \r4_red[3]_i_68_n_0\,
      I2 => \r4_red[3]_i_69_n_0\,
      I3 => \r4_red[3]_i_70_n_0\,
      I4 => \r4_red[3]_i_71_n_0\,
      I5 => \r4_red[3]_i_72_n_0\,
      O => \r4_red[3]_i_27_n_0\
    );
\r4_red[3]_i_28\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000100"
    )
        port map (
      I0 => r4_red115_out,
      I1 => \r4_red[3]_i_4_n_0\,
      I2 => r4_red128_out,
      I3 => State(0),
      I4 => State(1),
      O => \r4_red[3]_i_28_n_0\
    );
\r4_red[3]_i_29\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000400"
    )
        port map (
      I0 => r4_red128_out,
      I1 => r4_red115_out,
      I2 => \r4_red[3]_i_4_n_0\,
      I3 => State(0),
      I4 => State(1),
      O => \r4_red[3]_i_29_n_0\
    );
\r4_red[3]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFF8"
    )
        port map (
      I0 => \r4_red[3]_i_8_n_0\,
      I1 => iw4_red(3),
      I2 => \r4_red[3]_i_9_n_0\,
      I3 => \r4_red[3]_i_10_n_0\,
      O => r4_red(3)
    );
\r4_red[3]_i_30\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFEFEE"
    )
        port map (
      I0 => \r4_red[3]_i_73_n_0\,
      I1 => \r4_red[3]_i_74_n_0\,
      I2 => \r4_red[3]_i_75_n_0\,
      I3 => \r4_red[3]_i_25_n_0\,
      I4 => \r4_red[3]_i_76_n_0\,
      I5 => \r4_red[3]_i_77_n_0\,
      O => \r4_red[3]_i_30_n_0\
    );
\r4_red[3]_i_31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FACFFAC00ACF0AC0"
    )
        port map (
      I0 => \r4_red[3]_i_78_n_0\,
      I1 => \r4_red[3]_i_79_n_0\,
      I2 => iw4_result_right(1),
      I3 => iw4_result_right(0),
      I4 => \r4_red[3]_i_80_n_0\,
      I5 => \r4_red[3]_i_81_n_0\,
      O => \r4_red[3]_i_31_n_0\
    );
\r4_red[3]_i_32\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0400"
    )
        port map (
      I0 => \r4_red[3]_i_4_n_0\,
      I1 => State(0),
      I2 => State(1),
      I3 => r4_red128_out,
      O => \r4_red[3]_i_32_n_0\
    );
\r4_red[3]_i_33\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFEAAAAAFFEAAFAF"
    )
        port map (
      I0 => \r4_red[3]_i_82_n_0\,
      I1 => \r4_red[3]_i_25_n_0\,
      I2 => \r4_red[3]_i_22_n_0\,
      I3 => \r4_red[3]_i_83_n_0\,
      I4 => iw4_result_left(3),
      I5 => iw4_result_left(0),
      O => \r4_red[3]_i_33_n_0\
    );
\r4_red[3]_i_34\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAFFCA00CAF0CA0"
    )
        port map (
      I0 => \r4_red[3]_i_84_n_0\,
      I1 => \r4_red[3]_i_85_n_0\,
      I2 => iw4_result_left(1),
      I3 => iw4_result_left(0),
      I4 => \r4_red[3]_i_86_n_0\,
      I5 => \r4_red[3]_i_87_n_0\,
      O => \r4_red[3]_i_34_n_0\
    );
\r4_red[3]_i_35\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000100010001"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(5),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(3),
      I4 => r11_active_y_reg(2),
      I5 => r11_active_y_reg(1),
      O => \r4_red[3]_i_35_n_0\
    );
\r4_red[3]_i_36\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F0F080F000F000"
    )
        port map (
      I0 => \r4_red[3]_i_88_n_0\,
      I1 => r11_active_y_reg(4),
      I2 => r11_active_y_reg(9),
      I3 => r11_active_y_reg(7),
      I4 => r11_active_y_reg(5),
      I5 => r11_active_y_reg(6),
      O => \r4_red[3]_i_36_n_0\
    );
\r4_red[3]_i_37\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFAAAAAAFEAAAAAA"
    )
        port map (
      I0 => \r4_red[3]_i_38_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(6),
      I3 => r11_active_x_reg(8),
      I4 => r11_active_x_reg(7),
      I5 => \r4_red[2]_i_16_n_0\,
      O => r4_red434_in
    );
\r4_red[3]_i_38\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => r11_active_x_reg(10),
      I1 => r11_active_x_reg(9),
      O => \r4_red[3]_i_38_n_0\
    );
\r4_red[3]_i_39\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888888888888880"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(4),
      I2 => r11_active_y_reg(1),
      I3 => r11_active_y_reg(0),
      I4 => r11_active_y_reg(3),
      I5 => r11_active_y_reg(2),
      O => \r4_red[3]_i_39_n_0\
    );
\r4_red[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFAAEAAAEAAAEAAA"
    )
        port map (
      I0 => \r4_red[3]_i_11_n_0\,
      I1 => \r4_red[3]_i_12_n_0\,
      I2 => \r4_red[3]_i_13_n_0\,
      I3 => \r4_red[3]_i_14_n_0\,
      I4 => \r4_red[3]_i_15_n_0\,
      I5 => \r4_red[3]_i_16_n_0\,
      O => \r4_red[3]_i_4_n_0\
    );
\r4_red[3]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => r11_active_y_reg(7),
      I1 => r11_active_y_reg(5),
      I2 => r11_active_y_reg(6),
      O => \r4_red[3]_i_40_n_0\
    );
\r4_red[3]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => r11_active_y_reg(9),
      I1 => r11_active_y_reg(10),
      I2 => r11_active_y_reg(8),
      O => \r4_red[3]_i_41_n_0\
    );
\r4_red[3]_i_42\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => r11_active_x_reg(8),
      I1 => r11_active_x_reg(7),
      O => \r4_red[3]_i_42_n_0\
    );
\r4_red[3]_i_43\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => r11_active_y_reg(5),
      I1 => r11_active_y_reg(4),
      O => \r4_red[3]_i_43_n_0\
    );
\r4_red[3]_i_44\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(7),
      I2 => r11_active_y_reg(8),
      I3 => r11_active_y_reg(10),
      I4 => r11_active_y_reg(9),
      O => \r4_red[3]_i_44_n_0\
    );
\r4_red[3]_i_45\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => r11_active_y_reg(8),
      I1 => r11_active_y_reg(10),
      I2 => r11_active_y_reg(9),
      I3 => r11_active_y_reg(7),
      O => \r4_red[3]_i_45_n_0\
    );
\r4_red[3]_i_46\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => r11_active_y_reg(1),
      I1 => r11_active_y_reg(0),
      O => \r4_red[3]_i_46_n_0\
    );
\r4_red[3]_i_47\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"95959555"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(1),
      I4 => r11_active_x_reg(0),
      O => \r4_red[3]_i_47_n_0\
    );
\r4_red[3]_i_48\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1EF0"
    )
        port map (
      I0 => r11_active_x_reg(1),
      I1 => r11_active_x_reg(0),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(2),
      O => \r4_red[3]_i_48_n_0\
    );
\r4_red[3]_i_49\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => r11_active_x_reg(0),
      I1 => r11_active_x_reg(1),
      I2 => r11_active_x_reg(2),
      O => \r4_red[3]_i_49_n_0\
    );
\r4_red[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF0E0EFF0E"
    )
        port map (
      I0 => \r4_red[3]_i_17_n_0\,
      I1 => \r4_red[3]_i_18_n_0\,
      I2 => r4_red2(1),
      I3 => \r4_red[3]_i_19_n_0\,
      I4 => r4_red2(0),
      I5 => \r4_red[3]_i_20_n_0\,
      O => \r4_red[3]_i_5_n_0\
    );
\r4_red[3]_i_50\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7F807F807F80FF00"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(2),
      I3 => r11_active_x_reg(5),
      I4 => r11_active_x_reg(1),
      I5 => r11_active_x_reg(0),
      O => \r4_red[3]_i_50_n_0\
    );
\r4_red[3]_i_51\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000E0000000"
    )
        port map (
      I0 => r11_active_x_reg(1),
      I1 => r11_active_x_reg(0),
      I2 => r11_active_x_reg(8),
      I3 => r11_active_x_reg(6),
      I4 => r11_active_x_reg(5),
      I5 => \r11_active_x[8]_i_3_n_0\,
      O => \r4_red[3]_i_51_n_0\
    );
\r4_red[3]_i_52\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFA00F800"
    )
        port map (
      I0 => r11_active_y_reg(3),
      I1 => r11_active_y_reg(2),
      I2 => r11_active_y_reg(4),
      I3 => r11_active_y_reg(5),
      I4 => \r4_red[3]_i_46_n_0\,
      I5 => \r4_red[3]_i_44_n_0\,
      O => r4_red313_in
    );
\r4_red[3]_i_53\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FFFF00000015"
    )
        port map (
      I0 => r11_active_y_reg(3),
      I1 => r11_active_y_reg(2),
      I2 => \r4_red[3]_i_46_n_0\,
      I3 => r11_active_y_reg(4),
      I4 => \r4_red[3]_i_45_n_0\,
      I5 => \r4_red[3]_i_89_n_0\,
      O => \r4_red[3]_i_53_n_0\
    );
\r4_red[3]_i_54\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"88808080"
    )
        port map (
      I0 => r11_active_x_reg(8),
      I1 => r11_active_x_reg(6),
      I2 => r11_active_x_reg(5),
      I3 => \r4_red[3]_i_90_n_0\,
      I4 => r11_active_x_reg(4),
      O => \r4_red[3]_i_54_n_0\
    );
\r4_red[3]_i_55\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000015151555"
    )
        port map (
      I0 => r11_active_x_reg(4),
      I1 => r11_active_x_reg(2),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(0),
      I4 => r11_active_x_reg(1),
      I5 => r11_active_x_reg(5),
      O => \r4_red[3]_i_55_n_0\
    );
\r4_red[3]_i_56\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4444444444404040"
    )
        port map (
      I0 => \r4_red[3]_i_42_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(2),
      I4 => \r4_red[3]_i_91_n_0\,
      I5 => r11_active_x_reg(3),
      O => \r4_red[3]_i_56_n_0\
    );
\r4_red[3]_i_57\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => r11_active_x_reg(7),
      I1 => r11_active_x_reg(8),
      I2 => r11_active_x_reg(6),
      O => \r4_red[3]_i_57_n_0\
    );
\r4_red[3]_i_58\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000F400"
    )
        port map (
      I0 => \r11_active_x[8]_i_3_n_0\,
      I1 => r11_active_x_reg(8),
      I2 => \r4_red[3]_i_92_n_0\,
      I3 => r4_red318_in,
      I4 => \r4_red[3]_i_94_n_0\,
      I5 => \r4_red[3]_i_95_n_0\,
      O => r4_red120_out
    );
\r4_red[3]_i_59\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => \r4_red[3]_i_96_n_0\,
      I1 => \r4_red[3]_i_97_n_0\,
      I2 => \r4_red[3]_i_98_n_0\,
      I3 => \r4_red[3]_i_99_n_0\,
      I4 => \r4_red[3]_i_100_n_0\,
      I5 => \r4_red[3]_i_101_n_0\,
      O => \r4_red[3]_i_59_n_0\
    );
\r4_red[3]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000200000000"
    )
        port map (
      I0 => \r4_red[2]_i_7_n_0\,
      I1 => iw4_result_left(1),
      I2 => iw4_result_left(0),
      I3 => iw4_result_left(3),
      I4 => iw4_result_left(2),
      I5 => r4_red128_out,
      O => \r4_red[3]_i_6_n_0\
    );
\r4_red[3]_i_60\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \r4_red[3]_i_102_n_0\,
      I1 => \r4_red[3]_i_103_n_0\,
      I2 => \r4_red[3]_i_104_n_0\,
      I3 => \r4_red[3]_i_105_n_0\,
      I4 => \r4_red[3]_i_106_n_0\,
      I5 => \r4_red[3]_i_107_n_0\,
      O => \r4_red[3]_i_60_n_0\
    );
\r4_red[3]_i_61\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00FF01FE00000000"
    )
        port map (
      I0 => r11_active_x_reg(2),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(6),
      I4 => r11_active_x_reg(5),
      I5 => r11_active_x_reg(7),
      O => \r4_red[3]_i_61_n_0\
    );
\r4_red[3]_i_62\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"70007000FF000000"
    )
        port map (
      I0 => \r4_red[3]_i_108_n_0\,
      I1 => \r4_red[3]_i_109_n_0\,
      I2 => \r4_red[3]_i_110_n_0\,
      I3 => \r4_red[3]_i_111_n_0\,
      I4 => \r4_red[3]_i_112_n_0\,
      I5 => \r4_red[3]_i_113_n_0\,
      O => \r4_red[3]_i_62_n_0\
    );
\r4_red[3]_i_63\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000AAAAFFFC"
    )
        port map (
      I0 => \r4_red[3]_i_114_n_0\,
      I1 => \r4_red[3]_i_115_n_0\,
      I2 => \r4_red[3]_i_116_n_0\,
      I3 => \r4_red[3]_i_117_n_0\,
      I4 => \r4_red[3]_i_118_n_0\,
      I5 => \r4_red[3]_i_119_n_0\,
      O => \r4_red[3]_i_63_n_0\
    );
\r4_red[3]_i_64\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0C0000008080C0C0"
    )
        port map (
      I0 => \r4_red[3]_i_120_n_0\,
      I1 => \r4_red[3]_i_121_n_0\,
      I2 => r11_active_y_reg(8),
      I3 => \r4_red[3]_i_122_n_0\,
      I4 => r11_active_y_reg(6),
      I5 => r11_active_y_reg(7),
      O => \r4_red[3]_i_64_n_0\
    );
\r4_red[3]_i_65\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEEE"
    )
        port map (
      I0 => r11_active_x_reg(9),
      I1 => r11_active_x_reg(10),
      I2 => r11_active_x_reg(7),
      I3 => r11_active_x_reg(8),
      O => \r4_red[3]_i_65_n_0\
    );
\r4_red[3]_i_66\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"1F"
    )
        port map (
      I0 => r11_active_x_reg(2),
      I1 => r11_active_x_reg(3),
      I2 => r11_active_x_reg(4),
      O => \r4_red[3]_i_66_n_0\
    );
\r4_red[3]_i_67\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFAAA8"
    )
        port map (
      I0 => \r4_red[3]_i_123_n_0\,
      I1 => \r4_red[3]_i_124_n_0\,
      I2 => \r4_red[3]_i_125_n_0\,
      I3 => \r4_red[3]_i_126_n_0\,
      I4 => \r4_red[3]_i_127_n_0\,
      I5 => \r4_red[3]_i_128_n_0\,
      O => \r4_red[3]_i_67_n_0\
    );
\r4_red[3]_i_68\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9595959595555555"
    )
        port map (
      I0 => r11_active_x_reg(7),
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(6),
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(3),
      I5 => r11_active_x_reg(4),
      O => \r4_red[3]_i_68_n_0\
    );
\r4_red[3]_i_69\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"5666AAAA"
    )
        port map (
      I0 => r11_active_x_reg(6),
      I1 => r11_active_x_reg(4),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(2),
      I4 => r11_active_x_reg(5),
      O => \r4_red[3]_i_69_n_0\
    );
\r4_red[3]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"707F7F7F7F7F7F7F"
    )
        port map (
      I0 => \r4_red[3]_i_22_n_0\,
      I1 => iw4_result_left(3),
      I2 => r4_red128_out,
      I3 => \r4_red[3]_i_23_n_0\,
      I4 => iw4_result_right(3),
      I5 => r4_red115_out,
      O => \r4_red[3]_i_7_n_0\
    );
\r4_red[3]_i_70\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEFEFFFEFEFE"
    )
        port map (
      I0 => \r4_red[3]_i_129_n_0\,
      I1 => \r4_red[3]_i_130_n_0\,
      I2 => \r4_red[3]_i_131_n_0\,
      I3 => \r4_red[3]_i_132_n_0\,
      I4 => \r4_red[3]_i_133_n_0\,
      I5 => \r4_red[3]_i_134_n_0\,
      O => \r4_red[3]_i_70_n_0\
    );
\r4_red[3]_i_71\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"071FCFC710000000"
    )
        port map (
      I0 => \r4_red[3]_i_135_n_0\,
      I1 => r11_active_y_reg(6),
      I2 => r11_active_y_reg(3),
      I3 => r11_active_y_reg(2),
      I4 => r11_active_y_reg(4),
      I5 => r11_active_y_reg(5),
      O => \r4_red[3]_i_71_n_0\
    );
\r4_red[3]_i_72\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8111"
    )
        port map (
      I0 => r11_active_x_reg(5),
      I1 => r11_active_x_reg(4),
      I2 => r11_active_x_reg(3),
      I3 => r11_active_x_reg(2),
      O => \r4_red[3]_i_72_n_0\
    );
\r4_red[3]_i_73\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000000A00C0"
    )
        port map (
      I0 => \r4_red[3]_i_136_n_0\,
      I1 => \r4_red[3]_i_137_n_0\,
      I2 => iw4_result_right(3),
      I3 => iw4_result_right(2),
      I4 => iw4_result_right(0),
      I5 => iw4_result_right(1),
      O => \r4_red[3]_i_73_n_0\
    );
\r4_red[3]_i_74\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0002000200020000"
    )
        port map (
      I0 => iw4_result_right(1),
      I1 => iw4_result_right(2),
      I2 => iw4_result_right(3),
      I3 => iw4_result_right(0),
      I4 => \r4_red[3]_i_138_n_0\,
      I5 => \r4_red[3]_i_139_n_0\,
      O => \r4_red[3]_i_74_n_0\
    );
\r4_red[3]_i_75\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"57"
    )
        port map (
      I0 => iw4_result_right(3),
      I1 => iw4_result_right(2),
      I2 => iw4_result_right(1),
      O => \r4_red[3]_i_75_n_0\
    );
\r4_red[3]_i_76\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000C0000A"
    )
        port map (
      I0 => \r4_red[3]_i_140_n_0\,
      I1 => \r4_red[3]_i_141_n_0\,
      I2 => iw4_result_right(3),
      I3 => iw4_result_right(2),
      I4 => iw4_result_right(0),
      I5 => iw4_result_right(1),
      O => \r4_red[3]_i_76_n_0\
    );
\r4_red[3]_i_77\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1000100010000000"
    )
        port map (
      I0 => iw4_result_right(2),
      I1 => iw4_result_right(3),
      I2 => iw4_result_right(0),
      I3 => iw4_result_right(1),
      I4 => \r4_red[3]_i_142_n_0\,
      I5 => \r4_red[3]_i_143_n_0\,
      O => \r4_red[3]_i_77_n_0\
    );
\r4_red[3]_i_78\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFF4"
    )
        port map (
      I0 => \g0_b4__0_n_0\,
      I1 => \r4_red[3]_i_144_n_0\,
      I2 => \r4_red[3]_i_145_n_0\,
      I3 => \r4_red[3]_i_146_n_0\,
      I4 => \r4_red[3]_i_147_n_0\,
      O => \r4_red[3]_i_78_n_0\
    );
\r4_red[3]_i_79\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFF4"
    )
        port map (
      I0 => \g0_b2__4_n_0\,
      I1 => \r4_red[3]_i_144_n_0\,
      I2 => \r4_red[3]_i_145_n_0\,
      I3 => \r4_red[3]_i_148_n_0\,
      I4 => \r4_red[3]_i_149_n_0\,
      O => \r4_red[3]_i_79_n_0\
    );
\r4_red[3]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFA30AAF0A"
    )
        port map (
      I0 => \r4_red[3]_i_25_n_0\,
      I1 => r4_red125_out,
      I2 => State(0),
      I3 => State(1),
      I4 => \r4_red[3]_i_27_n_0\,
      I5 => \r4_red[3]_i_28_n_0\,
      O => \r4_red[3]_i_8_n_0\
    );
\r4_red[3]_i_80\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFEEFEEEFEEEFE"
    )
        port map (
      I0 => \r4_red[3]_i_150_n_0\,
      I1 => \r4_red[3]_i_151_n_0\,
      I2 => \r4_red[3]_i_144_n_0\,
      I3 => \r4_red[3]_i_152_n_0\,
      I4 => \r4_red[3]_i_153_n_0\,
      I5 => \r4_red[3]_i_154_n_0\,
      O => \r4_red[3]_i_80_n_0\
    );
\r4_red[3]_i_81\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AEAAAEAAFFFFAEAA"
    )
        port map (
      I0 => \r4_red[3]_i_155_n_0\,
      I1 => \r4_red[3]_i_156_n_0\,
      I2 => \r4_red[3]_i_47_n_0\,
      I3 => \r4_red[3]_i_157_n_0\,
      I4 => \r4_red[3]_i_158_n_0\,
      I5 => \g0_b1__2_n_0\,
      O => \r4_red[3]_i_81_n_0\
    );
\r4_red[3]_i_82\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFBA00"
    )
        port map (
      I0 => \r4_red[3]_i_159_n_0\,
      I1 => iw4_result_left(0),
      I2 => \r4_red[3]_i_160_n_0\,
      I3 => \r4_red[3]_i_161_n_0\,
      I4 => \r4_red[3]_i_162_n_0\,
      I5 => \r4_red[3]_i_163_n_0\,
      O => \r4_red[3]_i_82_n_0\
    );
\r4_red[3]_i_83\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0100"
    )
        port map (
      I0 => iw4_result_left(1),
      I1 => iw4_result_left(2),
      I2 => iw4_result_left(0),
      I3 => \r4_red[3]_i_164_n_0\,
      O => \r4_red[3]_i_83_n_0\
    );
\r4_red[3]_i_84\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFEFEE"
    )
        port map (
      I0 => \r4_red[3]_i_165_n_0\,
      I1 => \r4_red[3]_i_166_n_0\,
      I2 => \g0_b1__1_n_0\,
      I3 => \r4_red[3]_i_167_n_0\,
      I4 => \r4_red[3]_i_168_n_0\,
      O => \r4_red[3]_i_84_n_0\
    );
\r4_red[3]_i_85\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFEFEE"
    )
        port map (
      I0 => \r4_red[3]_i_169_n_0\,
      I1 => \r4_red[3]_i_166_n_0\,
      I2 => \g0_b1__0_n_0\,
      I3 => \r4_red[3]_i_167_n_0\,
      I4 => \r4_red[3]_i_170_n_0\,
      O => \r4_red[3]_i_85_n_0\
    );
\r4_red[3]_i_86\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFEAFFEAEA"
    )
        port map (
      I0 => \r4_red[3]_i_171_n_0\,
      I1 => \r4_red[3]_i_172_n_0\,
      I2 => \r4_red[3]_i_153_n_0\,
      I3 => \r4_red[3]_i_152_n_0\,
      I4 => \r4_red[3]_i_18_n_0\,
      I5 => \r4_red[3]_i_173_n_0\,
      O => \r4_red[3]_i_86_n_0\
    );
\r4_red[3]_i_87\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFF444F"
    )
        port map (
      I0 => \g0_b2__2_n_0\,
      I1 => \r4_red[3]_i_17_n_0\,
      I2 => \r4_red[3]_i_50_n_0\,
      I3 => \g0_b7__0_n_0\,
      I4 => \r4_red[3]_i_174_n_0\,
      I5 => \r4_red[3]_i_175_n_0\,
      O => \r4_red[3]_i_87_n_0\
    );
\r4_red[3]_i_88\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEEE"
    )
        port map (
      I0 => r11_active_y_reg(2),
      I1 => r11_active_y_reg(3),
      I2 => r11_active_y_reg(0),
      I3 => r11_active_y_reg(1),
      O => \r4_red[3]_i_88_n_0\
    );
\r4_red[3]_i_89\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => r11_active_y_reg(6),
      I1 => r11_active_y_reg(5),
      O => \r4_red[3]_i_89_n_0\
    );
\r4_red[3]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0808080808080"
    )
        port map (
      I0 => \r4_red[3]_i_29_n_0\,
      I1 => \r4_red[3]_i_30_n_0\,
      I2 => iw4_red(3),
      I3 => iw4_result_right(3),
      I4 => iw4_result_right(2),
      I5 => \r4_red[3]_i_31_n_0\,
      O => \r4_red[3]_i_9_n_0\
    );
\r4_red[3]_i_90\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFA8"
    )
        port map (
      I0 => r11_active_x_reg(2),
      I1 => r11_active_x_reg(1),
      I2 => r11_active_x_reg(0),
      I3 => r11_active_x_reg(3),
      O => \r4_red[3]_i_90_n_0\
    );
\r4_red[3]_i_91\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => r11_active_x_reg(1),
      I1 => r11_active_x_reg(0),
      O => \r4_red[3]_i_91_n_0\
    );
\r4_red[3]_i_92\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFAAA8"
    )
        port map (
      I0 => r11_active_x_reg(8),
      I1 => r11_active_x_reg(7),
      I2 => r11_active_x_reg(5),
      I3 => r11_active_x_reg(6),
      I4 => r11_active_x_reg(9),
      I5 => r11_active_x_reg(10),
      O => \r4_red[3]_i_92_n_0\
    );
\r4_red[3]_i_93\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFEEEEFFFEEEEE"
    )
        port map (
      I0 => r11_active_y_reg(10),
      I1 => r11_active_y_reg(9),
      I2 => r11_active_y_reg(6),
      I3 => r11_active_y_reg(7),
      I4 => r11_active_y_reg(8),
      I5 => \r4_red[3]_i_176_n_0\,
      O => r4_red318_in
    );
\r4_red[3]_i_94\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFE000E000E000"
    )
        port map (
      I0 => r11_active_y_reg(4),
      I1 => r11_active_y_reg(5),
      I2 => r11_active_y_reg(6),
      I3 => r11_active_y_reg(8),
      I4 => r11_active_x_reg(9),
      I5 => \r4_red[2]_i_17_n_0\,
      O => \r4_red[3]_i_94_n_0\
    );
\r4_red[3]_i_95\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \r4_red[3]_i_177_n_0\,
      I1 => r11_active_y_reg(9),
      I2 => r11_active_y_reg(10),
      I3 => r11_active_x_reg(10),
      I4 => \r4_red[3]_i_178_n_0\,
      O => \r4_red[3]_i_95_n_0\
    );
\r4_red[3]_i_96\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1111111111111114"
    )
        port map (
      I0 => r11_active_x_reg(7),
      I1 => r11_active_x_reg(6),
      I2 => r11_active_x_reg(5),
      I3 => r11_active_x_reg(4),
      I4 => r11_active_x_reg(3),
      I5 => r11_active_x_reg(2),
      O => \r4_red[3]_i_96_n_0\
    );
\r4_red[3]_i_97\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00800C0000800000"
    )
        port map (
      I0 => \r4_red[3]_i_179_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(2),
      I5 => \r4_red[3]_i_180_n_0\,
      O => \r4_red[3]_i_97_n_0\
    );
\r4_red[3]_i_98\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0C0080C000008000"
    )
        port map (
      I0 => \r4_red[3]_i_181_n_0\,
      I1 => r11_active_x_reg(5),
      I2 => r11_active_x_reg(4),
      I3 => r11_active_x_reg(3),
      I4 => r11_active_x_reg(2),
      I5 => \r4_red[3]_i_182_n_0\,
      O => \r4_red[3]_i_98_n_0\
    );
\r4_red[3]_i_99\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"07B0000000000000"
    )
        port map (
      I0 => \r4_red[3]_i_183_n_0\,
      I1 => \r4_red[3]_i_184_n_0\,
      I2 => \r4_red[3]_i_185_n_0\,
      I3 => \r4_red[3]_i_186_n_0\,
      I4 => r11_active_x_reg(2),
      I5 => \r4_red[3]_i_108_n_0\,
      O => \r4_red[3]_i_99_n_0\
    );
\r4_red_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => iw_pix_clk,
      CE => \r4_red[2]_i_2_n_0\,
      D => r4_red(0),
      Q => \r4_red_reg_n_0_[0]\,
      R => r4_blue(2)
    );
\r4_red_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => iw_pix_clk,
      CE => \r4_red[3]_i_2_n_0\,
      D => r4_red(1),
      Q => \r4_red_reg_n_0_[1]\,
      R => r4_blue(3)
    );
\r4_red_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => iw_pix_clk,
      CE => \r4_red[2]_i_2_n_0\,
      D => r4_red(2),
      Q => \r4_red_reg_n_0_[2]\,
      R => r4_blue(2)
    );
\r4_red_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => iw_pix_clk,
      CE => \r4_red[3]_i_2_n_0\,
      D => r4_red(3),
      Q => \r4_red_reg_n_0_[3]\,
      R => r4_blue(3)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity Uvod2_svga_0_0 is
  port (
    iw_pix_clk : in STD_LOGIC;
    iw4_red : in STD_LOGIC_VECTOR ( 3 downto 0 );
    iw4_green : in STD_LOGIC_VECTOR ( 3 downto 0 );
    iw4_blue : in STD_LOGIC_VECTOR ( 3 downto 0 );
    iw2_State : in STD_LOGIC_VECTOR ( 1 downto 0 );
    iw4_result_left : in STD_LOGIC_VECTOR ( 3 downto 0 );
    iw4_result_right : in STD_LOGIC_VECTOR ( 3 downto 0 );
    iw11_x_pos : in STD_LOGIC_VECTOR ( 10 downto 0 );
    iw11_y_pos : in STD_LOGIC_VECTOR ( 10 downto 0 );
    iw11_block_left_pos : in STD_LOGIC_VECTOR ( 10 downto 0 );
    iw11_block_right_pos : in STD_LOGIC_VECTOR ( 10 downto 0 );
    ow4_red : out STD_LOGIC_VECTOR ( 3 downto 0 );
    ow4_green : out STD_LOGIC_VECTOR ( 3 downto 0 );
    ow4_blue : out STD_LOGIC_VECTOR ( 3 downto 0 );
    ow_hsync : out STD_LOGIC;
    ow_vsync : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of Uvod2_svga_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of Uvod2_svga_0_0 : entity is "Uvod2_svga_0_0,svga,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of Uvod2_svga_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of Uvod2_svga_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of Uvod2_svga_0_0 : entity is "svga,Vivado 2025.1";
end Uvod2_svga_0_0;

architecture STRUCTURE of Uvod2_svga_0_0 is
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of iw_pix_clk : signal is "xilinx.com:signal:clock:1.0 iw_pix_clk CLK";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of iw_pix_clk : signal is "slave";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of iw_pix_clk : signal is "XIL_INTERFACENAME iw_pix_clk, FREQ_HZ 40000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0";
begin
inst: entity work.Uvod2_svga_0_0_svga
     port map (
      iw11_block_left_pos(10 downto 0) => iw11_block_left_pos(10 downto 0),
      iw11_block_right_pos(10 downto 0) => iw11_block_right_pos(10 downto 0),
      iw11_x_pos(10 downto 0) => iw11_x_pos(10 downto 0),
      iw11_y_pos(10 downto 0) => iw11_y_pos(10 downto 0),
      iw2_State(1 downto 0) => iw2_State(1 downto 0),
      iw4_blue(3 downto 0) => iw4_blue(3 downto 0),
      iw4_green(3 downto 0) => iw4_green(3 downto 0),
      iw4_red(3 downto 0) => iw4_red(3 downto 0),
      iw4_result_left(3 downto 0) => iw4_result_left(3 downto 0),
      iw4_result_right(3 downto 0) => iw4_result_right(3 downto 0),
      iw_pix_clk => iw_pix_clk,
      ow4_blue(3 downto 0) => ow4_blue(3 downto 0),
      ow4_green(3 downto 0) => ow4_green(3 downto 0),
      ow4_red(3 downto 0) => ow4_red(3 downto 0),
      ow_hsync => ow_hsync,
      ow_vsync => ow_vsync
    );
end STRUCTURE;
