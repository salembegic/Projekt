# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "G_CLK_DIV" -parent ${Page_0}
  ipgui::add_param $IPINST -name "G_DEBOUNCE_COUNTER_SIZE" -parent ${Page_0}
  ipgui::add_param $IPINST -name "G_ROW" -parent ${Page_0}


}

proc update_PARAM_VALUE.G_CLK_DIV { PARAM_VALUE.G_CLK_DIV } {
	# Procedure called to update G_CLK_DIV when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.G_CLK_DIV { PARAM_VALUE.G_CLK_DIV } {
	# Procedure called to validate G_CLK_DIV
	return true
}

proc update_PARAM_VALUE.G_DEBOUNCE_COUNTER_SIZE { PARAM_VALUE.G_DEBOUNCE_COUNTER_SIZE } {
	# Procedure called to update G_DEBOUNCE_COUNTER_SIZE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.G_DEBOUNCE_COUNTER_SIZE { PARAM_VALUE.G_DEBOUNCE_COUNTER_SIZE } {
	# Procedure called to validate G_DEBOUNCE_COUNTER_SIZE
	return true
}

proc update_PARAM_VALUE.G_ROW { PARAM_VALUE.G_ROW } {
	# Procedure called to update G_ROW when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.G_ROW { PARAM_VALUE.G_ROW } {
	# Procedure called to validate G_ROW
	return true
}


proc update_MODELPARAM_VALUE.G_ROW { MODELPARAM_VALUE.G_ROW PARAM_VALUE.G_ROW } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.G_ROW}] ${MODELPARAM_VALUE.G_ROW}
}

proc update_MODELPARAM_VALUE.G_CLK_DIV { MODELPARAM_VALUE.G_CLK_DIV PARAM_VALUE.G_CLK_DIV } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.G_CLK_DIV}] ${MODELPARAM_VALUE.G_CLK_DIV}
}

proc update_MODELPARAM_VALUE.G_DEBOUNCE_COUNTER_SIZE { MODELPARAM_VALUE.G_DEBOUNCE_COUNTER_SIZE PARAM_VALUE.G_DEBOUNCE_COUNTER_SIZE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.G_DEBOUNCE_COUNTER_SIZE}] ${MODELPARAM_VALUE.G_DEBOUNCE_COUNTER_SIZE}
}

